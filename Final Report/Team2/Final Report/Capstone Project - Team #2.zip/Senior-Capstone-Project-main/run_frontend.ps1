# Install powershell extension for VS Code for better experience.

# Bypass execution policy for this script
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

Write-Host ""
Write-Host "------------------ Starting frontend ------------------" -ForegroundColor DarkMagenta
Write-Host ""
Set-Location "$PSScriptRoot\frontend"
Write-Host "Current directory: $PWD" -ForegroundColor DarkYellow

# Install Node dependencies
npm install
Write-Host ""
Write-Host "Node dependencies installed." -ForegroundColor Cyan
Write-Host ""
Write-Host "Ctrl+C in vs code terminal to stop the frontend server." -ForegroundColor Cyan
Write-Host ""

Write-Host "-------------------------------------------------------------" -ForegroundColor DarkMagenta
# Start frontend server
npm run dev