import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import LandingPage from "./pages/LandingPage";

/*Client*/
import ClientSignUp from "./pages/client_pages/ClientSignUp";
import ClientSubscription from "./pages/client_pages/ClientSubscription";
import ClientShiftPostingForm from "./pages/client_pages/ClientShiftPostingForm";
import ClientStaffPreference from "./pages/client_pages/ClientStaffPreference";
import ClientDashboard from "./pages/client_pages/ClientDashboard";
import ClientProfile from "./pages/client_pages/ClientProfile";
import Client_Marketplace from "./pages/client_pages/Client_Marketplace";
/* Client Onboarding */
import ClientOnboardingWelcome from "./pages/client_pages/onboarding/ClientOnboardingWelcome";
import ClientOnboardingProfile from "./pages/client_pages/onboarding/ClientOnboardingProfile";
import ClientOnboardingComplete from "./pages/client_pages/onboarding/ClientOnboardingComplete";

/*Staff*/
import StaffSignUp from "./pages/staff_pages/StaffSignUp";
import StaffDashboard from "./pages/staff_pages/StaffDashboard";
import StaffProfile from "./pages/staff_pages/StaffProfile";
import StaffMarketplace from "./pages/staff_pages/StaffMarketplace";
/* Staff Onboarding */
import StaffOnboardingWelcome from "./pages/staff_pages/onboarding/StaffOnboardingWelcome";
import StaffOnboardingProfile from "./pages/staff_pages/onboarding/StaffOnboardingProfile";
import StaffOnboardingComplete from "./pages/staff_pages/onboarding/StaffOnboardingComplete";

/*Admin*/
import AdminDashboard from "./pages/admin_pages/AdminDashboard";
import AdminAccounts from "./pages/admin_pages/AdminAccounts";
import AdminFeedback from "./pages/admin_pages/AdminFeedback";
import AdminMaintenance from "./pages/admin_pages/AdminMaintenance";

/* Login */
import Login from "./pages/Login";
/* Password Reset */
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
/* Info Pages */
import AboutPage from "./pages/About";
import FAQPage from "./pages/FAQ";
import ContactPage from "./pages/contact";
import VerifyEmail from "./pages/VerifyEmail";
import Footer from "./components/Footer";
import TwoFactor from "./pages/TwoFactor";
import TwoFactorSettings from "./pages/TwoFactorSettings";
import TwoFactorMethodSelection from "./pages/TwoFactorMethodSelection";
import { getUserData } from "./utils/auth";


// Component that redirects based on authentication status
const RootRedirect = () => {
  const userData = getUserData();

  // Check if token exists but might be invalid/expired
  const token = localStorage.getItem("access_token");
  if (token && !userData) {
    // Token exists but couldn't be decoded - clear it
    localStorage.removeItem("access_token");
    return <LandingPage />;
  }

  if (!userData) {
    //   Not logged in - show landing page
    return <LandingPage />;
  }

  //Logged in - redirect based on role and onboarding status
  if (userData.role === 2) {
    // Staff- check if onboarding is complete
    if (!userData.profile_complete) {
      // redirect to appropriate onboarding step
      const step = userData.onboarding_step || 0;

      if (step === 0) {
        return <Navigate to="/staff/onboarding/welcome" replace />;
      } else if (step === 1) {
        return <Navigate to="/staff/onboarding/profile" replace />;
      } else if (step === 2) {
        return <Navigate to="/staff/onboarding/complete" replace />;
      }

      // fallback to welcome if step is unclear
      return <Navigate to="/staff/onboarding/welcome" replace />;
    }
    return <Navigate to="/staff/dashboard" replace />;
  } else if (userData.role === 1) {
    // client flow
    console.log("client user data:", userData); // debug: check what token contains

    // check if profile is complete first
    if (!userData.profile_complete) {
      // redirect to appropriate onboarding step
      const step = userData.onboarding_step || 0;

      if (step === 0) {
        return <Navigate to="/client/onboarding/welcome" replace />;
      } else if (step === 1) {
        return <Navigate to="/client/onboarding/profile" replace />;
      } else if (step === 2) {
        return <Navigate to="/client/onboarding/complete" replace />;
      }

      // fallback to welcome if step is unclear
      return <Navigate to="/client/onboarding/welcome" replace />;
    }

    // profile is complete - now check subscription (we don't touch this)
    if (userData.status === "pending") {
      return <Navigate to="/client/subscription" replace />;
    } else {
      return <Navigate to="/client/post-shift" replace />;
    }
  } else if (userData.role === 0) {
    // Admin - show landing page for now
    return <LandingPage />;
  }

  return <LandingPage />;
};

export default function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          {/* Landing Page - redirects based on auth status */}
          <Route path="/" element={<RootRedirect />} />

          {/* Login Page */}
          <Route path="/login" element={<Login />} />

          {/* Info Pages */}
          <Route path="/about" element={<AboutPage />} />
          <Route path="/faq" element={<FAQPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/verify-email" element={<VerifyEmail />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/reset-password" element={<ResetPassword />} />
          <Route path="/two-factor-method" element={<TwoFactorMethodSelection />} />
          <Route path="/two-factor" element={<TwoFactor />} />
          <Route path="/two-factor-settings" element={<TwoFactorSettings />} />

          {/*---Client Pages---*/}
          {/* Client Sign-up*/}
          <Route path="/client/signup" element={<ClientSignUp />} />

          {/* Client Onboarding */}
          <Route path="/client/onboarding/welcome" element={<ClientOnboardingWelcome />} />
          <Route path="/client/onboarding/profile" element={<ClientOnboardingProfile />} />
          <Route path="/client/onboarding/complete" element={<ClientOnboardingComplete />} />

          {/* Client Dashboard */}
          <Route path="/client/dashboard" element={<ClientDashboard />} />

          {/* Client Profile */}
          <Route path="/client/profile" element={<ClientProfile />} />

          {/* Client Subscription*/}
          <Route path="/client/subscription" element={<ClientSubscription />} />

          {/* Client Post Shift */}
          <Route path="/client/post-shift" element={<ClientShiftPostingForm />} />

          {/* Client Staff Preferences */}
          <Route path="/client/staff-preferences" element={<ClientStaffPreference />} />
          
          {/* Client Marketplace */}
          <Route path="/client/marketplace" element={<Client_Marketplace />} />
          
          {/*---Staff Pages---*/}
          {/* Staff Sign-up*/}
          <Route path="/staff/signup" element={<StaffSignUp />} />

          {/* Staff Onboarding */}
          <Route path="/staff/onboarding/welcome" element={<StaffOnboardingWelcome />} />
          <Route path="/staff/onboarding/profile" element={<StaffOnboardingProfile />} />
          <Route path="/staff/onboarding/complete" element={<StaffOnboardingComplete />} />

          {/*Dashboard*/}
          <Route path="/staff/dashboard" element={<StaffDashboard />} />

          {/*Marketplace*/}
          <Route path="/staff/marketplace" element={<StaffMarketplace />} />

          {/*Profile Page*/}
          <Route path="/staff/profile" element={<StaffProfile />} />

          {/*---Admin Pages---*/}
          {/*---Admin Dashbboard---*/}
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route path="/admin/accounts" element={<AdminAccounts />} />
          <Route path="/admin/feedback" element={<AdminFeedback />} />
          <Route path="/admin/maintenance" element={<AdminMaintenance />} />


        {/* Fallback */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
    </>
  );
}
