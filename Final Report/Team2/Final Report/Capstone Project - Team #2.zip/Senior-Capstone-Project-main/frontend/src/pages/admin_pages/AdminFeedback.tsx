import { MessageSquare, Trash2 } from "lucide-react";
import PageLayout from "../../layouts/PageLayout";
import { useEffect, useState } from "react";
import {
    getAllFeedback,
    deleteFeedback,
    respondToFeedback,
} from "../admin_api";

function AdminFeedback() {
    const adminMenu = [
        { path: "/admin/dashboard", label: "Dashboard" },
        { path: "/admin/accounts", label: "Accounts" },
        { path: "/admin/feedback", label: "Feedback" },
        { path: "/admin/maintenance", label: "Maintenance" },
    ];

    const [feedback, setFeedback] = useState([]);
    const [isMsgModalOpen, setIsMsgModalOpen] = useState(false);
    const [currentFB, setCurrentFB] = useState(null);
    const [responseText, setResponseText] = useState("");
    const [status, setStatus] = useState("unread");

    useEffect(() => {
        getAllFeedback().then(setFeedback);
    }, []);

    const openMsgModal = (fb) => {
        setCurrentFB(fb);
        setResponseText(fb.admin_response || "");
        setStatus(fb.status || "unread");
        setIsMsgModalOpen(true);
    };

    const submitResponse = async () => {
        if (!currentFB) return;

        await respondToFeedback(currentFB.id, responseText, status);

        setFeedback((prev) =>
            prev.map((item) =>
                item.id === currentFB.id
                    ? { ...item, admin_response: responseText, status }
                    : item
            )
        );

        setIsMsgModalOpen(false);
    };

    return (
        <PageLayout navbarConfig={{ menuItems: adminMenu }}>
            <div className="min-h-screen px-6 py-20 max-w-5xl mx-auto">
                <div className="flex items-center gap-4 mb-5">
                    <MessageSquare className="text-amber-400 w-10 h-10" />
                    <h1 className="text-white text-4xl font-bold">User Feedback</h1>
                </div>
                <p className="text-white/70 mb-10">
                    View user feedback and set the status of the response.
                </p>
                <div className="space-y-6">
                    {feedback.map((fb) => (
                        <div
                            key={fb.id}
                            className="bg-slate-900/70 p-6 rounded-2xl border border-slate-700/50"
                        >
                            <div className="flex justify-between items-center mb-1">
                                <span className="text-white/90 font-bold text-base">
                                    {fb.email}
                                </span>
                                <div className="flex gap-4">
                                    <button
                                        className="text-teal-400 hover:text-teal-300"
                                        onClick={() => openMsgModal(fb)}
                                    >
                                        Respond
                                    </button>
                                    <button
                                        onClick={() => {
                                            deleteFeedback(fb.id).then(() => {
                                                setFeedback((prev) =>
                                                    prev.filter((item) => item.id !== fb.id)
                                                );
                                            });
                                        }}
                                        className="flex items-center gap-2 text-red-400 hover:text-red-300"
                                    >
                                        <Trash2 className="w-4 h-4" /> Delete
                                    </button>
                                </div>
                            </div>
                            <p className="text-white/50 text-sm">
                                Posted on {fb.date_posted} at {fb.time_posted}
                            </p>
                            <p className="text-white/80 mt-3 text-base">{fb.message}</p>
                            {fb.admin_response && (
                                <p className="text-teal-300 mt-3 text-sm">
                                    <strong>Admin Response:</strong> {fb.admin_response}
                                </p>
                            )}
                            {fb.status && (
                                <p className="text-indigo-300 text-sm mt-1">
                                    <strong>Status:</strong> {fb.status}
                                </p>
                            )}
                        </div>
                    ))}
                </div>
            </div>
            {isMsgModalOpen && (
                <div className="fixed inset-0 bg-black/60 flex justify-center items-center">
                    <div className="bg-slate-800 p-6 rounded-xl max-w-md w-full border border-slate-600">
                        <h2 className="text-xl text-white font-bold mb-3">
                            Respond to {currentFB?.email}
                        </h2>
                        <textarea
                            className="w-full p-2 rounded bg-slate-700 text-white"
                            rows={4}
                            value={responseText}
                            onChange={(e) => setResponseText(e.target.value)}
                        />
                        <label className="text-white mt-4 block">Status</label>
                        <select
                            className="w-full p-2 rounded bg-slate-700 text-white mt-1"
                            value={status}
                            onChange={(e) => setStatus(e.target.value)}
                        >
                            <option value="unread">Unread</option>
                            <option value="read">Read</option>
                            <option value="in_progress">In Progress</option>
                            <option value="resolved">Resolved</option>
                        </select>
                        <div className="flex justify-end gap-2 mt-5">
                            <button
                                className="px-4 py-2 bg-gray-500 text-white rounded"
                                onClick={() => setIsMsgModalOpen(false)}
                            >
                                Cancel
                            </button>
                            <button
                                className="px-4 py-2 bg-teal-500 hover:bg-teal-400 text-white rounded"
                                onClick={submitResponse}
                            >
                                Save
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </PageLayout>
    );
}

export default AdminFeedback;
