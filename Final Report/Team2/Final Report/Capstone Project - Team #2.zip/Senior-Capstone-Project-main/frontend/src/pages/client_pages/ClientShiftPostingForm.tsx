import { useState } from 'react';
import { postShift } from '../../api';
import ClientSidebar from '../../components/ClientSidebar';

type ShiftFormState = {
  restaurant_name: string;
  position: string;
  location: string;
  date: string; // yyyy-mm-dd from input[type=date]
  start_time: string; // HH:mm
  end_time: string; // HH:mm
  hourly_rate: string; // keep as string for controlled input
  description: string;
  confirm_password: string;
};

export default function ClientShiftPostingForm() {
  const [form, setForm] = useState<ShiftFormState>({
    restaurant_name: '',
    position: '',
    location: '',
    date: '',
    start_time: '',
    end_time: '',
    hourly_rate: '',
    description: '',
    confirm_password: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  function handleChange(
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      // Prepare payload matching backend expectations
      // Convert hourly_rate to number, exclude confirm_password from submission
      const { confirm_password, hourly_rate, ...restForm } = form;
      const payload = {
        ...restForm,
        hourly_rate: parseFloat(hourly_rate) || 0,
      };
      
      const result = await postShift(payload);
      console.log('Shift posted successfully:', result);
      alert('Shift posted successfully!');
      
      // Reset form after successful submission
      setForm({
        restaurant_name: '',
        position: '',
        location: '',
        date: '',
        start_time: '',
        end_time: '',
        hourly_rate: '',
        description: '',
        confirm_password: '',
      });
    } catch (error: any) {
      console.error('Error posting shift:', error);
      const detail = error?.response?.data?.detail || error?.message || 'Error posting shift';
      alert(detail);
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen w-screen overflow-x-hidden bg-gradient-to-br from-slate-800 via-slate-700 to-teal-600">
      <div className="min-h-screen w-full flex relative">
        <ClientSidebar />
        <main className="flex-1 overflow-auto w-full">
          <div className="max-w-6xl mx-auto px-4 pt-20 sm:px-6 lg:px-8">
          <div className="bg-slate-300/30 backdrop-blur-sm rounded-xl p-8 shadow-md">
            <h1 className="text-3xl font-bold text-white mb-2">Post a New Shift</h1>
            <p className="text-white/80 mb-6">Fill out the form below to post a new shift for staff members.</p>
            <hr className="border-white/20 mb-8" />

            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Shift Details */}
              <section>
                <h2 className="text-xl font-semibold text-white mb-4">Shift Details</h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-white/90 mb-2">Restaurant Name</label>
                    <input
                      className="w-full px-4 py-3 rounded-lg bg-white/90 placeholder-slate-400 text-slate-900 border border-white/40 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:bg-white transition shadow-sm"
                      name="restaurant_name"
                      value={form.restaurant_name}
                      onChange={handleChange}
                      placeholder="Enter restaurant name"
                      type="text"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-white/90 mb-2">Position</label>
                    <input
                      className="w-full px-4 py-3 rounded-lg bg-white/90 placeholder-slate-400 text-slate-900 border border-white/40 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:bg-white transition shadow-sm"
                      name="position"
                      value={form.position}
                      onChange={handleChange}
                      placeholder="e.g., Server, Bartender, Host"
                      type="text"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-white/90 mb-2">Location</label>
                    <input
                      className="w-full px-4 py-3 rounded-lg bg-white/90 placeholder-slate-400 text-slate-900 border border-white/40 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:bg-white transition shadow-sm"
                      name="location"
                      value={form.location}
                      onChange={handleChange}
                      placeholder="Enter location"
                      type="text"
                      required
                    />
                  </div>
                </div>
              </section>

              <hr className="border-white/20" />

              {/* Schedule */}
              <section>
                <h2 className="text-xl font-semibold text-white mb-4">Schedule</h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-white/90 mb-2">Date</label>
                    <input
                      className="w-full px-4 py-3 rounded-lg bg-white/90 placeholder-slate-400 text-slate-900 border border-white/40 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:bg-white transition shadow-sm"
                      name="date"
                      value={form.date}
                      onChange={handleChange}
                      type="date"
                      required
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-white/90 mb-2">Start Time</label>
                      <input
                        className="w-full px-4 py-3 rounded-lg bg-white/90 placeholder-slate-400 text-slate-900 border border-white/40 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:bg-white transition shadow-sm"
                        name="start_time"
                        value={form.start_time}
                        onChange={handleChange}
                        type="time"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-white/90 mb-2">End Time</label>
                      <input
                        className="w-full px-4 py-3 rounded-lg bg-white/90 placeholder-slate-400 text-slate-900 border border-white/40 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:bg-white transition shadow-sm"
                        name="end_time"
                        value={form.end_time}
                        onChange={handleChange}
                        type="time"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-white/90 mb-2">Hourly Rate ($)</label>
                    <input
                      className="w-full px-4 py-3 rounded-lg bg-white/90 placeholder-slate-400 text-slate-900 border border-white/40 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:bg-white transition shadow-sm"
                      name="hourly_rate"
                      value={form.hourly_rate}
                      onChange={handleChange}
                      placeholder="0.00"
                      type="number"
                      min="0"
                      step="0.01"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-white/90 mb-2">Shift Description</label>
                    <textarea
                      className="w-full px-4 py-3 rounded-lg bg-white/90 placeholder-slate-400 text-slate-900 border border-white/40 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:bg-white transition shadow-sm"
                      name="description"
                      value={form.description}
                      onChange={handleChange}
                      placeholder="Provide details about the shift, responsibilities, and requirements"
                      rows={4}
                    />
                  </div>
                </div>
              </section>

              <hr className="border-white/20" />

              {/* Requirements */}
              <section>
                <h2 className="text-xl font-semibold text-white mb-4">Verification</h2>
                <div>
                  <label className="block text-sm font-medium text-white/90 mb-2">Confirm Password</label>
                  <input
                    className="w-full px-4 py-3 rounded-lg bg-white/90 placeholder-slate-400 text-slate-900 border border-white/40 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:bg-white transition shadow-sm"
                    name="confirm_password"
                    value={form.confirm_password}
                    onChange={handleChange}
                    placeholder="Enter your password to confirm"
                    type="password"
                    required
                  />
                </div>
              </section>

              <div className="pt-4">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-semibold transition-all shadow-lg hover:shadow-xl disabled:opacity-60 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? 'Posting Shift...' : 'Post Shift'}
                </button>
              </div>
            </form>
          </div>
          </div>
        </main>
      </div>
    </div>
  );
}


