import { useState, useEffect } from 'react';
import { Sparkles, Briefcase } from 'lucide-react';
import PageLayout from '../../layouts/PageLayout';
import ShiftCard from '../../components/ShiftCard';
import { getAvailableShifts } from '../../api';

interface Shift {
  id: number;
  restaurantName: string;
  restaurantType: string;
  role: string;
  date: string;
  startTime: string;
  endTime: string;
  payRate: string;
  location: string;
  description?: string;
}

export default function StaffMarketplace() {
  const staffMenu = [
    { path: "/staff/dashboard", label: "Dashboard" },
    { path: "/staff/marketplace", label: "Marketplace" },
    { path: "/staff/profile", label: "My Profile" },
  ];

  const [shifts, setShifts] = useState<Shift[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filterRole, setFilterRole] = useState<string>('all');

  useEffect(() => {
    const fetchShifts = async () => {
      try {
        setLoading(true);
        const data = await getAvailableShifts();
        setShifts(data);
      } catch (err: any) {
        console.error('Error fetching available shifts:', err);
        setError(err?.response?.data?.detail || 'Failed to load available shifts');
        // Mock data for development
        setShifts([
          {
            id: 1,
            restaurantName: 'The Golden Fork',
            restaurantType: 'Fine Dining',
            role: 'Server',
            date: 'December 15, 2025',
            startTime: '5:00 PM',
            endTime: '11:00 PM',
            payRate: '$25/hour + tips',
            location: '123 Main St, Downtown',
            description: 'Upscale dining experience. Wine knowledge preferred.',
          },
          {
            id: 2,
            restaurantName: 'Sunrise Café',
            restaurantType: 'Café',
            role: 'Barista',
            date: 'December 16, 2025',
            startTime: '6:00 AM',
            endTime: '2:00 PM',
            payRate: '$18/hour',
            location: '456 Oak Ave, Midtown',
            description: 'Busy morning shift. Latte art skills a plus.',
          },
          {
            id: 3,
            restaurantName: 'Bella Italia',
            restaurantType: 'Italian Restaurant',
            role: 'Line Cook',
            date: 'December 17, 2025',
            startTime: '4:00 PM',
            endTime: '10:00 PM',
            payRate: '$22/hour',
            location: '789 Elm St, West End',
            description: 'Fast-paced kitchen. Italian cuisine experience required.',
          },
          {
            id: 4,
            restaurantName: 'Ocean View Grill',
            restaurantType: 'Seafood Restaurant',
            role: 'Bartender',
            date: 'December 18, 2025',
            startTime: '3:00 PM',
            endTime: '11:00 PM',
            payRate: '$20/hour + tips',
            location: '321 Beach Blvd, Waterfront',
            description: 'Mixology skills required. Liquor license mandatory.',
          },
          {
            id: 5,
            restaurantName: 'Spice Route',
            restaurantType: 'Asian Fusion',
            role: 'Host/Hostess',
            date: 'December 19, 2025',
            startTime: '5:30 PM',
            endTime: '10:30 PM',
            payRate: '$16/hour',
            location: '654 Pine St, Arts District',
            description: 'Friendly personality needed. Reservation management experience.',
          },
          {
            id: 6,
            restaurantName: 'The Breakfast Club',
            restaurantType: 'Brunch Spot',
            role: 'Server',
            date: 'December 20, 2025',
            startTime: '7:00 AM',
            endTime: '3:00 PM',
            payRate: '$17/hour + tips',
            location: '987 Maple Dr, Uptown',
            description: 'Weekend brunch shift. High volume, great tips.',
          },
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchShifts();
  }, []);

  const handleApplyForShift = (shiftId: number, restaurantName: string) => {
    // TODO: Implement shift application logic
    alert(`Applying for shift at ${restaurantName}. This feature will be implemented soon.`);
  };

  // Get unique roles for filter
  const roles = ['all', ...Array.from(new Set(shifts.map(shift => shift.role)))];
  
  // Filter shifts by role
  const filteredShifts = filterRole === 'all' 
    ? shifts 
    : shifts.filter(shift => shift.role === filterRole);

  return (
    <PageLayout 
      className="bg-gradient-to-br from-slate-900 via-slate-800 to-amber-900" 
      navbarConfig={{ menuItems: staffMenu }}
    >
      <div className="min-h-screen w-screen overflow-x-hidden px-4 pt-10 sm:px-6 lg:px-8 pb-20">
        <div className="max-w-7xl mx-auto">
          {/* Page Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-amber-500/20 backdrop-blur-sm border border-amber-400/30 rounded-full mb-6">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span className="text-amber-300 text-sm font-semibold">Find Your Next Shift</span>
            </div>
            
            <h1 className="text-white text-4xl md:text-5xl font-bold mb-4">
              Available Shifts
            </h1>
            
            <p className="text-slate-300 text-lg max-w-2xl mx-auto">
              Browse and apply for shifts that match your skills and availability
            </p>
          </div>

          {/* Filter Section */}
          <div className="mb-8 flex flex-wrap items-center justify-center gap-3">
            <div className="flex items-center gap-2 text-white font-semibold">
              <Briefcase className="w-5 h-5 text-amber-400" />
              <span>Filter by Role:</span>
            </div>
            {roles.map((role) => (
              <button
                key={role}
                onClick={() => setFilterRole(role)}
                className={[
                  "px-4 py-2 rounded-lg font-medium text-sm transition-all",
                  filterRole === role
                    ? "bg-gradient-to-r from-amber-500 to-amber-600 text-white shadow-lg shadow-amber-500/30"
                    : "bg-white/10 text-white/80 hover:bg-white/20 hover:text-white backdrop-blur-sm border border-white/10",
                ].join(" ")}
              >
                {role.charAt(0).toUpperCase() + role.slice(1)}
              </button>
            ))}
          </div>

          {/* Loading State */}
          {loading && (
            <div className="flex justify-center items-center py-20">
              <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-8">
                <p className="text-white text-lg">Loading available shifts...</p>
              </div>
            </div>
          )}

          {/* Error State */}
          {error && !loading && (
            <div className="max-w-2xl mx-auto bg-red-500/20 backdrop-blur-sm border border-red-500/50 rounded-2xl p-6 mb-6">
              <p className="text-red-200 text-center">{error}</p>
              <p className="text-red-300 text-sm text-center mt-2">Showing sample data for demonstration</p>
            </div>
          )}

          {/* Shift Cards Grid */}
          {!loading && filteredShifts.length > 0 && (
            <div className="flex flex-wrap justify-center gap-6 lg:gap-8">
              {filteredShifts.map((shift) => (
                <ShiftCard
                  key={shift.id}
                  id={shift.id}
                  restaurantName={shift.restaurantName}
                  restaurantType={shift.restaurantType}
                  role={shift.role}
                  date={shift.date}
                  startTime={shift.startTime}
                  endTime={shift.endTime}
                  payRate={shift.payRate}
                  location={shift.location}
                  description={shift.description}
                  onApply={() => handleApplyForShift(shift.id, shift.restaurantName)}
                />
              ))}
            </div>
          )}

          {/* Empty State */}
          {!loading && filteredShifts.length === 0 && (
            <div className="flex justify-center items-center py-20">
              <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-12 text-center">
                <Briefcase className="w-16 h-16 text-amber-400 mx-auto mb-4" />
                <p className="text-white text-xl font-semibold mb-2">No shifts available</p>
                <p className="text-slate-300">
                  {filterRole !== 'all' 
                    ? `No ${filterRole} positions available at the moment. Try a different role.`
                    : 'Check back soon for new opportunities!'}
                </p>
              </div>
            </div>
          )}

          {/* Stats Section */}
          {!loading && shifts.length > 0 && (
            <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 text-center">
                <p className="text-4xl font-bold text-amber-400 mb-2">{shifts.length}</p>
                <p className="text-slate-300">Available Shifts</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 text-center">
                <p className="text-4xl font-bold text-amber-400 mb-2">{roles.length - 1}</p>
                <p className="text-slate-300">Different Roles</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 text-center">
                <p className="text-4xl font-bold text-amber-400 mb-2">$16-25</p>
                <p className="text-slate-300">Hourly Rate Range</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </PageLayout>
  );
}
