import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, Mail, MessageCircle, RotateCw } from 'lucide-react';
import axios from 'axios';
import waiterImg from "../assets/img/waiter.jpg";
import PageLayoutNoNav from "../layouts/PageLayoutNoNav";


const TwoFactor: React.FC = () => {
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const [method, setMethod] = useState('email');
  const [phoneMasked, setPhoneMasked] = useState('');
  const [isResending, setIsResending] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);
  const navigate = useNavigate();

  const email = sessionStorage.getItem('pending_2fa_email');

  // Check for 2FA method and phone info from session storage or login response
  useEffect(() => {
    const storedMethod = sessionStorage.getItem('pending_2fa_method');
    const storedPhone = sessionStorage.getItem('pending_2fa_phone');

    if (storedMethod) {
      setMethod(storedMethod);
    }
    if (storedPhone) {
      setPhoneMasked(storedPhone);
    }
  }, []);

  // Cooldown timer for resend button
  useEffect(() => {
    if (resendCooldown > 0) {
      const timer = setTimeout(() => {
        setResendCooldown(resendCooldown - 1);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [resendCooldown]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      setError('Missing email for 2FA. Please login again.');
      return;
    }

    try {
      const response = await axios.post('http://localhost:8000/auth/verify-2fa', {
        email: email,
        code: code
      });

      if (response.data?.access_token) {
        localStorage.setItem('access_token', response.data.access_token);
        // Clean up session storage
        sessionStorage.removeItem('pending_2fa_email');
        sessionStorage.removeItem('pending_2fa_method');
        sessionStorage.removeItem('pending_2fa_phone');
        setMessage('2FA verified — signing you in...');
        setError('');

        // Redirect to home - let RootRedirect handle routing based on role, onboarding status, etc
        setTimeout(() => {
          navigate('/');
        }, 800);
      } else {
        setError('Unexpected response from server');
      }
    } catch (err: any) {
      setError(err?.response?.data?.detail || 'Failed to verify 2FA code');
    }
  };

  const handleResendCode = async () => {
    if (!email) {
      setError('Missing email for 2FA. Please login again.');
      return;
    }

    setIsResending(true);
    setError('');
    setMessage('');

    try {
      await axios.post('http://localhost:8000/auth/send-2fa-code', {
        email: email,
        method: method
      });

      setMessage(`New code sent to your ${method === 'email' ? 'email' : 'phone'}!`);
      setResendCooldown(60); // 60 second cooldown
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setMessage('');
      }, 3000);
    } catch (err: any) {
      setError(err?.response?.data?.detail || 'Failed to resend code');
    } finally {
      setIsResending(false);
    }
  };

  return (
    <PageLayoutNoNav>
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-6xl rounded-2xl shadow-2xl overflow-hidden bg-slate-900/60 backdrop-blur-sm text-white">
          <div className="flex flex-col lg:flex-row">
            <div className="lg:w-2/5 p-8 lg:p-10 text-white">
              <div className="mb-8">
                <p className="text-base text-green-500 mb-6">Two-Factor Authentication</p>
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-amber-500 rounded-full flex items-center justify-center">
                    <Shield className="w-7 h-7 text-white" />
                  </div>
                  <h1 className="text-3xl font-bold">Shift Solutions</h1>
                </div>
                <div className="flex items-center gap-2 mb-4">
                  {method === 'email' ? (
                    <Mail className="w-5 h-5 text-amber-500" />
                  ) : (
                    <MessageCircle className="w-5 h-5 text-amber-500" />
                  )}
                  <span className="text-sm text-amber-500 font-medium">
                    {method === 'email' ? 'Email Verification' : 'SMS Verification'}
                  </span>
                </div>
                <p className="text-base font-semibold mb-8">
                  Enter the 6-digit verification code we sent to your {method === 'email' ? 'email' : `phone ending in ${phoneMasked}`}.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {message && (
                  <div className="p-3 rounded-xl bg-green-500/20 border border-green-500/30 text-green-300 text-sm">
                    {message}
                  </div>
                )}

                {error && (
                  <div className="p-3 rounded-xl bg-red-500/20 border border-red-500/30 text-red-300 text-sm">
                    {error}
                  </div>
                )}

                <div>
                  <input
                    type="text"
                    name="code"
                    placeholder="Enter 6-digit code"
                    value={code}
                    maxLength={6}
                    required
                    onChange={(e) => setCode(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-amber-600 focus:bg-white/20 transition-all text-center font-mono text-lg tracking-widest"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white font-semibold rounded-xl transition-all duration-300 shadow-lg shadow-teal-500/30 hover:shadow-teal-500/50"
                >
                  Verify Code
                </button>

                {/* Resend code button */}
                <div className="text-center">
                  <button
                    type="button"
                    onClick={handleResendCode}
                    disabled={isResending || resendCooldown > 0}
                    className="inline-flex items-center gap-2 text-sm text-amber-400 hover:text-amber-300 disabled:text-slate-500 disabled:cursor-not-allowed transition-colors"
                  >
                    <RotateCw className={`w-4 h-4 ${isResending ? 'animate-spin' : ''}`} />
                    {isResending ? 'Sending...' : resendCooldown > 0 ? `Resend code in ${resendCooldown}s` : 'Resend code'}
                  </button>
                </div>

                <p className="text-center text-gray-300 text-sm">
                  Having trouble?{" "}
                  <button
                    type="button"
                    onClick={() => {
                      sessionStorage.removeItem('pending_2fa_email');
                      sessionStorage.removeItem('pending_2fa_method');
                      sessionStorage.removeItem('pending_2fa_phone');
                      navigate('/login');
                    }}
                    className="text-amber-500 font-semibold hover:underline bg-transparent border-none cursor-pointer"
                  >
                    Cancel and return to login
                  </button>
                </p>
              </form>
            </div>

            <div className="lg:w-4/5 relative">
              <div
                className="absolute inset-0 bg-cover bg-center"
                style={{ backgroundImage: `url(${waiterImg})` }}
              >
                <div className="absolute inset-0 bg-gray-500/70"></div>
              </div>

              <div className="relative z-10 p-8 lg:p-16 h-full flex flex-col justify-center min-h-[400px] lg:min-h-0">
                <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
                  Secure Your Account
                </h2>
                <p className="text-lg text-white/90 leading-relaxed">
                  We've sent a verification code to your {method === 'email' ? 'email address' : 'phone number'}. Enter the code to complete your secure login and access your account.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageLayoutNoNav>
  );
};

export default TwoFactor;
