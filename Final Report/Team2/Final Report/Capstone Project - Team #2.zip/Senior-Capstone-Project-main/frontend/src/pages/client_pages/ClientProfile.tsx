import { useEffect, useState } from "react";
import { User, Building2 } from "lucide-react";
import ClientSidebar from "../../components/ClientSidebar";
import ProfileImgSection from "../../components/ProfileImgSection";
import AccountSection from "../../components/AccountSection";
import PaymentSection from "../../components/PaymentSection";
import { getCurrentUser, getClientProfile, updateClientProfile } from "../../api";
import restaurantImg from "../../assets/img/restaurant.png";

export default function ClientProfile() {
  const [userId, setUserId] = useState<number | null>(null);
  const [clientData, setClientData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // Get current user ID and client profile on component mount
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const user = await getCurrentUser();
        setUserId(user.id);
        
        // Try to fetch client profile data
        try {
          const profile = await getClientProfile(user.id);
          setClientData({
            profile: {
              first_name: profile.name?.split(' ')[0] || user.email?.split('@')[0] || "Client",
              last_name: profile.name?.split(' ').slice(1).join(' ') || "",
              status: profile.status || user.status || "active",
              imgSrc: profile.profile_image ? `http://localhost:8000${profile.profile_image}` : restaurantImg,
            },
            business: {
              name: profile.name || "Not set",
              restaurant_type: profile.restaurant_type || "Not set",
              phone: profile.phone || "Not set",
              email: user.email || "Not set",
              website_url: profile.website_url || "Not set",
              address_line1: profile.address_line1 || "Not set",
              address_line2: profile.address_line2 || "",
              city: profile.city || "Not set",
              state: profile.state || "Not set",
              zipcode: profile.zipcode || "Not set",
            }
          });
        } catch (profileError) {
          // If profile endpoint doesn't exist yet, use basic user data
          console.log("Client profile endpoint not available, using basic user data");
          setClientData({
            profile: {
              first_name: user.email?.split('@')[0] || "Client",
              last_name: "",
              status: user.status || "active",
              imgSrc: restaurantImg,
            },
            business: {
              name: user.email?.split('@')[0] || "Not set",
              restaurant_type: "Not set",
              phone: "Not set",
              email: user.email || "Not set",
              website_url: "Not set",
              address_line1: "Not set",
              address_line2: "",
              city: "Not set",
              state: "Not set",
              zipcode: "Not set",
            }
          });
        }
      } catch (error) {
        console.error("Failed to get user data:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchUserData();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen w-screen overflow-x-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-teal-900">
        <div className="min-h-screen w-full flex relative">
          <ClientSidebar />
          <main className="flex-1 overflow-auto w-full flex items-center justify-center">
            <p className="text-white text-lg">Loading profile...</p>
          </main>
        </div>
      </div>
    );
  }

  if (!userId || !clientData) {
    return (
      <div className="min-h-screen w-screen overflow-x-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-teal-900">
        <div className="min-h-screen w-full flex relative">
          <ClientSidebar />
          <main className="flex-1 overflow-auto w-full">
            <div className="max-w-7xl mx-auto px-4 pt-20 sm:px-6 lg:px-8">
              <p className="text-red-300">Failed to load user profile. Please log in again.</p>
            </div>
          </main>
        </div>
      </div>
    );
  }

  const handleImageUpdate = (newImageUrl: string) => {
    setClientData({
      ...clientData,
      profile: {
        ...clientData.profile,
        imgSrc: newImageUrl
      }
    });
  };

  return (
    <div className="min-h-screen w-screen overflow-x-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-teal-900">
      <div className="min-h-screen w-full flex relative">
        <ClientSidebar />
        <main className="flex-1 overflow-auto w-full">
          <div className="max-w-7xl mx-auto px-6 sm:px-8 pt-20 pb-20">
            {/* Header */}
            <div className="mb-8">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-teal-500/20 backdrop-blur-sm border border-teal-400/30 rounded-full mb-4">
                <User className="w-4 h-4 text-teal-400" />
                <span className="text-teal-300 text-sm font-semibold">Business Profile</span>
              </div>
              <h1 className="text-4xl font-bold text-white mb-2">Profile Settings</h1>
              <p className="text-slate-300 text-lg">Manage your business information and account settings</p>
            </div>

            {/* Profile Image and Business Info Section */}
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 mb-6">
              <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
                <Building2 className="w-6 h-6 text-teal-400" />
                Business Information
              </h2>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <ProfileImgSection profile={clientData.profile} userId={userId} onImageUpdate={handleImageUpdate} />
                <div className="lg:col-span-2">
                  <BusinessInfoSection business={clientData.business} userId={userId} />
                </div>
              </div>
            </div>

            {/* Payment Section */}
            <div className="mb-6">
              <PaymentSection />
            </div>

            {/* Account Section */}
            <div className="mb-6">
              <AccountSection />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

// Business Information Section Component
interface BusinessInfoSectionProps {
  business: {
    name: string;
    restaurant_type: string;
    phone: string;
    email: string;
    website_url: string;
    address_line1: string;
    address_line2: string;
    city: string;
    state: string;
    zipcode: string;
  };
  userId: number;
}

function BusinessInfoSection({ business, userId }: BusinessInfoSectionProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [businessData, setBusinessData] = useState({
    name: business?.name || "",
    restaurant_type: business?.restaurant_type || "",
    phone: business?.phone || "",
    website_url: business?.website_url || "",
    address_line1: business?.address_line1 || "",
    address_line2: business?.address_line2 || "",
    city: business?.city || "",
    state: business?.state || "",
    zipcode: business?.zipcode || "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setBusinessData({
      ...businessData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateClientProfile(userId, businessData);
      setIsEditing(false);
      alert("Profile updated successfully!");
    } catch (error: any) {
      alert(error.response?.data?.detail || "Failed to update profile");
    }
  };

  return (
    <div className="bg-white/5 border border-white/10 rounded-xl p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-semibold text-white">Details</h3>
        <button
          type="button"
          onClick={() => setIsEditing(!isEditing)}
          className="px-4 py-2 bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white font-semibold rounded-xl transition-all shadow-lg shadow-teal-500/30"
        >
          {isEditing ? "Cancel" : "Edit"}
        </button>
      </div>

      {!isEditing ? (
        <dl className="text-sm text-slate-300 space-y-3">
          <div className="flex flex-col gap-1">
            <dt className="font-semibold text-white/90">Business Name</dt>
            <dd className="text-slate-300">{business.name}</dd>
          </div>
          <div className="flex flex-col gap-1">
            <dt className="font-semibold text-white/90">Restaurant Type</dt>
            <dd className="text-slate-300">{business.restaurant_type}</dd>
          </div>
          <div className="flex flex-col gap-1">
            <dt className="font-semibold text-white/90">Email</dt>
            <dd className="text-slate-300">{business.email}</dd>
          </div>
          <div className="flex flex-col gap-1">
            <dt className="font-semibold text-white/90">Phone</dt>
            <dd className="text-slate-300">{business.phone}</dd>
          </div>
          <div className="flex flex-col gap-1">
            <dt className="font-semibold text-white/90">Website</dt>
            <dd className="text-slate-300">{business.website_url || "Not set"}</dd>
          </div>
          <div className="flex flex-col gap-1">
            <dt className="font-semibold text-white/90">Address</dt>
            <dd className="text-slate-300">
              {business.address_line1}
              {business.address_line2 && `, ${business.address_line2}`}
              <br />
              {business.city}, {business.state} {business.zipcode}
            </dd>
          </div>
        </dl>
      ) : (
        <div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-white mb-2">Business Name</label>
            <input
              type="text"
              name="name"
              value={businessData.name}
              onChange={handleChange}
              className="w-full px-4 py-2 rounded-xl bg-white/10 text-white border border-white/20 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent placeholder-slate-400"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-white mb-2">Restaurant Type</label>
            <input
              type="text"
              name="restaurant_type"
              value={businessData.restaurant_type}
              onChange={handleChange}
              className="w-full px-4 py-2 rounded-xl bg-white/10 text-white border border-white/20 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent placeholder-slate-400"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-white mb-2">Phone</label>
            <input
              type="tel"
              name="phone"
              value={businessData.phone}
              onChange={handleChange}
              className="w-full px-4 py-2 rounded-xl bg-white/10 text-white border border-white/20 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent placeholder-slate-400"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-white mb-2">Website URL</label>
            <input
              type="url"
              name="website_url"
              value={businessData.website_url}
              onChange={handleChange}
              className="w-full px-4 py-2 rounded-xl bg-white/10 text-white border border-white/20 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent placeholder-slate-400"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-white mb-2">Address Line 1</label>
            <input
              type="text"
              name="address_line1"
              value={businessData.address_line1}
              onChange={handleChange}
              className="w-full px-4 py-2 rounded-xl bg-white/10 text-white border border-white/20 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent placeholder-slate-400"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-white mb-2">Address Line 2</label>
            <input
              type="text"
              name="address_line2"
              value={businessData.address_line2}
              onChange={handleChange}
              className="w-full px-4 py-2 rounded-xl bg-white/10 text-white border border-white/20 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent placeholder-slate-400"
            />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-sm font-medium text-white mb-2">City</label>
              <input
                type="text"
                name="city"
                value={businessData.city}
                onChange={handleChange}
                className="w-full px-4 py-2 rounded-xl bg-white/10 text-white border border-white/20 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent placeholder-slate-400"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-white mb-2">State</label>
              <input
                type="text"
                name="state"
                value={businessData.state}
                onChange={handleChange}
                className="w-full px-4 py-2 rounded-xl bg-white/10 text-white border border-white/20 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent placeholder-slate-400"
                maxLength={2}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-white mb-2">Zipcode</label>
              <input
                type="text"
                name="zipcode"
                value={businessData.zipcode}
                onChange={handleChange}
                className="w-full px-4 py-2 rounded-xl bg-white/10 text-white border border-white/20 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent placeholder-slate-400"
                required
              />
            </div>
          </div>
          <button
            type="submit"
            className="w-full py-3 px-4 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700 text-white font-bold rounded-xl transition-all shadow-lg shadow-emerald-500/30"
          >
            Save Changes
          </button>
        </form>
        </div>
      )}
    </div>
  );
}

