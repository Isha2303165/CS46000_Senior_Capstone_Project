import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { HandPlatter } from 'lucide-react';
import PageLayoutNoNav from '../layouts/PageLayoutNoNav';
import axios from 'axios';
import waiterImg from "../assets/img/waiter.jpg";

const ForgotPassword: React.FC = () => {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8000/auth/forgot-password', {
        email: email
      });
      setMessage('If your email exists in our system, you will receive a password reset link.');
      setError('');
    } catch (err) {
      setError('An error occurred. Please try again later.');
      setMessage('');
    }
  };

  return (
    <PageLayoutNoNav>
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-6xl rounded-2xl shadow-2xl bg-slate-900/60 backdrop-blur-sm text-white">
          <div className="flex flex-col lg:flex-row">
            <div className="lg:w-2/5 p-8 lg:p-10 text-white">
              <div className="mb-8">
                <p className="text-base text-green-500 mb-6">Forgot Password</p>
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-amber-500 rounded-full flex items-center justify-center">
                    <HandPlatter className="w-7 h-7 text-white" />
                  </div>
                  <h1 className="text-3xl font-bold">Shift Solutions</h1>
                </div>
                <p className="text-base font-semibold mb-8">
                  Enter your email address and we'll send you a link to reset your password.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {message && (
                  <div className="p-3 rounded-xl bg-green-500/20 border border-green-500/30 text-green-300 text-sm">
                    {message}
                  </div>
                )}

                {error && (
                  <div className="p-3 rounded-xl bg-red-500/20 border border-red-500/30 text-red-300 text-sm">
                    {error}
                  </div>
                )}

                <div>
                  <input
                    type="email"
                    name="email"
                    placeholder="Email"
                    value={email}
                    required
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-amber-600 focus:bg-white/20 transition-all"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-blue-600 hover:bg-green-500 text-white font-semibold rounded-xl transition-all duration-300 shadow-md"
                >
                  Send Reset Link
                </button>

                <p className="text-center text-gray-300 text-sm">
                  Remember your password?{" "}
                  <Link to="/login" className="text-amber-500 font-semibold hover:underline">
                    Back to Login
                  </Link>
                </p>
              </form>
            </div>

            <div className="lg:w-4/5 relative">
              <div
                className="absolute inset-0 bg-cover bg-center"
                style={{ backgroundImage: `url(${waiterImg})` }}
              >
                <div className="absolute inset-0 bg-gray-500/70"></div>
              </div>

              <div className="relative z-10 p-8 lg:p-16 h-full flex flex-col justify-center min-h-[400px] lg:min-h-0">
                <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
                  Forgot Your Password?
                </h2>
                <p className="text-lg text-white/90 leading-relaxed">
                  No worries! Enter your email and we'll send you a secure link to reset your password and get back to managing your shifts.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageLayoutNoNav>
  );
};

export default ForgotPassword;