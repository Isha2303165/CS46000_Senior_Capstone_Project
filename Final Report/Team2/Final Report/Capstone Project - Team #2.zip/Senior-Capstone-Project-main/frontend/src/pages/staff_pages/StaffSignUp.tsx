import PageLayoutNoNav from "../../layouts/PageLayoutNoNav";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { HandPlatter, Eye, EyeOff, Check, X, Sparkles } from 'lucide-react';
import { signUpStaff } from "../../api"; // signUpStaff function found in api.js
import waiterImg from "../../assets/img/waiter.jpg"; // local image

export default function StaffSignUp() {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        email: "",
        password: "",
        confirm_password: "",
    });
    
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);
    const [errorMessage, setErrorMessage] = useState("");
    const [isSubmitting, setIsSubmitting] = useState(false);

    // Password validation rules
    const validatePassword = (password: string) => {
        const requirements = {
            length: password.length >= 8 && password.length <= 20,
            uppercase: /[A-Z]/.test(password),
            lowercase: /[a-z]/.test(password),
            number: /\d/.test(password),
            special: /[@$!%*?&#]/.test(password),
        };
        return requirements;
    };

    const passwordRequirements = validatePassword(formData.password);
    const isPasswordValid = Object.values(passwordRequirements).every(Boolean);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setErrorMessage("");

        if (!isPasswordValid) {
            setErrorMessage("Password does not meet the requirements shown below.");
            return;
        }
        
        if (formData.password !== formData.confirm_password) {
            setErrorMessage("Passwords do not match");
            return;
        }
        
        setIsSubmitting(true);
        
        try {
            // send all form data except confirmPassword to signUpStaff function
            const { confirm_password, ...signupData } = formData; // destructuring
            const result = await signUpStaff(signupData);
            console.log("Signup success:", result);
            
            // Check if email verification is required
            if (result?.email_verification_required) {
                // Store email for verification page
                sessionStorage.setItem('pending_verification_email', signupData.email);
                navigate('/verify-email');
            } else {
                // Redirect staff to sign-in page after successful signup
                navigate('/login');
            }
        } catch (error: any) {
            // Extract detailed error message from backend
            let errorMsg = "Error signing up staff";
            
            if (error?.response?.data?.detail) {
                if (Array.isArray(error.response.data.detail)) {
                    // Handle validation errors from pydantic
                    const validationErrors = error.response.data.detail
                        .map((err: any) => err.msg || err.message)
                        .join(", ");
                    errorMsg = validationErrors;
                } else {
                    errorMsg = error.response.data.detail;
                }
            } else if (error?.message) {
                errorMsg = error.message;
            }
            
            setErrorMessage(errorMsg);
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <PageLayoutNoNav>
        <div className="min-h-screen flex items-center justify-center p-4">
            <div className="w-full max-w-6xl rounded-2xl shadow-2xl overflow-hidden bg-slate-900/60 backdrop-blur-sm text-white">
                <div className="flex flex-col lg:flex-row">
                    {/* form section */}
                    <div className="lg:w-2/5 p-8 lg:p-10 text-white">
                        <div className="mb-8">
                            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-amber-500/10 border border-amber-500/20 rounded-full mb-4">
                                <Sparkles className="w-4 h-4 text-amber-400" />
                                <span className="text-amber-400 text-xs font-medium">Quick & Easy Signup</span>
                            </div>

                            <p className="text-base text-amber-400 mb-6">Staff Sign Up</p>

                            <div className="flex items-center gap-3 mb-6">
                                <div className="w-12 h-12 bg-gradient-to-br from-amber-500 to-amber-600 rounded-full flex items-center justify-center shadow-lg shadow-amber-500/30">
                                    <HandPlatter className="w-7 h-7 text-white" />
                                </div>
                                <h1 className="text-2xl font-bold">Shift Solutions</h1>
                            </div>

                            <p className="text-slate-300 text-sm mb-6">
                                Get started in seconds. We'll collect more details after you verify your email.
                            </p>
                        </div>

                        <form onSubmit={handleSubmit} className="space-y-6">
                            {errorMessage && (
                                <div className="p-3 rounded-xl bg-red-500/20 border border-red-500/30 text-red-300 text-sm flex items-start gap-2">
                                    <X className="w-4 h-4 flex-shrink-0 mt-0.5" />
                                    <span>{errorMessage}</span>
                                </div>
                            )}
                            
                            {/* email */}
                            <div>
                                <label className="block text-sm font-medium text-slate-300 mb-2">
                                    Email Address <span className="text-red-400">*</span>
                                </label>
                                <input
                                    type="email"
                                    name="email"
                                    placeholder="your@email.com"
                                    value={formData.email}
                                    onChange={handleChange}
                                    required
                                    className="w-full px-4 py-3 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                                />
                            </div>

                            {/* password */}
                            <div>
                                <label className="block text-sm font-medium text-slate-300 mb-2">
                                    Password <span className="text-red-400">*</span>
                                </label>
                                <div className="relative">
                                    <input
                                        type={showPassword ? "text" : "password"}
                                        name="password"
                                        placeholder="Create a strong password"
                                        value={formData.password}
                                        onChange={handleChange}
                                        required
                                        className="w-full px-4 py-3 pr-12 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                                    />
                                    <button
                                        type="button"
                                        onClick={() => setShowPassword(!showPassword)}
                                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-white/60 hover:text-white/80 transition-colors"
                                    >
                                        {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                                    </button>
                                </div>
                                
                                {formData.password && (
                                    <div className="mt-3 space-y-1.5 text-sm">
                                        <p className="text-white/70 mb-2 text-xs">Password must contain:</p>
                                        <div className="grid grid-cols-2 gap-2">
                                            <div className={`flex items-center gap-1.5 ${passwordRequirements.length ? 'text-green-400' : 'text-red-400'}`}>
                                                {passwordRequirements.length ? <Check size={14} /> : <X size={14} />}
                                                <span className="text-xs">8-20 characters</span>
                                            </div>
                                            <div className={`flex items-center gap-1.5 ${passwordRequirements.uppercase ? 'text-green-400' : 'text-red-400'}`}>
                                                {passwordRequirements.uppercase ? <Check size={14} /> : <X size={14} />}
                                                <span className="text-xs">Uppercase letter</span>
                                            </div>
                                            <div className={`flex items-center gap-1.5 ${passwordRequirements.lowercase ? 'text-green-400' : 'text-red-400'}`}>
                                                {passwordRequirements.lowercase ? <Check size={14} /> : <X size={14} />}
                                                <span className="text-xs">Lowercase letter</span>
                                            </div>
                                            <div className={`flex items-center gap-1.5 ${passwordRequirements.number ? 'text-green-400' : 'text-red-400'}`}>
                                                {passwordRequirements.number ? <Check size={14} /> : <X size={14} />}
                                                <span className="text-xs">Number</span>
                                            </div>
                                            <div className={`flex items-center gap-1.5 ${passwordRequirements.special ? 'text-green-400' : 'text-red-400'} col-span-2`}>
                                                {passwordRequirements.special ? <Check size={14} /> : <X size={14} />}
                                                <span className="text-xs">Special character (@$!%*?&#)</span>
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>

                            {/* confirm password */}
                            <div>
                                <label className="block text-sm font-medium text-slate-300 mb-2">
                                    Confirm Password <span className="text-red-400">*</span>
                                </label>
                                <div className="relative">
                                    <input
                                        type={showConfirmPassword ? "text" : "password"}
                                        name="confirm_password"
                                        placeholder="Re-enter your password"
                                        value={formData.confirm_password}
                                        onChange={handleChange}
                                        required
                                        className="w-full px-4 py-3 pr-12 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                                    />
                                    <button
                                        type="button"
                                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                                        className="absolute right-3 top-1/2 transform -translate-y-1/2 text-white/60 hover:text-white/80 transition-colors"
                                    >
                                        {showConfirmPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                                    </button>
                                </div>
                                
                                {formData.confirm_password && (
                                    <div className={`mt-2 flex items-center gap-1 text-sm ${formData.password === formData.confirm_password ? 'text-green-400' : 'text-red-400'}`}>
                                        {formData.password === formData.confirm_password ? <Check size={14} /> : <X size={14} />}
                                        <span className="text-xs">Passwords match</span>
                                    </div>
                                )}
                            </div>

                            {/* submit button */}
                            <button
                                type="submit"
                                disabled={isSubmitting}
                                className="w-full py-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 disabled:from-slate-600 disabled:to-slate-700 text-white font-semibold rounded-xl transition-all duration-300 shadow-lg shadow-amber-500/30 hover:shadow-amber-500/50 disabled:shadow-none"
                            >
                                {isSubmitting ? 'Creating Account...' : 'Create Account'}
                            </button>

                            <p className="text-center text-gray-300 text-sm">
                                Already have an account?{' '}
                                <Link to="/login" className="text-amber-400 font-semibold hover:text-amber-300 hover:underline">
                                    Log in
                                </Link>
                            </p>
                        </form>
                    </div>

                    {/* image section */}
                    <div className="lg:w-4/5 relative">
                        <div
                            className="absolute inset-0 bg-cover bg-center"
                            style={{ backgroundImage: `url(${waiterImg})` }}
                        >
                            <div className="absolute inset-0 bg-gradient-to-br from-slate-900/80 via-slate-800/70 to-slate-900/80"></div>
                        </div>

                        <div className="relative z-10 p-8 lg:p-16 h-full flex flex-col justify-center min-h-[400px] lg:min-h-0">
                            <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
                                Find Great Shifts.<br />
                                <span className="bg-gradient-to-r from-amber-400 to-teal-400 bg-clip-text text-transparent">
                                    Build Your Career.
                                </span>
                            </h2>
                            <p className="text-lg text-white/90 leading-relaxed max-w-xl">
                                Join Shift Solutions and discover flexible opportunities with
                                top restaurants in your area.
                            </p>

                            {/* feature list */}
                            <div className="mt-8 space-y-3">
                                <div className="flex items-center gap-3">
                                    <div className="w-6 h-6 bg-amber-500/20 rounded-full flex items-center justify-center">
                                        <Check className="w-4 h-4 text-amber-400" />
                                    </div>
                                    <span className="text-white/80">Browse available shifts instantly</span>
                                </div>
                                <div className="flex items-center gap-3">
                                    <div className="w-6 h-6 bg-amber-500/20 rounded-full flex items-center justify-center">
                                        <Check className="w-4 h-4 text-amber-400" />
                                    </div>
                                    <span className="text-white/80">Work when and where you want</span>
                                </div>
                                <div className="flex items-center gap-3">
                                    <div className="w-6 h-6 bg-amber-500/20 rounded-full flex items-center justify-center">
                                        <Check className="w-4 h-4 text-amber-400" />
                                    </div>
                                    <span className="text-white/80">Grow your hospitality career</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </PageLayoutNoNav>
    );
}