import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, Mail, MessageCircle, ArrowRight } from 'lucide-react';
import axios from 'axios';
import waiterImg from "../assets/img/waiter.jpg";
import PageLayoutNoNav from "../layouts/PageLayoutNoNav";


const TwoFactorMethodSelection: React.FC = () => {
  const [availableMethods, setAvailableMethods] = useState<string[]>([]);
  const [selectedMethod, setSelectedMethod] = useState('email');
  const [phoneMasked, setPhoneMasked] = useState('');
  const [phoneConfigured, setPhoneConfigured] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const email = sessionStorage.getItem('pending_2fa_email');

  useEffect(() => {
    // Get available methods from session storage
    const methods = sessionStorage.getItem('pending_2fa_methods');
    const phone = sessionStorage.getItem('pending_2fa_phone');

    if (methods) {
      try {
        const parsedMethods = JSON.parse(methods);
        setAvailableMethods(parsedMethods);
        // Default to email, or first available method
        setSelectedMethod(parsedMethods.includes('email') ? 'email' : parsedMethods[0]);
      } catch (e) {
        setAvailableMethods(['email']);
      }
    } else {
      setAvailableMethods(['email']);
    }

    if (phone) {
      setPhoneMasked(phone);
      setPhoneConfigured(true);
    }
  }, []);

  const handleSendCode = async () => {
    if (!email) {
      setError('Missing email for 2FA. Please login again.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const requestData = {
        email: email,
        method: selectedMethod
      };

      const response = await axios.post('http://localhost:8000/auth/send-2fa-code', requestData);

      if (response.data) {
        // Store the selected method and proceed to code entry
        sessionStorage.setItem('pending_2fa_method', selectedMethod);
        if (response.data.phone_masked) {
          sessionStorage.setItem('pending_2fa_phone', response.data.phone_masked);
        }
        navigate('/two-factor');
      }
    } catch (err: any) {
      setError(err?.response?.data?.detail || 'Failed to send verification code');
    } finally {
      setLoading(false);
    }
  };

  const getMethodIcon = (method: string) => {
    return method === 'email' ? <Mail className="w-5 h-5" /> : <MessageCircle className="w-5 h-5" />;
  };

  const getMethodName = (method: string) => {
    return method === 'email' ? 'Email' : 'SMS';
  };

  const getMethodDescription = (method: string) => {
    if (method === 'email') {
      return 'Receive code via email';
    } else {
      if (phoneConfigured && phoneMasked) {
        return `Receive code via text message (ending in ${phoneMasked})`;
      } else {
        return 'Receive code via text message (requires phone setup)';
      }
    }
  };

  return (
    <PageLayoutNoNav>
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-6xl rounded-2xl shadow-2xl overflow-hidden bg-slate-900/60 backdrop-blur-sm text-white">
          <div className="flex flex-col lg:flex-row">
            <div className="lg:w-2/5 p-8 lg:p-10 text-white">
              <div className="mb-8">
                <p className="text-base text-green-500 mb-6">Two-Factor Authentication</p>
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-amber-500 rounded-full flex items-center justify-center">
                    <Shield className="w-7 h-7 text-white" />
                  </div>
                  <h1 className="text-3xl font-bold">Shift Solutions</h1>
                </div>
                <p className="text-base font-semibold mb-8">
                  Choose how you'd like to receive your verification code.
                </p>
              </div>

              <div className="space-y-6">
                {error && (
                  <div className="p-3 rounded-xl bg-red-500/20 border border-red-500/30 text-red-300 text-sm">
                    {error}
                  </div>
                )}

                <div>
                  <label className="block text-sm font-semibold text-gray-300 mb-4">
                    Select verification method:
                  </label>

                  <div className="space-y-3">
                    {availableMethods.map((method) => (
                      <label
                        key={method}
                        className="flex items-center gap-3 p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all cursor-pointer"
                      >
                        <input
                          type="radio"
                          name="method"
                          value={method}
                          checked={selectedMethod === method}
                          onChange={(e) => setSelectedMethod(e.target.value)}
                          className="text-amber-500 focus:ring-amber-500"
                        />
                        <div className="text-amber-500">
                          {getMethodIcon(method)}
                        </div>
                        <div>
                          <div className="font-medium">{getMethodName(method)} Verification</div>
                          <div className="text-sm text-gray-400">{getMethodDescription(method)}</div>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                {selectedMethod === 'sms' && !phoneConfigured && (
                  <div className="bg-amber-500/10 rounded-xl p-6 border border-amber-500/20">
                    <div className="flex items-start gap-3">
                      <MessageCircle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                      <div className="text-sm text-amber-300">
                        <p className="font-medium mb-1">SMS Setup Required</p>
                        <p>
                          To use SMS verification, you'll need to configure a phone number in your profile settings first.
                          For now, please use email verification.
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {selectedMethod === 'sms' && phoneConfigured && (
                  <div className="bg-green-500/10 rounded-xl p-6 border border-green-500/20">
                    <div className="flex items-start gap-3">
                      <MessageCircle className="w-5 h-5 text-green-400 flex-shrink-0 mt-0.5" />
                      <div className="text-sm text-green-300">
                        <p className="font-medium mb-1">SMS Ready</p>
                        <p>
                          Verification code will be sent to your phone number ending in {phoneMasked}.
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                <button
                  onClick={handleSendCode}
                  disabled={loading}
                  className="w-full py-3 bg-blue-600 hover:bg-green-500 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-semibold rounded-xl transition-all duration-300 shadow-md flex items-center justify-center gap-2"
                >
                  {loading ? (
                    'Sending...'
                  ) : (
                    <>
                      Send Verification Code
                      <ArrowRight className="w-5 h-5" />
                    </>
                  )}
                </button>

                <p className="text-center text-gray-300 text-sm">
                  Having trouble?{" "}
                  <button
                    onClick={() => {
                      sessionStorage.removeItem('pending_2fa_email');
                      sessionStorage.removeItem('pending_2fa_methods');
                      sessionStorage.removeItem('pending_2fa_phone');
                      navigate('/login');
                    }}
                    className="text-amber-500 font-semibold hover:underline bg-transparent border-none cursor-pointer"
                  >
                    Cancel and return to login
                  </button>
                </p>
              </div>
            </div>

            <div className="lg:w-4/5 relative">
              <div
                className="absolute inset-0 bg-cover bg-center"
                style={{ backgroundImage: `url(${waiterImg})` }}
              >
                <div className="absolute inset-0 bg-gray-500/70"></div>
              </div>

              <div className="relative z-10 p-8 lg:p-16 h-full flex flex-col justify-center min-h-[400px] lg:min-h-0">
                <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
                  Choose Your Method
                </h2>
                <p className="text-lg text-white/90 leading-relaxed">
                  Select how you'd like to receive your verification code. We support both email and SMS delivery for your convenience.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageLayoutNoNav>
  );
};

export default TwoFactorMethodSelection;