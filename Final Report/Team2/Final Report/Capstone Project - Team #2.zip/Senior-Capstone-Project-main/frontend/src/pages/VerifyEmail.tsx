import { useEffect, useState } from "react";
import { useSearchParams, useNavigate, Link } from "react-router-dom";
import { Mail, CheckCircle, XCircle, RefreshCw } from 'lucide-react';
import axios from "axios";
import { resendVerificationEmail } from "../api";
import waiterImg from "../assets/img/waiter.jpg";
import PageLayoutNoNav from "../layouts/PageLayoutNoNav";


export default function VerifyEmail() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [status, setStatus] = useState<"pending" | "success" | "error">("pending");
  const [message, setMessage] = useState<string>("");
  const [error, setError] = useState<string>("");
  const [isResending, setIsResending] = useState(false);

  const email = sessionStorage.getItem('pending_verification_email');

  useEffect(() => {
    const token = searchParams.get("token");
    const statusParam = searchParams.get("status");

    // If backend redirected with status, show it immediately
    if (statusParam) {
      if (statusParam === "success") {
        setStatus("success");
        setMessage("Email successfully verified. You can now log in to your account.");
        // Clear stored email on successful verification
        sessionStorage.removeItem('pending_verification_email');
      } else {
        setStatus("error");
        setError("Verification failed or link expired.");
      }
      return;
    }
    if (!token) {
      // If no token, check if we came from login redirect
      if (!email) {
        setStatus("error");
        setError("No verification token or email found.");
      } else {
        // Show verification pending state
        setMessage("Please check your email for a verification link.");
      }
      return;
    }

    const verify = async () => {
      try {
        // Decode token in case it was URL-encoded in the email link
        const decoded = decodeURIComponent(token as string);
        // Call backend verify endpoint and explicitly ask for JSON so we get a programmatic response
        const res = await axios.get(`http://localhost:8000/verify/${decoded}?json=true`);
        if (res.status === 200) {
          setStatus("success");
          setMessage("Email successfully verified. You can now log in to your account.");
          // Clear stored email on successful verification
          sessionStorage.removeItem('pending_verification_email');
        } else {
          setStatus("error");
          setError("Verification failed.");
        }
      } catch (err: any) {
        setStatus("error");
        setError(err?.response?.data?.detail || "Verification failed.");
      }
    };

    verify();
  }, [searchParams, navigate]);

  const handleResendVerification = async () => {
    if (!email) {
      setError('No email address found. Please try logging in again.');
      return;
    }

    setIsResending(true);
    setError('');
    setMessage('');

    try {
      const result = await resendVerificationEmail(email);
      setMessage('Verification email has been sent! Please check your inbox.');
    } catch (error: any) {
      const detail = error?.response?.data?.detail || 'Failed to resend verification email';
      setError(detail);
    } finally {
      setIsResending(false);
    }
  };

  const handleBackToLogin = () => {
    sessionStorage.removeItem('pending_verification_email');
    navigate('/login');
  };

  return (
    <PageLayoutNoNav>
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-6xl rounded-2xl shadow-2xl overflow-hidden bg-slate-900/60 backdrop-blur-sm text-white">
          <div className="flex flex-col lg:flex-row">
            <div className="lg:w-2/5 p-8 lg:p-10 text-white">
              <div className="mb-8">
                <p className="text-base text-blue-400 mb-6">Email Verification</p>
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-amber-500 rounded-full flex items-center justify-center">
                    <Mail className="w-7 h-7 text-white" />
                  </div>
                  <h1 className="text-3xl font-bold">Shift Solutions</h1>
                </div>

                {/* Success state */}
                {status === 'success' && (
                  <div className="mb-8">
                    <div className="flex items-center gap-3 mb-4">
                      <CheckCircle className="w-8 h-8 text-green-400" />
                      <p className="text-base font-semibold text-green-400">Email Verified!</p>
                    </div>
                    <p className="text-base text-white/90 mb-8">
                      {message}
                    </p>
                  </div>
                )}

                {/* Error state */}
                {status === 'error' && (
                  <div className="mb-8">
                    <div className="flex items-center gap-3 mb-4">
                      <XCircle className="w-8 h-8 text-red-400" />
                      <p className="text-base font-semibold text-red-400">
                        {error.includes('token') ? 'Verification Failed' : 'Action Required'}
                      </p>
                    </div>
                    <p className="text-base text-white/90 mb-8">
                      {error || 'Please verify your email address to continue.'}
                    </p>
                  </div>
                )}

                {/* Pending state */}
                {status === 'pending' && (
                  <div className="mb-8">
                    <p className="text-base font-semibold mb-4">
                      {searchParams.get('token') ? 'Verifying your email...' : 'Please verify your email address'}
                    </p>
                    <p className="text-base text-white/90 mb-8">
                      {message || 'We\'ve sent a verification link to your email address. Please check your inbox and click the link to verify your account.'}
                    </p>
                  </div>
                )}
              </div>

              <div className="space-y-6">
                {message && status !== 'success' && (
                  <div className="p-3 rounded-xl bg-green-500/20 border border-green-500/30 text-green-300 text-sm">
                    {message}
                  </div>
                )}

                {error && status !== 'error' && (
                  <div className="p-3 rounded-xl bg-red-500/20 border border-red-500/30 text-red-300 text-sm">
                    {error}
                  </div>
                )}

                {/* Show resend button only if we have an email and verification hasn't succeeded */}
                {email && status !== 'success' && (
                  <button
                    onClick={handleResendVerification}
                    disabled={isResending}
                    className="w-full py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-600/50 text-white font-semibold rounded-xl transition-all duration-300 shadow-md flex items-center justify-center gap-2"
                  >
                    {isResending ? (
                      <>
                        <RefreshCw className="w-5 h-5 animate-spin" />
                        Sending...
                      </>
                    ) : (
                      <>
                        <Mail className="w-5 h-5" />
                        Resend Verification Email
                      </>
                    )}
                  </button>
                )}

                <button
                  onClick={handleBackToLogin}
                  className="w-full py-3 bg-slate-700 hover:bg-slate-600 text-white font-semibold rounded-xl transition-all duration-300 shadow-md"
                >
                  {status === 'success' ? 'Go to Login' : 'Back to Login'}
                </button>

                <p className="text-center text-gray-300 text-sm">
                  Need help?{" "}
                  <Link to="/contact" className="text-amber-500 font-semibold hover:underline">
                    Contact Support
                  </Link>
                </p>
              </div>
            </div>

            <div className="lg:w-4/5 relative">
              <div
                className="absolute inset-0 bg-cover bg-center"
                style={{ backgroundImage: `url(${waiterImg})` }}
              >
                <div className="absolute inset-0 bg-gray-500/70"></div>
              </div>

              <div className="relative z-10 p-8 lg:p-16 h-full flex flex-col justify-center min-h-[400px] lg:min-h-0">
                <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
                  {status === 'success' ? 'Welcome to Shift Solutions!' : 'Verify Your Email'}
                </h2>
                <p className="text-lg text-white/90 leading-relaxed">
                  {status === 'success'
                    ? 'Your account is now verified and ready to use. Start managing your shifts today!'
                    : 'Email verification helps keep your account secure and ensures you receive important updates about your shifts and account.'
                  }
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageLayoutNoNav>
  );
}
