import React, { useState, useEffect } from 'react';
import { Shield, Mail, MessageCircle, Save, Phone } from 'lucide-react';
import axios from 'axios';

const TwoFactorSettings: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [method, setMethod] = useState('email');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [phoneMasked, setPhoneMasked] = useState('');
  const [phoneConfigured, setPhoneConfigured] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const token = localStorage.getItem('access_token');
      const response = await axios.get('http://localhost:8000/auth/2fa-settings', {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      setMethod(response.data.method);
      setPhoneConfigured(response.data.phone_configured);
      setPhoneMasked(response.data.phone_masked || '');
      setLoading(false);
    } catch (err: any) {
      setError('Failed to load 2FA settings');
      setLoading(false);
    }
  };

  const formatPhoneNumber = (value: string) => {
    // Remove all non-digits
    const digits = value.replace(/\D/g, '');
    
    // Format as XXX-XXX-XXXX
    if (digits.length >= 6) {
      return `${digits.slice(0, 3)}-${digits.slice(3, 6)}-${digits.slice(6, 10)}`;
    } else if (digits.length >= 3) {
      return `${digits.slice(0, 3)}-${digits.slice(3)}`;
    }
    return digits;
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatPhoneNumber(e.target.value);
    setPhoneNumber(formatted);
  };

  const handleSave = async () => {
    setError('');
    setMessage('');
    setSaving(true);

    try {
      const token = localStorage.getItem('access_token');
      const response = await axios.post('http://localhost:8000/auth/update-2fa-method', {
        method: method,
        phone_number: method === 'sms' ? phoneNumber : null
      }, {
        headers: { Authorization: `Bearer ${token}` }
      });

      setMessage('2FA settings updated successfully!');
      setPhoneConfigured(method === 'sms');
      setPhoneMasked(response.data.phone_masked || '');
      
      // Clear success message after 3 seconds
      setTimeout(() => setMessage(''), 3000);
    } catch (err: any) {
      setError(err?.response?.data?.detail || 'Failed to update 2FA settings');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="text-white">Loading 2FA settings...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      <div className="max-w-2xl mx-auto">
        <div className="bg-slate-900/60 backdrop-blur-sm rounded-2xl shadow-2xl p-8 text-white border border-white/10">
          <div className="flex items-center gap-3 mb-8">
            <div className="w-12 h-12 bg-amber-500 rounded-full flex items-center justify-center">
              <Shield className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Two-Factor Authentication Settings</h1>
              <p className="text-gray-400">Configure how you receive verification codes</p>
            </div>
          </div>

          {message && (
            <div className="mb-6 p-4 rounded-xl bg-green-500/20 border border-green-500/30 text-green-300">
              {message}
            </div>
          )}

          {error && (
            <div className="mb-6 p-4 rounded-xl bg-red-500/20 border border-red-500/30 text-red-300">
              {error}
            </div>
          )}

          <div className="space-y-6">
            <div>
              <label className="block text-sm font-semibold text-gray-300 mb-4">
                Choose your preferred 2FA method:
              </label>
              
              <div className="space-y-3">
                <label className="flex items-center gap-3 p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all cursor-pointer">
                  <input
                    type="radio"
                    name="method"
                    value="email"
                    checked={method === 'email'}
                    onChange={(e) => setMethod(e.target.value)}
                    className="text-amber-500 focus:ring-amber-500"
                  />
                  <Mail className="w-5 h-5 text-amber-500" />
                  <div>
                    <div className="font-medium">Email Verification</div>
                    <div className="text-sm text-gray-400">Receive codes via email</div>
                  </div>
                </label>

                <label className="flex items-center gap-3 p-4 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all cursor-pointer">
                  <input
                    type="radio"
                    name="method"
                    value="sms"
                    checked={method === 'sms'}
                    onChange={(e) => setMethod(e.target.value)}
                    className="text-amber-500 focus:ring-amber-500"
                  />
                  <MessageCircle className="w-5 h-5 text-amber-500" />
                  <div>
                    <div className="font-medium">SMS Verification</div>
                    <div className="text-sm text-gray-400">
                      Receive codes via text message
                      {phoneConfigured && (
                        <span className="text-amber-400"> (ending in {phoneMasked})</span>
                      )}
                    </div>
                  </div>
                </label>
              </div>
            </div>

            {method === 'sms' && (
              <div className="bg-white/5 rounded-xl p-6 border border-white/10">
                <label className="block text-sm font-semibold text-gray-300 mb-3">
                  <Phone className="w-4 h-4 inline mr-2" />
                  Phone Number for SMS
                </label>
                <input
                  type="tel"
                  placeholder="555-123-4567"
                  value={phoneNumber}
                  onChange={handlePhoneChange}
                  maxLength={12}
                  className="w-full px-4 py-3 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-amber-600 focus:bg-white/20 transition-all"
                />
                <p className="text-xs text-gray-400 mt-2">
                  Enter a US phone number to receive SMS verification codes
                </p>
              </div>
            )}

            <button
              onClick={handleSave}
              disabled={saving || (method === 'sms' && !phoneNumber)}
              className="w-full py-3 bg-amber-600 hover:bg-amber-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-semibold rounded-xl transition-all duration-300 shadow-md flex items-center justify-center gap-2"
            >
              {saving ? (
                'Saving...'
              ) : (
                <>
                  <Save className="w-5 h-5" />
                  Save 2FA Settings
                </>
              )}
            </button>
          </div>

          <div className="mt-8 p-4 rounded-xl bg-blue-500/10 border border-blue-500/20">
            <div className="flex items-start gap-3">
              <Shield className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-blue-300">
                <p className="font-medium mb-1">About Two-Factor Authentication</p>
                <p>
                  2FA adds an extra layer of security to your account. After entering your password, 
                  you'll receive a verification code via your chosen method.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TwoFactorSettings;