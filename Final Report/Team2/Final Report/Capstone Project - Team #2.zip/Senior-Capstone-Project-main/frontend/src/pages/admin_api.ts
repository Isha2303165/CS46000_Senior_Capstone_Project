// Mock API functions for testing the Admin Interface

export interface Client {
  id: number;
  business_name: string;
  email: string;
  last_login_at: string;
  status?: "active" | "suspended" | "pending";
}

export interface Server {
  id: number;
  first_name: string;
  last_name: string;
  email: string;
  last_login_at: string;
  status?: "active" | "suspended" | "pending";
}

// Mock feedback
let mockFeedback = [
  { id: 1, message: "Great platform!", email: "user1@example.com", date_posted: "2025-12-10", time_posted: "10:30 AM" },
  { id: 2, message: "Found a bug in the system.", email: "user2@example.com", date_posted: "2025-12-10", time_posted: "10:30 AM" },
  { id: 3, message: "Request for new feature.", email: "user3@example.com", date_posted: "2025-12-10", time_posted: "10:30 AM" },
];

// Mock data for clients and servers
let mockClients: Client[] = [
  { id: 1, business_name: "Acme Corp", email: "contact@acme.com", last_login_at: "2025-12-10T10:30:00Z", status: "active" },
  { id: 2, business_name: "Globex", email: "info@globex.com", last_login_at: "2025-12-09T15:45:00Z", status: "suspended" },
  { id: 3, business_name: "Initech", email: "hello@initech.com", last_login_at: "2025-12-08T09:20:00Z", status: "pending" },
  { id: 4, business_name: "Umbrella", email: "support@umbrella.com", last_login_at: "2025-12-07T11:00:00Z", status: "active" },
  { id: 5, business_name: "Stark Industries", email: "tony@stark.com", last_login_at: "2025-12-06T14:10:00Z", status: "suspended" },
  { id: 6, business_name: "Wayne Enterprises", email: "bruce@wayne.com", last_login_at: "2025-12-05T08:50:00Z", status: "active" },
];

let mockServers: Server[] = [
  { id: 1, first_name: "John", last_name: "Doe", email: "john@example.com", last_login_at: "2025-12-10T10:30:00Z", status: "active" },
  { id: 2, first_name: "Jane", last_name: "Smith", email: "jane@example.com", last_login_at: "2025-12-09T12:20:00Z", status: "pending" },
  { id: 3, first_name: "Alice", last_name: "Johnson", email: "alice@example.com", last_login_at: "2025-12-08T16:15:00Z", status: "suspended" },
  { id: 4, first_name: "Bob", last_name: "Brown", email: "bob@example.com", last_login_at: "2025-12-07T10:00:00Z", status: "active" },
  { id: 5, first_name: "Charlie", last_name: "Davis", email: "charlie@example.com", last_login_at: "2025-12-06T09:40:00Z", status: "pending" },
  { id: 6, first_name: "Eve", last_name: "Miller", email: "eve@example.com", last_login_at: "2025-12-05T14:50:00Z", status: "active" },
];

// Simulate network delay
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

// Feedback API functions
export async function getAllFeedback() {
  await delay(300);
  return [...mockFeedback];
}

export async function deleteFeedback(id: number) {
  await delay(200);
  mockFeedback = mockFeedback.filter((fb) => fb.id !== id);
  return { success: true };
}

export async function respondToFeedback(
  id: number,
  response: string,
  status: "unread" | "read" | "in_progress" | "resolved"
) {
  await delay(200);

  mockFeedback = mockFeedback.map((fb) =>
    fb.id === id
      ? { ...fb, admin_response: response, status }
      : fb
  );

  return { success: true };
}


// Account Management API functions
export const getAllClients = (): Promise<Client[]> =>
  new Promise((resolve) => setTimeout(() => resolve([...mockClients]), 500));

export const getAllServers = (): Promise<Server[]> =>
  new Promise((resolve) => setTimeout(() => resolve([...mockServers]), 500));

export const removeAccount = (id: number): Promise<void> =>
  new Promise((resolve) => {
    mockClients = mockClients.filter((c) => c.id !== id);
    mockServers = mockServers.filter((s) => s.id !== id);
    setTimeout(() => resolve(), 200);
  });

export const suspendAccount = (id: number): Promise<void> =>
  new Promise((resolve) => {
    // Toggle status for clients
    mockClients = mockClients.map((c) =>
      c.id === id
        ? { ...c, status: c.status === "active" ? "suspended" : "active" }
        : c
    );
    // Toggle status for servers
    mockServers = mockServers.map((s) =>
      s.id === id
        ? { ...s, status: s.status === "active" ? "suspended" : "active" }
        : s
    );
    console.log("Toggled account status for ID:", id);
    setTimeout(() => resolve(), 200);
  });

// Maintenance API functions
export async function restartServices() {
  return "Mock response: Services are restarting..." ;
}

export async function databaseCleanup() {
  return "Mock response: Database cleaned up." ;
}
