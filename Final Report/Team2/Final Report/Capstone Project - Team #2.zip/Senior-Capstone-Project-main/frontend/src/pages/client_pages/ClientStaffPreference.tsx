import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import ClientSidebar from '../../components/ClientSidebar';
import RoleDropdown from '../../components/RoleDropdown';
import { saveStaffPreferences, getStaffPreferences } from '../../api';

type StaffPreferenceFormState = {
  role: string;
  minimumTierRating: string[];
  dressCodeNotes: string;
  tipPolicy: string;
};

const roleOptions = ['Server', 'Bartender', 'Host', 'Busser', 'Cook', 'Manager'];

const tierDescriptions = {
  'Tier 1': 'Experienced staff with excellent performance ratings and proven track record.',
  'Tier 2': 'Moderately experienced staff with good performance ratings.',
  'Tier 3': 'Entry-level staff or those with limited experience.'
};

export default function ClientStaffPreference() {
  const navigate = useNavigate();
  const [form, setForm] = useState<StaffPreferenceFormState>({
    role: 'Server',
    minimumTierRating: [],
    dressCodeNotes: '',
    tipPolicy: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Load existing preferences on component mount
  useEffect(() => {
    async function loadPreferences() {
      try {
        setIsLoading(true);
        const data = await getStaffPreferences();
        if (data) {
          setForm({
            role: data.role || 'Server',
            minimumTierRating: data.minimum_tier_rating || [],
            dressCodeNotes: data.dress_code_notes || '',
            tipPolicy: data.tip_policy || ''
          });
        }
      } catch (error: any) {
        // If preferences don't exist yet, that's okay - use defaults
        console.log('No existing preferences found, using defaults');
      } finally {
        setIsLoading(false);
      }
    }
    loadPreferences();
  }, []);

  function handleRoleChange(role: string) {
    setForm((prev) => ({ ...prev, role }));
  }

  function handleTierChange(tier: string) {
    setForm((prev) => {
      const currentTiers = prev.minimumTierRating;
      const isSelected = currentTiers.includes(tier);
      
      if (isSelected) {
        return {
          ...prev,
          minimumTierRating: currentTiers.filter((t) => t !== tier)
        };
      } else {
        return {
          ...prev,
          minimumTierRating: [...currentTiers, tier]
        };
      }
    });
  }

  function handleChange(
    e: React.ChangeEvent<HTMLTextAreaElement>
  ) {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const preferencesData = {
        role: form.role,
        minimum_tier_rating: form.minimumTierRating,
        dress_code_notes: form.dressCodeNotes,
        tip_policy: form.tipPolicy
      };
      
      const result = await saveStaffPreferences(preferencesData);
      console.log('Staff preferences saved successfully:', result);
      alert('Staff preferences saved successfully!');
    } catch (error: any) {
      console.error('Error saving preferences:', error);
      const errorMessage = error?.response?.data?.detail || error?.message || 'Error saving preferences. Please try again.';
      alert(errorMessage);
    } finally {
      setIsSubmitting(false);
    }
  }

  function handleCancel() {
    navigate(-1);
  }

  return (
    <div className="min-h-screen w-screen overflow-x-hidden bg-gradient-to-br from-slate-800 via-slate-700 to-teal-600">
      <div className="min-h-screen w-full flex relative">
        <ClientSidebar />
        <main className="flex-1 overflow-auto w-full">
          <div className="max-w-5xl mx-auto px-6 pt-20 pb-10">
            <div className="bg-slate-300/30 backdrop-blur-sm rounded-xl p-8 shadow-md">
              <h1 className="text-3xl font-bold text-white mb-2">Staffing Preferences</h1>
              <p className="text-white/80 mb-6">Configure your preferred staff requirements and policies.</p>
              <hr className="border-white/20 mb-8" />

              {isLoading ? (
                <div className="text-center py-10">
                  <p className="text-white">Loading preferences...</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-8">
                  {/* Role Selection */}
                  <section>
                    <h2 className="text-xl font-semibold text-white mb-4">Preferred Role</h2>
                    <RoleDropdown
                      value={form.role}
                      onChange={handleRoleChange}
                      options={roleOptions}
                    />
                  </section>

                  <hr className="border-white/20" />

                  {/* Minimum Tier Rating */}
                  <section>
                    <h2 className="text-xl font-semibold text-white mb-4">Minimum Tier Rating</h2>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      <div className="bg-slate-800/40 backdrop-blur-sm rounded-lg p-6">
                        <p className="text-white/90 text-sm mb-4">Select the minimum tier levels you'll accept:</p>
                        <div className="space-y-3">
                          {['Tier 1', 'Tier 2', 'Tier 3'].map((tier) => (
                            <label key={tier} className="flex items-center gap-3 cursor-pointer group">
                              <input
                                type="checkbox"
                                checked={form.minimumTierRating.includes(tier)}
                                onChange={() => handleTierChange(tier)}
                                className="w-5 h-5 rounded border-white/40 text-teal-500 focus:ring-2 focus:ring-teal-400 bg-white/90"
                              />
                              <span className="text-white font-medium group-hover:text-teal-300 transition">{tier}</span>
                            </label>
                          ))}
                        </div>
                      </div>

                      {/* Tier Descriptions Panel */}
                      <div className="bg-white/90 rounded-lg p-6 shadow-sm">
                        <h3 className="text-slate-900 font-semibold mb-4 text-lg">Tier Descriptions</h3>
                        <div className="space-y-4">
                          {Object.entries(tierDescriptions).map(([tier, description]) => (
                            <div key={tier} className="border-l-4 border-teal-500 pl-4">
                              <p className="text-slate-800 text-sm">
                                <span className="font-semibold text-slate-900">{tier}:</span>
                                <br />
                                <span className="text-slate-600">{description}</span>
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </section>

                  <hr className="border-white/20" />

                  {/* Dress Code Notes */}
                  <section>
                    <h2 className="text-xl font-semibold text-white mb-4">Dress Code Requirements</h2>
                    <textarea
                      className="w-full px-4 py-3 rounded-lg bg-white/90 placeholder-slate-400 text-slate-900 border border-white/40 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:bg-white transition shadow-sm"
                      name="dressCodeNotes"
                      value={form.dressCodeNotes}
                      onChange={handleChange}
                      placeholder="Describe your dress code requirements (e.g., black pants, white shirt, closed-toe shoes)..."
                      rows={4}
                    />
                  </section>

                  <hr className="border-white/20" />

                  {/* Tip Policy */}
                  <section>
                    <h2 className="text-xl font-semibold text-white mb-4">Tip Policy</h2>
                    <textarea
                      className="w-full px-4 py-3 rounded-lg bg-white/90 placeholder-slate-400 text-slate-900 border border-white/40 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:bg-white transition shadow-sm"
                      name="tipPolicy"
                      value={form.tipPolicy}
                      onChange={handleChange}
                      placeholder="Explain your tipping policy (e.g., tips pooled, individual tips, percentage to house)..."
                      rows={4}
                    />
                  </section>

                  {/* Action Buttons */}
                  <div className="flex justify-end gap-4 pt-6">
                    <button
                      type="button"
                      onClick={handleCancel}
                      className="px-6 py-3 rounded-lg bg-white/10 hover:bg-white/20 text-white font-semibold transition-all border border-white/30"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="px-6 py-3 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-semibold transition-all shadow-lg hover:shadow-xl disabled:opacity-60 disabled:cursor-not-allowed"
                    >
                      {isSubmitting ? 'Saving...' : 'Save Preferences'}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

