import PageLayoutNoNav from "../layouts/PageLayoutNoNav";

function ContactPage() {
  return (
    <PageLayoutNoNav>
      <div className="h-screen w-full overflow-auto">
        <div className="min-h-full w-full flex items-center justify-center p-6">
          <div className="w-full max-w-4xl bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20 shadow-2xl p-8">
            <h1 className="text-4xl font-bold text-white mb-6">Contact Us</h1>
            <div className="space-y-6">
              <p className="text-white/90">
                Have questions or need support? We're here to help!
              </p>
              {/* Add contact form or contact information here */}
            </div>
          </div>
        </div>
      </div>
    </PageLayoutNoNav>
  );
}

export default ContactPage;