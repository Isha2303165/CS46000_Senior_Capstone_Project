import { Users, Trash2 } from "lucide-react";
import PageLayout from "../../layouts/PageLayout";
import {
  getAllClients,
  getAllServers,
  removeAccount,
  suspendAccount,
  Client,
  Server,
} from "../admin_api";
import { useEffect, useState } from "react";

function AdminAccounts() {
  const adminMenu = [
    { path: "/admin/dashboard", label: "Dashboard" },
    { path: "/admin/accounts", label: "Accounts" },
    { path: "/admin/feedback", label: "Feedback" },
    { path: "/admin/maintenance", label: "Maintenance" },
  ];

  const [clients, setClients] = useState<Client[]>([]);
  const [servers, setServers] = useState<Server[]>([]);
  const [sortField, setSortField] = useState<string>("");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");

  const [pageSize, setPageSize] = useState<number>(5);
  const [currentPage, setCurrentPage] = useState<number>(1);

  useEffect(() => {
    getAllClients().then(setClients);
    getAllServers().then(setServers);
  }, []);

  const handleSort = (field: string) => {
    const direction =
      sortField === field && sortDirection === "asc" ? "desc" : "asc";
    setSortField(field);
    setSortDirection(direction);
  };

  const sortData = <T extends object>(data: T[]) => {
    if (!sortField) return data;
    return [...data].sort((a, b) => {
      const aValue = a[sortField as keyof T];
      const bValue = b[sortField as keyof T];
      return sortDirection === "asc"
        ? String(aValue).localeCompare(String(bValue))
        : String(bValue).localeCompare(String(aValue));
    });
  };

  const paginatedData = <T extends object>(data: T[]) =>
    data.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const handleSuspendClient = async (id: number) => {
    await suspendAccount(id);
    setClients((prev) =>
      prev.map((c) =>
        c.id === id
          ? { ...c, status: c.status === "active" ? "suspended" : "active" }
          : c
      )
    );
  };

  const handleSuspendServer = async (id: number) => {
    await suspendAccount(id);
    setServers((prev) =>
      prev.map((s) =>
        s.id === id
          ? { ...s, status: s.status === "active" ? "suspended" : "active" }
          : s
      )
    );
  };

  const handleRemoveClient = async (id: number) => {
    await removeAccount(id);
    setClients((prev) => prev.filter((c) => c.id !== id));
  };

  const handleRemoveServer = async (id: number) => {
    await removeAccount(id);
    setServers((prev) => prev.filter((s) => s.id !== id));
  };

  const statusColor: Record<string, string> = {
    active: "text-green-400",
    pending: "text-yellow-400",
    suspended: "text-red-400",
  };

  const sortedClients = sortData(clients);
  const sortedServers = sortData(servers);

  const paginatedClients = paginatedData(sortedClients);
  const paginatedServers = paginatedData(sortedServers);


  return (
    <PageLayout navbarConfig={{ menuItems: adminMenu }}>
      <div className="min-h-screen px-6 py-20 max-w-7xl mx-auto">
        <div className="flex items-center gap-4 mb-5">
          <Users className="text-teal-400 w-10 h-10" />
          <h1 className="text-white text-4xl font-bold">Manage Accounts</h1>
        </div>
        <p className="text-white/70 mb-10">
          Remove inactive users and suspend accounts.
        </p>

        {/* Page size selector */}
        <div className="mb-6 flex justify-end gap-4">
          <label className="text-white/70">Rows per page:</label>
          <select
            className="bg-slate-800 text-white p-2 rounded"
            value={pageSize}
            onChange={(e) => setPageSize(Number(e.target.value))}
          >
            {[5, 10, 20].map((size) => (
              <option key={size} value={size}>
                {size}
              </option>
            ))}
          </select>
        </div>

        {/* Clients Table */}
        <h2 className="text-white text-2xl font-semibold mb-2">Clients</h2>
        <table className="min-w-full text-left border border-slate-700 rounded-lg overflow-hidden mb-10">
          <thead className="bg-slate-900/80 text-white">
            <tr>
              <th
                className="p-3 cursor-pointer"
                onClick={() => handleSort("business_name")}
              >
                Business Name{" "}
                {sortField === "business_name"
                  ? sortDirection === "asc"
                    ? "↑"
                    : "↓"
                  : ""}
              </th>
              <th
                className="p-3 cursor-pointer"
                onClick={() => handleSort("email")}
              >
                Email{" "}
                {sortField === "email"
                  ? sortDirection === "asc"
                    ? "↑"
                    : "↓"
                  : ""}
              </th>
              <th className="p-3">Last Login</th>
              <th className="p-3">Status</th>
              <th className="p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {paginatedClients.map((c) => (
              <tr
                key={c.id}
                className="bg-slate-800/50 backdrop-blur-sm border-b border-slate-300 hover:bg-slate-800 transition-colors"
              >
                <td className="p-3 text-white">{c.business_name}</td>
                <td className="p-3 text-white/70">{c.email}</td>
                <td className="p-3 text-white/70">
                  {c.last_login_at
                    ? new Date(c.last_login_at).toLocaleString()
                    : "—"}
                </td>
                <td
                  className={`p-3 font-semibold ${statusColor[c.status || "active"]
                    }`}
                >
                  {c.status || "active"}
                </td>
                <td className="p-3 flex gap-4">
                  <button
                    onClick={() => handleSuspendClient(c.id)}
                    className="text-yellow-400 hover:text-yellow-300"
                  >
                    {c.status === "suspended" ? "Activate" : "Suspend"}
                  </button>
                  <button
                    onClick={() => handleRemoveClient(c.id)}
                    className="flex items-center gap-2 text-red-400 hover:text-red-300"
                  >
                    <Trash2 className="w-4 h-4" /> Remove
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Servers Table */}
        <h2 className="text-white text-2xl font-semibold mb-2">Servers</h2>
        <table className="min-w-full text-left border border-slate-700 rounded-lg overflow-hidden">
          <thead className="bg-slate-900/80 text-white">
            <tr>
              <th
                className="p-3 cursor-pointer"
                onClick={() => handleSort("first_name")}
              >
                First Name{" "}
                {sortField === "first_name"
                  ? sortDirection === "asc"
                    ? "↑"
                    : "↓"
                  : ""}
              </th>
              <th
                className="p-3 cursor-pointer"
                onClick={() => handleSort("last_name")}
              >
                Last Name{" "}
                {sortField === "last_name"
                  ? sortDirection === "asc"
                    ? "↑"
                    : "↓"
                  : ""}
              </th>
              <th
                className="p-3 cursor-pointer"
                onClick={() => handleSort("email")}
              >
                Email{" "}
                {sortField === "email"
                  ? sortDirection === "asc"
                    ? "↑"
                    : "↓"
                  : ""}
              </th>
              <th className="p-3">Last Login</th>
              <th className="p-3">Status</th>
              <th className="p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {paginatedServers.map((s) => (
              <tr
                key={s.id}
                className="bg-slate-800/50 backdrop-blur-sm border-b border-slate-300 hover:bg-slate-800 transition-colors"
              >
                <td className="p-3 text-white">{s.first_name}</td>
                <td className="p-3 text-white">{s.last_name}</td>
                <td className="p-3 text-white/70">{s.email}</td>
                <td className="p-3 text-white/70">
                  {s.last_login_at
                    ? new Date(s.last_login_at).toLocaleString()
                    : "—"}
                </td>
                <td
                  className={`p-3 font-semibold ${statusColor[s.status || "active"]
                    }`}
                >
                  {s.status || "active"}
                </td>
                <td className="p-3 flex gap-4">
                  <button
                    onClick={() => handleSuspendServer(s.id)}
                    className="text-yellow-400 hover:text-yellow-300"
                  >
                    {s.status === "suspended" ? "Activate" : "Suspend"}
                  </button>
                  <button
                    onClick={() => handleRemoveServer(s.id)}
                    className="flex items-center gap-2 text-red-400 hover:text-red-300"
                  >
                    <Trash2 className="w-4 h-4" /> Remove
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </PageLayout>
  );
}

export default AdminAccounts;
