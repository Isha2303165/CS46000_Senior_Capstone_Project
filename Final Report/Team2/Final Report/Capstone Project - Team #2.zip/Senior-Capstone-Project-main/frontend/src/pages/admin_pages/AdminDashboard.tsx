import { Users, MessageSquare, Server, Wrench, Shield } from "lucide-react";
import PageLayout from "../../layouts/PageLayout";
import { Link } from "react-router-dom";

function AdminDashboard() {
    const adminMenu = [
        { path: "/admin/dashboard", label: "Dashboard" },
        { path: "/admin/accounts", label: "Accounts" },
        { path: "/admin/feedback", label: "Feedback" },
        { path: "/admin/maintenance", label: "Maintenance" },
    ];

    const menu = [
        { label: "Feedback", icon: MessageSquare, path: "/admin/feedback", color: "teal" },
        { label: "Accounts & Users", icon: Users, path: "/admin/accounts", color: "amber" },
        { label: "System Maintenance", icon: Wrench, path: "/admin/maintenance", color: "teal" },
    ];

    return (
        <PageLayout navbarConfig={{ menuItems: adminMenu }}>
            <div className="min-h-screen px-6 py-20 max-w-7xl mx-auto">

                {/* Header */}
                <div className="text-center mb-16">
                    <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-500/10 to-amber-500/10 border border-teal-500/30 rounded-full backdrop-blur-sm mb-8">
                        <Shield className="w-4 h-4 text-teal-400" />
                        <span className="text-teal-300 text-sm font-medium">Administrator Access</span>
                    </div>

                    <h1 className="text-white text-5xl font-bold mb-4">Admin Control Center</h1>
                    <p className="text-white/70 text-lg max-w-2xl mx-auto">
                        Review platform activity, manage accounts, and maintain system integrity.
                    </p>
                </div>

                {/* Dashboard Grid */}
                <div className="grid md:grid-cols-3 gap-10">
                    {menu.map((item, index) => {
                        const Icon = item.icon;
                        const gradient = item.color === "teal"
                            ? "from-teal-500 to-teal-600"
                            : "from-amber-500 to-amber-600";
                        return (
                            <Link key={index} to={item.path}>
                                <div className="group relative bg-slate-900/80 p-8 rounded-3xl border border-slate-700/50 backdrop-blur-md hover:border-teal-500/40 hover:-translate-y-2 transition-all duration-300 shadow-xl">

                                    {/* Glow Effect */}
                                    <div className={`absolute inset-0 bg-gradient-to-br ${item.color === "teal"
                                        ? "from-teal-500/10"
                                        : "from-amber-500/10"
                                        } to-transparent rounded-3xl opacity-0 group-hover:opacity-100 transition-all`} />

                                    <div className="relative">
                                        <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${gradient} flex items-center justify-center shadow-lg mb-6`}>
                                            <Icon className="w-8 h-8 text-white" />
                                        </div>

                                        <h2 className="text-white text-2xl font-bold mb-2">{item.label}</h2>
                                        <p className="text-white/60 text-sm">
                                            Manage and monitor {item.label.toLowerCase()}.
                                        </p>
                                    </div>
                                </div>
                            </Link>
                        );
                    })}
                </div>
            </div>
        </PageLayout>
    );
}

export default AdminDashboard;
