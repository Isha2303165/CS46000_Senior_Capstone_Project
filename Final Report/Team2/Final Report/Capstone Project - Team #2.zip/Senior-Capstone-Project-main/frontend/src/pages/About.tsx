import PageLayoutNoNav from "../layouts/PageLayoutNoNav";

function AboutPage() {
  return (
    <PageLayoutNoNav>
      <div className="h-screen">
        <div className="min-h-full w-full flex items-center justify-center p-6">
          <div className="w-full max-w-4xl bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20 shadow-2xl p-8">
            <h1 className="text-4xl font-bold text-white mb-6">About Us</h1>
            <div className="prose prose-invert">
              <p className="text-white/90">
                Shift Solutions is dedicated to bridging the gap between restaurants and staff,
                creating a seamless platform for shift management and staffing solutions.
              </p>
              {/* Add more content here */}
            </div>
          </div>
        </div>
      </div>
    </PageLayoutNoNav>
  );
}

export default AboutPage;