import { useEffect, useState } from "react";
import { User } from "lucide-react";
import PageLayout from "../../layouts/PageLayout";
import ProfileImgSection from "../../components/ProfileImgSection";
import PersonalSection from "../../components/PersonalSection";
import ResumeSection from "../../components/ResumeSection";
import VerificationSection from "../../components/VerificationSection";
import AccountSection from "../../components/AccountSection";
import PaymentSection from "../../components/PaymentSection";
import { getCurrentUser, getStaffProfile } from "../../api";
import waiterImg from "../../assets/img/waiter.jpg";



export default function StaffProfile() {
  const [userId, setUserId] = useState<number | null>(null);
  const [staffData, setStaffData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const staffMenu = [
    { path: "/staff/dashboard", label: "Dashboard" },
    { path: "/staff/marketplace", label: "Marketplace" },
    { path: "/staff/profile", label: "My Profile" },
  ];

  // Get current user ID and staff profile on component mount
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const user = await getCurrentUser();
        setUserId(user.id);
        
        // Fetch staff profile data
        const profile = await getStaffProfile(user.id);
        setStaffData({
          profile: {
            first_name: profile.first_name,
            last_name: profile.last_name,
            status: profile.status,
            imgSrc: profile.profile_image ? `http://localhost:8000${profile.profile_image}` : waiterImg,
          },
          personal: {
            address: "Not available", // This might need to be added to the backend
            date_of_birth: profile.date_of_birth,
            ssn: "***-**-****", // Hidden for security
            email: profile.email,
            phone: profile.phone,
            e_contact_name: "Not available", // Emergency contact info would come from backend
            e_contact_relation: "Not available",
            e_contact_phone: "Not available",
          },
          verification: {
            ssn: "***-**-****", // Hidden for security
            liq_license_number: "Not available", // This would come from backend
            liq_license_state: "Not available",
            liq_license_exp_date: "Not available",
          }
        });
      } catch (error) {
        console.error("Failed to get user data:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchUserData();
  }, []);
  if (loading) {
    return (
      <PageLayout className="bg-gradient-to-br from-slate-900 via-slate-800 to-amber-900" navbarConfig={{ menuItems: staffMenu }}>
        <div className="w-screen min-h-screen overflow-hidden px-4 pt-10 sm:px-6 lg:px-8 max-w-7xl mx-auto flex items-center justify-center">
          <p className="text-white text-lg">Loading profile...</p>
        </div>
      </PageLayout>
    );
  }

  if (!userId || !staffData) {
    return (
      <PageLayout className="bg-gradient-to-br from-slate-900 via-slate-800 to-amber-900" navbarConfig={{ menuItems: staffMenu }}>
        <div className="w-screen min-h-screen overflow-hidden px-4 pt-10 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <p className="text-red-300">Failed to load user profile. Please log in again.</p>
        </div>
      </PageLayout>
    );
  }

  const handleImageUpdate = (newImageUrl: string) => {
    setStaffData({
      ...staffData,
      profile: {
        ...staffData.profile,
        imgSrc: newImageUrl
      }
    });
  };

  return (
    <PageLayout className="bg-gradient-to-br from-slate-900 via-slate-800 to-amber-900" navbarConfig={{ menuItems: staffMenu }}>
      <div className="w-screen min-h-screen overflow-hidden px-6 sm:px-8 pt-10 pb-20">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-amber-500/20 backdrop-blur-sm border border-amber-400/30 rounded-full mb-4">
              <User className="w-4 h-4 text-amber-400" />
              <span className="text-amber-300 text-sm font-semibold">My Profile</span>
            </div>
            <h1 className="text-4xl font-bold text-white mb-2">Profile Settings</h1>
            <p className="text-slate-300 text-lg">Manage your personal information and credentials</p>
          </div>

          {/* Profile & Personal Info */}
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 mb-6">
            <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
              <User className="w-6 h-6 text-amber-400" />
              Personal Information
            </h2>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <ProfileImgSection profile={staffData.profile} userId={userId} onImageUpdate={handleImageUpdate} />
              <div className="lg:col-span-2">
                <PersonalSection personal={staffData.personal} userId={userId} />
              </div>
            </div>
          </div>

          {/* Resume Section */}
          <div className="mb-6">
            <ResumeSection userId={userId} />
          </div>

          {/* Verification Section */}
          <div className="mb-6">
            <VerificationSection verification={staffData.verification} userId={userId} />
          </div>

          {/* Payment Section */}
          <div className="mb-6">
            <PaymentSection />
          </div>

          {/* Account Section */}
          <div className="mb-6">
            <AccountSection />
          </div>
        </div>
      </div>
    </PageLayout>
  );
}

