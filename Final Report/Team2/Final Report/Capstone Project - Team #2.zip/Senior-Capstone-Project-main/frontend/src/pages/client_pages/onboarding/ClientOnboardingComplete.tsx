import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, FileText, Users, Settings, HelpCircle, ArrowRight, Sparkles } from 'lucide-react';
import OnboardingLayout from '../../../components/onboarding/OnboardingLayout';
import { getUserData } from '../../../utils/auth';
import axios from 'axios';

export default function ClientOnboardingComplete() {
  const navigate = useNavigate();
  const userData = getUserData();
  const [isCompleting, setIsCompleting] = useState(false);

  const handleGoToDashboard = async () => {
    setIsCompleting(true);

    try {
      const token = localStorage.getItem('access_token');

      // mark onboarding as complete in backend
      const response = await axios.post(
        `http://localhost:8000/auth/onboarding-complete`,
        {},
        { headers: { Authorization: `Bearer ${token}` } }
      );

      // update token with new one that has profile_complete=true
      if (response.data?.access_token) {
        localStorage.setItem('access_token', response.data.access_token);
      }

      // navigate to dashboard
      navigate('/client/post-shift');
    } catch (error) {
      console.error('failed to complete onboarding:', error);
      // continue to dashboard anyway
      navigate('/client/post-shift');
    }
  };

  // tutorial cards data
  const tutorialCards = [
    {
      icon: FileText,
      iconColor: 'text-teal-400',
      bgColor: 'bg-teal-500/10',
      borderColor: 'hover:border-teal-500/50',
      shadowColor: 'hover:shadow-teal-500/10',
      title: 'Post Your First Shift',
      description: 'Create detailed shift postings and start receiving applications from qualified staff.',
      link: '/client/post-shift'
    },
    {
      icon: Users,
      iconColor: 'text-amber-400',
      bgColor: 'bg-amber-500/10',
      borderColor: 'hover:border-amber-500/50',
      shadowColor: 'hover:shadow-amber-500/10',
      title: 'Review Applications',
      description: 'Browse staff profiles, review their experience, and hire the perfect fit for your team.',
      link: '/client/dashboard'
    },
    {
      icon: Settings,
      iconColor: 'text-blue-400',
      bgColor: 'bg-blue-500/10',
      borderColor: 'hover:border-blue-500/50',
      shadowColor: 'hover:shadow-blue-500/10',
      title: 'Manage Your Profile',
      description: 'Update your business info, preferences, and account settings anytime.',
      link: '/client/profile'
    },
    {
      icon: HelpCircle,
      iconColor: 'text-purple-400',
      bgColor: 'bg-purple-500/10',
      borderColor: 'hover:border-purple-500/50',
      shadowColor: 'hover:shadow-purple-500/10',
      title: 'Get Support',
      description: 'Have questions? Our support team is here to help you succeed.',
      link: '/contact'
    }
  ];

  return (
    <OnboardingLayout
      currentStep={3}
      totalSteps={3}
      stepLabels={['Welcome', 'Complete Profile', 'Get Started']}
      title="You're All Set!"
      subtitle="Your account is ready. Let's show you around."
      showBackButton={false}
    >
      <div className="space-y-8">
        {/* success message */}
        <div className="text-center py-6">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-teal-500 to-teal-600 rounded-full mb-6 shadow-lg shadow-teal-500/30 animate-pulse">
            <CheckCircle className="w-10 h-10 text-white" strokeWidth={2.5} />
          </div>

          <div className="inline-flex items-center gap-2 px-4 py-2 bg-green-500/10 border border-green-500/20 rounded-full mb-4">
            <Sparkles className="w-4 h-4 text-green-400" />
            <span className="text-green-400 text-sm font-medium">Profile Complete</span>
          </div>

          <p className="text-slate-300 text-lg leading-relaxed max-w-2xl mx-auto mt-4">
            Congratulations! You're ready to start finding great staff for your business.
            Here's what you can do next:
          </p>
        </div>

        {/* tutorial cards */}
        <div className="grid sm:grid-cols-2 gap-4">
          {tutorialCards.map((card, index) => {
            const Icon = card.icon;
            return (
              <div
                key={index}
                className={`group bg-gradient-to-br from-slate-700/40 to-slate-800/40 rounded-xl p-6 border border-slate-600/30 ${card.borderColor} transition-all duration-300 hover:shadow-lg ${card.shadowColor} hover:-translate-y-1 cursor-pointer`}
                onClick={() => card.link && navigate(card.link)}
              >
                <div className={`w-12 h-12 ${card.bgColor} rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                  <Icon className={`w-6 h-6 ${card.iconColor}`} />
                </div>
                <h3 className="text-white font-semibold mb-2 group-hover:text-teal-300 transition-colors">
                  {card.title}
                </h3>
                <p className="text-slate-400 text-sm leading-relaxed">
                  {card.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* resources section */}
        <div className="bg-gradient-to-br from-slate-700/20 to-slate-800/20 rounded-xl p-6 border border-slate-600/20">
          <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-teal-400" />
            Helpful Resources
          </h3>
          <div className="space-y-2">
            <a
              href="/faq"
              className="block text-slate-300 hover:text-teal-400 text-sm transition-colors group"
            >
              <span className="group-hover:underline">Frequently Asked Questions</span>
              <ArrowRight className="inline w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
            </a>
            <a
              href="/contact"
              className="block text-slate-300 hover:text-teal-400 text-sm transition-colors group"
            >
              <span className="group-hover:underline">Contact Support Team</span>
              <ArrowRight className="inline w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
            </a>
          </div>
        </div>

        {/* cta button */}
        <div className="pt-4">
          <button
            onClick={handleGoToDashboard}
            disabled={isCompleting}
            className="group w-full py-4 bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 disabled:from-slate-600 disabled:to-slate-700 text-white font-semibold rounded-xl transition-all duration-300 shadow-lg shadow-teal-500/30 hover:shadow-teal-500/50 hover:scale-105 disabled:scale-100 flex items-center justify-center gap-3"
          >
            <span>{isCompleting ? 'Loading Dashboard...' : 'Go to Dashboard'}</span>
            {!isCompleting && (
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
            )}
          </button>
        </div>
      </div>
    </OnboardingLayout>
  );
}
