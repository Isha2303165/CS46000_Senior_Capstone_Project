import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { HandPlatter, Eye, EyeOff, Check, X } from 'lucide-react';
import PageLayoutNoNav from "../layouts/PageLayoutNoNav";
import axios from 'axios';
import waiterImg from "../assets/img/waiter.jpg";

const ResetPassword: React.FC = () => {
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const token = new URLSearchParams(location.search).get('token');

  // Password validation rules
  const validatePassword = (password: string) => {
    const requirements = {
      length: password.length >= 8 && password.length <= 20,
      uppercase: /[A-Z]/.test(password),
      lowercase: /[a-z]/.test(password),
      number: /\d/.test(password),
      special: /[@$!%*?&#]/.test(password),
    };
    return requirements;
  };

  const passwordRequirements = validatePassword(password);
  const isPasswordValid = Object.values(passwordRequirements).every(Boolean);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Client-side validation
    if (!isPasswordValid) {
      setError("Password does not meet the requirements shown below.");
      return;
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    try {
      const response = await axios.post('http://localhost:8000/auth/reset-password', {
        token: token,
        new_password: password
      });

      setMessage('Password has been reset successfully. You can now login with your new password.');
      setError('');

      // Redirect to login page after 3 seconds
      setTimeout(() => {
        navigate('/login');
      }, 3000);
    } catch (err: any) {
      let errorMsg = 'Failed to reset password. The link may be expired or invalid.';

      if (err?.response?.data?.detail) {
        if (Array.isArray(err.response.data.detail)) {
          const validationErrors = err.response.data.detail
            .map((error: any) => error.msg || error.message)
            .join(", ");
          errorMsg = validationErrors;
        } else {
          errorMsg = err.response.data.detail;
        }
      }

      setError(errorMsg);
      setMessage('');
    }
  };

  if (!token) {
    return (
      <PageLayoutNoNav>
        <div className="min-h-screen flex items-center justify-center p-4">
          <div className="w-full max-w-6xl rounded-2xl shadow-2xl bg-slate-900/60 backdrop-blur-sm text-white">
            <div className="flex flex-col lg:flex-row">
              <div className="lg:w-2/5 p-8 lg:p-10 text-white">
                <div className="mb-8">
                  <p className="text-base text-red-400 mb-6">Invalid Reset Link</p>
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 bg-amber-500 rounded-full flex items-center justify-center">
                      <HandPlatter className="w-7 h-7 text-white" />
                    </div>
                    <h1 className="text-3xl font-bold">Shift Solutions</h1>
                  </div>
                  <p className="text-base font-semibold mb-8">
                    This password reset link is invalid or has expired. Please request a new password reset link.
                  </p>
                </div>

                <div className="space-y-6">
                  <p className="text-center text-gray-300 text-sm">
                    Need a new reset link?{" "}
                    <Link
                      to="/forgot-password"
                      className="text-amber-500 font-semibold hover:underline"
                    >
                      Return to Forgot Password
                    </Link>
                  </p>
                </div>
              </div>

              <div className="lg:w-4/5 relative">
                <div
                  className="absolute inset-0 bg-cover bg-center"
                  style={{ backgroundImage: `url(${waiterImg})` }}
                >
                  <div className="absolute inset-0 bg-gray-500/70"></div>
                </div>

                <div className="relative z-10 p-8 lg:p-16 h-full flex flex-col justify-center min-h-[400px] lg:min-h-0">
                  <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
                    Link Expired
                  </h2>
                  <p className="text-lg text-white/90 leading-relaxed">
                    This password reset link is no longer valid. For security reasons, reset links expire after a certain time.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </PageLayoutNoNav>
    );
  }

  return (
    <PageLayoutNoNav>

      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-6xl rounded-2xl shadow-2xl overflow-hidden bg-slate-900/60 backdrop-blur-sm text-white">
          <div className="flex flex-col lg:flex-row">
            <div className="lg:w-2/5 p-8 lg:p-10 text-white">
              <div className="mb-8">
                <p className="text-base text-green-500 mb-6">Reset Password</p>
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-amber-500 rounded-full flex items-center justify-center">
                    <HandPlatter className="w-7 h-7 text-white" />
                  </div>
                  <h1 className="text-3xl font-bold">Shift Solutions</h1>
                </div>
                <p className="text-base font-semibold mb-8">
                  Enter your new password below.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {message && (
                  <div className="p-3 rounded-xl bg-green-500/20 border border-green-500/30 text-green-300 text-sm">
                    {message}
                  </div>
                )}

                {error && (
                  <div className="p-3 rounded-xl bg-red-500/20 border border-red-500/30 text-red-300 text-sm">
                    {error}
                  </div>
                )}

                <div>
                  <div className="relative">
                    <input
                      type={showPassword ? "text" : "password"}
                      name="password"
                      placeholder="New Password"
                      value={password}
                      required
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full px-4 py-3 pr-12 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-amber-600 focus:bg-white/20 transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-white/60 hover:text-white/80"
                    >
                      {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                    </button>
                  </div>

                  {password && (
                    <div className="mt-2 space-y-1 text-sm">
                      <p className="text-white/70 mb-1">Password must contain:</p>
                      <div className="grid grid-cols-2 gap-1">
                        <div className={`flex items-center gap-1 ${passwordRequirements.length ? 'text-green-400' : 'text-red-400'}`}>
                          {passwordRequirements.length ? <Check size={14} /> : <X size={14} />}
                          <span>8-20 characters</span>
                        </div>
                        <div className={`flex items-center gap-1 ${passwordRequirements.uppercase ? 'text-green-400' : 'text-red-400'}`}>
                          {passwordRequirements.uppercase ? <Check size={14} /> : <X size={14} />}
                          <span>Uppercase letter</span>
                        </div>
                        <div className={`flex items-center gap-1 ${passwordRequirements.lowercase ? 'text-green-400' : 'text-red-400'}`}>
                          {passwordRequirements.lowercase ? <Check size={14} /> : <X size={14} />}
                          <span>Lowercase letter</span>
                        </div>
                        <div className={`flex items-center gap-1 ${passwordRequirements.number ? 'text-green-400' : 'text-red-400'}`}>
                          {passwordRequirements.number ? <Check size={14} /> : <X size={14} />}
                          <span>Number</span>
                        </div>
                        <div className={`flex items-center gap-1 ${passwordRequirements.special ? 'text-green-400' : 'text-red-400'} col-span-2`}>
                          {passwordRequirements.special ? <Check size={14} /> : <X size={14} />}
                          <span>Special character (@$!%*?&#)</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <div className="relative">
                    <input
                      type={showConfirmPassword ? "text" : "password"}
                      name="confirm-password"
                      placeholder="Confirm New Password"
                      value={confirmPassword}
                      required
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full px-4 py-3 pr-12 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-amber-600 focus:bg-white/20 transition-all"
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-white/60 hover:text-white/80"
                    >
                      {showConfirmPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                    </button>
                  </div>

                  {confirmPassword && (
                    <div className={`mt-2 flex items-center gap-1 text-sm ${password === confirmPassword ? 'text-green-400' : 'text-red-400'
                      }`}>
                      {password === confirmPassword ? <Check size={14} /> : <X size={14} />}
                      <span>Passwords match</span>
                    </div>
                  )}
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-blue-600 hover:bg-green-500 text-white font-semibold rounded-xl transition-all duration-300 shadow-md"
                >
                  Reset Password
                </button>

                <p className="text-center text-gray-300 text-sm">
                  Remember your password?{" "}
                  <Link to="/login" className="text-amber-500 font-semibold hover:underline">
                    Back to Login
                  </Link>
                </p>
              </form>
            </div>

            <div className="lg:w-4/5 relative">
              <div
                className="absolute inset-0 bg-cover bg-center"
                style={{ backgroundImage: `url(${waiterImg})` }}
              >
                <div className="absolute inset-0 bg-gray-500/70"></div>
              </div>

              <div className="relative z-10 p-8 lg:p-16 h-full flex flex-col justify-center min-h-[400px] lg:min-h-0">
                <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6 leading-tight">
                  Create New Password
                </h2>
                <p className="text-lg text-white/90 leading-relaxed">
                  Choose a strong password that meets all security requirements. Your new password will keep your account secure.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageLayoutNoNav>
  );
};

export default ResetPassword;