import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Calendar, 
  Users, 
  Briefcase, 
  TrendingUp, 
  Clock,
  CheckCircle,
  ArrowRight,
  Sparkles,
  Settings,
  FileText
} from 'lucide-react';
import ClientSidebar from '../../components/ClientSidebar';
import { getCurrentUser } from '../../api';

interface QuickStat {
  label: string;
  value: string | number;
  icon: React.ReactNode;
  trend?: string;
  color: string;
}

interface QuickAction {
  title: string;
  description: string;
  icon: React.ReactNode;
  link: string;
  color: string;
}

export default function ClientDashboard() {
  const [userName, setUserName] = useState<string>('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const user = await getCurrentUser();
        setUserName(user.email.split('@')[0]); // Use email username as fallback
      } catch (error) {
        console.error('Error fetching user data:', error);
        setUserName('Client');
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, []);

  const quickStats: QuickStat[] = [
    {
      label: 'Active Shifts',
      value: 12,
      icon: <Calendar className="w-6 h-6" />,
      trend: '+3 this week',
      color: 'from-teal-500 to-teal-600'
    },
    {
      label: 'Staff Hired',
      value: 24,
      icon: <Users className="w-6 h-6" />,
      trend: '+5 this month',
      color: 'from-blue-500 to-blue-600'
    },
    {
      label: 'Fill Rate',
      value: '94%',
      icon: <TrendingUp className="w-6 h-6" />,
      trend: '+2% vs last month',
      color: 'from-emerald-500 to-emerald-600'
    },
    {
      label: 'Avg Response',
      value: '2.5h',
      icon: <Clock className="w-6 h-6" />,
      trend: '15min faster',
      color: 'from-purple-500 to-purple-600'
    }
  ];

  const quickActions: QuickAction[] = [
    {
      title: 'Post New Shift',
      description: 'Create and publish a new staffing request',
      icon: <Briefcase className="w-8 h-8" />,
      link: '/client/post-shift',
      color: 'from-teal-500 to-teal-600'
    },
    {
      title: 'Browse Staff',
      description: 'View available professionals in the marketplace',
      icon: <Users className="w-8 h-8" />,
      link: '/client/marketplace',
      color: 'from-blue-500 to-blue-600'
    },
    {
      title: 'Staff Preferences',
      description: 'Set your hiring requirements and preferences',
      icon: <Settings className="w-8 h-8" />,
      link: '/client/staff-preferences',
      color: 'from-purple-500 to-purple-600'
    },
    {
      title: 'Manage Profile',
      description: 'Update your business information and settings',
      icon: <FileText className="w-8 h-8" />,
      link: '/client/profile',
      color: 'from-amber-500 to-amber-600'
    }
  ];

  const upcomingShifts = [
    { date: 'Dec 10', time: '5:00 PM - 11:00 PM', role: 'Server', status: 'Filled' },
    { date: 'Dec 11', time: '6:00 AM - 2:00 PM', role: 'Barista', status: 'Pending' },
    { date: 'Dec 12', time: '4:00 PM - 12:00 AM', role: 'Bartender', status: 'Filled' },
  ];

  if (loading) {
    return (
      <div className="min-h-screen w-screen overflow-x-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-teal-900">
        <div className="min-h-screen w-full flex relative">
          <ClientSidebar />
          <main className="flex-1 overflow-auto w-full flex items-center justify-center">
            <div className="text-white text-lg">Loading dashboard...</div>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen w-screen overflow-x-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-teal-900">
      <div className="min-h-screen w-full flex relative">
        <ClientSidebar />
        
        {/* Main Content Area */}
        <main className="flex-1 overflow-auto w-full">
          <div className="max-w-7xl mx-auto p-6 sm:p-8 pt-20">
            
            {/* Welcome Header */}
            <div className="mb-8">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-teal-500/20 backdrop-blur-sm border border-teal-400/30 rounded-full mb-4">
                <Sparkles className="w-4 h-4 text-teal-400" />
                <span className="text-teal-300 text-sm font-semibold">Dashboard</span>
              </div>
              <h1 className="text-4xl font-bold text-white mb-2">
                Welcome back, {userName}!
              </h1>
              <p className="text-slate-300 text-lg">
                Here's what's happening with your staffing today
              </p>
            </div>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {quickStats.map((stat, index) => (
                <div
                  key={index}
                  className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 hover:bg-white/15 transition-all duration-300 hover:scale-105 group"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className={`p-3 rounded-xl bg-gradient-to-br ${stat.color} shadow-lg`}>
                      {stat.icon}
                    </div>
                  </div>
                  <h3 className="text-3xl font-bold text-white mb-1">{stat.value}</h3>
                  <p className="text-slate-300 text-sm font-medium mb-2">{stat.label}</p>
                  {stat.trend && (
                    <p className="text-teal-400 text-xs font-semibold">{stat.trend}</p>
                  )}
                </div>
              ))}
            </div>

            {/* Quick Actions */}
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                <Briefcase className="w-6 h-6 text-teal-400" />
                Quick Actions
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {quickActions.map((action, index) => (
                  <Link
                    key={index}
                    to={action.link}
                    className="group bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 hover:bg-white/15 transition-all duration-300 hover:scale-105 hover:shadow-2xl"
                  >
                    <div className="flex items-start gap-4">
                      <div className={`p-3 rounded-xl bg-gradient-to-br ${action.color} shadow-lg group-hover:scale-110 transition-transform`}>
                        {action.icon}
                      </div>
                      <div className="flex-1">
                        <h3 className="text-xl font-bold text-white mb-1 group-hover:text-teal-300 transition-colors flex items-center gap-2">
                          {action.title}
                          <ArrowRight className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-all group-hover:translate-x-1" />
                        </h3>
                        <p className="text-slate-300 text-sm">{action.description}</p>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            {/* Upcoming Shifts */}
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                  <Calendar className="w-6 h-6 text-teal-400" />
                  Upcoming Shifts
                </h2>
                <Link
                  to="/client/post-shift"
                  className="text-teal-400 hover:text-teal-300 text-sm font-semibold flex items-center gap-1 transition-colors"
                >
                  View All
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
              
              <div className="space-y-3">
                {upcomingShifts.map((shift, index) => (
                  <div
                    key={index}
                    className="bg-white/5 border border-white/10 rounded-xl p-4 hover:bg-white/10 transition-all"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="text-center">
                          <p className="text-2xl font-bold text-white">{shift.date.split(' ')[1]}</p>
                          <p className="text-xs text-slate-400 uppercase">{shift.date.split(' ')[0]}</p>
                        </div>
                        <div className="h-12 w-px bg-white/20" />
                        <div>
                          <p className="text-white font-semibold">{shift.role}</p>
                          <p className="text-slate-300 text-sm">{shift.time}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {shift.status === 'Filled' ? (
                          <span className="flex items-center gap-1 px-3 py-1 bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 rounded-lg text-sm font-semibold">
                            <CheckCircle className="w-4 h-4" />
                            Filled
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 px-3 py-1 bg-amber-500/20 border border-amber-500/30 text-amber-400 rounded-lg text-sm font-semibold">
                            <Clock className="w-4 h-4" />
                            Pending
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
