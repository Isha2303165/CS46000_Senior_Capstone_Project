import { Building2, Users, Calendar, TrendingUp, CheckCircle, ArrowRight, Sparkles, Zap, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';
import PageLayout from '../layouts/PageLayout';

function LandingPage() {
  const landingMenu = [
    { path: "/about", label: "About Us" },
    { path: "/faq", label: "FAQ" },
    { path: "/contact", label: "Contact Us" }
  ];

  return (
    <PageLayout navbarConfig={{ menuItems: landingMenu }}>
      <div className="min-h-screen w-full overflow-auto">
        {/* Hero Section */}
        <div className="max-w-7xl mx-auto px-6 py-20 md:py-32">
          <div className="text-center mb-20">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-500/10 to-amber-500/10 border border-teal-500/20 rounded-full mb-8 backdrop-blur-sm">
              <Sparkles className="w-4 h-4 text-teal-400" />
              <span className="text-teal-300 text-sm font-medium">The Future of Hospitality Staffing</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-white text-5xl md:text-7xl font-bold mb-6 leading-tight">
              Connect. Staff. Thrive.
            </h1>
            <p className="text-white/80 text-xl md:text-2xl max-w-4xl mx-auto leading-relaxed mb-4">
              The all-in-one platform connecting restaurants with qualified hospitality professionals
            </p>
            <p className="text-white/60 text-lg max-w-3xl mx-auto">
              Fill shifts instantly or find flexible work — all in one place
            </p>
          </div>

          {/* Portal Cards */}
          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto mb-24">
            {/* Clients Card */}
            <div className="group relative bg-gradient-to-br from-slate-800/90 to-slate-900/90 backdrop-blur-sm rounded-3xl p-8 shadow-2xl border border-teal-500/20 hover:border-teal-500/40 transition-all duration-500 hover:-translate-y-2 hover:shadow-teal-500/20">
              {/* Glow effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-teal-500/0 to-teal-500/0 group-hover:from-teal-500/5 group-hover:to-transparent rounded-3xl transition-all duration-500" />
              
              <div className="relative">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-3xl font-bold text-white">For Restaurants</h2>
                  <div className="w-14 h-14 bg-gradient-to-br from-teal-400 to-teal-600 rounded-2xl flex items-center justify-center shadow-lg shadow-teal-500/30 group-hover:scale-110 transition-transform duration-300">
                    <Building2 className="w-7 h-7 text-white" />
                  </div>
                </div>

                <p className="text-white/70 text-base mb-8 leading-relaxed">
                  Post shifts, find vetted professionals, and build your dream team with ease
                </p>

                {/* Features */}
                <div className="space-y-3 mb-8">
                  <div className="flex items-center gap-3">
                    <div className="w-5 h-5 bg-teal-500/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <CheckCircle className="w-3 h-3 text-teal-400" />
                    </div>
                    <span className="text-white/80 text-sm">Post shifts in under 2 minutes</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-5 h-5 bg-teal-500/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <CheckCircle className="w-3 h-3 text-teal-400" />
                    </div>
                    <span className="text-white/80 text-sm">Access pre-screened professionals</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-5 h-5 bg-teal-500/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <CheckCircle className="w-3 h-3 text-teal-400" />
                    </div>
                    <span className="text-white/80 text-sm">Fill last-minute coverage gaps</span>
                  </div>
                </div>

                <Link
                  to="/client/signup"
                  className="group/btn flex items-center justify-center gap-2 w-full bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white py-4 rounded-xl font-semibold transition-all duration-300 shadow-lg shadow-teal-500/30 hover:shadow-teal-500/50"
                >
                  Get Started
                  <ArrowRight className="w-5 h-5 group-hover/btn:translate-x-1 transition-transform" />
                </Link>
              </div>
            </div>

            {/* Staff Card */}
            <div className="group relative bg-gradient-to-br from-slate-800/90 to-slate-900/90 backdrop-blur-sm rounded-3xl p-8 shadow-2xl border border-amber-500/20 hover:border-amber-500/40 transition-all duration-500 hover:-translate-y-2 hover:shadow-amber-500/20">
              {/* Glow effect */}
              <div className="absolute inset-0 bg-gradient-to-br from-amber-500/0 to-amber-500/0 group-hover:from-amber-500/5 group-hover:to-transparent rounded-3xl transition-all duration-500" />
              
              <div className="relative">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-3xl font-bold text-white">For Staff</h2>
                  <div className="w-14 h-14 bg-gradient-to-br from-amber-400 to-amber-600 rounded-2xl flex items-center justify-center shadow-lg shadow-amber-500/30 group-hover:scale-110 transition-transform duration-300">
                    <Users className="w-7 h-7 text-white" />
                  </div>
                </div>

                <p className="text-white/70 text-base mb-8 leading-relaxed">
                  Browse flexible shifts, build your schedule, and grow your hospitality career
                </p>

                {/* Features */}
                <div className="space-y-3 mb-8">
                  <div className="flex items-center gap-3">
                    <div className="w-5 h-5 bg-amber-500/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <CheckCircle className="w-3 h-3 text-amber-400" />
                    </div>
                    <span className="text-white/80 text-sm">Work when and where you want</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-5 h-5 bg-amber-500/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <CheckCircle className="w-3 h-3 text-amber-400" />
                    </div>
                    <span className="text-white/80 text-sm">Browse hundreds of local shifts</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-5 h-5 bg-amber-500/20 rounded-full flex items-center justify-center flex-shrink-0">
                      <CheckCircle className="w-3 h-3 text-amber-400" />
                    </div>
                    <span className="text-white/80 text-sm">Get paid quickly and securely</span>
                  </div>
                </div>

                <Link 
                  to="/staff/signup"
                  className="group/btn flex items-center justify-center gap-2 w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white py-4 rounded-xl font-semibold transition-all duration-300 shadow-lg shadow-amber-500/30 hover:shadow-amber-500/50"
                > 
                  Get Started
                  <ArrowRight className="w-5 h-5 group-hover/btn:translate-x-1 transition-transform" />
                </Link>
              </div>
            </div>
          </div>

          {/* Stats Section */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-5xl mx-auto mb-24">
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-teal-400 to-teal-600 bg-clip-text text-transparent mb-2">
                10K+
              </div>
              <div className="text-white/60 text-sm">Active Staff</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-amber-400 to-amber-600 bg-clip-text text-transparent mb-2">
                500+
              </div>
              <div className="text-white/60 text-sm">Restaurants</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-teal-400 to-amber-400 bg-clip-text text-transparent mb-2">
                98%
              </div>
              <div className="text-white/60 text-sm">Fill Rate</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-amber-400 to-teal-400 bg-clip-text text-transparent mb-2">
                24/7
              </div>
              <div className="text-white/60 text-sm">Support</div>
            </div>
          </div>

          {/* Features Grid */}
          <div className="max-w-6xl mx-auto mb-24">
            <div className="text-center mb-16">
              <h2 className="text-white text-4xl md:text-5xl font-bold mb-4">
                Why Choose Shift Solutions?
              </h2>
              <p className="text-white/70 text-lg max-w-2xl mx-auto">
                Everything you need to manage staffing efficiently, all in one platform
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {/* Feature 1 */}
              <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50 hover:border-teal-500/30 transition-all duration-300">
                <div className="w-12 h-12 bg-gradient-to-br from-teal-500/20 to-teal-600/20 rounded-xl flex items-center justify-center mb-4">
                  <Zap className="w-6 h-6 text-teal-400" />
                </div>
                <h3 className="text-white text-xl font-semibold mb-2">Lightning Fast</h3>
                <p className="text-white/60 text-sm">
                  Post shifts or find work in minutes. Our streamlined process gets you connected instantly.
                </p>
              </div>

              {/* Feature 2 */}
              <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50 hover:border-amber-500/30 transition-all duration-300">
                <div className="w-12 h-12 bg-gradient-to-br from-amber-500/20 to-amber-600/20 rounded-xl flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-amber-400" />
                </div>
                <h3 className="text-white text-xl font-semibold mb-2">Verified & Secure</h3>
                <p className="text-white/60 text-sm">
                  All staff members are vetted. Payments are secure. Your peace of mind is guaranteed.
                </p>
              </div>

              {/* Feature 3 */}
              <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 border border-slate-700/50 hover:border-teal-500/30 transition-all duration-300">
                <div className="w-12 h-12 bg-gradient-to-br from-teal-500/20 to-amber-500/20 rounded-xl flex items-center justify-center mb-4">
                  <TrendingUp className="w-6 h-6 text-teal-400" />
                </div>
                <h3 className="text-white text-xl font-semibold mb-2">Grow Together</h3>
                <p className="text-white/60 text-sm">
                  Build lasting relationships. Find your favorite venues or trusted staff for repeat bookings.
                </p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </PageLayout>
  );
}

export default LandingPage;
