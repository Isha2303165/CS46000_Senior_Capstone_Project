import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, X, User, Phone, Calendar, Shield } from 'lucide-react';
import OnboardingLayout from '../../../components/onboarding/OnboardingLayout';
import { getUserData } from '../../../utils/auth';
import axios from 'axios';

export default function StaffOnboardingProfile() {
  const navigate = useNavigate();
  const userData = getUserData();

  const [formData, setFormData] = useState({
    first_name: '',
    middle_name: '',
    last_name: '',
    date_of_birth: '',
    SSN_hashed: '',
    phone: '',
    short_bio: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // phone validation
  const validatePhone = (phone: string) => {
    const phoneRegex = /^\d{3}-\d{3}-\d{4}$/;
    return phoneRegex.test(phone);
  };

  // ssn validation
  const validateSSN = (ssn: string) => {
    if (!ssn) return false; // required
    const ssnRegex = /^\d{3}-\d{2}-\d{4}$/;
    return ssnRegex.test(ssn);
  };

  // age validation (must be 18+)
  const validateAge = (dob: string) => {
    if (!dob) return false;
    const today = new Date();
    const birthDate = new Date(dob);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age >= 18;
  };

  const isPhoneValid = validatePhone(formData.phone);
  const isSSNValid = validateSSN(formData.SSN_hashed);
  const isAgeValid = validateAge(formData.date_of_birth);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    let value = e.target.value;

    // auto-format phone
    if (e.target.name === 'phone') {
      value = value.replace(/\D/g, '');
      if (value.length >= 7) {
        value = value.slice(0, 3) + '-' + value.slice(3, 6) + '-' + value.slice(6, 10);
      } else if (value.length >= 4) {
        value = value.slice(0, 3) + '-' + value.slice(3);
      }
    }

    // auto-format SSN
    if (e.target.name === 'SSN_hashed') {
      value = value.replace(/\D/g, '');
      if (value.length >= 6) {
        value = value.slice(0, 3) + '-' + value.slice(3, 5) + '-' + value.slice(5, 9);
      } else if (value.length >= 4) {
        value = value.slice(0, 3) + '-' + value.slice(3);
      }
    }

    setFormData({ ...formData, [e.target.name]: value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    // validate required fields
    if (!formData.first_name || !formData.last_name || !formData.date_of_birth ||
        !formData.SSN_hashed || !formData.phone) {
      setErrorMessage('Please fill in all required fields');
      return;
    }

    if (!isPhoneValid) {
      setErrorMessage('Please enter a valid phone number (XXX-XXX-XXXX)');
      return;
    }

    if (!isSSNValid) {
      setErrorMessage('Please enter a valid SSN (XXX-XX-XXXX)');
      return;
    }

    if (!isAgeValid) {
      setErrorMessage('You must be at least 18 years old to register');
      return;
    }

    setIsSubmitting(true);

    try {
      const token = localStorage.getItem('access_token');

      // update profile with new data
      const response = await axios.put(
        `http://localhost:8000/profile/staff/${userData?.user_id}`,
        formData,
        { headers: { Authorization: `Bearer ${token}` } }
      );

      // if profile is complete, navigate to final step
      if (response.data.profile_complete) {
        navigate('/staff/onboarding/complete');
      } else {
        setErrorMessage('Profile update succeeded but some required fields may be missing');
      }
    } catch (error: any) {
      console.error('failed to update profile:', error);
      setErrorMessage(error?.response?.data?.detail || 'Failed to update profile. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <OnboardingLayout
      currentStep={2}
      totalSteps={3}
      stepLabels={['Welcome', 'Complete Profile', 'Get Started']}
      title="Complete Your Profile"
      subtitle="Help restaurants get to know you better."
      showBackButton={true}
      onBack={() => navigate('/staff/onboarding/welcome')}
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* error message */}
        {errorMessage && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
            <p className="text-red-400 text-sm">{errorMessage}</p>
          </div>
        )}

        {/* personal information section */}
        <div className="bg-slate-800/40 rounded-xl p-6 border border-slate-600/30">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-teal-500/10 rounded-lg flex items-center justify-center">
              <User className="w-5 h-5 text-teal-400" />
            </div>
            <h3 className="text-lg font-semibold text-white">Personal Information</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* first name */}
            <div>
              <label className="block text-sm font-medium text-white/90 mb-2">
                First Name <span className="text-red-400">*</span>
              </label>
              <input
                type="text"
                name="first_name"
                value={formData.first_name}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-lg bg-slate-700/50 text-white placeholder-slate-400 border border-slate-600/50 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition"
                placeholder="Enter first name"
                required
              />
            </div>

            {/* middle name */}
            <div>
              <label className="block text-sm font-medium text-white/90 mb-2">
                Middle Name <span className="text-slate-400 text-xs">(Optional)</span>
              </label>
              <input
                type="text"
                name="middle_name"
                value={formData.middle_name}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-lg bg-slate-700/50 text-white placeholder-slate-400 border border-slate-600/50 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition"
                placeholder="Enter middle name"
              />
            </div>

            {/* last name */}
            <div>
              <label className="block text-sm font-medium text-white/90 mb-2">
                Last Name <span className="text-red-400">*</span>
              </label>
              <input
                type="text"
                name="last_name"
                value={formData.last_name}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-lg bg-slate-700/50 text-white placeholder-slate-400 border border-slate-600/50 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition"
                placeholder="Enter last name"
                required
              />
            </div>

            {/* date of birth */}
            <div>
              <label className="block text-sm font-medium text-white/90 mb-2">
                Date of Birth <span className="text-red-400">*</span>
              </label>
              <div className="relative">
                <input
                  type="date"
                  name="date_of_birth"
                  value={formData.date_of_birth}
                  onChange={handleChange}
                  max={new Date(new Date().setFullYear(new Date().getFullYear() - 18)).toISOString().split('T')[0]}
                  className="w-full px-4 py-3 rounded-lg bg-slate-700/50 text-white placeholder-slate-400 border border-slate-600/50 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition"
                  required
                />
                {formData.date_of_birth && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2">
                    {isAgeValid ? (
                      <Check className="w-5 h-5 text-green-400" />
                    ) : (
                      <X className="w-5 h-5 text-red-400" />
                    )}
                  </div>
                )}
              </div>
              {formData.date_of_birth && !isAgeValid && (
                <p className="text-red-400 text-xs mt-1">Must be 18 years or older</p>
              )}
            </div>
          </div>
        </div>

        {/* contact information section */}
        <div className="bg-slate-800/40 rounded-xl p-6 border border-slate-600/30">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-amber-500/10 rounded-lg flex items-center justify-center">
              <Phone className="w-5 h-5 text-amber-400" />
            </div>
            <h3 className="text-lg font-semibold text-white">Contact Information</h3>
          </div>

          <div>
            <label className="block text-sm font-medium text-white/90 mb-2">
              Phone Number <span className="text-red-400">*</span>
            </label>
            <div className="relative">
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-lg bg-slate-700/50 text-white placeholder-slate-400 border border-slate-600/50 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition"
                placeholder="XXX-XXX-XXXX"
                required
              />
              {formData.phone && (
                <div className="absolute right-3 top-1/2 -translate-y-1/2">
                  {isPhoneValid ? (
                    <Check className="w-5 h-5 text-green-400" />
                  ) : (
                    <X className="w-5 h-5 text-red-400" />
                  )}
                </div>
              )}
            </div>
            {formData.phone && !isPhoneValid && (
              <p className="text-red-400 text-xs mt-1">Format: XXX-XXX-XXXX</p>
            )}
          </div>
        </div>

        {/* verification section */}
        <div className="bg-slate-800/40 rounded-xl p-6 border border-slate-600/30">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-blue-500/10 rounded-lg flex items-center justify-center">
              <Shield className="w-5 h-5 text-blue-400" />
            </div>
            <h3 className="text-lg font-semibold text-white">Verification</h3>
          </div>

          <div>
            <label className="block text-sm font-medium text-white/90 mb-2">
              Social Security Number <span className="text-red-400">*</span>
            </label>
            <div className="relative">
              <input
                type="text"
                name="SSN_hashed"
                value={formData.SSN_hashed}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-lg bg-slate-700/50 text-white placeholder-slate-400 border border-slate-600/50 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition"
                placeholder="XXX-XX-XXXX"
                required
              />
              {formData.SSN_hashed && (
                <div className="absolute right-3 top-1/2 -translate-y-1/2">
                  {isSSNValid ? (
                    <Check className="w-5 h-5 text-green-400" />
                  ) : (
                    <X className="w-5 h-5 text-red-400" />
                  )}
                </div>
              )}
            </div>
            {formData.SSN_hashed && !isSSNValid && (
              <p className="text-red-400 text-xs mt-1">Format: XXX-XX-XXXX</p>
            )}
            <p className="text-slate-400 text-xs mt-2">
              <Shield className="w-3 h-3 inline mr-1" />
              Your SSN is encrypted and securely stored
            </p>
          </div>
        </div>

        {/* bio section */}
        <div className="bg-slate-800/40 rounded-xl p-6 border border-slate-600/30">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-purple-500/10 rounded-lg flex items-center justify-center">
              <User className="w-5 h-5 text-purple-400" />
            </div>
            <h3 className="text-lg font-semibold text-white">About You</h3>
          </div>

          <div>
            <label className="block text-sm font-medium text-white/90 mb-2">
              Short Bio <span className="text-slate-400 text-xs">(Optional)</span>
            </label>
            <textarea
              name="short_bio"
              value={formData.short_bio}
              onChange={handleChange}
              rows={4}
              className="w-full px-4 py-3 rounded-lg bg-slate-700/50 text-white placeholder-slate-400 border border-slate-600/50 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition resize-none"
              placeholder="Tell restaurants about your experience and what makes you a great team member..."
            />
            <p className="text-slate-400 text-xs mt-2">
              Share your experience, skills, and what you're looking for
            </p>
          </div>
        </div>

        {/* submit button */}
        <div className="pt-4">
          <button
            type="submit"
            disabled={isSubmitting || !isPhoneValid || !isSSNValid || !isAgeValid}
            className="w-full py-4 px-6 bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white font-semibold rounded-xl transition-all duration-300 shadow-lg shadow-teal-500/30 hover:shadow-teal-500/50 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:shadow-teal-500/30"
          >
            {isSubmitting ? 'Saving Profile...' : 'Continue'}
          </button>
        </div>
      </form>
    </OnboardingLayout>
  );
}
