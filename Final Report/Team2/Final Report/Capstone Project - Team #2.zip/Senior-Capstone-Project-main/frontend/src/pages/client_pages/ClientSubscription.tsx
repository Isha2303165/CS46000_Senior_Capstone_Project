import { useState } from 'react';
import { subscribeClient } from '../../api';
import PageLayout from '../../layouts/PageLayout';

interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  description: string;
  features: string[];
}

const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: 'standard',
    name: 'Standard Plan',
    price: 49.95,
    description: 'Essential features for managing your restaurant staff',
    features: [
      'Full access to staff marketplace',
      'Shift scheduling & management',
      'Staff profile viewing',
      'Basic reporting & analytics',
      'Email support',
      'Secure payment processing'
    ]
  },
  {
    id: 'premium',
    name: 'Premium Plan',
    price: 69.95,
    description: 'Enhanced service with dedicated support',
    features: [
      'Everything in Standard Plan',
      'White Glove Service',
      'Dedicated account manager',
      'Priority customer support',
      'Advanced analytics & insights',
      'Custom staff matching assistance',
      'Onboarding assistance'
    ]
  }
];

export default function ClientSubscription() {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<Record<string, boolean>>({});

  const handleSubscribe = async (planId: string) => {
    setIsLoading((s) => ({ ...s, [planId]: true }));
    try {
      const subscriptionData = {
        plan_id: planId,
        // Add any additional subscription data as needed
      };
      
      const result = await subscribeClient(subscriptionData);
      console.log('Subscription success:', result);
      alert(`Successfully subscribed to ${planId} plan!`);
    } catch (error: any) {
      console.error('Subscription error:', error);
      const detail = error?.response?.data?.detail || error?.message || 'Error processing subscription';
      alert(detail);
    } finally {
      setIsLoading((s) => ({ ...s, [planId]: false }));
    }
  };

  return (
    <div className="min-h-screen w-screen overflow-x-hidden">
      <PageLayout navbarConfig={{
        menuItems: [
          { path: "/about", label: "About Us" },
          { path: "/faq", label: "FAQ" },
          { path: "/contact", label: "Contact Us" }
        ],
        authLinks: {
          login: { path: "/logout", text: "Log Out" }
        }
      }}>
        <div className="max-w-7xl mx-auto px-6 py-16">
        {/* Title */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Find the Right Subscription for You
          </h1>
          <p className="text-white/80 text-lg max-w-2xl mx-auto">
            Choose the perfect plan for your restaurant's needs and start managing your staff more effectively.
          </p>
        </div>

        {/* Subscription Cards */}
        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto items-stretch">
          {subscriptionPlans.map((plan, index) => (
            <div
              key={plan.id}
              className={`bg-white rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 flex flex-col h-full ${
                selectedPlan === plan.id ? 'ring-4 ring-teal-500' : ''
              } ${index === 1 ? 'md:scale-105 border-4 border-teal-500/30' : ''}`}
            >
              {index === 1 && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-teal-500 text-white px-4 py-1 rounded-full text-sm font-semibold">
                  RECOMMENDED
                </div>
              )}
              
              {/* Plan Header */}
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                <div className="mb-4">
                  <span className="text-5xl font-bold text-gray-900">${plan.price}</span>
                  <span className="text-gray-500 ml-1">/month</span>
                </div>
                <p className="text-gray-600">{plan.description}</p>
              </div>

              {/* Features */}
              <div className="mb-8 flex-1">
                <ul className="space-y-4">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start text-gray-700">
                      <svg className="w-6 h-6 text-teal-500 mr-3 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                      <span className={featureIndex === 1 && index === 1 ? 'font-semibold text-teal-700' : ''}>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Subscribe Button */}
              <div className="mt-auto">
                <button
                  onClick={() => handleSubscribe(plan.id)}
                  disabled={Boolean(isLoading[plan.id])}
                  className={`w-full py-4 px-6 rounded-lg font-semibold transition-all duration-300 ${
                    index === 0
                      ? 'bg-gradient-to-r from-slate-600 to-slate-700 hover:from-slate-700 hover:to-slate-800 text-white shadow-lg hover:shadow-xl'
                      : 'bg-gradient-to-r from-teal-600 to-teal-700 hover:from-teal-700 hover:to-teal-800 text-white shadow-lg hover:shadow-xl'
                  } ${Boolean(isLoading[plan.id]) ? 'opacity-50 cursor-not-allowed' : 'hover:-translate-y-0.5'}`}
                >
                  {Boolean(isLoading[plan.id]) ? 'Processing...' : `Get Started with ${plan.name}`}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Additional Info */}
        <div className="text-center mt-16">
          <p className="text-white/70 text-sm">
            All plans include a 30-day money-back guarantee. Cancel anytime.
          </p>
        </div>
        </div>
      </PageLayout>
    </div>
  );
}
