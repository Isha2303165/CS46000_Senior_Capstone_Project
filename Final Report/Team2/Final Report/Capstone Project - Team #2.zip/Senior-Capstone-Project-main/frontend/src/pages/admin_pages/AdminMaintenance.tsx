import { Wrench, RefreshCw, Database } from "lucide-react";
import PageLayout from "../../layouts/PageLayout";
import { restartServices, databaseCleanup } from "../admin_api";

function AdminMaintenance() {
  const adminMenu = [
    { path: "/admin/dashboard", label: "Dashboard" },
    { path: "/admin/accounts", label: "Accounts" },
    { path: "/admin/feedback", label: "Feedback" },
    { path: "/admin/maintenance", label: "Maintenance" },
  ];

  const handleRestart = async () => {
    const message = await restartServices();
    alert(message);
  };

  const handleCleanup = async () => {
    const message = await databaseCleanup();
    alert(message);
  };

  return (
    <PageLayout navbarConfig={{ menuItems: adminMenu }}>
      <div className="min-h-screen px-6 py-20 max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-5">
          <Wrench className="text-teal-400 w-10 h-10" />
          <h1 className="text-white text-4xl font-bold">System Maintenance</h1>
        </div>
         <p className="text-white/70 mb-10">
            Perform system-level maintenance tasks such as restarting services or cleaning up the database.
          </p>
        <div className="space-y-8">
          
          {/* Restart Services */}
          <button
            onClick={handleRestart}
            className="w-full bg-slate-900/70 p-6 rounded-2xl border border-slate-700/50 hover:border-teal-500/40 transition-all flex items-center justify-between"
          >
            <div>
              <h3 className="text-white font-semibold text-xl text-left">
                Restart Backend Services
              </h3>
              <p className="text-white/60 text-sm">
                Refresh workers, queues, and schedulers
              </p>
            </div>
            <RefreshCw className="text-teal-400 w-8 h-8" />
          </button>

          {/* Database Cleanup */}
          <button
            onClick={handleCleanup}
            className="w-full bg-slate-900/70 p-6 rounded-2xl border border-slate-700/50 hover:border-amber-500/40 transition-all flex items-center justify-between"
          >
            <div>
              <h3 className="text-white font-semibold text-xl text-left">
                Database Cleanup
              </h3>
              <p className="text-white/60 text-sm">
                Clear inactive users, expired tokens, unused logs
              </p>
            </div>
            <Database className="text-amber-400 w-8 h-8" />
          </button>

        </div>
      </div>
    </PageLayout>
  );
}

export default AdminMaintenance;
