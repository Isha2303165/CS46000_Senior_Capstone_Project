import React from 'react';
import { Link } from 'react-router-dom';
import PageLayoutNoNav from "../layouts/PageLayoutNoNav";

function FAQPage() {
  return (
    <PageLayoutNoNav>
      <div className="h-screen">
        <div className="min-h-full w-full flex items-center justify-center p-6">
          <div className="w-full max-w-4xl bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20 shadow-2xl p-8">
            <h1 className="text-4xl font-bold text-white mb-6">Frequently Asked Questions</h1>
            <div className="space-y-6">
              <div className="border-b border-white/10 pb-4">
                <h3 className="text-xl font-semibold text-white mb-2">How does Shift Solutions work?</h3>
                <p className="text-white/90">
                  Our platform connects restaurants with available staff, making it easy to fill shifts
                  and manage scheduling needs efficiently.
                </p>
              </div>
              {/* Add more FAQ items here */}
            </div>
          </div>
        </div>
      </div>
    </PageLayoutNoNav>
  );
}

export default FAQPage;