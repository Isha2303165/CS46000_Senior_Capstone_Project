import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Check, X, Building2, Phone, MapPin, Globe } from 'lucide-react';
import OnboardingLayout from '../../../components/onboarding/OnboardingLayout';
import { getUserData } from '../../../utils/auth';
import axios from 'axios';

export default function ClientOnboardingProfile() {
  const navigate = useNavigate();
  const userData = getUserData();

  const [formData, setFormData] = useState({
    restaurant_type: '',
    phone: '',
    address_line1: '',
    address_line2: '',
    city: '',
    state: '',
    zipcode: '',
    website_url: '',
    EIN_hashed: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // phone validation
  const validatePhone = (phone: string) => {
    const phoneRegex = /^\d{3}-\d{3}-\d{4}$/;
    return phoneRegex.test(phone);
  };

  // ein validation
  const validateEIN = (ein: string) => {
    if (!ein) return false; // required
    const einRegex = /^\d{2}-\d{7}$/;
    return einRegex.test(ein);
  };

  const isPhoneValid = validatePhone(formData.phone);
  const isEINValid = validateEIN(formData.EIN_hashed);

  // us states list
  const usStates = [
    { value: '', label: 'Select State' },
    { value: 'AL', label: 'Alabama' }, { value: 'AK', label: 'Alaska' }, { value: 'AZ', label: 'Arizona' },
    { value: 'AR', label: 'Arkansas' }, { value: 'CA', label: 'California' }, { value: 'CO', label: 'Colorado' },
    { value: 'CT', label: 'Connecticut' }, { value: 'DE', label: 'Delaware' }, { value: 'FL', label: 'Florida' },
    { value: 'GA', label: 'Georgia' }, { value: 'HI', label: 'Hawaii' }, { value: 'ID', label: 'Idaho' },
    { value: 'IL', label: 'Illinois' }, { value: 'IN', label: 'Indiana' }, { value: 'IA', label: 'Iowa' },
    { value: 'KS', label: 'Kansas' }, { value: 'KY', label: 'Kentucky' }, { value: 'LA', label: 'Louisiana' },
    { value: 'ME', label: 'Maine' }, { value: 'MD', label: 'Maryland' }, { value: 'MA', label: 'Massachusetts' },
    { value: 'MI', label: 'Michigan' }, { value: 'MN', label: 'Minnesota' }, { value: 'MS', label: 'Mississippi' },
    { value: 'MO', label: 'Missouri' }, { value: 'MT', label: 'Montana' }, { value: 'NE', label: 'Nebraska' },
    { value: 'NV', label: 'Nevada' }, { value: 'NH', label: 'New Hampshire' }, { value: 'NJ', label: 'New Jersey' },
    { value: 'NM', label: 'New Mexico' }, { value: 'NY', label: 'New York' }, { value: 'NC', label: 'North Carolina' },
    { value: 'ND', label: 'North Dakota' }, { value: 'OH', label: 'Ohio' }, { value: 'OK', label: 'Oklahoma' },
    { value: 'OR', label: 'Oregon' }, { value: 'PA', label: 'Pennsylvania' }, { value: 'RI', label: 'Rhode Island' },
    { value: 'SC', label: 'South Carolina' }, { value: 'SD', label: 'South Dakota' }, { value: 'TN', label: 'Tennessee' },
    { value: 'TX', label: 'Texas' }, { value: 'UT', label: 'Utah' }, { value: 'VT', label: 'Vermont' },
    { value: 'VA', label: 'Virginia' }, { value: 'WA', label: 'Washington' }, { value: 'WV', label: 'West Virginia' },
    { value: 'WI', label: 'Wisconsin' }, { value: 'WY', label: 'Wyoming' }
  ];

  // restaurant types
  const restaurantTypes = [
    { value: '', label: 'Select Restaurant Type' },
    { value: 'Fast Food', label: 'Fast Food' },
    { value: 'Casual Dining', label: 'Casual Dining' },
    { value: 'Fine Dining', label: 'Fine Dining' },
    { value: 'Fast Casual', label: 'Fast Casual' },
    { value: 'Cafe/Bakery', label: 'Cafe/Bakery' },
    { value: 'Food Truck', label: 'Food Truck' },
    { value: 'Bar/Pub', label: 'Bar/Pub' },
    { value: 'Buffet', label: 'Buffet' },
    { value: 'Other', label: 'Other' }
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    let value = e.target.value;

    // auto-format phone
    if (e.target.name === 'phone') {
      value = value.replace(/\D/g, '');
      if (value.length >= 7) {
        value = value.slice(0, 3) + '-' + value.slice(3, 6) + '-' + value.slice(6, 10);
      } else if (value.length >= 4) {
        value = value.slice(0, 3) + '-' + value.slice(3);
      }
    }

    // auto-format ein
    if (e.target.name === 'EIN_hashed') {
      value = value.replace(/\D/g, '');
      if (value.length >= 3) {
        value = value.slice(0, 2) + '-' + value.slice(2, 9);
      }
    }

    setFormData({ ...formData, [e.target.name]: value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    // validate required fields
    if (!formData.restaurant_type || !formData.phone || !formData.address_line1 ||
        !formData.city || !formData.state || !formData.zipcode || !formData.EIN_hashed) {
      setErrorMessage('Please fill in all required fields');
      return;
    }

    if (!isPhoneValid) {
      setErrorMessage('Please enter a valid phone number (XXX-XXX-XXXX)');
      return;
    }

    if (!isEINValid) {
      setErrorMessage('Please enter a valid EIN (XX-XXXXXXX)');
      return;
    }

    setIsSubmitting(true);

    try {
      const token = localStorage.getItem('access_token');

      // update profile with new data
      const response = await axios.put(
        `http://localhost:8000/profile/client/${userData?.user_id}`,
        formData,
        { headers: { Authorization: `Bearer ${token}` } }
      );

      // if profile is complete, navigate to final step
      if (response.data.profile_complete) {
        navigate('/client/onboarding/complete');
      } else {
        setErrorMessage('Profile update succeeded but some required fields may be missing');
      }
    } catch (error: any) {
      console.error('failed to update profile:', error);
      setErrorMessage(error?.response?.data?.detail || 'Failed to update profile. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <OnboardingLayout
      currentStep={2}
      totalSteps={3}
      stepLabels={['Welcome', 'Complete Profile', 'Get Started']}
      title="Complete Your Business Profile"
      subtitle="Tell us about your restaurant so we can match you with the right staff."
    >
      <form onSubmit={handleSubmit} className="space-y-8">
        {errorMessage && (
          <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-sm flex items-start gap-3">
            <X className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* business details section */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-4">
            <Building2 className="w-5 h-5 text-teal-400" />
            <h3 className="text-lg font-semibold text-white">Business Details</h3>
          </div>

          <div className="grid sm:grid-cols-2 gap-4">
            {/* restaurant type */}
            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Restaurant Type <span className="text-red-400">*</span>
              </label>
              <select
                name="restaurant_type"
                value={formData.restaurant_type}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 rounded-xl bg-slate-900/50 border border-slate-600/50 text-white focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
              >
                {restaurantTypes.map(type => (
                  <option key={type.value} value={type.value} className="bg-slate-800">
                    {type.label}
                  </option>
                ))}
              </select>
            </div>

            {/* phone */}
            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Phone Number <span className="text-red-400">*</span>
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                <input
                  type="tel"
                  name="phone"
                  placeholder="XXX-XXX-XXXX"
                  value={formData.phone}
                  onChange={handleChange}
                  maxLength={12}
                  required
                  className="w-full pl-11 pr-4 py-3 rounded-xl bg-slate-900/50 border border-slate-600/50 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
                />
              </div>
              {formData.phone && (
                <div className={`mt-2 flex items-center gap-1 text-sm ${isPhoneValid ? 'text-green-400' : 'text-red-400'}`}>
                  {isPhoneValid ? <Check size={14} /> : <X size={14} />}
                  <span>Valid phone format (XXX-XXX-XXXX)</span>
                </div>
              )}
            </div>

            {/* website (optional) */}
            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Website <span className="text-slate-500 text-xs">(Optional)</span>
              </label>
              <div className="relative">
                <Globe className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                <input
                  type="url"
                  name="website_url"
                  placeholder="https://yourrestaurant.com"
                  value={formData.website_url}
                  onChange={handleChange}
                  className="w-full pl-11 pr-4 py-3 rounded-xl bg-slate-900/50 border border-slate-600/50 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
                />
              </div>
            </div>

            {/* ein (required) */}
            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-slate-300 mb-2">
                EIN / Tax ID <span className="text-red-400">*</span>
              </label>
              <input
                type="text"
                name="EIN_hashed"
                placeholder="XX-XXXXXXX"
                required
                value={formData.EIN_hashed}
                onChange={handleChange}
                maxLength={10}
                className="w-full px-4 py-3 rounded-xl bg-slate-900/50 border border-slate-600/50 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
              />
              {formData.EIN_hashed && (
                <div className={`mt-2 flex items-center gap-1 text-sm ${isEINValid ? 'text-green-400' : 'text-red-400'}`}>
                  {isEINValid ? <Check size={14} /> : <X size={14} />}
                  <span>Valid EIN format (XX-XXXXXXX)</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* business address section */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-4">
            <MapPin className="w-5 h-5 text-amber-400" />
            <h3 className="text-lg font-semibold text-white">Business Address</h3>
          </div>
          <p className="text-sm text-slate-400 -mt-2">This helps us match you with nearby staff</p>

          <div className="grid sm:grid-cols-2 gap-4">
            {/* address line 1 */}
            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Address Line 1 <span className="text-red-400">*</span>
              </label>
              <input
                type="text"
                name="address_line1"
                placeholder="123 Main Street"
                value={formData.address_line1}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 rounded-xl bg-slate-900/50 border border-slate-600/50 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
              />
            </div>

            {/* address line 2 */}
            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Address Line 2 <span className="text-slate-500 text-xs">(Optional)</span>
              </label>
              <input
                type="text"
                name="address_line2"
                placeholder="Suite, Unit, etc."
                value={formData.address_line2}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-xl bg-slate-900/50 border border-slate-600/50 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
              />
            </div>

            {/* city */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                City <span className="text-red-400">*</span>
              </label>
              <input
                type="text"
                name="city"
                placeholder="City"
                value={formData.city}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 rounded-xl bg-slate-900/50 border border-slate-600/50 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
              />
            </div>

            {/* state */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">
                State <span className="text-red-400">*</span>
              </label>
              <select
                name="state"
                value={formData.state}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 rounded-xl bg-slate-900/50 border border-slate-600/50 text-white focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
              >
                {usStates.map(state => (
                  <option key={state.value} value={state.value} className="bg-slate-800">
                    {state.label}
                  </option>
                ))}
              </select>
            </div>

            {/* zipcode */}
            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Zip Code <span className="text-red-400">*</span>
              </label>
              <input
                type="text"
                name="zipcode"
                placeholder="12345"
                value={formData.zipcode}
                onChange={handleChange}
                maxLength={5}
                required
                className="w-full px-4 py-3 rounded-xl bg-slate-900/50 border border-slate-600/50 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
              />
            </div>
          </div>
        </div>

        {/* submit button */}
        <div className="flex gap-4 pt-4">
          <button
            type="submit"
            disabled={isSubmitting}
            className="flex-1 py-4 bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 disabled:from-slate-600 disabled:to-slate-700 text-white font-semibold rounded-xl transition-all duration-300 shadow-lg shadow-teal-500/30 hover:shadow-teal-500/50 disabled:shadow-none"
          >
            {isSubmitting ? 'Saving...' : 'Continue'}
          </button>
        </div>
      </form>
    </OnboardingLayout>
  );
}
