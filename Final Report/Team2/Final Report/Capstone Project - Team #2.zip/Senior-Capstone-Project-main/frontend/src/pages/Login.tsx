import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Sparkles, Mail, Lock, ArrowRight } from 'lucide-react';
import { loginUser } from "../api"; // signInStaff function found in api.js
import PageLayoutNoNav from "../layouts/PageLayoutNoNav";

export default function StaffSignIn() {
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const navigate = useNavigate();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const result = await loginUser(formData);
      if (result?.access_token) {
        localStorage.setItem("access_token", result.access_token);
        console.log("Login success:", result);
        alert("Logged in!");
      } else if ((result as any) && (result as any)["2fa_method_selection_required"]) {
        // Store email and available methods, then navigate to method selection
        sessionStorage.setItem('pending_2fa_email', (result as any).email);
        sessionStorage.setItem('pending_2fa_methods', JSON.stringify((result as any).available_methods));
        if ((result as any).phone_masked) {
          sessionStorage.setItem('pending_2fa_phone', (result as any).phone_masked);
        }
        navigate('/two-factor-method');
      } else if ((result as any) && (result as any)["2fa_required"]) {
        // Direct 2FA (legacy support) - store email and method, then navigate to 2FA page
        sessionStorage.setItem('pending_2fa_email', (result as any).email);
        sessionStorage.setItem('pending_2fa_method', (result as any).method || 'email');
        if ((result as any).phone_masked) {
          sessionStorage.setItem('pending_2fa_phone', (result as any).phone_masked);
        }
        navigate('/two-factor');
      } else if ((result as any) && (result as any)["email_verification_required"]) {
        // store email temporarily and navigate to email verification page
        sessionStorage.setItem('pending_verification_email', (result as any).email);
        navigate('/verify-email');
      } else {
        console.log("Login response:", result);
      }
    } catch (error: any) {
      const detail = error?.response?.data?.detail || "Error signing in";
      alert(detail);
    }
  };

  return (
    <PageLayoutNoNav>
      <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-slate-900 via-slate-800 to-teal-900">
        <div className="w-full max-w-md">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-teal-500/20 backdrop-blur-sm border border-teal-400/30 rounded-full mb-4">
              <Sparkles className="w-4 h-4 text-teal-400" />
              <span className="text-teal-300 text-sm font-semibold">Welcome Back</span>
            </div>
            <h1 className="text-4xl font-bold text-white mb-2">Sign In</h1>
            <p className="text-slate-300">Access your Shift Solutions account</p>
          </div>

          {/* Login Card */}
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-8 shadow-2xl">
            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Email Input */}
              <div>
                <label className="block text-sm font-medium text-white mb-2">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="email"
                    name="email"
                    placeholder="your@email.com"
                    value={formData.email}
                    required
                    onChange={handleChange}
                    className="w-full pl-12 pr-4 py-3 rounded-xl bg-white/10 text-white border border-white/20 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent transition-all"
                  />
                </div>
              </div>

              {/* Password Input */}
              <div>
                <label className="block text-sm font-medium text-white mb-2">Password</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                  <input
                    type="password"
                    name="password"
                    placeholder="Enter your password"
                    value={formData.password}
                    required
                    onChange={handleChange}
                    className="w-full pl-12 pr-4 py-3 rounded-xl bg-white/10 text-white border border-white/20 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-transparent transition-all"
                  />
                </div>
              </div>

              {/* Forgot Password Link */}
              <div className="text-right">
                <Link
                  to="/forgot-password"
                  className="text-teal-400 text-sm hover:text-teal-300 transition-colors"
                >
                  Forgot password?
                </Link>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="group w-full py-3.5 bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white font-bold rounded-xl transition-all duration-300 shadow-lg shadow-teal-500/30 hover:shadow-teal-500/50 flex items-center justify-center gap-2"
              >
                Sign In
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </form>

            {/* Divider */}
            <div className="relative my-8">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-white/20"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-4 bg-slate-800/50 text-slate-300">Don't have an account?</span>
              </div>
            </div>

            {/* Sign Up Links */}
            <div className="grid grid-cols-2 gap-4">
              <Link
                to="/staff/signup"
                className="py-3 px-4 bg-white/5 hover:bg-white/10 border border-white/20 hover:border-amber-400/40 text-white font-semibold rounded-xl transition-all duration-300 text-center"
              >
                Staff Sign Up
              </Link>
              <Link
                to="/client/signup"
                className="py-3 px-4 bg-white/5 hover:bg-white/10 border border-white/20 hover:border-teal-400/40 text-white font-semibold rounded-xl transition-all duration-300 text-center"
              >
                Client Sign Up
              </Link>
            </div>
          </div>

          {/* Back to Home */}
          <div className="text-center mt-6">
            <Link
              to="/"
              className="text-slate-400 text-sm hover:text-white transition-colors"
            >
              ← Back to home
            </Link>
          </div>
        </div>
      </div>
    </PageLayoutNoNav>
  );
}
