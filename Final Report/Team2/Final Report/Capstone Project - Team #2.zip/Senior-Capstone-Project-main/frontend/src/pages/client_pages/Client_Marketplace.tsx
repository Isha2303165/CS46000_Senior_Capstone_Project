import { useState, useEffect } from 'react';
import { Sparkles, Briefcase } from 'lucide-react';
import ClientSidebar from '../../components/ClientSidebar';
import StaffCard from '../../components/StaffCard';
import { getAvailableStaff } from '../../api';

interface StaffMember {
  id: number;
  name: string;
  role: string;
  qualifications: string[];
  availability: {
    days: string;
    time: string;
  };
}

export default function Client_Marketplace() {
  const [staffMembers, setStaffMembers] = useState<StaffMember[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filterRole, setFilterRole] = useState<string>('all');

  useEffect(() => {
    const fetchStaff = async () => {
      try {
        setLoading(true);
        const data = await getAvailableStaff();
        setStaffMembers(data);
      } catch (err: any) {
        console.error('Error fetching available staff:', err);
        setError(err?.response?.data?.detail || 'Failed to load available staff');
        // For now, use mock data if API fails
        setStaffMembers([
          {
            id: 1,
            name: 'Sarah Martinez',
            role: 'Server',
            qualifications: ['5+ years fine dining', 'Wine sommelier certified', 'Bilingual (English/Spanish)'],
            availability: {
              days: 'Mon - Fri',
              time: '4:00 PM - 12:00 AM',
            },
          },
          {
            id: 2,
            name: 'John Anderson',
            role: 'Barista',
            qualifications: ['3+ years specialty coffee', 'Latte art expert', 'Customer service excellence'],
            availability: {
              days: 'Tue - Sat',
              time: '6:00 AM - 2:00 PM',
            },
          },
          {
            id: 3,
            name: 'Marcus Chen',
            role: 'Line Cook',
            qualifications: ['7+ years culinary experience', 'Italian cuisine specialist', 'Fast-paced environment'],
            availability: {
              days: 'Wed - Sun',
              time: '2:00 PM - 10:00 PM',
            },
          },
          {
            id: 4,
            name: 'Emily Rodriguez',
            role: 'Bartender',
            qualifications: ['Certified mixologist', 'Craft cocktail expertise', 'Liquor license active'],
            availability: {
              days: 'Thu - Mon',
              time: '5:00 PM - 1:00 AM',
            },
          },
          {
            id: 5,
            name: 'David Kim',
            role: 'Host',
            qualifications: ['4+ years hospitality', 'OpenTable management', 'Professional demeanor'],
            availability: {
              days: 'Mon - Fri',
              time: '5:00 PM - 11:00 PM',
            },
          },
          {
            id: 6,
            name: 'Lisa Thompson',
            role: 'Server',
            qualifications: ['8+ years experience', 'High-volume service', 'Team leadership skills'],
            availability: {
              days: 'Sat - Sun',
              time: '10:00 AM - 6:00 PM',
            },
          },
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchStaff();
  }, []);

  const handleRequestStaff = (staffId: number, staffName: string) => {
    // TODO: Implement staff request logic
    alert(`Requesting ${staffName} for staffing. This feature will be implemented soon.`);
  };

  // Get unique roles for filter
  const roles = ['all', ...Array.from(new Set(staffMembers.map(staff => staff.role)))];
  
  // Filter staff by role
  const filteredStaff = filterRole === 'all' 
    ? staffMembers 
    : staffMembers.filter(staff => staff.role === filterRole);

  return (
    <div className="min-h-screen w-screen overflow-x-hidden bg-gradient-to-br from-slate-900 via-slate-800 to-teal-900">
      <div className="min-h-screen w-full flex relative">
        <ClientSidebar />
        <main className="flex-1 overflow-auto w-full">
          <div className="w-full min-h-screen px-4 pt-20 sm:px-6 lg:px-8 pb-20">
            <div className="max-w-7xl mx-auto">
              {/* Page Header */}
              <div className="text-center mb-12">
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-teal-500/20 backdrop-blur-sm border border-teal-400/30 rounded-full mb-6">
                  <Sparkles className="w-4 h-4 text-teal-400" />
                  <span className="text-teal-300 text-sm font-semibold">Hire Top Talent</span>
                </div>
                
                <h1 className="text-white text-4xl md:text-5xl font-bold mb-4">
                  Available Staff
                </h1>
                
                <p className="text-slate-300 text-lg max-w-2xl mx-auto">
                  Browse verified professionals ready to join your team
                </p>
              </div>

              {/* Filter Section */}
              <div className="mb-8 flex flex-wrap items-center justify-center gap-3">
                <div className="flex items-center gap-2 text-white font-semibold">
                  <Briefcase className="w-5 h-5 text-teal-400" />
                  <span>Filter by Role:</span>
                </div>
                {roles.map((role) => (
                  <button
                    key={role}
                    onClick={() => setFilterRole(role)}
                    className={[
                      "px-4 py-2 rounded-lg font-medium text-sm transition-all",
                      filterRole === role
                        ? "bg-gradient-to-r from-teal-500 to-teal-600 text-white shadow-lg shadow-teal-500/30"
                        : "bg-white/10 text-white/80 hover:bg-white/20 hover:text-white backdrop-blur-sm border border-white/10",
                    ].join(" ")}
                  >
                    {role.charAt(0).toUpperCase() + role.slice(1)}
                  </button>
                ))}
              </div>

              {/* Loading State */}
              {loading && (
                <div className="flex justify-center items-center py-20">
                  <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-8">
                    <p className="text-white text-lg">Loading available staff...</p>
                  </div>
                </div>
              )}

              {/* Error State */}
              {error && !loading && (
                <div className="max-w-2xl mx-auto bg-red-500/20 backdrop-blur-sm border border-red-500/50 rounded-2xl p-6 mb-6">
                  <p className="text-red-200 text-center">{error}</p>
                  <p className="text-red-300 text-sm text-center mt-2">Showing sample data for demonstration</p>
                </div>
              )}

              {/* Staff Cards Grid */}
              {!loading && filteredStaff.length > 0 && (
                <div className="flex flex-wrap justify-center gap-6 lg:gap-8">
                  {filteredStaff.map((staff) => (
                    <StaffCard
                      key={staff.id}
                      name={staff.name}
                      role={staff.role}
                      qualifications={staff.qualifications}
                      availability={staff.availability}
                      onApply={() => handleRequestStaff(staff.id, staff.name)}
                    />
                  ))}
                </div>
              )}

              {/* Empty State */}
              {!loading && filteredStaff.length === 0 && (
                <div className="flex justify-center items-center py-20">
                  <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-12 text-center">
                    <Briefcase className="w-16 h-16 text-teal-400 mx-auto mb-4" />
                    <p className="text-white text-xl font-semibold mb-2">No staff available</p>
                    <p className="text-slate-300">
                      {filterRole !== 'all' 
                        ? `No ${filterRole} professionals available at the moment. Try a different role.`
                        : 'Check back soon for new talent!'}
                    </p>
                  </div>
                </div>
              )}

              {/* Stats Section */}
              {!loading && staffMembers.length > 0 && (
                <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 text-center">
                    <p className="text-4xl font-bold text-teal-400 mb-2">{staffMembers.length}</p>
                    <p className="text-slate-300">Available Professionals</p>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 text-center">
                    <p className="text-4xl font-bold text-teal-400 mb-2">{roles.length - 1}</p>
                    <p className="text-slate-300">Different Roles</p>
                  </div>
                  <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 text-center">
                    <p className="text-4xl font-bold text-teal-400 mb-2">100%</p>
                    <p className="text-slate-300">Verified Profiles</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

