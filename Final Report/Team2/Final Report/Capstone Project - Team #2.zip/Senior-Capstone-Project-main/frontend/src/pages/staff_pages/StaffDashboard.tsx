import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {Briefcase, Calendar, DollarSign, TrendingUp, Clock, CheckCircle, ArrowRight, Sparkles,
User, Award, MapPin,} from "lucide-react";
import PageLayout from "../../layouts/PageLayout";
import waiterImg from "../../assets/img/waiter.jpg";
import { getCurrentUser, getStaffDashboard } from "../../api";

interface DashboardProfile {
  first_name: string;
  last_name: string;
  status: string;
  imgSrc: string;
}

interface QuickStat {
  label: string;
  value: string | number;
  icon: React.ReactNode;
  trend?: string;
  color: string;
}

interface QuickAction {
  title: string;
  description: string;
  icon: React.ReactNode;
  link: string;
  color: string;
}

export default function StaffDashboard() {
  const staffMenu = [
    { path: "/staff/dashboard", label: "Dashboard" },
    { path: "/staff/marketplace", label: "Marketplace" },
    { path: "/staff/profile", label: "My Profile" },
  ];

  const [userId, setUserId] = useState<number | null>(null);
  const [profile, setProfile] = useState<DashboardProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const user = await getCurrentUser();
        setUserId(user.id);

        const dashboard = await getStaffDashboard(user.id);
        setProfile({
          first_name: dashboard.profile.first_name,
          last_name: dashboard.profile.last_name,
          status: dashboard.profile.status,
          imgSrc: dashboard.profile.profile_image_url
            ? `http://localhost:8000${dashboard.profile.profile_image_url}`
            : waiterImg,
        });
      } catch (err: any) {
        console.error("Failed to load staff dashboard data:", err);
        setError("Failed to load dashboard data. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  const quickStats: QuickStat[] = [
    {
      label: "Active Shifts",
      value: 8,
      icon: <Calendar className="w-6 h-6" />,
      trend: "+2 this week",
      color: "from-amber-500 to-amber-600",
    },
    {
      label: "Total Earnings",
      value: "$2,450",
      icon: <DollarSign className="w-6 h-6" />,
      trend: "+$320 this week",
      color: "from-emerald-500 to-emerald-600",
    },
    {
      label: "Completion Rate",
      value: "98%",
      icon: <TrendingUp className="w-6 h-6" />,
      trend: "Excellent rating",
      color: "from-blue-500 to-blue-600",
    },
    {
      label: "Hours Worked",
      value: 42,
      icon: <Clock className="w-6 h-6" />,
      trend: "This month",
      color: "from-purple-500 to-purple-600",
    },
  ];

  const quickActions: QuickAction[] = [
    {
      title: "Browse Shifts",
      description: "Find and apply for available shifts",
      icon: <Briefcase className="w-8 h-8" />,
      link: "/staff/marketplace",
      color: "from-amber-500 to-amber-600",
    },
    {
      title: "My Profile",
      description: "Update your profile and credentials",
      icon: <User className="w-8 h-8" />,
      link: "/staff/profile",
      color: "from-blue-500 to-blue-600",
    },
  ];

  const upcomingShifts = [
    {
      date: "Dec 10",
      time: "5:00 PM - 11:00 PM",
      restaurant: "The Golden Fork",
      role: "Server",
      location: "Downtown",
      pay: "$25/hr",
    },
    {
      date: "Dec 12",
      time: "6:00 AM - 2:00 PM",
      restaurant: "Sunrise Café",
      role: "Barista",
      location: "Midtown",
      pay: "$18/hr",
    },
    {
      date: "Dec 14",
      time: "4:00 PM - 10:00 PM",
      restaurant: "Bella Italia",
      role: "Server",
      location: "West End",
      pay: "$22/hr",
    },
  ];

  if (loading) {
    return (
      <PageLayout
        className="bg-gradient-to-br from-slate-900 via-slate-800 to-amber-900"
        navbarConfig={{ menuItems: staffMenu }}
      >
        <div className="min-h-screen w-screen overflow-hidden px-4 pt-10 sm:px-6 lg:px-8 max-w-7xl mx-auto flex items-center justify-center">
          <p className="text-white text-lg">Loading dashboard...</p>
        </div>
      </PageLayout>
    );
  }

  if (error || !profile || !userId) {
    return (
      <PageLayout
        className="bg-gradient-to-br from-slate-900 via-slate-800 to-amber-900"
        navbarConfig={{ menuItems: staffMenu }}
      >
        <div className="min-h-screen w-screen overflow-hidden px-4 pt-10 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <p className="text-red-300">{error || "Unable to load dashboard."}</p>
        </div>
      </PageLayout>
    );
  }

  return (
    <PageLayout
      className="bg-gradient-to-br from-slate-900 via-slate-800 to-amber-900"
      navbarConfig={{ menuItems: staffMenu }}
    >
      <div className="min-h-screen w-screen overflow-hidden px-6 sm:px-8 pt-10 pb-20">
        <div className="max-w-7xl mx-auto">
          {/* Welcome Header with Profile */}
          <div className="mb-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-amber-500/20 backdrop-blur-sm border border-amber-400/30 rounded-full mb-4">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span className="text-amber-300 text-sm font-semibold">
                Dashboard
              </span>
            </div>

            <div className="flex items-center gap-6 mb-4">
              <div className="relative group">
                <div className="absolute inset-0 bg-gradient-to-r from-amber-400 to-amber-600 rounded-full blur-md opacity-50 group-hover:opacity-75 transition-opacity" />
                <img
                  src={profile.imgSrc}
                  alt="Profile"
                  className="relative w-20 h-20 rounded-full object-cover ring-4 ring-white/20 group-hover:ring-amber-400/50 transition-all"
                />
              </div>
              <div>
                <h1 className="text-4xl font-bold text-white mb-1">
                  Welcome back, {profile.first_name}!
                </h1>
                <p className="text-slate-300 text-lg flex items-center gap-2">
                  <Award className="w-5 h-5 text-amber-400" />
                  Status: <span className="text-amber-400 font-semibold">{profile.status}</span>
                </p>
              </div>
            </div>
          </div>

          {/* Quick Stats Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {quickStats.map((stat, index) => (
              <div
                key={index}
                className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 hover:bg-white/15 transition-all duration-300 hover:scale-105 group"
              >
                <div className="flex items-start justify-between mb-4">
                  <div
                    className={`p-3 rounded-xl bg-gradient-to-br ${stat.color} shadow-lg`}
                  >
                    {stat.icon}
                  </div>
                </div>
                <h3 className="text-3xl font-bold text-white mb-1">
                  {stat.value}
                </h3>
                <p className="text-slate-300 text-sm font-medium mb-2">
                  {stat.label}
                </p>
                {stat.trend && (
                  <p className="text-amber-400 text-xs font-semibold">
                    {stat.trend}
                  </p>
                )}
              </div>
            ))}
          </div>

          {/* Quick Actions */}
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
              <Briefcase className="w-6 h-6 text-amber-400" />
              Quick Actions
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {quickActions.map((action, index) => (
                <Link
                  key={index}
                  to={action.link}
                  className="group bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 hover:bg-white/15 transition-all duration-300 hover:scale-105 hover:shadow-2xl"
                >
                  <div className="flex items-start gap-4">
                    <div
                      className={`p-3 rounded-xl bg-gradient-to-br ${action.color} shadow-lg group-hover:scale-110 transition-transform`}
                    >
                      {action.icon}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-white mb-1 group-hover:text-amber-300 transition-colors flex items-center gap-2">
                        {action.title}
                        <ArrowRight className="w-5 h-5 opacity-0 group-hover:opacity-100 transition-all group-hover:translate-x-1" />
                      </h3>
                      <p className="text-slate-300 text-sm">
                        {action.description}
                      </p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>

          {/* Upcoming Shifts */}
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                <Calendar className="w-6 h-6 text-amber-400" />
                Upcoming Shifts
              </h2>
              <Link
                to="/staff/marketplace"
                className="text-amber-400 hover:text-amber-300 text-sm font-semibold flex items-center gap-1 transition-colors"
              >
                Browse More
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            <div className="space-y-3">
              {upcomingShifts.map((shift, index) => (
                <div
                  key={index}
                  className="bg-white/5 border border-white/10 rounded-xl p-4 hover:bg-white/10 transition-all"
                >
                  <div className="flex items-center justify-between flex-wrap gap-4">
                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <p className="text-2xl font-bold text-white">
                          {shift.date.split(" ")[1]}
                        </p>
                        <p className="text-xs text-slate-400 uppercase">
                          {shift.date.split(" ")[0]}
                        </p>
                      </div>
                      <div className="h-12 w-px bg-white/20" />
                      <div>
                        <p className="text-white font-bold">
                          {shift.restaurant}
                        </p>
                        <p className="text-slate-300 text-sm flex items-center gap-2">
                          <Briefcase className="w-3 h-3" />
                          {shift.role} • {shift.time}
                        </p>
                        <p className="text-slate-400 text-xs flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          {shift.location}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="px-3 py-1 bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 rounded-lg text-sm font-bold">
                        {shift.pay}
                      </span>
                      <span className="flex items-center gap-1 px-3 py-1 bg-amber-500/20 border border-amber-500/30 text-amber-400 rounded-lg text-sm font-semibold">
                        <CheckCircle className="w-4 h-4" />
                        Confirmed
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </PageLayout>
  );
}
