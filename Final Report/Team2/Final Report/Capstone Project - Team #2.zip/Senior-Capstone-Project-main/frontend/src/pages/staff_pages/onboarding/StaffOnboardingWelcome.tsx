import { useNavigate } from 'react-router-dom';
import { Sparkles, Briefcase, TrendingUp, Shield, ArrowRight } from 'lucide-react';
import OnboardingLayout from '../../../components/onboarding/OnboardingLayout';
import { getUserData } from '../../../utils/auth';
import axios from 'axios';

export default function StaffOnboardingWelcome() {
  const navigate = useNavigate();
  const userData = getUserData();

  const handleGetStarted = async () => {
    try {
      // update backend that user reached step 1
      const token = localStorage.getItem('access_token');
      await axios.post(
        'http://localhost:8000/auth/onboarding-step',
        { step: 1 },
        { headers: { Authorization: `Bearer ${token}` } }
      );
    } catch (error) {
      console.error('failed to update onboarding step:', error);
      // continue anyway
    }

    // navigate to profile completion
    navigate('/staff/onboarding/profile');
  };

  return (
    <OnboardingLayout
      currentStep={1}
      totalSteps={3}
      stepLabels={['Welcome', 'Complete Profile', 'Get Started']}
      title="Welcome to Shift Solutions!"
      subtitle="Let's get your profile set up and start finding shifts."
      showBackButton={false}
    >
      <div className="space-y-8">
        {/* welcome message */}
        <div className="text-center py-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-amber-500/10 border border-amber-500/20 rounded-full mb-6">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span className="text-amber-400 text-sm font-medium">You're almost there</span>
          </div>

          <p className="text-slate-300 text-lg leading-relaxed max-w-2xl mx-auto">
            Complete your profile to start applying for shifts at great restaurants.
            This will only take a few minutes!
          </p>
        </div>

        {/* feature cards */}
        <div className="grid sm:grid-cols-3 gap-4 sm:gap-6">
          {/* card 1 */}
          <div className="group bg-gradient-to-br from-slate-700/40 to-slate-800/40 rounded-xl p-6 border border-slate-600/30 hover:border-teal-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-teal-500/10 hover:-translate-y-1">
            <div className="w-12 h-12 bg-teal-500/10 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
              <Briefcase className="w-6 h-6 text-teal-400" />
            </div>
            <h3 className="text-white font-semibold mb-2">Find Shifts Quickly</h3>
            <p className="text-slate-400 text-sm">
              Browse available shifts and apply instantly to opportunities that fit your schedule.
            </p>
          </div>

          {/* card 2 */}
          <div className="group bg-gradient-to-br from-slate-700/40 to-slate-800/40 rounded-xl p-6 border border-slate-600/30 hover:border-amber-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-amber-500/10 hover:-translate-y-1">
            <div className="w-12 h-12 bg-amber-500/10 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
              <TrendingUp className="w-6 h-6 text-amber-400" />
            </div>
            <h3 className="text-white font-semibold mb-2">Build Your Career</h3>
            <p className="text-slate-400 text-sm">
              Work with top restaurants and build your reputation in the hospitality industry.
            </p>
          </div>

          {/* card 3 */}
          <div className="group bg-gradient-to-br from-slate-700/40 to-slate-800/40 rounded-xl p-6 border border-slate-600/30 hover:border-blue-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-blue-500/10 hover:-translate-y-1">
            <div className="w-12 h-12 bg-blue-500/10 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
              <Shield className="w-6 h-6 text-blue-400" />
            </div>
            <h3 className="text-white font-semibold mb-2">Secure & Reliable</h3>
            <p className="text-slate-400 text-sm">
              Get paid on time with secure payments and work with verified restaurants.
            </p>
          </div>
        </div>

        {/* cta button */}
        <div className="pt-4">
          <button
            onClick={handleGetStarted}
            className="group w-full sm:w-auto sm:min-w-[300px] mx-auto flex items-center justify-center gap-3 px-8 py-4 bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white font-semibold rounded-xl transition-all duration-300 shadow-lg shadow-teal-500/30 hover:shadow-teal-500/50 hover:scale-105"
          >
            <span>Get Started</span>
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
          </button>
        </div>
      </div>
    </OnboardingLayout>
  );
}
