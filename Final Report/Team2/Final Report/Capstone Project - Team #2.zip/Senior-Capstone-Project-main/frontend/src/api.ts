/* api.js
    * Receives data from the front end pages and sends it to FastAPI using axios. The result from 
    * the API call is returned to the front end pages where they're called.
*/

//--import axios--
import axios from 'axios';

//--backend URL--
const API_URL = 'http://localhost:8000';


//--sign-up functions--
const signUpStaff = async (staffData: any): Promise<any> => {
    try {
        // print for debugging
        console.log("signUpStaff called in api.ts with:", staffData);
        // POST request to backend
        const response = await axios.post(`${API_URL}/sign_up_staff`, staffData);
        console.log("Response from backend:", response.data);
        return response.data;
    } catch (error: any) {
        console.error("Sign-up error (staff):", error.response?.data || error.message);
        throw error;
    }
};


const signUpClient = async (clientData: any): Promise<any> => {
    try {
        // print for debugging
        console.log("signUpClient called in api.ts with:", clientData);
        // POST request to backend
        const response = await axios.post(`${API_URL}/sign_up_client`, clientData);
        console.log("Response from backend:", response.data);
        return response.data;
    } catch (error: any) {
        console.error("Sign-up error (client):", error.response?.data || error.message);
        throw error;
    }
};


//--login function--
const loginUser = async (loginData: any): Promise<any> => {
    try {
        // print for debugging
        console.log("loginUser called in api.ts with:", loginData);
        // POST request to backend
        const response = await axios.post(`${API_URL}/auth/login`, loginData);
        console.log("Response from backend:", response.data);
        return response.data;
    } catch (error: any) {
        console.error("Login error:", error.response?.data || error.message);
        throw error;
    }
};
//--subscription function--
const subscribeClient = async (subscriptionData: any): Promise<any> => {
    try {
        // print for debugging
        console.log("subscribeClient called in api.ts with:", subscriptionData);
        // POST request to backend
        const response = await axios.post(`${API_URL}/client/subscribe`, subscriptionData);
        console.log("Response from backend:", response.data);
        return response.data;
    } catch (error: any) {
        console.error("Subscription error:", error.response?.data || error.message);
        throw error;
    }
};

//--post shift function--
const postShift = async (shiftData: any): Promise<any> => {
    try {
        // print for debugging
        console.log("postShift called in api.ts with:", shiftData);
        // POST request to backend
        const response = await axios.post(`${API_URL}/client/post_shift`, shiftData);
        console.log("Response from backend:", response.data);
        return response.data;
    } catch (error: any) {
        console.error("Post shift error:", error.response?.data || error.message);
        throw error;
    }
};

//--resend verification email function--
const resendVerificationEmail = async (email: string): Promise<any> => {
    try {
        console.log("resendVerificationEmail called in api.ts with:", email);
        const response = await axios.post(`${API_URL}/auth/resend-verification`, { email });
        console.log("Response from backend:", response.data);
        return response.data;
    } catch (error: any) {
        console.error("Resend verification error:", error.response?.data || error.message);
    }
};

//--get current user info--
const getCurrentUser = async (): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        const response = await axios.get(`${API_URL}/auth/me`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        return response.data;
    } catch (error: any) {
        console.error("Get current user error:", error.response?.data || error.message);
        throw error;
    }
};

//--get staff profile--
const getStaffProfile = async (userId: number): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        const response = await axios.get(`${API_URL}/profile/staff/${userId}`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        return response.data;
    } catch (error: any) {
        console.error("Get staff profile error:", error.response?.data || error.message);
        throw error;
    }
};

//--get staff dashboard data--
const getStaffDashboard = async (userId: number): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        const response = await axios.get(`${API_URL}/staff/dashboard/${userId}`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        return response.data;
    } catch (error: any) {
        console.error("Get staff dashboard error:", error.response?.data || error.message);
        throw error;
    }
};

//--update staff profile--
const updateStaffProfile = async (userId: number, profileData: any): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        const response = await axios.put(`${API_URL}/profile/staff/${userId}`, profileData, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        return response.data;
    } catch (error: any) {
        console.error("Update staff profile error:", error.response?.data || error.message);
        throw error;
    }
};

//--upload profile image--
const uploadProfileImage = async (userId: number, file: File): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        const formData = new FormData();
        formData.append('file', file);
        
        const response = await axios.post(`${API_URL}/profile/upload-image/${userId}`, formData, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'multipart/form-data'
            }
        });
        return response.data;
    } catch (error: any) {
        console.error("Upload profile image error:", error.response?.data || error.message);
        throw error;
    }
};

//--upload liquor license--
const uploadLiquorLicense = async (userId: number, file: File): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        const formData = new FormData();
        formData.append('file', file);
        
        const response = await axios.post(`${API_URL}/profile/upload-license/${userId}`, formData, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'multipart/form-data'
            }
        });
        return response.data;
    } catch (error: any) {
        console.error("Upload liquor license error:", error.response?.data || error.message);
        throw error;
    }
};

//--upload resume--
const uploadResume = async (userId: number, file: File): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        const formData = new FormData();
        formData.append('file', file);
        
        const response = await axios.post(`${API_URL}/profile/upload-resume/${userId}`, formData, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'multipart/form-data'
            }
        });
        return response.data;
    } catch (error: any) {
        console.error("Upload resume error:", error.response?.data || error.message);
        throw error;
    }
};

//--get resume--
const getResume = async (userId: number): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        const response = await axios.get(`${API_URL}/profile/resume/${userId}`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        return response.data;
    } catch (error: any) {
        // Don't log 404 errors - it just means no resume uploaded yet
        if (error.response?.status !== 404) {
            console.error("Get resume error:", error.response?.data || error.message);
        }
        throw error;
    }
};

//--upload government ID--
const uploadGovernmentId = async (userId: number, file: File): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        const formData = new FormData();
        formData.append('file', file);
        
        const response = await axios.post(`${API_URL}/profile/upload-gov-id/${userId}`, formData, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'multipart/form-data'
            }
        });
        return response.data;
    } catch (error: any) {
        console.error("Upload government ID error:", error.response?.data || error.message);
        throw error;
    }
};

//--get government ID--
const getGovernmentId = async (userId: number): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        const response = await axios.get(`${API_URL}/profile/gov-id/${userId}`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        return response.data;
    } catch (error: any) {
        // Don't log 404 errors - it just means no government ID uploaded yet
        if (error.response?.status !== 404) {
            console.error("Get government ID error:", error.response?.data || error.message);
        }
        throw error;
    }
};

//--change password--
const changePassword = async (currentPassword: string, newPassword: string): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        const response = await axios.post(`${API_URL}/auth/change-password`, {
            current_password: currentPassword,
            new_password: newPassword
        }, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        return response.data;
    } catch (error: any) {
        console.error("Change password error:", error.response?.data || error.message);
        throw error;
    }
};

//--save staff preferences--
const saveStaffPreferences = async (preferencesData: any): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        // print for debugging
        console.log("saveStaffPreferences called in api.ts with:", preferencesData);
        // POST request to backend
        const response = await axios.post(`${API_URL}/client/staff-preferences`, preferencesData, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        console.log("Response from backend:", response.data);
        return response.data;
    } catch (error: any) {
        console.error("Save staff preferences error:", error.response?.data || error.message);
        throw error;
    }
};

//--get staff preferences--
const getStaffPreferences = async (): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        const response = await axios.get(`${API_URL}/client/staff-preferences`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        return response.data;
    } catch (error: any) {
        console.error("Get staff preferences error:", error.response?.data || error.message);
        throw error;
    }
};

//--get emergency contacts--
const getEmergencyContacts = async (userId: number): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        const response = await axios.get(`${API_URL}/profile/emergency-contacts/${userId}`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        return response.data;
    } catch (error: any) {
        console.error("Get emergency contacts error:", error.response?.data || error.message);
        throw error;
    }
};

//--create emergency contact--
const createEmergencyContact = async (userId: number, contactData: any): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        const response = await axios.post(`${API_URL}/profile/emergency-contacts/${userId}`, contactData, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        return response.data;
    } catch (error: any) {
        console.error("Create emergency contact error:", error.response?.data || error.message);
        throw error;
    }
};

//--update emergency contact--
const updateEmergencyContact = async (contactId: number, contactData: any): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        const response = await axios.put(`${API_URL}/profile/emergency-contacts/${contactId}`, contactData, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        return response.data;
    } catch (error: any) {
        console.error("Update emergency contact error:", error.response?.data || error.message);
        throw error;
    }
};

//--delete emergency contact--
const deleteEmergencyContact = async (contactId: number): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        const response = await axios.delete(`${API_URL}/profile/emergency-contacts/${contactId}`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        return response.data;
    } catch (error: any) {
        console.error("Delete emergency contact error:", error.response?.data || error.message);
        throw error;
    }
};

//--get client profile--
const getClientProfile = async (userId: number): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        const response = await axios.get(`${API_URL}/profile/client/${userId}`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        return response.data;
    } catch (error: any) {
        console.error("Get client profile error:", error.response?.data || error.message);
        throw error;
    }
};

//--update client profile--
const updateClientProfile = async (userId: number, profileData: any): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        const response = await axios.put(`${API_URL}/profile/client/${userId}`, profileData, {
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        return response.data;
    } catch (error: any) {
        console.error("Update client profile error:", error.response?.data || error.message);
        throw error;
    }
};

//--get available staff for marketplace--
const getAvailableStaff = async (): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        const response = await axios.get(`${API_URL}/client/marketplace/available-staff`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        return response.data;
    } catch (error: any) {
        console.error("Get available staff error:", error.response?.data || error.message);
        throw error;
    }
};

//--get available shifts for staff marketplace--
const getAvailableShifts = async (): Promise<any> => {
    try {
        const token = localStorage.getItem('access_token');
        if (!token) {
            throw new Error('No access token found');
        }
        const response = await axios.get(`${API_URL}/staff/marketplace/available-shifts`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        return response.data;
    } catch (error: any) {
        console.error("Get available shifts error:", error.response?.data || error.message);
        throw error;
    }
};

// export functions
export { 
    signUpStaff, 
    signUpClient, 
    loginUser, 
    subscribeClient, 
    postShift,
    resendVerificationEmail,
    getCurrentUser,
    getStaffProfile,
    getStaffDashboard,
    updateStaffProfile,
    getClientProfile,
    updateClientProfile,
    uploadProfileImage,
    uploadLiquorLicense,
    uploadResume,
    getResume,
    uploadGovernmentId,
    getGovernmentId,
    changePassword,
    saveStaffPreferences,
    getStaffPreferences,
    getEmergencyContacts,
    createEmergencyContact,
    updateEmergencyContact,
    deleteEmergencyContact,
    getAvailableStaff,
    getAvailableShifts
};
