/*
 * This file tells TypeScript how to handle non-code imports (like images).
 * Without this file, TypeScript will throw errors when importing .jpg, .png, etc.
 * This file makes it so TypeScript will treat these imports as strings (URLs).
*/

declare module "*.jpg" {
  const value: string;
  export default value;
}

declare module "*.png" {
  const value: string;
  export default value;
}

declare module "*.jpeg" {
  const value: string;
  export default value;
}
