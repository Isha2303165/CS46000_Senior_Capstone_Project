import React from 'react';
import { Calendar, Clock, CheckCircle, Briefcase, User } from 'lucide-react';

interface StaffCardProps {
  name: string;
  role: string;
  qualifications: string[];
  availability: {
    days: string;
    time: string;
  };
  onApply: () => void;
}

const StaffCard: React.FC<StaffCardProps> = ({
  name,
  role,
  qualifications,
  availability,
  onApply,
}) => {
  return (
    <div className="group bg-gradient-to-br from-white to-slate-50 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 p-6 flex flex-col gap-4 min-w-[300px] max-w-[360px] border border-slate-200 hover:border-teal-300 hover:-translate-y-1">
      {/* Staff Info */}
      <div className="border-b border-slate-200 pb-4">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center">
            <User className="w-6 h-6 text-white" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-slate-900 group-hover:text-teal-600 transition-colors">
              {name}
            </h3>
          </div>
        </div>
      </div>

      {/* Role Badge */}
      <div className="flex items-center gap-2 bg-gradient-to-r from-teal-50 to-teal-100 px-4 py-2 rounded-lg">
        <Briefcase className="w-4 h-4 text-teal-600" />
        <span className="text-teal-900 font-semibold">{role}</span>
      </div>

      {/* Qualifications */}
      <div className="flex-1 space-y-2">
        <p className="text-sm text-slate-500 font-medium flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-teal-600" />
          Qualifications
        </p>
        <ul className="space-y-2 pl-6">
          {qualifications.map((qual, index) => (
            <li key={index} className="text-slate-900 text-sm flex items-start gap-2">
              <span className="text-teal-500 mt-0.5">•</span>
              <span>{qual}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Availability */}
      <div className="border-t border-slate-100 pt-4 space-y-3">
        <p className="text-sm text-slate-500 font-medium">Availability</p>
        
        {/* Days */}
        <div className="flex items-start gap-3">
          <Calendar className="w-4 h-4 text-slate-600 mt-0.5 flex-shrink-0" />
          <div>
            <p className="text-xs text-slate-500 font-medium">Days</p>
            <p className="text-slate-900 font-semibold">{availability.days}</p>
          </div>
        </div>

        {/* Time */}
        <div className="flex items-start gap-3">
          <Clock className="w-4 h-4 text-slate-600 mt-0.5 flex-shrink-0" />
          <div>
            <p className="text-xs text-slate-500 font-medium">Hours</p>
            <p className="text-slate-900 font-semibold">{availability.time}</p>
          </div>
        </div>
      </div>

      {/* Apply Button */}
      <button
        onClick={onApply}
        className="w-full py-3.5 rounded-xl bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white font-bold transition-all shadow-lg shadow-teal-500/30 hover:shadow-teal-500/50 hover:scale-105 flex items-center justify-center gap-2 group"
      >
        Request Staffing
        <Briefcase className="w-4 h-4 group-hover:rotate-12 transition-transform" />
      </button>
    </div>
  );
};

export default StaffCard;

