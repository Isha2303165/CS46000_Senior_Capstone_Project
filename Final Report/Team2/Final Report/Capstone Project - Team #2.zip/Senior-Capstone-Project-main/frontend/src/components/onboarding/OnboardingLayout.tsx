import { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Building2 } from 'lucide-react';
import ProgressIndicator from './ProgressIndicator';

interface OnboardingLayoutProps {
  children: ReactNode;
  currentStep: number;
  totalSteps: number;
  stepLabels: string[];
  title: string;
  subtitle?: string;
  onBack?: () => void;
  showBackButton?: boolean;
}

export default function OnboardingLayout({
  children,
  currentStep,
  totalSteps,
  stepLabels,
  title,
  subtitle,
  onBack,
  showBackButton = true
}: OnboardingLayoutProps) {
  const navigate = useNavigate();

  const handleBack = () => {
    if (onBack) {
      onBack();
    } else {
      navigate(-1);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* animated background pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 2px 2px, rgba(255,255,255,0.15) 1px, transparent 0)`,
          backgroundSize: '40px 40px'
        }}></div>
      </div>

      <div className="relative min-h-screen flex flex-col">
        {/* header with logo */}
        <div className="w-full py-6 px-4 sm:px-8">
          <div className="max-w-4xl mx-auto flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-amber-500 to-amber-600 rounded-full flex items-center justify-center shadow-lg shadow-amber-500/30">
              <Building2 className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-xl font-bold text-white">Shift Solutions</h1>
          </div>
        </div>

        {/* main content */}
        <div className="flex-1 flex items-center justify-center px-4 py-8">
          <div className="w-full max-w-4xl">
            {/* progress indicator */}
            <div className="mb-12">
              <ProgressIndicator
                currentStep={currentStep}
                totalSteps={totalSteps}
                stepLabels={stepLabels}
              />
            </div>

            {/* content card */}
            <div className="bg-slate-800/60 backdrop-blur-xl rounded-2xl shadow-2xl border border-slate-700/50 overflow-hidden">
              {/* card header */}
              <div className="p-8 sm:p-10 border-b border-slate-700/50">
                {showBackButton && currentStep > 1 && (
                  <button
                    onClick={handleBack}
                    className="mb-4 flex items-center gap-2 text-slate-400 hover:text-teal-400 transition-colors duration-200 group"
                  >
                    <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform duration-200" />
                    <span className="text-sm font-medium">Back</span>
                  </button>
                )}

                <h2 className="text-3xl sm:text-4xl font-bold text-white mb-3 bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent">
                  {title}
                </h2>

                {subtitle && (
                  <p className="text-slate-400 text-lg">
                    {subtitle}
                  </p>
                )}
              </div>

              {/* card content */}
              <div className="p-8 sm:p-10">
                {children}
              </div>
            </div>

            {/* helper text */}
            <p className="text-center text-slate-500 text-sm mt-6">
              Need help? <a href="/contact" className="text-teal-400 hover:text-teal-300 font-medium hover:underline">Contact Support</a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
