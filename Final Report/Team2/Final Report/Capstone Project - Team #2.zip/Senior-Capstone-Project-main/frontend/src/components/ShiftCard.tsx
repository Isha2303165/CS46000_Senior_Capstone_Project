import React from 'react';
import { Calendar, Clock, DollarSign, MapPin, Briefcase } from 'lucide-react';

interface ShiftCardProps {
  id: number;
  restaurantName: string;
  restaurantType: string;
  role: string;
  date: string;
  startTime: string;
  endTime: string;
  payRate: string;
  location: string;
  description?: string;
  onApply: () => void;
}

const ShiftCard: React.FC<ShiftCardProps> = ({
  restaurantName,
  restaurantType,
  role,
  date,
  startTime,
  endTime,
  payRate,
  location,
  description,
  onApply,
}) => {
  return (
    <div className="group bg-gradient-to-br from-white to-slate-50 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 p-6 flex flex-col gap-4 min-w-[300px] max-w-[360px] border border-slate-200 hover:border-amber-300 hover:-translate-y-1">
      {/* Restaurant Info */}
      <div className="border-b border-slate-200 pb-4">
        <h3 className="text-2xl font-bold text-slate-900 mb-1 group-hover:text-amber-600 transition-colors">
          {restaurantName}
        </h3>
        <p className="text-sm font-medium text-slate-600">{restaurantType}</p>
      </div>

      {/* Role Badge */}
      <div className="flex items-center gap-2 bg-gradient-to-r from-amber-50 to-amber-100 px-4 py-2 rounded-lg">
        <Briefcase className="w-4 h-4 text-amber-600" />
        <span className="text-amber-900 font-semibold">{role}</span>
      </div>

      {/* Shift Details */}
      <div className="flex-1 space-y-3">
        {/* Date */}
        <div className="flex items-start gap-3">
          <Calendar className="w-4 h-4 text-slate-600 mt-0.5 flex-shrink-0" />
          <div>
            <p className="text-sm text-slate-500 font-medium">Date</p>
            <p className="text-slate-900 font-semibold">{date}</p>
          </div>
        </div>

        {/* Time */}
        <div className="flex items-start gap-3">
          <Clock className="w-4 h-4 text-slate-600 mt-0.5 flex-shrink-0" />
          <div>
            <p className="text-sm text-slate-500 font-medium">Time</p>
            <p className="text-slate-900 font-semibold">{startTime} - {endTime}</p>
          </div>
        </div>

        {/* Pay Rate */}
        <div className="flex items-start gap-3">
          <DollarSign className="w-4 h-4 text-green-600 mt-0.5 flex-shrink-0" />
          <div>
            <p className="text-sm text-slate-500 font-medium">Pay Rate</p>
            <p className="text-green-700 font-bold text-lg">{payRate}</p>
          </div>
        </div>

        {/* Location */}
        <div className="flex items-start gap-3">
          <MapPin className="w-4 h-4 text-slate-600 mt-0.5 flex-shrink-0" />
          <div>
            <p className="text-sm text-slate-500 font-medium">Location</p>
            <p className="text-slate-900">{location}</p>
          </div>
        </div>

        {/* Description */}
        {description && (
          <div className="pt-2 border-t border-slate-100">
            <p className="text-sm text-slate-600 line-clamp-2">{description}</p>
          </div>
        )}
      </div>

      {/* Apply Button */}
      <button
        onClick={onApply}
        className="w-full py-3.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-bold transition-all shadow-lg shadow-amber-500/30 hover:shadow-amber-500/50 hover:scale-105 flex items-center justify-center gap-2 group"
      >
        Apply for Shift
        <Briefcase className="w-4 h-4 group-hover:rotate-12 transition-transform" />
      </button>
    </div>
  );
};

export default ShiftCard;
