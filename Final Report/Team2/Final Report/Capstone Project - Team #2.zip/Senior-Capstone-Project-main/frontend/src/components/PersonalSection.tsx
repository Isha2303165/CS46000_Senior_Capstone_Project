import { useState, useEffect } from "react";
import { updateStaffProfile, getEmergencyContacts, createEmergencyContact, updateEmergencyContact } from "../api";

interface PersonalSectionProps {
  personal: {
    address: string;
    date_of_birth: string;
    ssn: string;
    email: string;
    phone: string;
    e_contact_name?: string;
    e_contact_relation?: string;
    e_contact_phone?: string;
  };
  userId: number;
  showEmergencyContact?: boolean;
}

export default function PersonalSection({ personal, userId, showEmergencyContact = true, }: PersonalSectionProps) {
  const [isEditingInfo, setIsEditingInfo] = useState(false);
  const [isEditingContact, setIsEditingContact] = useState(false);
  const [emergencyContactId, setEmergencyContactId] = useState<number | null>(null);

  const [infoData, setInfoData] = useState({
    phone: personal?.phone || "",
  });

  const [contactData, setContactData] = useState({
    name: personal?.e_contact_name || "",
    relation: personal?.e_contact_relation || "",
    phone: personal?.e_contact_phone || "",
    email: "",
    address: "",
    city: "",
    state: "",
  });

  // Load emergency contacts on mount
  useEffect(() => {
    if (showEmergencyContact) {
      loadEmergencyContacts();
    }
  }, [userId, showEmergencyContact]);

  const loadEmergencyContacts = async () => {
    try {
      const response = await getEmergencyContacts(userId);
      if (response.contacts && response.contacts.length > 0) {
        const primaryContact = response.contacts.find((c: any) => c.is_primary) || response.contacts[0];
        setEmergencyContactId(primaryContact.id);
        setContactData({
          name: primaryContact.name,
          relation: primaryContact.relation,
          phone: primaryContact.phone,
          email: primaryContact.email || "",
          address: primaryContact.address || "",
          city: primaryContact.city || "",
          state: primaryContact.state || "",
        });
      }
    } catch (error) {
      console.log("No emergency contacts found or error loading");
    }
  };

  const handleInfoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInfoData({
      ...infoData,
      [e.target.name]: e.target.value,
    });
  };

  const handleInfoSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateStaffProfile(userId, infoData);
      setIsEditingInfo(false);
      alert("Profile updated successfully!");
    } catch (error: any) {
      alert(error.response?.data?.detail || "Failed to update profile");
    }
  };

  const handleContactChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setContactData({
      ...contactData,
      [e.target.name]: e.target.value,
    });
  };

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (emergencyContactId) {
        // Update existing contact
        await updateEmergencyContact(emergencyContactId, contactData);
      } else {
        // Create new contact
        const response = await createEmergencyContact(userId, {
          ...contactData,
          is_primary: true
        });
        setEmergencyContactId(response.contact.id);
      }
      setIsEditingContact(false);
      alert("Emergency contact saved successfully!");
    } catch (error: any) {
      alert(error.response?.data?.detail || "Failed to save emergency contact");
    }
  };

  return (
    <div className="col-span flex flex-col gap-4">
      {/* Personal Info Section */}
      <div className="p-6 border bg-slate-800/40 border-slate-400/40 rounded-lg shadow-sm">
        <div className="flex justify-between items-center mb-2">
          <h3>Personal Information</h3>
          <button
            type="button"
            onClick={() => setIsEditingInfo(!isEditingInfo)}
            className="py-1 px-4 border-2 border-blue-500 hover:bg-blue-500 text-white font-semibold rounded-full transition-all duration-300"
          >
            {isEditingInfo ? "Cancel" : "Edit"}
          </button>
        </div>

        {/* Conditional Rendering - in editing mode a form is rendered*/}
        {!isEditingInfo ? (
          <dl className="text-sm text-slate-300 space-y-1">
            <div className="flex flex-row gap-3">
              <dt className="font-semibold text-white/90">Email</dt>
              <dd>{personal.email}</dd>
            </div>
            <div className="flex flex-row gap-3">
              <dt className="font-semibold text-white/90">Date of Birth</dt>
              <dd>{personal.date_of_birth}</dd>
            </div>
            <div className="flex flex-row gap-3">
              <dt className="font-semibold text-white/90">Phone</dt>
              <dd>{infoData.phone}</dd>
            </div>
          </dl>
        ) : (
          <form onSubmit={handleInfoSubmit} className="space-y-2">
            <label className="block text-sm text-slate-300">
              Phone Number
              <input
                type="tel"
                name="phone"
                value={infoData.phone}
                onChange={handleInfoChange}
                className="w-full p-2 mt-1 rounded-xl bg-slate-800 text-slate-200 border border-slate-600"
                placeholder="Phone number"
              />
            </label>
            <button
              type="submit"
              className="py-2 px-4 bg-green-600 hover:bg-green-500 text-white font-semibold rounded-full transition-all duration-300"
            >
              Save
            </button>
          </form>
        )}
      </div>

      {/* Emergency Contact Section */}
      {showEmergencyContact && (
        <div className="p-6 border border-slate-400/40 rounded-lg shadow-sm">
          <div className="flex justify-between items-center mb-2">
            <h3>Emergency Contact</h3>
            <button
              type="button"
              onClick={() => setIsEditingContact(!isEditingContact)}
              className="py-1 px-4 border-2 border-blue-500 hover:bg-blue-500 text-white font-semibold rounded-full transition-all duration-300"
            >
              {isEditingContact ? "Cancel" : "Edit"}
            </button>
          </div>

          {/* Conditional Rendering - in editing mode a form is rendered*/}
          {!isEditingContact ? (
            <dl className="text-sm text-slate-300 space-y-1">
              <div className=" flex flex-row gap-3">
                <dt className="font-semibold text-white/90">Name</dt>
                <dd>{contactData.name || "Not set"}</dd>
              </div>
              <div className=" flex flex-row gap-3">
                <dt className="font-semibold text-white/90">Relation</dt>
                <dd>{contactData.relation || "Not set"}</dd>
              </div>
              <div className=" flex flex-row gap-3">
                <dt className="font-semibold text-white/90">Phone</dt>
                <dd>{contactData.phone || "Not set"}</dd>
              </div>
            </dl>
          ) : (
            <form onSubmit={handleContactSubmit} className="space-y-2">
              <input
                type="text"
                name="name"
                value={contactData.name}
                onChange={handleContactChange}
                placeholder="Contact Name"
                required
                className="w-full p-2 rounded-xl bg-slate-800 text-slate-200 border border-slate-600"
              />
              <input
                type="text"
                name="relation"
                value={contactData.relation}
                onChange={handleContactChange}
                placeholder="Relationship (e.g., Spouse, Parent)"
                required
                className="w-full p-2 rounded-xl bg-slate-800 text-slate-200 border border-slate-600"
              />
              <input
                type="tel"
                name="phone"
                onChange={handleContactChange}
                value={contactData.phone}
                placeholder="Contact Phone"
                required
                className="w-full p-2 rounded-xl bg-slate-800 text-slate-200 border border-slate-600"
              />
              <input
                type="email"
                name="email"
                onChange={handleContactChange}
                value={contactData.email}
                placeholder="Contact Email (optional)"
                className="w-full p-2 rounded-xl bg-slate-800 text-slate-200 border border-slate-600"
              />
              <input
                type="text"
                name="address"
                onChange={handleContactChange}
                value={contactData.address}
                placeholder="Address"
                required
                className="w-full p-2 rounded-xl bg-slate-800 text-slate-200 border border-slate-600"
              />
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  name="city"
                  onChange={handleContactChange}
                  value={contactData.city}
                  placeholder="City"
                  required
                  className="w-full p-2 rounded-xl bg-slate-800 text-slate-200 border border-slate-600"
                />
                <input
                  type="text"
                  name="state"
                  onChange={handleContactChange}
                  value={contactData.state}
                  placeholder="State"
                  required
                  maxLength={2}
                  className="w-full p-2 rounded-xl bg-slate-800 text-slate-200 border border-slate-600"
                />
              </div>
              <button
                type="submit"
                className="py-2 px-4 bg-green-600 hover:bg-green-500 text-white font-semibold rounded-full transition-all duration-300"
              >
                Save
              </button>
            </form>
          )}
        </div>
      )}
    </div>
  );
}