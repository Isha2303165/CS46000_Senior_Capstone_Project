import { Check } from 'lucide-react';

interface ProgressIndicatorProps {
  currentStep: number;
  totalSteps: number;
  stepLabels: string[];
}

export default function ProgressIndicator({ currentStep, totalSteps, stepLabels }: ProgressIndicatorProps) {
  return (
    <div className="w-full">
      {/* progress bar */}
      <div className="relative">
        {/* background line */}
        <div className="absolute top-5 left-0 right-0 h-1 bg-slate-700/50">
          {/* active progress line with gradient */}
          <div
            className="h-full bg-gradient-to-r from-teal-500 to-amber-500 transition-all duration-700 ease-out"
            style={{ width: `${((currentStep - 1) / (totalSteps - 1)) * 100}%` }}
          />
        </div>

        {/* step circles */}
        <div className="relative flex justify-between">
          {stepLabels.map((label, index) => {
            const stepNumber = index + 1;
            const isCompleted = stepNumber < currentStep;
            const isCurrent = stepNumber === currentStep;
            const isUpcoming = stepNumber > currentStep;

            return (
              <div key={stepNumber} className="flex flex-col items-center">
                {/* circle */}
                <div
                  className={`
                    w-10 h-10 rounded-full flex items-center justify-center
                    transition-all duration-500 z-10
                    ${isCompleted
                      ? 'bg-gradient-to-br from-teal-500 to-teal-600 shadow-lg shadow-teal-500/50 scale-100'
                      : isCurrent
                      ? 'bg-gradient-to-br from-amber-500 to-amber-600 shadow-lg shadow-amber-500/50 scale-110 animate-pulse'
                      : 'bg-slate-700 border-2 border-slate-600'
                    }
                  `}
                >
                  {isCompleted ? (
                    <Check className="w-5 h-5 text-white" strokeWidth={3} />
                  ) : (
                    <span className={`text-sm font-bold ${isCurrent ? 'text-white' : 'text-slate-400'}`}>
                      {stepNumber}
                    </span>
                  )}
                </div>

                {/* label - only show on desktop */}
                <span className={`
                  mt-3 text-xs font-medium text-center hidden sm:block max-w-[100px]
                  transition-colors duration-300
                  ${isCurrent ? 'text-amber-400' : isCompleted ? 'text-teal-400' : 'text-slate-500'}
                `}>
                  {label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* mobile: show current step label below */}
      <div className="sm:hidden mt-4 text-center">
        <p className="text-sm font-medium text-amber-400">
          {stepLabels[currentStep - 1]}
        </p>
        <p className="text-xs text-slate-400 mt-1">
          Step {currentStep} of {totalSteps}
        </p>
      </div>
    </div>
  );
}
