export default function PaymentSection() {
  return (
    <div className="rounded-xl p-6 mt-6 bg-slate-950/30 backdrop-blur-sm shadow-md">
      <div className="flex justify-between items-center">
        <h3>Payment Account</h3>
      </div>
      <p className="text-md text-slate-300 pb-2">Link your bank or Stripe account here.</p>
    </div>
  );
}