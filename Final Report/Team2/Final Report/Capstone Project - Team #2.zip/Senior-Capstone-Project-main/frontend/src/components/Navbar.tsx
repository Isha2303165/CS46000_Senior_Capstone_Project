// components/Navbar.tsx
import React, { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Building2, LucideIcon, LogOut, Menu, X } from "lucide-react";
import { getUserData, getUserRole } from "../utils/auth";

interface MenuItem {
  path: string;
  label: string;
  className?: string;
}

interface AuthLinks {
  login: {
    path: string;
    text: string;
  };
}

export interface NavbarProps {
  menuItems?: MenuItem[];
  showLogo?: boolean;
  logo?: {
    icon: LucideIcon;
    text: string;
  };
  showAuth?: boolean;
  authLinks?: AuthLinks;
  className?: string;
}

const Navbar: React.FC<NavbarProps> = ({
  menuItems = [],
  showLogo = true,
  logo = {
    icon: Building2,
    text: "Shift Solutions",
  },
  showAuth = true,
  authLinks = {
    login: { path: "/login", text: "Login" },
  },
  className = "",
}) => {
  const location = useLocation();
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 4);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Handle logo click - redirect based on authentication, role, and status
  const handleLogoClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const userData = getUserData();
    
    if (!userData) {
      // Not logged in - go to landing page
      navigate("/");
    } else if (userData.role === 2) {
      // Staff - go to dashboard
      navigate("/staff/dashboard");
    } else if (userData.role === 1) {
      // Client - check subscription status
      if (userData.status === "pending") {
        navigate("/client/subscription");
      } else {
        navigate("/client/post-shift");
      }
    } else if (userData.role === 0) {
      // Admin - go to landing page (or admin dashboard when implemented)
      navigate("/");
    } else {
      navigate("/");
    }
  };

  // Handle logout
  const handleLogout = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    localStorage.removeItem("access_token");
    sessionStorage.removeItem("pending_2fa_email");
    navigate("/");
  };

  // Check if user is logged in
  const isLoggedIn = getUserRole() !== null;

  return (
    <>
      {/* Spacer so content doesn't sit under the fixed nav */}
      <div className="h-20" />

      <nav
        className={[
          "fixed inset-x-0 top-0 z-50",
          "px-4 sm:px-6",
          "pt-4",
          className,
        ].join(" ")}
        aria-label="Primary"
      >
        <div
          className={[
            "max-w-7xl mx-auto",
            "rounded-2xl",
            "backdrop-blur-xl",
            "bg-gradient-to-r from-slate-900/95 via-slate-800/95 to-slate-900/95",
            "border border-white/10",
            "shadow-xl",
            "flex items-center justify-between",
            "px-6 py-4",
            "transition-all duration-300",
            scrolled ? "shadow-2xl shadow-black/20 border-teal-500/20" : "",
          ].join(" ")}
        >
          {/* Logo */}
          {showLogo && (
            <div className="flex items-center gap-3 z-10">
              <a
                href="#"
                onClick={handleLogoClick}
                className="group flex items-center gap-3 cursor-pointer"
              >
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-teal-400 to-amber-400 rounded-full blur-md opacity-50 group-hover:opacity-75 transition-opacity" />
                  <img
                    src="/src/assets/img/logo.png"
                    alt="Shift Solutions Logo"
                    className="relative w-10 h-10 rounded-full object-cover ring-2 ring-white/20 group-hover:ring-teal-400/50 transition-all"
                  />
                </div>
                <span className="text-white font-bold text-xl whitespace-nowrap group-hover:text-teal-300 transition-colors hidden sm:block">
                  {logo.text}
                </span>
              </a>
            </div>
          )}

          {/* Center menu - desktop */}
          {menuItems.length > 0 && (
            <div className="hidden md:flex items-center justify-center gap-8 flex-1 mx-8">
              {menuItems.map((item, index) => (
                <Link
                  key={index}
                  to={item.path}
                  className={[
                    "relative px-4 py-2 rounded-lg transition-all text-sm font-medium",
                    location.pathname === item.path
                      ? "text-white bg-white/10"
                      : "text-white/80 hover:text-white hover:bg-white/5",
                    item.className || "",
                  ].join(" ")}
                >
                  {item.label}
                  {location.pathname === item.path && (
                    <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1/2 h-0.5 bg-gradient-to-r from-teal-400 to-amber-400 rounded-full" />
                  )}
                </Link>
              ))}
            </div>
          )}

          {/* Auth buttons - desktop */}
          {showAuth && (
            <div className="hidden md:flex items-center gap-3 z-10">
              {isLoggedIn ? (
                <button
                  onClick={handleLogout}
                  className="group flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-red-500/10 to-red-600/10 hover:from-red-500/20 hover:to-red-600/20 text-white border border-red-500/30 hover:border-red-500/50 rounded-xl transition-all text-sm font-medium shadow-lg shadow-red-500/10"
                >
                  <LogOut className="w-4 h-4 group-hover:scale-110 transition-transform" />
                  Log Out
                </button>
              ) : (
                <Link
                  className="px-6 py-2.5 bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white rounded-xl transition-all text-sm font-semibold shadow-lg shadow-teal-500/30 hover:shadow-teal-500/50 hover:scale-105"
                  to={authLinks.login.path}
                >
                  {authLinks.login.text}
                </Link>
              )}
            </div>
          )}

          {/* Mobile menu button */}
          {menuItems.length > 0 && (
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-white hover:bg-white/10 rounded-lg transition-colors"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          )}
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && menuItems.length > 0 && (
          <div className="md:hidden mt-2 max-w-7xl mx-auto">
            <div className="bg-gradient-to-br from-slate-900/98 to-slate-800/98 backdrop-blur-xl border border-white/10 rounded-2xl p-4 shadow-2xl">
              <div className="flex flex-col gap-2">
                {menuItems.map((item, index) => (
                  <Link
                    key={index}
                    to={item.path}
                    onClick={() => setMobileMenuOpen(false)}
                    className={[
                      "px-4 py-3 rounded-xl transition-all text-sm font-medium",
                      location.pathname === item.path
                        ? "text-white bg-gradient-to-r from-teal-500/20 to-amber-500/20 border border-teal-500/30"
                        : "text-white/80 hover:text-white hover:bg-white/5",
                      item.className || "",
                    ].join(" ")}
                  >
                    {item.label}
                  </Link>
                ))}
                
                {/* Mobile auth */}
                {showAuth && (
                  <div className="pt-2 mt-2 border-t border-white/10">
                    {isLoggedIn ? (
                      <button
                        onClick={(e) => {
                          handleLogout(e as any);
                          setMobileMenuOpen(false);
                        }}
                        className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-red-500/10 to-red-600/10 text-white border border-red-500/30 rounded-xl transition-all text-sm font-medium"
                      >
                        <LogOut className="w-4 h-4" />
                        Log Out
                      </button>
                    ) : (
                      <Link
                        className="block w-full text-center px-4 py-3 bg-gradient-to-r from-teal-500 to-teal-600 text-white rounded-xl transition-all text-sm font-semibold shadow-lg shadow-teal-500/30"
                        to={authLinks.login.path}
                        onClick={() => setMobileMenuOpen(false)}
                      >
                        {authLinks.login.text}
                      </Link>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </nav>
    </>
  );
};

export default Navbar;
