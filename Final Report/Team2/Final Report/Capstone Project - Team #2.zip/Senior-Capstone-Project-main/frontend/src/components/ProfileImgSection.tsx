import { SquarePen } from 'lucide-react';
import { useRef, useState } from 'react';
import { uploadProfileImage } from '../api';

interface ProfileImageSectionProps {
  profile: {
    first_name: string;
    last_name: string;
    status: string;
    imgSrc: string;
  };
  userId: number;
  onImageUpdate?: (newImageUrl: string) => void;
}

export default function ProfileImageSection({ profile, userId, onImageUpdate }: ProfileImageSectionProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState<string>("");

  const handleEditClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      setMessage("Please upload an image file");
      setTimeout(() => setMessage(""), 3000);
      return;
    }

    setUploading(true);
    setMessage("");

    try {
      const response = await uploadProfileImage(userId, file);
      setMessage("Profile image updated successfully!");
      setTimeout(() => setMessage(""), 3000);
      
      // Call the callback to update the image in parent component
      if (onImageUpdate) {
        onImageUpdate(`http://localhost:8000${response.image_url}`);
      }
    } catch (error: any) {
      setMessage(error.response?.data?.detail || "Failed to upload profile image");
      setTimeout(() => setMessage(""), 3000);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center rounded-xl p-6 bg-slate-800/70 border border-slate-400/40 shadow-sm">
      <div className="relative">
        <img
          className="w-60 h-60 mb-4 rounded-full shadow-lg object-cover"
          src={profile.imgSrc}
          alt={`${profile.first_name} ${profile.last_name}`}
        />
        <button
          type="button"
          onClick={handleEditClick}
          disabled={uploading}
          className="absolute top-2 right-2 rounded-full p-1 hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
          title="Change profile picture"
        >
          <SquarePen className="w-6 h-6 text-white" />
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileSelect}
          className="hidden"
        />
      </div>
      <h2 className="mb-0">
        {profile.first_name} {profile.last_name}
      </h2>
      <p>Profile Status: {profile.status}</p>
      {message && (
        <div className={`mt-2 p-2 rounded text-sm ${message.includes("success") ? "bg-green-500/20 text-green-300" : "bg-red-500/20 text-red-300"}`}>
          {message}
        </div>
      )}
      {uploading && <p className="text-sm text-slate-400">Uploading...</p>}
    </div>
  );
}
