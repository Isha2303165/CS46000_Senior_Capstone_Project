import { useState, useRef, useEffect } from 'react';
import { ChevronDown } from 'lucide-react';

interface RoleDropdownProps {
  value: string;
  onChange: (value: string) => void;
  options: string[];
  className?: string;
}

export default function RoleDropdown({ 
  value, 
  onChange, 
  options, 
  className = '' 
}: RoleDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div ref={dropdownRef} className={`relative ${className}`}>
      <div className="flex items-center gap-2">
        <input
          type="text"
          value={value}
          readOnly
          className="w-full px-5 py-3 rounded-full bg-white placeholder-slate-600 text-slate-900 border border-white/40 focus:outline-none focus:ring-2 focus:ring-blue-300 transition shadow-sm"
          onClick={() => setIsOpen(!isOpen)}
        />
        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className="px-3 py-3 rounded-full bg-white border border-white/40 hover:bg-slate-50 transition shadow-sm flex items-center justify-center"
        >
          <ChevronDown className={`w-5 h-5 text-slate-700 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
        </button>
      </div>
      
      {isOpen && (
        <div className="absolute z-10 w-full mt-2 bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden">
          {options.map((option) => (
            <button
              key={option}
              type="button"
              onClick={() => {
                onChange(option);
                setIsOpen(false);
              }}
              className={`w-full px-5 py-3 text-left hover:bg-slate-100 transition ${
                value === option ? 'bg-slate-100 font-medium' : ''
              }`}
            >
              {option}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

