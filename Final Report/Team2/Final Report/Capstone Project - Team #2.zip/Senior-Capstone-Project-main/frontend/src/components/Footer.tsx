{/*footer component - © 2025 Shift Solutions. All rights reserved.*/}

export default function Footer() {
  return (
    <footer className="text-white py-4 text-center text-sm">
      <p className="text-white/80">
        © {new Date().getFullYear()} Shift Solutions. All rights reserved.
      </p>
    </footer>
  );
}
