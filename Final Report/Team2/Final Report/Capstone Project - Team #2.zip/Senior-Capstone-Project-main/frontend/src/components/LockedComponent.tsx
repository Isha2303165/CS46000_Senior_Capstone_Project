export default function LockedComponent({
  text = "Locked",
  size = "md",
  colorClass = "bg-slate-300/30", // semi-transparent default
}) {
  const heights = {
    sm: "h-24",
    md: "h-40",
    lg: "h-60",
  };

  return (
    <div
      className={`${heights[size]} ${colorClass} w-full flex items-center justify-center rounded-xl mb-8 shadow-md backdrop-blur-md`}
    >
      <h3>{text}</h3>
    </div>
  );
}
