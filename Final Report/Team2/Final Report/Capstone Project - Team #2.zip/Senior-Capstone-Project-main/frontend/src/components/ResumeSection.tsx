import { useState, useEffect, useRef } from "react";
import { uploadResume, getResume } from "../api";

interface ResumeSectionProps {
  userId: number;
}

export default function ResumeSection({ userId }: ResumeSectionProps) {
  const [resumeUrl, setResumeUrl] = useState<string | null>(null);
  const [resumeStatus, setResumeStatus] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load existing resume on component mount
  useEffect(() => {
    loadResume();
  }, [userId]);

  const loadResume = async () => {
    try {
      const data = await getResume(userId);
      setResumeUrl(data.resume_url);
      setResumeStatus(data.status);
    } catch (error: any) {
      // No resume uploaded yet - this is expected, not an error
      if (error.response?.status === 404) {
        // Silently handle - no resume uploaded yet
        return;
      }
      console.error("Error loading resume:", error);
    }
  };

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    const allowedTypes = [
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];
    
    if (!allowedTypes.includes(file.type)) {
      setMessage("Please upload a PDF or Word document");
      return;
    }

    setUploading(true);
    setMessage("");

    try {
      const response = await uploadResume(userId, file);
      setResumeUrl(response.resume_url);
      setResumeStatus("pending");
      setMessage("Resume uploaded successfully!");
      setTimeout(() => setMessage(""), 3000);
    } catch (error: any) {
      setMessage(error.response?.data?.detail || "Failed to upload resume");
    } finally {
      setUploading(false);
    }
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const getStatusBadge = () => {
    if (!resumeStatus) return null;
    
    const statusColors = {
      pending: "bg-yellow-500",
      approved: "bg-green-500",
      rejected: "bg-red-500"
    };

    return (
      <span className={`px-2 py-1 text-xs rounded-full ${statusColors[resumeStatus as keyof typeof statusColors] || 'bg-gray-500'}`}>
        {resumeStatus.charAt(0).toUpperCase() + resumeStatus.slice(1)}
      </span>
    );
  };

  return (
    <div className="rounded-xl p-6 mt-6 bg-slate-300/30 backdrop-blur-sm shadow-md">
      <div className="flex justify-between items-center mb-2">
        <div className="flex items-center gap-3">
          <h3>Resume</h3>
          {getStatusBadge()}
        </div>
        <button 
          type="button" 
          className="py-1 px-4 border-2 border-blue-500 hover:bg-blue-500 text-white font-semibold rounded-full transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
          onClick={handleUploadClick}
          disabled={uploading}
        >
          {uploading ? "Uploading..." : resumeUrl ? "Replace" : "Upload"}
        </button>
      </div>
      <p className="text-md text-slate-300 pb-2">Upload your resume here (PDF or Word document).</p>
      
      <input
        ref={fileInputRef}
        type="file"
        accept=".pdf,.doc,.docx"
        onChange={handleFileSelect}
        className="hidden"
      />

      {resumeUrl && (
        <div className="mt-3">
          <a 
            href={`http://localhost:8000${resumeUrl}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-400 hover:text-blue-300 underline text-sm"
          >
            View Current Resume
          </a>
        </div>
      )}

      {message && (
        <div className={`mt-3 p-2 rounded ${message.includes("success") ? "bg-green-500/20 text-green-300" : "bg-red-500/20 text-red-300"}`}>
          {message}
        </div>
      )}
    </div>
  );
}