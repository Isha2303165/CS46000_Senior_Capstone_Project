import { useState, useEffect, useRef } from "react";
import { uploadGovernmentId, getGovernmentId } from "../api";

interface VerificationSectionProps {
  verification: {
    ssn: string;
    liq_license_number: string;
    liq_license_state: string;
    liq_license_exp_date: string;
  };
  userId: number;
}

export default function VerificationSection({ verification, userId }: VerificationSectionProps) {
  const [govIdUrl, setGovIdUrl] = useState<string | null>(null);
  const [govIdStatus, setGovIdStatus] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load existing government ID on component mount
  useEffect(() => {
    loadGovernmentId();
  }, [userId]);

  const loadGovernmentId = async () => {
    try {
      const data = await getGovernmentId(userId);
      setGovIdUrl(data.gov_id_url);
      setGovIdStatus(data.status);
    } catch (error: any) {
      // No government ID uploaded yet - this is expected, not an error
      if (error.response?.status === 404) {
        // Silently handle - no government ID uploaded yet
        return;
      }
      console.error("Error loading government ID:", error);
    }
  };

  const handleFileSelect = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type (PDF or images)
    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png'];
    
    if (!allowedTypes.includes(file.type)) {
      setMessage("Please upload a PDF or image file (JPG, PNG)");
      return;
    }

    setUploading(true);
    setMessage("");

    try {
      const response = await uploadGovernmentId(userId, file);
      setGovIdUrl(response.gov_id_url);
      setGovIdStatus("pending");
      setMessage("Government ID uploaded successfully!");
      setTimeout(() => setMessage(""), 3000);
    } catch (error: any) {
      setMessage(error.response?.data?.detail || "Failed to upload government ID");
    } finally {
      setUploading(false);
    }
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const getStatusBadge = () => {
    if (!govIdStatus) return null;
    
    const statusColors = {
      pending: "bg-yellow-500",
      approved: "bg-green-500",
      rejected: "bg-red-500",
      expired: "bg-gray-500"
    };

    return (
      <span className={`px-2 py-1 text-xs rounded-full ${statusColors[govIdStatus as keyof typeof statusColors] || 'bg-gray-500'}`}>
        {govIdStatus.charAt(0).toUpperCase() + govIdStatus.slice(1)}
      </span>
    );
  };

  return (
    <div className="rounded-xl p-6 mt-6 bg-slate-300/30 backdrop-blur-sm shadow-md">
      <div className="flex justify-between items-center mb-2">
        <div className="flex items-center gap-3">
          <h3>Verification</h3>
          {getStatusBadge()}
        </div>
        <button 
          type="button" 
          className="py-1 px-4 border-2 border-blue-500 hover:bg-blue-500 text-white font-semibold rounded-full transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
          onClick={handleUploadClick}
          disabled={uploading}
        >
          {uploading ? "Uploading..." : govIdUrl ? "Replace ID" : "Upload ID"}
        </button>
      </div>
      <p className="text-md text-slate-300 pb-2">Upload your government ID and verification documents here.</p>
      
      <input
        ref={fileInputRef}
        type="file"
        accept=".pdf,.jpg,.jpeg,.png"
        onChange={handleFileSelect}
        className="hidden"
      />

      {govIdUrl && (
        <div className="mb-3">
          <a 
            href={`http://localhost:8000${govIdUrl}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-400 hover:text-blue-300 underline text-sm"
          >
            View Uploaded Government ID
          </a>
        </div>
      )}

      {message && (
        <div className={`mb-3 p-2 rounded ${message.includes("success") ? "bg-green-500/20 text-green-300" : "bg-red-500/20 text-red-300"}`}>
          {message}
        </div>
      )}

      <dl className="text-sm text-slate-300 space-y-1">
        <div className="flex flex-row gap-2">
          <dt className="font-semibold text-white/90">SSN</dt>
          <dd>{verification.ssn}</dd>
        </div>
        <div className="flex flex-row gap-3"> 
          <dt className="font-semibold text-white/90">License Number</dt>
          <dd>{verification.liq_license_number}</dd>
        </div>
        <div className="flex flex-row gap-3">
          <dt className="font-semibold text-white/90">License State</dt>
          <dd>{verification.liq_license_state}</dd>
        </div>
        <div className="flex flex-row gap-3">
          <dt className="font-semibold text-white/90">Expiration Date</dt>
          <dd>{verification.liq_license_exp_date}</dd>
        </div>
      </dl>       
    </div>
  );
}