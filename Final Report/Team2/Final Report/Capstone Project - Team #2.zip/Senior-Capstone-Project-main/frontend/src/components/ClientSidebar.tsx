import { useNavigate, useLocation } from 'react-router-dom';
import { CreditCard, Calendar, Settings, User, Store, LogOut, Menu, X } from 'lucide-react';
import { useState } from 'react';

export default function ClientSidebar() {
  const navigate = useNavigate();
  const location = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  // Define the sidebar navigation items for each client page
  const clientPages = [
    { 
      path: "/client/dashboard", 
      label: "Dashboard",
      icon: User
    },
    { 
      path: "/client/post-shift", 
      label: "Post Shift",
      icon: Calendar
    },
    { 
      path: "/client/marketplace", 
      label: "Marketplace",
      icon: Store
    },
    { 
      path: "/client/subscription", 
      label: "Subscription",
      icon: CreditCard
    },
    { 
      path: "/client/staff-preferences", 
      label: "Staff Preferences",
      icon: Settings
    },
    { 
      path: "/client/profile", 
      label: "My Profile",
      icon: User
    },
  ];

  const isActive = (path: string) => location.pathname === path;

  // Get current page title based on path
  const getCurrentPageTitle = () => {
    const currentPage = clientPages.find(page => page.path === location.pathname);
    return currentPage ? currentPage.label : "Client Dashboard";
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  return (
    <>
      {/* Menu Button */}
      <button
        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
        className="fixed top-4 left-4 z-50 p-2 rounded-lg bg-slate-800/80 backdrop-blur-sm text-white hover:bg-slate-700/80 transition-all shadow-lg"
      >
        {isSidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>

      {/* Sidebar Navigation */}
      <aside className={`fixed inset-y-0 left-0 z-40 w-64 bg-slate-800/50 backdrop-blur-sm shadow-lg flex flex-col border-r border-white/10 transform transition-transform duration-300 ease-in-out ${
        isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        <div className="p-6 flex-1 flex flex-col">
          <h2 className="text-xl font-bold text-white mb-6 mt-16">{getCurrentPageTitle()}</h2>
          <nav className="space-y-2 flex-1">
            {clientPages.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.path);
              return (
                <button
                  key={item.path}
                  onClick={() => navigate(item.path)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                    active
                      ? 'bg-white/20 text-white'
                      : 'text-white/80 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </button>
              );
            })}
          </nav>
          
          {/* Logout Button */}
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all text-red-400 hover:bg-red-500/10 hover:text-red-300 mt-4"
          >
            <LogOut className="w-5 h-5" />
            <span className="font-medium">Log Out</span>
          </button>
        </div>
      </aside>

      {/* Overlay */}
      {isSidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}
    </>
  );
}
