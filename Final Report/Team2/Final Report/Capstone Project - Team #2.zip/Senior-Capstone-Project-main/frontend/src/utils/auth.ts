// Authentication utility functions

/**
 * Decodes JWT token and extracts user data
 * @returns User data object with role, status, profile_complete, onboarding_step, user_id
 */
export const getUserData = (): {
  role: number;
  status: string;
  profile_complete: boolean;
  onboarding_step: number;
  user_id: number;
} | null => {
  const token = localStorage.getItem("access_token");
  if (!token) return null;

  try {
    // JWT structure: header.payload.signature
    const payload = token.split('.')[1];
    if (!payload) {
      localStorage.removeItem("access_token");
      return null;
    }
    const decoded = JSON.parse(atob(payload));
    
    // Check if token is expired
    if (decoded.exp && decoded.exp * 1000 < Date.now()) {
      localStorage.removeItem("access_token");
      return null;
    }
    
    return {
      role: decoded.role ?? null,
      status: decoded.status ?? "active",
      profile_complete: decoded.profile_complete ?? false,  // onboarding tracking
      onboarding_step: decoded.onboarding_step ?? 0,        // current step in onboarding
      user_id: decoded.user_id ?? decoded.sub ?? null       // user id from token
    };
  } catch (error) {
    console.error("error decoding token:", error);
    localStorage.removeItem("access_token");
    return null;
  }
};

/**
 * Gets just the user role from the JWT token
 * @returns User role number (0=admin, 1=client, 2=staff) or null if not authenticated
 */
export const getUserRole = (): number | null => {
  const userData = getUserData();
  return userData?.role ?? null;
};

/**
 * Checks if a user is currently logged in
 * @returns true if user is authenticated, false otherwise
 */
export const isAuthenticated = (): boolean => {
  return getUserData() !== null;
};
