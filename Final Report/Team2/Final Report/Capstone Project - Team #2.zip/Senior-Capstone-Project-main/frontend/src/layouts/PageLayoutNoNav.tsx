import React from "react";
import Footer from "../components/Footer";

interface PageLayoutProps {
  children: React.ReactNode;
  className?: string;
}

const PageLayout: React.FC<PageLayoutProps> = ({
  children,
  className = "",
}) => {
  return (
    <div className={`flex flex-col min-h-screen w-full bg-linear-to-br from-slate-800 via-slate-700 to-teal-600 text-white" ${className}`}>
      <main>{children}</main>
      <Footer />
    </div>
  );
};

export default PageLayout;
