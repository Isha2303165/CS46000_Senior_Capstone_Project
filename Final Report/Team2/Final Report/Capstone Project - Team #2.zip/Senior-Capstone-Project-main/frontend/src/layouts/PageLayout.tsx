// layouts/PageLayout.tsx
import React from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

import { NavbarProps } from '../components/Navbar';

interface PageLayoutProps {
  children: React.ReactNode;
  navbarConfig?: Omit<NavbarProps, 'className'>;
  className?: string;
}

const PageLayout: React.FC<PageLayoutProps> = ({
  children,
  navbarConfig = {},
  className = ''
}) => {
  return (
    <div className={`flex flex-col min-h-screen w-full bg-linear-to-br from-slate-800 via-slate-700 to-teal-600 ${className}`}>
      <Navbar {...navbarConfig} />
      <main>{children}</main>
      <Footer />
    </div>
  );
};

export default PageLayout;