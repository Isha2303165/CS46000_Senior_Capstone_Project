#!/bin/bash

# Frontend setup script for Linux/macOS

echo ""
echo "------------------ Starting frontend ------------------"
echo ""
cd "$(dirname "$0")/frontend"
echo "Current directory: $PWD"

# Install Node dependencies
npm install
echo ""
echo "Node dependencies installed."
echo ""
echo "Ctrl+C in terminal to stop the frontend server."
echo ""

echo "-------------------------------------------------------------"
# Start frontend server
npm run dev
