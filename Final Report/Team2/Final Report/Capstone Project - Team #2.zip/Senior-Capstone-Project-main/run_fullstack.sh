#!/bin/bash

# Fullstack setup script for Linux/macOS
# This script starts both backend and frontend servers

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Backend setup
echo ""
echo "------------------ Starting backend ------------------"
echo ""
cd "$SCRIPT_DIR/backend" # Change to backend directory
echo "Current directory: $PWD"

# Create virtual environment if it doesn't exist
if [ ! -d ".venv" ]; then
    echo "Creating virtual environment this may take a while..."
    python3 -m venv .venv 
    echo "Virtual environment created."
fi

# Activate virtual environment
source .venv/bin/activate
echo "Virtual environment activated."

# Install Python dependencies
pip install -r requirements.txt --quiet # --quiet hide the installation logs for cleaner output in terminal
echo ""
echo "Python dependencies from requirements.txt installed."

# Start backend server in background using gnome-terminal if available, otherwise xterm
if command -v gnome-terminal &> /dev/null; then
    gnome-terminal -- bash -c "cd '$SCRIPT_DIR/backend'; source .venv/bin/activate; echo 'Backend server starting...'; echo 'Press Ctrl+C to stop'; python -m uvicorn app.main:app --reload --port 8000 --host 127.0.0.1; exec bash"
    echo "Backend started in new terminal window."
elif command -v xterm &> /dev/null; then
    xterm -e "cd '$SCRIPT_DIR/backend'; source .venv/bin/activate; echo 'Backend server starting...'; echo 'Press Ctrl+C to stop'; python -m uvicorn app.main:app --reload --port 8000 --host 127.0.0.1; exec bash" &
    echo "Backend started in new terminal window."
else
    # Fallback: start in background without new terminal
    bash -c "cd '$SCRIPT_DIR/backend'; source .venv/bin/activate; python -m uvicorn app.main:app --reload --port 8000 --host 127.0.0.1" &
    BACKEND_PID=$!
    echo "Backend started in background (PID: $BACKEND_PID)"
    echo "To stop backend: kill $BACKEND_PID"
fi

echo ""
echo "Backend: http://localhost:8000"

# Wait a moment for backend to start
sleep 2

echo ""
echo "------------------ Starting frontend ------------------"
echo ""
cd "$SCRIPT_DIR/frontend"
echo "Current directory: $PWD"

# Install Node dependencies
npm install
echo ""
echo "Node dependencies installed."
echo ""
echo "Ctrl+C in this terminal to stop the frontend server."
echo ""

echo "-------------------------------------------------------------"
# Start frontend server
npm run dev
