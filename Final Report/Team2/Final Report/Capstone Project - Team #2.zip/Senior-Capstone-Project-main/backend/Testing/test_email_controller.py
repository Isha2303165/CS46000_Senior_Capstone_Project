"""
Test suite for email controller functionality.
Tests email verification, 2FA codes, and password reset emails.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, MagicMock
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.main import app
from database.db import Base, get_db
from database.models import User
from app.Helper import utils

# Create test database
SQLALCHEMY_DATABASE_URL = "sqlite:///./test_email.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db
client = TestClient(app)

@pytest.fixture(scope="function")
def setup_database():
    """Create and drop test database for each test"""
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)

@pytest.fixture
def db_session(setup_database):
    """Provide a database session for tests"""
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()

@pytest.fixture
def test_user(db_session):
    """Create a test user"""
    hashed_password = utils.hash_password("Test@1234")
    user = User(
        email="test@example.com",
        password_hash=hashed_password,
        role=2,
        email_verified=False,
        tfa_method="email",
        status="pending"
    )
    db_session.add(user)
    db_session.commit()
    db_session.refresh(user)
    return user


class TestEmailVerification:
    """Test email verification functionality"""
    
    @patch('app.Controllers.email_controller.FastMail')
    def test_send_verification_email(self, mock_fastmail, test_user):
        """Test sending verification email"""
        mock_fm = MagicMock()
        mock_fastmail.return_value = mock_fm
        
        response = client.post(
            "/send-verification",
            json={"email": ["test@example.com"]}
        )
        
        assert response.status_code == 200
        assert "Verification email has been sent" in response.json()["message"]
    
    def test_verify_email_success(self, db_session, test_user):
        """Test successful email verification"""
        # Create a valid verification token
        token = utils.create_verification_token(test_user.email)
        
        response = client.get(f"/verify/{token}?json=true")
        
        assert response.status_code == 200
        assert "successfully verified" in response.json()["message"]
        
        # Check that user is verified in database
        db_session.refresh(test_user)
        assert test_user.email_verified == True
    
    def test_verify_email_invalid_token(self, db_session):
        """Test email verification with invalid token"""
        response = client.get("/verify/invalid_token?json=true")
        
        assert response.status_code == 400
    
    def test_verify_email_expired_token(self, db_session, test_user):
        """Test email verification with expired token"""
        # Create a token that's already expired (negative expiry)
        import jwt
        from datetime import datetime, timedelta
        
        payload = {
            "email": test_user.email,
            "type": "email_verification",
            "exp": datetime.utcnow() - timedelta(hours=1)
        }
        expired_token = jwt.encode(payload, "test_secret", algorithm="HS256")
        
        response = client.get(f"/verify/{expired_token}?json=true")
        
        assert response.status_code == 400


class TestPasswordResetEmail:
    """Test password reset email functionality"""
    
    @patch('app.Controllers.email_controller.FastMail')
    def test_send_password_reset_email(self, mock_fastmail, test_user):
        """Test sending password reset email"""
        mock_fm = MagicMock()
        mock_fastmail.return_value = mock_fm
        
        # Note: This would need the actual endpoint from auth controller
        # Testing the email sending function directly
        from app.Controllers.email_controller import send_password_reset_email_sync
        from database.schemas import EmailSchema
        
        try:
            send_password_reset_email_sync(
                EmailSchema(email=[test_user.email]),
                "test_reset_token"
            )
            # If no exception, test passes
            assert True
        except Exception as e:
            # Expected in test environment without actual mail server
            assert "mail" in str(e).lower() or "smtp" in str(e).lower()


class Test2FAEmail:
    """Test 2FA email code functionality"""
    
    @patch('app.Controllers.email_controller.FastMail')
    def test_send_2fa_email_code(self, mock_fastmail, test_user):
        """Test sending 2FA code via email"""
        mock_fm = MagicMock()
        mock_fastmail.return_value = mock_fm
        
        from app.Controllers.email_controller import send_2fa_code_sync
        from database.schemas import EmailSchema
        
        code = "123456"
        try:
            send_2fa_code_sync(EmailSchema(email=[test_user.email]), code)
            assert True
        except Exception as e:
            # Expected in test environment
            assert "mail" in str(e).lower() or "smtp" in str(e).lower()
    
    def test_2fa_code_format(self):
        """Test that 2FA codes are 6 digits"""
        import secrets
        code = f"{secrets.randbelow(1000000):06d}"
        
        assert len(code) == 6
        assert code.isdigit()


class TestEmailValidation:
    """Test email validation and error handling"""
    
    def test_invalid_email_format(self):
        """Test that invalid email format is rejected"""
        from pydantic import ValidationError
        from database.schemas import EmailSchema
        
        with pytest.raises(ValidationError):
            EmailSchema(email=["not-an-email"])
    
    def test_empty_email_list(self):
        """Test that empty email list is rejected"""
        response = client.post(
            "/send-verification",
            json={"email": []}
        )
        
        # Should return validation error
        assert response.status_code in [400, 422]
    
    def test_multiple_emails(self):
        """Test sending to multiple emails"""
        with patch('app.Controllers.email_controller.FastMail'):
            response = client.post(
                "/send-verification",
                json={"email": ["test1@example.com", "test2@example.com"]}
            )
            
            # Should handle multiple recipients
            assert response.status_code in [200, 500]  # 500 expected without mail config


class TestEmailTokens:
    """Test email token generation and validation"""
    
    def test_verification_token_creation(self):
        """Test creating verification token"""
        email = "test@example.com"
        token = utils.create_verification_token(email)
        
        assert token is not None
        assert len(token) > 0
    
    def test_verification_token_decode(self):
        """Test decoding verification token"""
        email = "test@example.com"
        token = utils.create_verification_token(email)
        
        payload = utils.verify_token(token)
        
        assert payload["email"] == email
        assert payload["type"] == "email_verification"
    
    def test_password_reset_token_creation(self):
        """Test creating password reset token"""
        email = "test@example.com"
        token = utils.create_password_reset_token(email)
        
        assert token is not None
        assert len(token) > 0
    
    def test_password_reset_token_decode(self):
        """Test decoding password reset token"""
        email = "test@example.com"
        token = utils.create_password_reset_token(email)
        
        payload = utils.verify_password_reset_token(token)
        
        assert payload["email"] == email
        assert payload["type"] == "password_reset"
    
    def test_token_type_validation(self):
        """Test that token types are validated correctly"""
        email = "test@example.com"
        verification_token = utils.create_verification_token(email)
        
        # Should fail when verifying as wrong type
        with pytest.raises(ValueError):
            utils.verify_password_reset_token(verification_token)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
