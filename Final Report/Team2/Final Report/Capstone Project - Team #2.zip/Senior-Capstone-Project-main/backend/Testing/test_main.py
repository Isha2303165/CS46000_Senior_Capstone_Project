# Uses FastAPI's built in TestClient to test that the back end is functioning
# correctly. It does this by using automated tests for the endpoints
# To test my code I've been using FastAPI's TestClient. 
# In cmd ensure you have the virtual environment activated and use the command-
#python -m pytest -v
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from fastapi.testclient import TestClient
from app.main import app
from database.db import SessionLocal
from database import models

client = TestClient(app)


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}

# Provides basic information to test staff signup with
def test_signup_staff():
    payload = {
        "email": "staff@example.com",
        "password": "MyPassword",
        "first_name": "John",
        "middle_name": "M",
        "last_name": "Doe",
        "date_of_birth": "1980-01-01",
        "ssn": "123-45-6789",
        "phone": "555-555-1234"
    }

    response = client.post("/sign_up_staff", json=payload)
    assert response.status_code == 201
    staff_id = response.json()["staff_id"]
    assert staff_id

    # Removes the user after the test is run
    db = SessionLocal()
    db.query(models.StaffProfile).filter(models.StaffProfile.staff_id == staff_id).delete()
    db.query(models.User).filter(models.User.id == staff_id).delete()
    db.commit()
    db.close()

def test_signup_client():
    payload = {
        "email": "client@example.com",
        "password": "MyPassword",
        "EIN_hashed": "123456",
        "name": "The Restaurant",
        "restaurant_type": "Fast Food",
        "phone": "444-444-5678",
        "website_url": "TheRestaurant.com",
        "address_line1": "6401 St Joe Rd",
        "address_line2": "6401 St Joe Rd",
        "city": "Fort Wayne",
        "state": "Indiana",
        "zipcode": "46835"
    }

    response = client.post("/sign_up_client", json=payload)
    assert response.status_code == 201
    client_id = response.json()["client_id"]
    assert client_id
    
    # Removes the user after the test is run
    db = SessionLocal()
    db.query(models.ClientProfile).filter(models.ClientProfile.client_id == client_id).delete()
    db.query(models.User).filter(models.User.id == client_id).delete()
    db.commit()
    db.close()
  
