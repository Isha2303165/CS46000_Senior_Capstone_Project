"""
Test suite for utility functions.
Tests password hashing, token generation, SSN hashing, and validation utilities.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
from datetime import datetime, timedelta
import jwt

from app.Helper import utils


class TestPasswordHashing:
    """Test password hashing and verification"""
    
    def test_hash_password(self):
        """Test password hashing"""
        password = "Test@1234"
        hashed = utils.hash_password(password)
        
        assert hashed is not None
        assert hashed != password
        assert len(hashed) > 0
    
    def test_verify_password_correct(self):
        """Test password verification with correct password"""
        password = "Test@1234"
        hashed = utils.hash_password(password)
        
        assert utils.verify_password(password, hashed) == True
    
    def test_verify_password_incorrect(self):
        """Test password verification with incorrect password"""
        password = "Test@1234"
        wrong_password = "Wrong@5678"
        hashed = utils.hash_password(password)
        
        assert utils.verify_password(wrong_password, hashed) == False
    
    def test_hash_password_different_each_time(self):
        """Test that hashing same password produces different hashes (salt)"""
        password = "Test@1234"
        hash1 = utils.hash_password(password)
        hash2 = utils.hash_password(password)
        
        assert hash1 != hash2
        # But both should verify
        assert utils.verify_password(password, hash1) == True
        assert utils.verify_password(password, hash2) == True


class TestAccessTokens:
    """Test JWT access token creation and verification"""
    
    def test_create_access_token(self):
        """Test creating access token"""
        data = {
            "sub": "test@example.com",
            "user_id": 123,
            "role": 2
        }
        token = utils.create_access_token(data)
        
        assert token is not None
        assert len(token) > 0
    
    def test_verify_access_token(self):
        """Test verifying valid access token"""
        data = {
            "sub": "test@example.com",
            "user_id": 123,
            "role": 2
        }
        token = utils.create_access_token(data)
        payload = utils.verify_access_token(token)
        
        assert payload["sub"] == "test@example.com"
        assert payload["user_id"] == 123
        assert payload["role"] == 2
    
    def test_verify_invalid_token(self):
        """Test verifying invalid token"""
        with pytest.raises(ValueError):
            utils.verify_access_token("invalid.token.here")
    
    def test_verify_expired_token(self):
        """Test verifying expired token"""
        import os
        data = {"sub": "test@example.com"}
        secret_key = os.getenv("SECRET_KEY", "test-secret-key")
        
        # Create expired token
        payload = {
            **data,
            "exp": datetime.utcnow() - timedelta(minutes=1)
        }
        expired_token = jwt.encode(payload, secret_key, algorithm="HS256")
        
        with pytest.raises(ValueError):
            utils.verify_access_token(expired_token)
    
    def test_token_expiration_time(self):
        """Test that token has correct expiration"""
        data = {"sub": "test@example.com"}
        token = utils.create_access_token(data)
        payload = utils.verify_access_token(token)
        
        # Check expiration is set
        assert "exp" in payload
        exp_time = datetime.fromtimestamp(payload["exp"])
        now = datetime.utcnow()
        
        # Should expire in approximately 60 minutes (default)
        time_diff = (exp_time - now).total_seconds()
        assert 3500 < time_diff < 3700  # Allow some margin


class TestVerificationTokens:
    """Test email verification token functions"""
    
    def test_create_verification_token(self):
        """Test creating email verification token"""
        email = "test@example.com"
        token = utils.create_verification_token(email)
        
        assert token is not None
        assert len(token) > 0
    
    def test_verify_verification_token(self):
        """Test verifying email verification token"""
        email = "test@example.com"
        token = utils.create_verification_token(email)
        payload = utils.verify_token(token)
        
        assert payload["email"] == email
        assert payload["type"] == "email_verification"
    
    def test_verification_token_expiration(self):
        """Test verification token expiration (24 hours)"""
        email = "test@example.com"
        token = utils.create_verification_token(email)
        payload = utils.verify_token(token)
        
        exp_time = datetime.fromtimestamp(payload["exp"])
        now = datetime.utcnow()
        time_diff = (exp_time - now).total_seconds()
        
        # Should expire in approximately 24 hours
        assert 86000 < time_diff < 87000


class TestPasswordResetTokens:
    """Test password reset token functions"""
    
    def test_create_password_reset_token(self):
        """Test creating password reset token"""
        email = "test@example.com"
        token = utils.create_password_reset_token(email)
        
        assert token is not None
        assert len(token) > 0
    
    def test_verify_password_reset_token(self):
        """Test verifying password reset token"""
        email = "test@example.com"
        token = utils.create_password_reset_token(email)
        payload = utils.verify_password_reset_token(token)
        
        assert payload["email"] == email
        assert payload["type"] == "password_reset"
    
    def test_password_reset_token_expiration(self):
        """Test password reset token expiration (1 hour default)"""
        email = "test@example.com"
        token = utils.create_password_reset_token(email, expires_hours=1)
        payload = utils.verify_password_reset_token(token)
        
        exp_time = datetime.fromtimestamp(payload["exp"])
        now = datetime.utcnow()
        time_diff = (exp_time - now).total_seconds()
        
        # Should expire in approximately 1 hour
        assert 3500 < time_diff < 3700
    
    def test_password_reset_custom_expiration(self):
        """Test password reset token with custom expiration"""
        email = "test@example.com"
        token = utils.create_password_reset_token(email, expires_hours=2)
        payload = utils.verify_password_reset_token(token)
        
        exp_time = datetime.fromtimestamp(payload["exp"])
        now = datetime.utcnow()
        time_diff = (exp_time - now).total_seconds()
        
        # Should expire in approximately 2 hours
        assert 7100 < time_diff < 7300


class TestSSNHashing:
    """Test SSN hashing functionality"""
    
    def test_hash_ssn(self):
        """Test basic SSN hashing"""
        ssn = "123-45-6789"
        hashed = utils.hash_info(ssn)
        
        assert hashed is not None
        assert hashed != ssn
        assert len(hashed) == 64  # SHA-256 produces 64 character hex string
    
    def test_hash_ssn_consistent(self):
        """Test that hashing the same SSN produces the same hash"""
        ssn = "123-45-6789"
        hash1 = utils.hash_info(ssn)
        hash2 = utils.hash_info(ssn)
        
        assert hash1 == hash2
    
    def test_hash_ssn_different_for_different_input(self):
        """Test that different SSNs produce different hashes"""
        ssn1 = "123-45-6789"
        ssn2 = "987-65-4321"
        hash1 = utils.hash_info(ssn1)
        hash2 = utils.hash_info(ssn2)
        
        assert hash1 != hash2
    
    def test_hash_ssn_formats(self):
        """Test hashing SSN in different formats"""
        ssn_with_dashes = "123-45-6789"
        ssn_without_dashes = "123456789"
        
        hash1 = utils.hash_info(ssn_with_dashes)
        hash2 = utils.hash_info(ssn_without_dashes)
        
        # Different formats should produce different hashes
        assert hash1 != hash2


class TestTokenTypeValidation:
    """Test token type validation"""
    
    def test_verification_token_wrong_type(self):
        """Test using verification token as password reset fails"""
        email = "test@example.com"
        verification_token = utils.create_verification_token(email)
        
        with pytest.raises(ValueError):
            utils.verify_password_reset_token(verification_token)
    
    def test_password_reset_token_wrong_type(self):
        """Test using password reset token as verification fails"""
        email = "test@example.com"
        reset_token = utils.create_password_reset_token(email)
        
        # This should fail because it's checking for "email_verification" type
        with pytest.raises(ValueError):
            payload = utils.verify_token(reset_token)
            if payload.get("type") != "email_verification":
                raise ValueError("Wrong token type")


class TestPasswordValidation:
    """Test password validation rules"""
    
    def test_password_strength_validation(self):
        """Test password strength requirements"""
        from database.schemas import PasswordValidator
        from pydantic import ValidationError
        
        # Valid password
        class TestModel(PasswordValidator):
            email: str
        
        # Should not raise error
        valid = TestModel(email="test@example.com", password="Test@1234")
        assert valid.password == "Test@1234"
        
        # Invalid - too short
        with pytest.raises(ValidationError):
            TestModel(email="test@example.com", password="Ts@1")
        
        # Invalid - no uppercase
        with pytest.raises(ValidationError):
            TestModel(email="test@example.com", password="test@1234")
        
        # Invalid - no lowercase
        with pytest.raises(ValidationError):
            TestModel(email="test@example.com", password="TEST@1234")
        
        # Invalid - no number
        with pytest.raises(ValidationError):
            TestModel(email="test@example.com", password="Test@abcd")
        
        # Invalid - no special char
        with pytest.raises(ValidationError):
            TestModel(email="test@example.com", password="Test1234")


class TestUtilityHelpers:
    """Test miscellaneous utility helper functions"""
    
    def test_token_randomness(self):
        """Test that tokens are random"""
        email = "test@example.com"
        token1 = utils.create_verification_token(email)
        token2 = utils.create_verification_token(email)
        
        # Tokens should be different due to random component
        assert token1 != token2
    
    def test_hash_consistency(self):
        """Test that hashing utility is consistent"""
        # Password hashes should differ (salt)
        pw = "Test@1234"
        pw_hash1 = utils.hash_password(pw)
        pw_hash2 = utils.hash_password(pw)
        assert pw_hash1 != pw_hash2
        
        # SSN hashes should be same (no salt)
        ssn = "123-45-6789"
        ssn_hash1 = utils.hash_info(ssn)
        ssn_hash2 = utils.hash_info(ssn)
        assert ssn_hash1 == ssn_hash2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
