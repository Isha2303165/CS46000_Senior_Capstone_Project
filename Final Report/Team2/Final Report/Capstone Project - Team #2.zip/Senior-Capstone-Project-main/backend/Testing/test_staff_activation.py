"""
Test suite for staff profile activation functionality.
Tests the activation of staff profiles after subscription payment.
"""
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from datetime import datetime, timezone

from app.main import app
from database.db import Base, get_db
from database import models
from app.Helper import utils

# Create test database
SQLALCHEMY_DATABASE_URL = "sqlite:///./test_staff_activation.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db
client = TestClient(app)

@pytest.fixture(scope="function")
def setup_database():
    """Create and drop test database for each test"""
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)

@pytest.fixture
def db_session(setup_database):
    """Provide a database session for tests"""
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()

@pytest.fixture
def seed_subscription_plans(db_session):
    """Seed the database with required subscription plans"""
    # Create staff onboarding fee plan
    onboarding_plan = models.StaffOneTimePlan(
        plan_name="Staff Onboarding Fee",
        price=50.00,
        description="One-time onboarding fee for new staff members",
        is_active=True
    )
    db_session.add(onboarding_plan)
    
    # Create staff subscription plan
    subscription_plan = models.StaffSubscriptionPlan(
        plan_name="Staff Basic Monthly",
        price=29.99,
        billing_frequency="monthly",
        description="Basic monthly subscription for staff members",
        is_active=True
    )
    db_session.add(subscription_plan)
    db_session.commit()
    
    return {
        "onboarding_plan": onboarding_plan,
        "subscription_plan": subscription_plan
    }

@pytest.fixture
def create_staff_user(db_session, seed_subscription_plans):
    """Create a test staff user with pending status"""
    # Create user
    user = models.User(
        email="teststaff@example.com",
        password_hash=utils.hash_password("Test@1234"),
        role=2,  # Staff role
        status="pending",
        email_verified=True
    )
    db_session.add(user)
    db_session.flush()
    
    # Create staff profile
    staff_profile = models.StaffProfile(
        staff_id=user.id,
        first_name="Test",
        last_name="Staff",
        date_of_birth="1990-01-01",
        SSN_hashed=utils.hash_info("123456789"),
        phone="1234567890"
    )
    db_session.add(staff_profile)
    
    # Create onboarding fee (pending)
    onboarding_fee = models.StaffOneTimeFee(
        staff_id=user.id,
        plan_id=seed_subscription_plans["onboarding_plan"].id,
        amount=50.00,
        status="pending"
    )
    db_session.add(onboarding_fee)
    
    # Create active subscription
    subscription = models.StaffSubscription(
        staff_id=user.id,
        plan_id=seed_subscription_plans["subscription_plan"].id,
        status="active",
        start_date=datetime.now(timezone.utc),
        next_billing_date=datetime.now(timezone.utc)
    )
    db_session.add(subscription)
    db_session.commit()
    
    return user

def test_activate_staff_profile_success(db_session, create_staff_user):
    """Test successful activation of staff profile"""
    from app.Controllers.staff_billing_controller import activate_staff_profile_on_subscription
    
    staff_id = create_staff_user.id
    
    # Verify initial state
    user = db_session.query(models.User).filter(models.User.id == staff_id).first()
    assert user.status == "pending"
    
    onboarding_fee = db_session.query(models.StaffOneTimeFee).filter(
        models.StaffOneTimeFee.staff_id == staff_id
    ).first()
    assert onboarding_fee.status == "pending"
    
    # Activate profile
    result = activate_staff_profile_on_subscription(staff_id, db_session)
    
    # Verify activation
    assert result["message"] == "Staff profile activated successfully"
    assert result["user_status"] == "active"
    assert result["subscription_status"] == "active"
    assert result["onboarding_fee_paid"] == True
    
    # Verify database state
    db_session.refresh(user)
    db_session.refresh(onboarding_fee)
    
    assert user.status == "active"
    assert onboarding_fee.status == "paid"

def test_activate_staff_profile_no_subscription(db_session, create_staff_user):
    """Test activation fails when no active subscription exists"""
    from app.Controllers.staff_billing_controller import activate_staff_profile_on_subscription
    from fastapi import HTTPException
    
    staff_id = create_staff_user.id
    
    # Deactivate subscription
    subscription = db_session.query(models.StaffSubscription).filter(
        models.StaffSubscription.staff_id == staff_id
    ).first()
    subscription.status = "inactive"
    db_session.commit()
    
    # Try to activate profile
    with pytest.raises(HTTPException) as exc_info:
        activate_staff_profile_on_subscription(staff_id, db_session)
    
    assert exc_info.value.status_code == 400
    assert "No active subscription found" in exc_info.value.detail

def test_activate_staff_profile_not_found(db_session, seed_subscription_plans):
    """Test activation fails when staff member doesn't exist"""
    from app.Controllers.staff_billing_controller import activate_staff_profile_on_subscription
    from fastapi import HTTPException
    
    # Try to activate non-existent staff
    with pytest.raises(HTTPException) as exc_info:
        activate_staff_profile_on_subscription(999, db_session)
    
    assert exc_info.value.status_code == 404
    assert "Staff member not found" in exc_info.value.detail

def test_process_subscription_payment(db_session, create_staff_user):
    """Test the payment processing function"""
    from app.Controllers.staff_billing_controller import process_subscription_payment
    
    staff_id = create_staff_user.id
    
    # Process payment
    result = process_subscription_payment(staff_id, "stripe", db_session)
    
    # Verify result
    assert result["message"] == "Staff profile activated successfully"
    assert result["payment_method"] == "stripe"
    assert "payment_processed_at" in result
    assert result["user_status"] == "active"
    assert result["onboarding_fee_paid"] == True

def test_activation_endpoint_as_staff(db_session, create_staff_user):
    """Test activation endpoint when called by the staff member themselves"""
    # Login as staff user
    login_response = client.post(
        "/login",
        json={
            "email": "teststaff@example.com",
            "password": "Test@1234"
        }
    )
    assert login_response.status_code == 200
    token = login_response.json()["access_token"]
    
    # Activate profile
    response = client.post(
        f"/staff/activate_profile/{create_staff_user.id}",
        headers={"Authorization": f"Bearer {token}"}
    )
    
    assert response.status_code == 200
    data = response.json()
    assert data["message"] == "Staff profile activated successfully"
    assert data["user_status"] == "active"

def test_activation_endpoint_wrong_staff(db_session, create_staff_user, seed_subscription_plans):
    """Test that staff cannot activate another staff member's profile"""
    # Create another staff user
    another_user = models.User(
        email="otherstaff@example.com",
        password_hash=utils.hash_password("Test@1234"),
        role=2,
        status="active",
        email_verified=True
    )
    db_session.add(another_user)
    db_session.flush()
    
    staff_profile = models.StaffProfile(
        staff_id=another_user.id,
        first_name="Other",
        last_name="Staff",
        date_of_birth="1990-01-01",
        SSN_hashed=utils.hash_info("987654321"),
        phone="0987654321"
    )
    db_session.add(staff_profile)
    db_session.commit()
    
    # Login as the other staff user
    login_response = client.post(
        "/login",
        json={
            "email": "otherstaff@example.com",
            "password": "Test@1234"
        }
    )
    assert login_response.status_code == 200
    token = login_response.json()["access_token"]
    
    # Try to activate the first staff's profile
    response = client.post(
        f"/staff/activate_profile/{create_staff_user.id}",
        headers={"Authorization": f"Bearer {token}"}
    )
    
    assert response.status_code == 403
    assert "can only activate their own profile" in response.json()["detail"]
