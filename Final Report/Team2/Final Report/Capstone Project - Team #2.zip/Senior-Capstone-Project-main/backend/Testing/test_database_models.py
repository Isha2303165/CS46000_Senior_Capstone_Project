"""
Test suite for database models and relationships.
Tests model creation, relationships, constraints, and data integrity.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from datetime import datetime

from database.db import Base
from database.models import (
    User, StaffProfile, ClientProfile,
    StaffSubscription, StaffSubscriptionPlan, StaffOneTimeFee,
    StaffEmergencyContact, StaffDocument, StaffLiquorLicense,
    ClientSubscription, ClientSubscriptionPlan
)
from app.Helper import utils

# Create test database
SQLALCHEMY_DATABASE_URL = "sqlite:///./test_models.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


@pytest.fixture(scope="function")
def setup_database():
    """Create and drop test database for each test"""
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)


@pytest.fixture
def db_session(setup_database):
    """Provide a database session for tests"""
    db = TestingSessionLocal()
    try:
        yield db
    finally:
        db.close()


class TestUserModel:
    """Test User model"""
    
    def test_create_user(self, db_session):
        """Test creating a user"""
        user = User(
            email="test@example.com",
            password_hash=utils.hash_password("Test@1234"),
            role=2,
            email_verified=False,
            tfa_method="email",
            status="pending"
        )
        db_session.add(user)
        db_session.commit()
        
        assert user.id is not None
        assert user.email == "test@example.com"
        assert user.role == 2
    
    def test_user_email_unique(self, db_session):
        """Test that email must be unique"""
        user1 = User(
            email="test@example.com",
            password_hash="hash1",
            role=2
        )
        db_session.add(user1)
        db_session.commit()
        
        user2 = User(
            email="test@example.com",
            password_hash="hash2",
            role=1
        )
        db_session.add(user2)
        
        with pytest.raises(Exception):  # IntegrityError
            db_session.commit()
    
    def test_user_default_values(self, db_session):
        """Test user model default values"""
        user = User(
            email="test@example.com",
            password_hash="hash",
            role=2
        )
        db_session.add(user)
        db_session.commit()
        db_session.refresh(user)
        
        assert user.email_verified == False
        assert user.tfa_method == "email"
        assert user.status == "active"
        assert user.profile_complete == False
        assert user.onboarding_step == 0


class TestStaffProfile:
    """Test StaffProfile model and relationship"""
    
    def test_create_staff_profile(self, db_session):
        """Test creating staff profile with user"""
        user = User(
            email="staff@example.com",
            password_hash=utils.hash_password("Test@1234"),
            role=2
        )
        db_session.add(user)
        db_session.commit()
        
        staff = StaffProfile(
            staff_id=user.id,
            first_name="John",
            last_name="Doe",
            date_of_birth="1990-01-01",
            SSN_hashed=utils.hash_ssn("123-45-6789"),
            phone="555-1234"
        )
        db_session.add(staff)
        db_session.commit()
        
        assert staff.staff_id == user.id
        assert staff.first_name == "John"
    
    def test_staff_user_relationship(self, db_session):
        """Test staff profile to user relationship"""
        user = User(
            email="staff@example.com",
            password_hash="hash",
            role=2
        )
        db_session.add(user)
        db_session.commit()
        
        staff = StaffProfile(
            staff_id=user.id,
            first_name="John",
            last_name="Doe",
            date_of_birth="1990-01-01",
            SSN_hashed="hashed_ssn",
            phone="555-1234"
        )
        db_session.add(staff)
        db_session.commit()
        db_session.refresh(user)
        
        assert user.staff_profile is not None
        assert user.staff_profile.first_name == "John"
    
    def test_staff_cascade_delete(self, db_session):
        """Test that deleting user deletes staff profile"""
        user = User(
            email="staff@example.com",
            password_hash="hash",
            role=2
        )
        db_session.add(user)
        db_session.commit()
        
        staff = StaffProfile(
            staff_id=user.id,
            first_name="John",
            last_name="Doe",
            date_of_birth="1990-01-01",
            SSN_hashed="hashed_ssn",
            phone="555-1234"
        )
        db_session.add(staff)
        db_session.commit()
        
        user_id = user.id
        db_session.delete(user)
        db_session.commit()
        
        # Staff profile should be deleted
        deleted_staff = db_session.query(StaffProfile).filter(
            StaffProfile.staff_id == user_id
        ).first()
        assert deleted_staff is None


class TestClientProfile:
    """Test ClientProfile model"""
    
    def test_create_client_profile(self, db_session):
        """Test creating client profile"""
        user = User(
            email="client@example.com",
            password_hash="hash",
            role=1
        )
        db_session.add(user)
        db_session.commit()
        
        client = ClientProfile(
            client_id=user.id,
            name="Test Restaurant",
            EIN_hashed=utils.hash_ssn("12-3456789"),
            restaurant_type="Casual Dining",
            phone="555-5678",
            address_line1="123 Main St",
            city="Fort Wayne",
            state="IN",
            zipcode=46805
        )
        db_session.add(client)
        db_session.commit()
        
        assert client.client_id == user.id
        assert client.name == "Test Restaurant"


class TestStaffSubscription:
    """Test staff subscription models"""
    
    def test_create_subscription_plan(self, db_session):
        """Test creating subscription plan"""
        plan = StaffSubscriptionPlan(
            name="Monthly Subscription",
            price_id="price_123",
            price=5.95,
            interval="month",
            interval_count=1
        )
        db_session.add(plan)
        db_session.commit()
        
        assert plan.id is not None
        assert plan.price == 5.95
    
    def test_create_staff_subscription(self, db_session):
        """Test creating staff subscription"""
        user = User(email="staff@example.com", password_hash="hash", role=2)
        db_session.add(user)
        db_session.commit()
        
        staff = StaffProfile(
            staff_id=user.id,
            first_name="John",
            last_name="Doe",
            date_of_birth="1990-01-01",
            SSN_hashed="hashed",
            phone="555-1234"
        )
        db_session.add(staff)
        
        plan = StaffSubscriptionPlan(
            name="Monthly",
            price_id="price_123",
            price=5.95,
            interval="month",
            interval_count=1
        )
        db_session.add(plan)
        db_session.commit()
        
        subscription = StaffSubscription(
            staff_id=staff.staff_id,
            plan_id=plan.id,
            stripe_subscription_id="sub_123",
            status="active"
        )
        db_session.add(subscription)
        db_session.commit()
        
        assert subscription.staff_id == staff.staff_id
        assert subscription.status == "active"


class TestStaffDocuments:
    """Test staff document models"""
    
    def test_create_staff_document(self, db_session):
        """Test creating staff document"""
        user = User(email="staff@example.com", password_hash="hash", role=2)
        db_session.add(user)
        db_session.commit()
        
        staff = StaffProfile(
            staff_id=user.id,
            first_name="John",
            last_name="Doe",
            date_of_birth="1990-01-01",
            SSN_hashed="hashed",
            phone="555-1234"
        )
        db_session.add(staff)
        db_session.commit()
        
        document = StaffDocument(
            staff_id=staff.staff_id,
            document_type="resume",
            file_path="/static/resumes/resume.pdf"
        )
        db_session.add(document)
        db_session.commit()
        
        assert document.staff_id == staff.staff_id
        assert document.document_type == "resume"


class TestEmergencyContacts:
    """Test emergency contact model"""
    
    def test_create_emergency_contact(self, db_session):
        """Test creating emergency contact"""
        user = User(email="staff@example.com", password_hash="hash", role=2)
        db_session.add(user)
        db_session.commit()
        
        staff = StaffProfile(
            staff_id=user.id,
            first_name="John",
            last_name="Doe",
            date_of_birth="1990-01-01",
            SSN_hashed="hashed",
            phone="555-1234"
        )
        db_session.add(staff)
        db_session.commit()
        
        contact = StaffEmergencyContact(
            staff_id=staff.staff_id,
            name="Jane Doe",
            relationship="Spouse",
            phone="555-5678"
        )
        db_session.add(contact)
        db_session.commit()
        
        assert contact.name == "Jane Doe"
        assert contact.relationship == "Spouse"


class TestDataIntegrity:
    """Test data integrity constraints"""
    
    def test_role_constraint(self, db_session):
        """Test user role constraint (must be 0, 1, or 2)"""
        user = User(
            email="test@example.com",
            password_hash="hash",
            role=5  # Invalid role
        )
        db_session.add(user)
        
        with pytest.raises(Exception):  # CheckConstraint violation
            db_session.commit()
    
    def test_tfa_method_constraint(self, db_session):
        """Test TFA method constraint"""
        user = User(
            email="test@example.com",
            password_hash="hash",
            role=2,
            tfa_method="invalid"  # Must be 'email' or 'sms'
        )
        db_session.add(user)
        
        with pytest.raises(Exception):  # CheckConstraint violation
            db_session.commit()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
