"""
Test suite for Stripe payment integration.
Tests payment processing, webhooks, and subscription management.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import pytest
from fastapi.testclient import TestClient
from unittest.mock import patch, MagicMock
import os

from app.main import app

client = TestClient(app)


class TestStripeConnection:
    """Test Stripe API connection"""
    
    @patch('stripe.Product.list')
    def test_stripe_ping_success(self, mock_product_list):
        """Test successful Stripe connection"""
        mock_product_list.return_value = MagicMock(data=[{"id": "prod_123"}])
        
        response = client.get("/stripe/ping")
        
        assert response.status_code == 200
        assert "status" in response.json()
        assert response.json()["status"] == "ok"
    
    @patch('stripe.Product.list')
    def test_stripe_ping_failure(self, mock_product_list):
        """Test Stripe connection failure"""
        mock_product_list.side_effect = Exception("API Error")
        
        response = client.get("/stripe/ping")
        
        assert response.status_code == 500


class TestOneTimePayment:
    """Test one-time payment checkout sessions"""
    
    @patch('stripe.checkout.Session.create')
    def test_create_one_time_checkout_session(self, mock_session_create):
        """Test creating one-time payment checkout session"""
        mock_session_create.return_value = MagicMock(
            id="cs_test_123",
            url="https://checkout.stripe.com/test"
        )
        
        payload = {
            "price_env_key": "STRIPE_PRICE_ONBOARDING",
            "email": "test@example.com"
        }
        
        with patch.dict(os.environ, {"STRIPE_PRICE_ONBOARDING": "price_123"}):
            response = client.post("/stripe/checkout/one-time", json=payload)
        
        if response.status_code == 200:
            assert "checkout_url" in response.json()
    
    def test_create_one_time_missing_price_key(self):
        """Test one-time payment with missing price environment key"""
        payload = {
            "price_env_key": "NONEXISTENT_KEY",
            "email": "test@example.com"
        }
        
        response = client.post("/stripe/checkout/one-time", json=payload)
        
        # Should fail without proper environment variable
        assert response.status_code in [400, 500]


class TestSubscriptionPayment:
    """Test subscription checkout sessions"""
    
    @patch('stripe.checkout.Session.create')
    def test_create_subscription_checkout_session(self, mock_session_create):
        """Test creating subscription checkout session"""
        mock_session_create.return_value = MagicMock(
            id="cs_test_456",
            url="https://checkout.stripe.com/test"
        )
        
        payload = {
            "price_env_key": "STRIPE_PRICE_SUBSCRIPTION",
            "email": "test@example.com"
        }
        
        with patch.dict(os.environ, {"STRIPE_PRICE_SUBSCRIPTION": "price_456"}):
            response = client.post("/stripe/checkout/subscription", json=payload)
        
        if response.status_code == 200:
            assert "checkout_url" in response.json()
    
    def test_create_subscription_missing_email(self):
        """Test subscription payment without email"""
        payload = {
            "price_env_key": "STRIPE_PRICE_SUBSCRIPTION"
        }
        
        response = client.post("/stripe/checkout/subscription", json=payload)
        
        # Should handle missing email
        assert response.status_code in [200, 400, 422, 500]


class TestStripeWebhook:
    """Test Stripe webhook handling"""
    
    @patch('stripe.Webhook.construct_event')
    def test_webhook_payment_success(self, mock_construct_event):
        """Test webhook handling for successful payment"""
        mock_event = MagicMock()
        mock_event.type = "checkout.session.completed"
        mock_event.data.object = MagicMock(
            payment_status="paid",
            customer_email="test@example.com",
            amount_total=3000
        )
        mock_construct_event.return_value = mock_event
        
        headers = {"stripe-signature": "test_signature"}
        payload = '{"type": "checkout.session.completed"}'
        
        with patch.dict(os.environ, {"STRIPE_WEBHOOK_SECRET": "whsec_test"}):
            response = client.post(
                "/stripe/webhook",
                content=payload,
                headers=headers
            )
        
        # Webhook should be processed
        assert response.status_code in [200, 400, 500]
    
    @patch('stripe.Webhook.construct_event')
    def test_webhook_invalid_signature(self, mock_construct_event):
        """Test webhook with invalid signature"""
        mock_construct_event.side_effect = ValueError("Invalid signature")
        
        headers = {"stripe-signature": "invalid_signature"}
        payload = '{"type": "checkout.session.completed"}'
        
        with patch.dict(os.environ, {"STRIPE_WEBHOOK_SECRET": "whsec_test"}):
            response = client.post(
                "/stripe/webhook",
                content=payload,
                headers=headers
            )
        
        # Should reject invalid signature
        assert response.status_code in [400, 500]
    
    @patch('stripe.Webhook.construct_event')
    def test_webhook_subscription_created(self, mock_construct_event):
        """Test webhook for subscription creation"""
        mock_event = MagicMock()
        mock_event.type = "customer.subscription.created"
        mock_event.data.object = MagicMock(
            id="sub_123",
            customer="cus_123",
            status="active"
        )
        mock_construct_event.return_value = mock_event
        
        headers = {"stripe-signature": "test_signature"}
        payload = '{"type": "customer.subscription.created"}'
        
        with patch.dict(os.environ, {"STRIPE_WEBHOOK_SECRET": "whsec_test"}):
            response = client.post(
                "/stripe/webhook",
                content=payload,
                headers=headers
            )
        
        assert response.status_code in [200, 400, 500]


class TestPaymentValidation:
    """Test payment data validation"""
    
    def test_one_time_payment_schema_validation(self):
        """Test one-time payment request schema"""
        from app.Controllers.stripe_controller import OneTimeBody
        from pydantic import ValidationError
        
        # Valid
        valid_data = OneTimeBody(
            price_env_key="STRIPE_PRICE_TEST",
            email="test@example.com"
        )
        assert valid_data.price_env_key == "STRIPE_PRICE_TEST"
        
        # Invalid - missing required field
        with pytest.raises(ValidationError):
            OneTimeBody(email="test@example.com")
    
    def test_subscription_payment_schema_validation(self):
        """Test subscription payment request schema"""
        from app.Controllers.stripe_controller import SubBody
        from pydantic import ValidationError
        
        # Valid
        valid_data = SubBody(
            price_env_key="STRIPE_PRICE_SUB",
            email="test@example.com"
        )
        assert valid_data.price_env_key == "STRIPE_PRICE_SUB"


class TestStripeConfiguration:
    """Test Stripe configuration and setup"""
    
    def test_stripe_api_key_loaded(self):
        """Test that Stripe API key is configured"""
        import stripe
        
        # Check if API key is set (will be None in test env without .env)
        # This is expected behavior
        assert stripe.api_key is not None or os.getenv("STRIPE_SECRET_KEY") is None
    
    def test_webhook_secret_configured(self):
        """Test that webhook secret can be loaded"""
        webhook_secret = os.getenv("STRIPE_WEBHOOK_SECRET")
        
        # In test environment, this might not be set
        # Just verify the env var mechanism works
        assert webhook_secret is None or isinstance(webhook_secret, str)


class TestPaymentAmounts:
    """Test payment amount calculations"""
    
    def test_onboarding_fee_amount(self):
        """Test onboarding fee is $30"""
        # This would be in your business logic
        ONBOARDING_FEE = 3000  # $30.00 in cents
        
        assert ONBOARDING_FEE == 3000
    
    def test_subscription_amount(self):
        """Test subscription fee is $5.95"""
        # This would be in your business logic
        SUBSCRIPTION_FEE = 595  # $5.95 in cents
        
        assert SUBSCRIPTION_FEE == 595


class TestErrorHandling:
    """Test error handling in payment processing"""
    
    @patch('stripe.checkout.Session.create')
    def test_stripe_api_error_handling(self, mock_session_create):
        """Test handling of Stripe API errors"""
        import stripe
        mock_session_create.side_effect = stripe.error.StripeError("API Error")
        
        payload = {
            "price_env_key": "STRIPE_PRICE_TEST",
            "email": "test@example.com"
        }
        
        with patch.dict(os.environ, {"STRIPE_PRICE_TEST": "price_123"}):
            response = client.post("/stripe/checkout/one-time", json=payload)
        
        # Should handle Stripe errors gracefully
        assert response.status_code in [400, 500]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
