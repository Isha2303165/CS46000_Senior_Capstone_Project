
# This file contains utility functions for password hashing and JWT token creation. 
from datetime import datetime, timedelta
from jose import jwt, JWTError
from passlib.context import CryptContext
from passlib.exc import UnknownHashError
import os
from dotenv import load_dotenv
# Stores shared logic to make main and other files more readable
import hashlib
import secrets
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer
from sqlalchemy.orm import Session

load_dotenv()

# uses SHA-256 to hash personal information for security purposes 
def hash_info(information: str) -> str:
    return hashlib.sha256(information.encode()).hexdigest()

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
SECRET_KEY = os.getenv("SECRET_KEY", "supersecretkey")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

def verify_password(plain_password : str, hashed_password : str) -> bool:
    try:
        return pwd_context.verify(plain_password, hashed_password)
    except UnknownHashError:
        return False

def hash_password(plain_password: str) -> str:
    return pwd_context.hash(plain_password)

def create_access_token(data: dict, expires_delta: timedelta | None = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def create_verification_token(email: str) -> str:
    # Create a secure random token
    token = secrets.token_urlsafe(32)
    # Create a JWT that includes both the token and email
    data = {
        "email": email,
        "token": token,
        "type": "email_verification"
    }
    # Token expires in 24 hours
    return create_access_token(data, timedelta(hours=24))


def create_password_reset_token(email: str, expires_hours: int = 1) -> str:
    """
    Create a JWT token used specifically for password reset flows.
    The token payload contains the email and a random token and will
    be marked with type "password_reset" so it can be validated
    separately from email verification tokens.
    """
    token = secrets.token_urlsafe(32)
    data = {
        "email": email,
        "token": token,
        "type": "password_reset",
    }
    return create_access_token(data, timedelta(hours=expires_hours))


def verify_password_reset_token(token: str) -> dict:
    """
    Verify and decode a password reset token. Raises ValueError on failure.
    """
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        if payload.get("type") != "password_reset":
            raise ValueError("Invalid token type")
        return payload
    except jwt.JWTError:
        raise ValueError("Invalid token")

def verify_token(token: str) -> dict:
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        if payload.get("type") != "email_verification":
            raise ValueError("Invalid token type")
        return payload
    except jwt.JWTError:
        raise ValueError("Invalid token")

def verify_access_token(token: str) -> dict:
    """
    Verify and decode an access token. Returns payload or raises ValueError.
    """
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except JWTError:
        raise ValueError("Invalid token")
