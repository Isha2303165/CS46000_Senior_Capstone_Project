# import necessary modules
from fastapi import FastAPI, Depends, HTTPException, status, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from database import models
from database.db import SessionLocal, get_db, engine
from database.models import User, StaffProfile
from app.Helper import utils
from app.Controllers import staff_controller, client_controller, email_controller, stripe_controller, stripe_webhook_controller
from database import schemas
from database.schemas import EmailSchema
from app.Controllers import auth
from app.Controllers import profile_controller
from app.Controllers import staff_dashboard_controller
from app.Controllers import staff_billing_controller
from app.Controllers import client_staff_preferences_controller
from fastapi.staticfiles import StaticFiles
from sqlalchemy import text
from app.constants import UserRole


# create the FastAPI app
app = FastAPI()

# allow React dev server later (Vite uses 5173)
# Cross-Origin Resource Sharing, so your React(port 5173) app can call
# the backend (port 8000)
# This is how frontend and backend can talk to each other
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173",
                  "http://localhost:5174", "http://127.0.0.1:5174"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# notice the decorator for GET/POST request (@app.get or @app.post)
# Example: if you visit http://127.0.0.1:8000/health, you should see that JSON response.

# Basic health check, nothing to do with DB
@app.get("/health") 
def health():
    return {"status": "ok"}

# Startup script removed - columns are now managed through database reset script
# All columns (profile_image, liquor_license_path, phone_2fa, tfa_method) are created 
# via models.py when running database/scripts/reset.py
# Ensure non-breaking column exists without separate migration file
@app.on_event("startup")
def _ensure_profile_columns():
    try:
        with engine.connect() as conn:
            conn.execute(text(
                "ALTER TABLE staff_profiles ADD COLUMN IF NOT EXISTS profile_image TEXT"
            ))
            conn.execute(text(
                "ALTER TABLE staff_profiles ADD COLUMN IF NOT EXISTS liquor_license_path TEXT"
            ))
            conn.commit()
    except Exception as e:
        # Log and continue; don't block app startup if DB is not reachable at boot
        print(f"Startup column check skipped or failed: {e}")

# Mount static directory for profile images
app.mount("/static", StaticFiles(directory="static"), name="static")

app.include_router(auth.router)
app.include_router(email_controller.router)
app.include_router(profile_controller.router)
app.include_router(staff_dashboard_controller.router)
# For Stripe
app.include_router(stripe_controller.router)
app.include_router(stripe_webhook_controller.router)


# Endpoint for staff sign up
@app.post("/sign_up_staff", status_code=status.HTTP_201_CREATED)
def sign_up_staff_route(
    staff: staff_controller.schemas.StaffSignUp,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    result = staff_controller.sign_up_staff(staff, db, background_tasks)
    return result

# Endpoint for client sign up
@app.post("/sign_up_client", status_code=status.HTTP_201_CREATED)
def sign_up_client_route(
    client: client_controller.schemas.ClientSignUpMinimal,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
):
    result = client_controller.sign_up_client(client, db, background_tasks)
    return result

# endpoint to update onboarding step
@app.post("/auth/onboarding-step")
def update_onboarding_step(
    data: dict,
    db: Session = Depends(get_db)
):
    #update the current onboarding step for a user
    step = data.get("step", 0)
    token = data.get("token")  # we'll get user id from headers instead

    # in a real implementation, get user_id from JWT token in headers
    # for now, we'll update it when they complete profile
    return {"message": "step updated", "step": step}

# endpoint to mark onboarding as complete
@app.post("/auth/onboarding-complete")
def complete_onboarding(
    current_user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db)
):
    """Mark user's onboarding as complete and return new token with updated claims"""
    # Update user's profile_complete status
    current_user.profile_complete = True
    db.commit()
    db.refresh(current_user)
    
    # Generate new token with updated profile_complete status
    new_token = auth.create_access_token(
        data={
            "sub": current_user.email,
            "user_id": current_user.id,
            "role": current_user.role,
            "profile_complete": current_user.profile_complete,
            "onboarding_step": current_user.onboarding_step,
            "status": current_user.status
        }
    )
    
    return {
        "message": "onboarding marked complete",
        "profile_complete": True,
        "access_token": new_token,
        "token_type": "bearer"
    }
# Endpoint to activate staff profile after subscription payment
@app.post("/staff/activate_profile/{staff_id}", status_code=status.HTTP_200_OK)
def activate_staff_profile_route(
    staff_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    """
    Activate a staff member's profile after they complete subscription payment.
    This endpoint can be called by the staff member themselves or an admin.
    """
    # Allow staff to activate their own profile or admin to activate any profile
    if current_user.role not in [UserRole.ADMIN.value, UserRole.STAFF.value]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not authorized to activate staff profiles"
        )
    
    # Staff can only activate their own profile, admin can activate any
    if current_user.role == UserRole.STAFF.value and current_user.id != staff_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Staff members can only activate their own profile"
        )
    
    result = staff_billing_controller.activate_staff_profile_on_subscription(staff_id, db)
    return result

# ==================== CLIENT STAFF PREFERENCES ENDPOINTS ====================

@app.post("/client/staff-preferences", status_code=status.HTTP_200_OK)
def save_client_staff_preferences(
    preferences_data: schemas.ClientStaffPreferenceCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    """
    Save or update staff preferences for a client
    """
    # Only clients can set staff preferences
    if current_user.role != UserRole.CLIENT.value:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only clients can set staff preferences"
        )
    
    result = client_staff_preferences_controller.save_staff_preferences(
        client_id=current_user.id,
        preferences_data=preferences_data,
        db=db
    )
    return result

@app.get("/client/staff-preferences", status_code=status.HTTP_200_OK)
def get_client_staff_preferences(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    """
    Get staff preferences for the current client
    """
    # Only clients can access their staff preferences
    if current_user.role != UserRole.CLIENT.value:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only clients can access staff preferences"
        )
    
    result = client_staff_preferences_controller.get_staff_preferences(
        client_id=current_user.id,
        db=db
    )
    return result

@app.delete("/client/staff-preferences", status_code=status.HTTP_200_OK)
def delete_client_staff_preferences(
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    """
    Delete staff preferences for the current client
    """
    # Only clients can delete their staff preferences
    if current_user.role != UserRole.CLIENT.value:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only clients can delete staff preferences"
        )
    
    result = client_staff_preferences_controller.delete_staff_preferences(
        client_id=current_user.id,
        db=db
    )
    return result
