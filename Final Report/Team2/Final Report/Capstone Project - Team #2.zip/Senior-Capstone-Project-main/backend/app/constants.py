"""
Application-wide constants and enumerations.
This module is imported by other modules to avoid circular imports.
"""
from enum import Enum


class UserRole(Enum):
    """User role enumeration"""
    ADMIN = 0
    CLIENT = 1
    STAFF = 2
