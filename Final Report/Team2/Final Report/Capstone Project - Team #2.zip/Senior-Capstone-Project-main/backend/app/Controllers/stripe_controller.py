import os
import stripe
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel
from starlette.responses import JSONResponse

stripe.api_key = os.getenv("STRIPE_SECRET_KEY")

router = APIRouter(prefix="/stripe", tags=["Stripe"])

# a quick ping to very the secret key is working
@router.get("/ping")
def ping():
    try:
        products = stripe.Product.list(limit=1)
        return {"status": "ok", "products_found": len(products.data)}
    except Exception as e:
        print("Stripe Ping Error:", e)  # <-- Add this
        raise HTTPException(status_code=500, detail=str(e))
    
# Checkout session creators
class OneTimeBody(BaseModel):
    price_env_key: str
    email:str | None = None

@router.post("/checkout/one-time")
def create_one_time_session(body: OneTimeBody):
    price_id = os.getenv(body.price_env_key)
    if not price_id:
        raise HTTPException(status_code=400, detail=f"Missing env: {body.price_env_key}")
    
    try: 
        session = stripe.checkout.Session.create(
            mode="payment",
            line_items=[{"price": price_id, "quantity": 1}],
            success_url=os.getenv("STRIPE_SUCCESS_URL"),
            cancel_url=os.getenv("STRIPE_CANCEL_URL"),
            customer_email=body.email,
        )
        return {"checkout_url": session.url}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    

class SubBody(BaseModel):
    # STRIPE_PRICE_STAFF_SUB
    price_env_key: str
    email: str | None = None

@router.post("/checkout/subscription")
def create_subscription_session(body: SubBody):
    price_id = os.getenv(body.price_env_key)
    if not price_id:
        raise HTTPException(status_code=400, detail=f"Missing env: {body.price_env_key}")
    
    try:
        session = stripe.checkout.Session.create(
            mode="subscription",
            line_items=[{"price": price_id, "quantity": 1}],
            success_url=os.getenv("STRIPE_SUCCESS_URL"),
            cancel_url=os.getenv("STRIPE_CANCEL_URL"),
            customer_email=body.email,
        )

        return {"checkout_url": session.url}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))