from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from database.db import get_db
from database.models import StaffDocument, StaffProfile
from pydantic import BaseModel

router = APIRouter(prefix="/staff/dashboard", tags=["Staff Dashboard"])


class ProfileSummary(BaseModel):
    first_name: str
    last_name: str
    status: str
    profile_image_url: Optional[str] = None


class PersonalInfo(BaseModel):
    date_of_birth: Optional[str]
    phone: Optional[str]
    email: str
    address: Optional[str] = None


class StaffDashboardBasicResponse(BaseModel):
    profile: ProfileSummary
    personal: PersonalInfo


def _get_profile_image_url(documents: list[StaffDocument]) -> Optional[str]:
    for doc in documents:
        if doc.document_type == "profile_picture":
            return doc.file_path
    return None


@router.get("/{user_id}", response_model=StaffDashboardBasicResponse)
def get_staff_dashboard_basic(user_id: int, db: Session = Depends(get_db)):
    staff = (
        db.query(StaffProfile)
        .filter(StaffProfile.staff_id == user_id)
        .first()
    )

    if not staff or not staff.user or staff.user.role != 2:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Staff profile not found"
        )

    documents = (
        db.query(StaffDocument)
        .filter(StaffDocument.staff_id == user_id)
        .all()
    )

    profile_data = ProfileSummary(
        first_name=staff.first_name,
        last_name=staff.last_name,
        status=staff.user.status,
        profile_image_url=_get_profile_image_url(documents),
    )

    personal_data = PersonalInfo(
        date_of_birth=staff.date_of_birth,
        phone=staff.phone,
        email=staff.user.email,
        address=None,  # Staff addresses are not stored yet
    )

    return StaffDashboardBasicResponse(
        profile=profile_data,
        personal=personal_data,
    )
