# Controller for managing client staff preferences
from sqlalchemy.orm import Session
from fastapi import HTTPException, status
from database.models import ClientStaffPreference, User
from database.schemas import ClientStaffPreferenceCreate
import json
from app.constants import UserRole


def save_staff_preferences(
    client_id: int,
    preferences_data: ClientStaffPreferenceCreate,
    db: Session
):
    """
    Save or update staff preferences for a client
    """
    try:
        # Convert minimum_tier_rating list to JSON string
        tier_rating_json = json.dumps(preferences_data.minimum_tier_rating)
        
        # Check if preferences already exist
        existing_preferences = db.query(ClientStaffPreference).filter(
            ClientStaffPreference.client_id == client_id
        ).first()
        
        if existing_preferences:
            # Update existing preferences
            existing_preferences.role = preferences_data.role
            existing_preferences.minimum_tier_rating = tier_rating_json
            existing_preferences.dress_code_notes = preferences_data.dress_code_notes
            existing_preferences.tip_policy = preferences_data.tip_policy
            db.commit()
            db.refresh(existing_preferences)
            
            return {
                "message": "Staff preferences updated successfully",
                "preferences": {
                    "id": existing_preferences.id,
                    "client_id": existing_preferences.client_id,
                    "role": existing_preferences.role,
                    "minimum_tier_rating": json.loads(existing_preferences.minimum_tier_rating) if existing_preferences.minimum_tier_rating else [],
                    "dress_code_notes": existing_preferences.dress_code_notes,
                    "tip_policy": existing_preferences.tip_policy,
                    "created_at": str(existing_preferences.created_at),
                    "updated_at": str(existing_preferences.updated_at)
                }
            }
        else:
            # Create new preferences
            new_preferences = ClientStaffPreference(
                client_id=client_id,
                role=preferences_data.role,
                minimum_tier_rating=tier_rating_json,
                dress_code_notes=preferences_data.dress_code_notes,
                tip_policy=preferences_data.tip_policy
            )
            db.add(new_preferences)
            db.commit()
            db.refresh(new_preferences)
            
            return {
                "message": "Staff preferences saved successfully",
                "preferences": {
                    "id": new_preferences.id,
                    "client_id": new_preferences.client_id,
                    "role": new_preferences.role,
                    "minimum_tier_rating": json.loads(new_preferences.minimum_tier_rating) if new_preferences.minimum_tier_rating else [],
                    "dress_code_notes": new_preferences.dress_code_notes,
                    "tip_policy": new_preferences.tip_policy,
                    "created_at": str(new_preferences.created_at),
                    "updated_at": str(new_preferences.updated_at)
                }
            }
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error saving staff preferences: {str(e)}"
        )


def get_staff_preferences(client_id: int, db: Session):
    """
    Get staff preferences for a client
    """
    try:
        preferences = db.query(ClientStaffPreference).filter(
            ClientStaffPreference.client_id == client_id
        ).first()
        
        if not preferences:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Staff preferences not found for this client"
            )
        
        return {
            "id": preferences.id,
            "client_id": preferences.client_id,
            "role": preferences.role,
            "minimum_tier_rating": json.loads(preferences.minimum_tier_rating) if preferences.minimum_tier_rating else [],
            "dress_code_notes": preferences.dress_code_notes,
            "tip_policy": preferences.tip_policy,
            "created_at": str(preferences.created_at),
            "updated_at": str(preferences.updated_at)
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error retrieving staff preferences: {str(e)}"
        )


def delete_staff_preferences(client_id: int, db: Session):
    """
    Delete staff preferences for a client
    """
    try:
        preferences = db.query(ClientStaffPreference).filter(
            ClientStaffPreference.client_id == client_id
        ).first()
        
        if not preferences:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Staff preferences not found for this client"
            )
        
        db.delete(preferences)
        db.commit()
        
        return {"message": "Staff preferences deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error deleting staff preferences: {str(e)}"
        )
