# import necessary modules
from fastapi import FastAPI, Depends, HTTPException, status, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from pydantic import BaseModel

from database import schemas
from database.db import SessionLocal
from database.models import User
from app.Helper import utils
from database import models
from app.main import get_db
from app.Controllers.email_controller import send_verification_email, send_verification_email_sync

from app.Controllers.client_billing_controller import assign_client_billing

# Endpoint for client sign up minimal version (3 fields only)
def sign_up_client(client: schemas.ClientSignUpMinimal, db: Session = Depends(get_db), background_tasks: BackgroundTasks = None):
    #check if the email is already in use
    existing_user = db.query(models.User).filter(models.User.email == client.email).first()
    if existing_user:
        raise HTTPException(status_code=400, detail="This email is already in use")

    # Create the new user with onboarding tracking
    new_user = models.User(
        email=client.email,
        password_hash = utils.hash_password(client.password),
        role = 1, # the client role
        status = "pending",
        profile_complete = False,  # user needs to complete onboarding
        onboarding_step = 0  # step 0 = just signed up
    )
    db.add(new_user)
    db.flush()

    # Create profile with minimal data and placeholders for required fields
    # placeholders will be replaced during onboarding flow
    new_profile = models.ClientProfile(
        client_id = new_user.id,
        name = client.name,
        # placeholder values that pass validation, will be updated in onboarding
        restaurant_type = "ONBOARDING_INCOMPLETE",
        phone = "000-000-0000",
        address_line1 = "ONBOARDING_INCOMPLETE",
        address_line2 = None,
        city = "TBD",
        state = "NA",
        zipcode = 0,
        EIN_hashed = "",  # empty for now, optional field
        website_url = None
    )
    db.add(new_profile)
    db.commit()
    db.refresh(new_user)

    # create billing with default values (subscription will be handled later)
    billing_data = assign_client_billing(new_user.id, db, expedited=False, white_glove=False)

    # Send verification email
    try:
        if background_tasks is not None:
            background_tasks.add_task(
                send_verification_email_sync, schemas.EmailSchema(email=[client.email])
            )
        else:
            # Use the sync wrapper when no background tasks available
            send_verification_email_sync(schemas.EmailSchema(email=[client.email]))
    except Exception as e:
        # Log the error but don't fail the signup process
        print(f"Failed to send verification email: {e}")

    return {
        "message": "Client registered successfully. Please check your email to verify your account.", 
        "client_id": new_user.id,
        "email_verification_required": True,
        "profile_complete": False,
        "billing_data": billing_data
    }
