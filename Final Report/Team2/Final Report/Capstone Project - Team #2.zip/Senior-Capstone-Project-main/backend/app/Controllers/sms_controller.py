import os
from twilio.rest import Client
from database import schemas
from fastapi import HTTPException
import asyncio
from functools import wraps
from typing import List

# Initialize Twilio client
def get_twilio_client():
    account_sid = os.getenv("TWILIO_ACCOUNT_SID")
    auth_token = os.getenv("TWILIO_AUTH_TOKEN")
    
    if not account_sid or not auth_token:
        raise HTTPException(status_code=500, detail="Twilio credentials not configured")
    
    return Client(account_sid, auth_token)

def sync_wrapper(async_func):
    """Wrapper to make async functions callable from sync context"""
    @wraps(async_func)
    def wrapper(*args, **kwargs):
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # If we're already in an event loop, create a new task
                return asyncio.create_task(async_func(*args, **kwargs))
            else:
                # If no event loop is running, run until complete
                return loop.run_until_complete(async_func(*args, **kwargs))
        except RuntimeError:
            # If no event loop exists, create a new one
            return asyncio.run(async_func(*args, **kwargs))
    return wrapper

async def send_2fa_sms(phone_number: str, code: str):
    """Send 2FA code via SMS using Twilio"""
    try:
        client = get_twilio_client()
        from_number = os.getenv("TWILIO_PHONE_NUMBER")
        
        if not from_number:
            raise HTTPException(status_code=500, detail="Twilio phone number not configured")
        
        message = client.messages.create(
            body=f"Your Shift Solutions verification code is: {code}. This code expires in 5 minutes.",
            from_=from_number,
            to=phone_number
        )
        
        print(f"SMS sent successfully. SID: {message.sid}")
        return {"status": "sent", "sid": message.sid}
        
    except Exception as e:
        print(f"Failed to send SMS: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to send SMS: {str(e)}")

# Sync wrapper for background tasks
send_2fa_sms_sync = sync_wrapper(send_2fa_sms)

def format_phone_number(phone: str) -> str:
    """Format phone number to E.164 format for Twilio"""
    # Remove all non-digit characters
    digits_only = ''.join(filter(str.isdigit, phone))
    
    # If it's a 10-digit US number, add +1
    if len(digits_only) == 10:
        return f"+1{digits_only}"
    # If it already has country code
    elif len(digits_only) == 11 and digits_only.startswith('1'):
        return f"+{digits_only}"
    else:
        # Assume it's already in international format
        return f"+{digits_only}" if not phone.startswith('+') else phone

def validate_phone_number(phone: str) -> bool:
    """Basic phone number validation"""
    digits_only = ''.join(filter(str.isdigit, phone))
    # Accept 10-digit US numbers or 11-digit numbers starting with 1
    return len(digits_only) in [10, 11] and (len(digits_only) == 10 or digits_only.startswith('1'))