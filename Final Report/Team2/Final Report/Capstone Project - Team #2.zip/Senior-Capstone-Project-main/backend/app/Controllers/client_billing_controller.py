from datetime import datetime, timedelta, timezone
from database import models

def assign_client_billing(client_id, db, expedited= False, white_glove = False):
    """
    Assigns billing plans to a new client (restaurant) upon signup.
    Includes both one-time and recurring subscription plans.
    Optional flags allow additional services.
    """

    # Fetch the required plan
    base_subscription = db.query(models.ClientSubscriptionPlan).filter_by(plan_name = "Restaurant Setup Fee").first()
    tablet_mainenance = db.query(models.ClientSubscriptionPlan).filter_by(plan_name = "Tablet Maintenance Fee").first()
    tablet_setup = db.query(models.ClientOneTimePlan).filter_by(plan_name = "Tablet and Setup Fee").first()

    if not base_subscription or not tablet_mainenance or not tablet_setup:
        raise ValueError("Required client billing plans not found: seed plans first.")
    
    now = datetime.now(timezone.utc)

    # Assign the main monthly subscription
    db.add(models.ClientSubscription(
        client_id = client_id,
        plan_id = base_subscription.id,
        status = "active",
        start_date = now,
        next_billing_date = now + timedelta(days = 30)
    ))

    # Add one-tome tablet setup fee
    db.add(models.ClientOneTimeFee(
        client_id = client_id,
        plan_id = tablet_setup.id,
        amount = tablet_setup.price,
        status = "paid"
    ))

    # Add tablet maintenance monthly fee
    db.add(models.ClientSubscription(
        client_id = client_id,
        plan_id = tablet_mainenance.id,
        status = "active",
        start_date = now,
        next_billing_date = now + timedelta(days = 30)
    ))

    # Expedited Setup (Optional)
    if expedited:
        expedited_plan = db.query(models.ClientOneTimePlan).filter_by(plan_name = "Expedited Setup").first()
        if expedited_plan:
            db.add(models.ClientOneTimeFee(
                client_id = client_id,
                plan_id = expedited_plan.id,
                amount = expedited_plan.price,
                status = "paid"
            ))

    # White Glove Access (Optional)
    if white_glove:
        wg_plan = db.query(models.ClientSubscriptionPlan).filter_by(plan_name = "White Glove Access").first()
        if wg_plan:
            db.add(models.ClientSubscription(
                client_id = client_id,
                plan_id = wg_plan.id,
                status = "active",
                start_date = now,
                next_billing_date = now + timedelta(days = 30)
            ))
            
    db.commit()

    return{
        "base_subscription_id": base_subscription.id,
        "tablet_mainenance_id": tablet_mainenance.id,
        "tablet_setup_id": tablet_setup.id
    }