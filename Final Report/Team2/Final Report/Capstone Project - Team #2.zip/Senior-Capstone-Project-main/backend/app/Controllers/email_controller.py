from fastapi import APIRouter, HTTPException, status, Depends, Request
from pydantic import BaseModel, EmailStr
from typing import List
from fastapi_mail import FastMail, MessageSchema, ConnectionConfig, MessageType
from starlette.responses import JSONResponse, RedirectResponse
from sqlalchemy.orm import Session
from database.schemas import EmailSchema
from database.db import get_db
from database.models import User
from app.Helper.utils import create_verification_token, verify_token
from dotenv import load_dotenv
import os
from urllib.parse import quote
import logging
import asyncio

load_dotenv()

# Frontend base URL (used for redirecting users after verification)
FRONTEND_URL = os.getenv("FRONTEND_URL", "http://localhost:5173")

router = APIRouter()

conf = ConnectionConfig(
    MAIL_USERNAME = os.getenv("MAIL_USERNAME"),
    MAIL_PASSWORD = os.getenv("MAIL_PASSWORD"),
    MAIL_FROM = os.getenv("MAIL_FROM"),
    MAIL_PORT = 587,
    MAIL_SERVER = "smtp.gmail.com",
    MAIL_FROM_NAME = os.getenv("MAIL_FROM_NAME"),
    MAIL_STARTTLS = True,
    MAIL_SSL_TLS = False,
    USE_CREDENTIALS = True,
    VALIDATE_CERTS = True
)

@router.post("/send-verification")
async def send_verification_email(email: EmailSchema) -> JSONResponse:
    try:
        logging.info(f"send_verification_email called for: {email}")
        # Generate verification token
        token = create_verification_token(email.dict().get("email")[0])
        # URL-encode the token so it survives being placed in an email URL
        token_encoded = quote(token, safe="")
        verification_url = f"{FRONTEND_URL}/verify-email?token={token_encoded}"

        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {{
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    color: #333333;
                    max-width: 600px;
                    margin: 0 auto;
                }}
                .container {{
                    background-color: #ffffff;
                    padding: 40px;
                    border-radius: 8px;
                }}
                .header {{
                    text-align: center;
                    margin-bottom: 30px;
                }}
                .logo {{
                    font-size: 28px;
                    font-weight: bold;
                    color: #0891b2;
                    margin-bottom: 10px;
                }}
                .content {{
                    margin: 30px 0;
                }}
                .button {{
                    display: inline-block;
                    padding: 14px 32px;
                    background: linear-gradient(135deg, #0891b2 0%, #06b6d4 100%);
                    color: #ffffff !important;
                    text-decoration: none;
                    border-radius: 8px;
                    font-weight: bold;
                    margin: 20px 0;
                    text-align: center;
                }}
                .button:hover {{
                    background: linear-gradient(135deg, #0e7490 0%, #0891b2 100%);
                }}
                .footer {{
                    margin-top: 40px;
                    padding-top: 20px;
                    border-top: 1px solid #e5e7eb;
                    font-size: 14px;
                    color: #6b7280;
                    text-align: center;
                }}
                .security-note {{
                    background-color: #f0f9ff;
                    border-left: 4px solid #0891b2;
                    padding: 15px;
                    margin: 20px 0;
                    font-size: 14px;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <div class="logo">Shift Solutions</div>
                    <p style="color: #6b7280; margin: 0;">Restaurant Staffing Platform</p>
                </div>
                
                <div class="content">
                    <h2 style="color: #0891b2; margin-bottom: 20px;">Welcome to Shift Solutions!</h2>
                    
                    <p>Thank you for creating your account. To get started and access all features of our platform, please verify your email address by clicking the button below:</p>
                    
                    <div style="text-align: center; margin: 30px 0;">
                        <a href="{verification_url}" class="button">Verify Email Address</a>
                    </div>
                    
                    <p style="color: #6b7280; font-size: 14px;">Or copy and paste this link into your browser:</p>
                    <p style="background-color: #f9fafb; padding: 12px; border-radius: 4px; word-break: break-all; font-size: 12px; color: #4b5563;">
                        {verification_url}
                    </p>
                    
                    <div class="security-note">
                        <strong>Security Notice:</strong> This verification link will expire in 24 hours for your security. If you didn't create an account with Shift Solutions, you can safely ignore this email.
                    </div>
                </div>
                
                <div class="footer">
                    <p style="margin: 10px 0;">Need help? Contact us at support@shiftsolutions.com</p>
                    <p style="margin: 10px 0; font-size: 12px;">&copy; 2025 Shift Solutions. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
        """

        message = MessageSchema(
            subject="Welcome to Shift Solutions - Verify Your Email",
            recipients=email.dict().get("email"),
            body=html,
            subtype=MessageType.html,
        )

        fm = FastMail(conf)
        logging.info(f"Attempting to send email to: {email.dict().get('email')}")
        await fm.send_message(message)
        logging.info("Verification email sent successfully")
        return JSONResponse(status_code=200, content={"message": "Verification email has been sent"})
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to send verification email: {str(e)}"
        )

@router.get("/verify/{token}")
async def verify_email(token: str, request: Request, db: Session = Depends(get_db)):
    try:
        # Verify and decode the token
        payload = verify_token(token)
        email = payload.get("email")
        
        if not email:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid verification token"
            )

        # Update user's email_verified status
        user = db.query(User).filter(User.email == email).first()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
        
        user.email_verified = True
        db.add(user)
        db.commit()
        # Refresh to ensure the ORM has the latest DB state
        db.refresh(user)
        logging.info(f"User {user.email} verified and status set to active (email_verified={user.email_verified})")

        # If the client explicitly asked for JSON (e.g., Accept header or query param), return JSON with the updated user
        wants_json = request.query_params.get("json") == "true" or "application/json" in request.headers.get("accept", "")
        success_url = f"{FRONTEND_URL}/verify-email?token={token}&status=success"
        if wants_json:
            return JSONResponse(
                status_code=status.HTTP_200_OK,
                content={
                    "message": "Email successfully verified",
                    "user": {
                        "email": user.email,
                        "email_verified": bool(user.email_verified),
                    },
                },
            )
        # Otherwise redirect the user's browser to a friendly frontend page
        return RedirectResponse(url=success_url)
    except ValueError as e:
        logging.warning(f"Verification token error: {e}")
        # If the request came from a browser, redirect to frontend failure page
        wants_json = request.query_params.get("json") == "true" or "application/json" in request.headers.get("accept", "")
        failure_url = f"{FRONTEND_URL}/verify-email?status=failed"
        if wants_json:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=str(e)
            )
        return RedirectResponse(url=failure_url)
    except Exception as e:
        logging.exception("Unexpected error during email verification")
        wants_json = request.query_params.get("json") == "true" or "application/json" in request.headers.get("accept", "")
        failure_url = f"{FRONTEND_URL}/verify-email?status=failed"
        if wants_json:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error verifying email: {str(e)}"
            )
        return RedirectResponse(url=failure_url)


def send_verification_email_sync(email: EmailSchema):
    """
    Synchronous wrapper that schedules the async send_verification_email
    to run in the event loop. Useful for BackgroundTasks which may call
    sync callables.
    """
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = None

    coro = send_verification_email(email)
    if loop and loop.is_running():
        # If we're in an event loop, create a task
        asyncio.create_task(coro)
    else:
        # Otherwise run until complete
        asyncio.run(coro)

async def send_password_reset_email(email: EmailSchema, token: str) -> JSONResponse:
    try:
        # URL-encode the token so it survives being placed in an email URL
        token_encoded = quote(token, safe="")
        reset_url = f"{FRONTEND_URL}/reset-password?token={token_encoded}"

        html = f"""
        <p>You have requested to reset your password. Click the link below to set a new password:</p>
        <p><a href="{reset_url}">Reset Password</a></p>
        <p>If you didn't request this, you can safely ignore this email.</p>
        <p>This link will expire in 1 hour.</p>
        """

        message = MessageSchema(
            subject="Reset Your Password",
            recipients=email.dict().get("email"),
            body=html,
            subtype=MessageType.html,
        )

        fm = FastMail(conf)
        await fm.send_message(message)
        return JSONResponse(status_code=200, content={"message": "Password reset email has been sent"})
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to send password reset email: {str(e)}"
        )

def send_password_reset_email_sync(email: EmailSchema, token: str):
    """
    Synchronous wrapper for send_password_reset_email
    """
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = None

    coro = send_password_reset_email(email, token)
    if loop and loop.is_running():
        asyncio.create_task(coro)
    else:
        asyncio.run(coro)


async def send_2fa_code(email: EmailSchema, code: str) -> JSONResponse:
    """
    Send a 6-digit 2FA code to the provided email address.
    """
    try:
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {{
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    color: #333333;
                    max-width: 600px;
                    margin: 0 auto;
                }}
                .container {{
                    background-color: #ffffff;
                    padding: 40px;
                    border-radius: 8px;
                }}
                .header {{
                    text-align: center;
                    margin-bottom: 30px;
                }}
                .logo {{
                    font-size: 28px;
                    font-weight: bold;
                    color: #0891b2;
                    margin-bottom: 10px;
                }}
                .content {{
                    margin: 30px 0;
                    text-align: center;
                }}
                .code-box {{
                    background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
                    border: 2px solid #0891b2;
                    border-radius: 12px;
                    padding: 30px;
                    margin: 30px 0;
                    text-align: center;
                }}
                .code {{
                    font-size: 42px;
                    font-weight: bold;
                    letter-spacing: 8px;
                    color: #0891b2;
                    font-family: 'Courier New', monospace;
                }}
                .warning {{
                    background-color: #fef3c7;
                    border-left: 4px solid #f59e0b;
                    padding: 15px;
                    margin: 20px 0;
                    font-size: 14px;
                    text-align: left;
                }}
                .footer {{
                    margin-top: 40px;
                    padding-top: 20px;
                    border-top: 1px solid #e5e7eb;
                    font-size: 14px;
                    color: #6b7280;
                    text-align: center;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <div class="logo">Shift Solutions</div>
                    <p style="color: #6b7280; margin: 0;">Security Verification</p>
                </div>
                
                <div class="content">
                    <h2 style="color: #0891b2; margin-bottom: 20px;">Two-Factor Authentication</h2>
                    
                    <p>A sign-in attempt requires your verification code. Please enter the following code to complete your login:</p>
                    
                    <div class="code-box">
                        <div class="code">{code}</div>
                        <p style="color: #6b7280; font-size: 14px; margin-top: 15px; margin-bottom: 0;">Valid for 5 minutes</p>
                    </div>
                    
                    <p style="color: #4b5563; font-size: 15px;">Enter this code in your browser to continue securely.</p>
                    
                    <div class="warning">
                        <strong>⚠️ Security Alert:</strong> If you did not attempt to sign in, please ignore this email and ensure your account password is secure. Someone may be trying to access your account.
                    </div>
                </div>
                
                <div class="footer">
                    <p style="margin: 10px 0;">This is an automated security message.</p>
                    <p style="margin: 10px 0;">Need help? Contact us at support@shiftsolutions.com</p>
                    <p style="margin: 10px 0; font-size: 12px;">&copy; 2025 Shift Solutions. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
        """

        message = MessageSchema(
            subject="Shift Solutions - Your Security Code",
            recipients=email.dict().get("email"),
            body=html,
            subtype=MessageType.html,
        )

        fm = FastMail(conf)
        await fm.send_message(message)
        return JSONResponse(status_code=200, content={"message": "2FA code sent"})
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to send 2FA code: {str(e)}"
        )


def send_2fa_code_sync(email: EmailSchema, code: str):
    """Synchronous wrapper for send_2fa_code (if needed)"""
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = None

    coro = send_2fa_code(email, code)
    if loop and loop.is_running():
        asyncio.create_task(coro)
    else:
        asyncio.run(coro)