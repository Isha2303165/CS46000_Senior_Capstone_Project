from app.Helper import utils
from fastapi import APIRouter, Depends, HTTPException, status, Request, BackgroundTasks, Header
from fastapi.security import HTTPBearer
from sqlalchemy.orm import Session
from database import schemas
from database.models import User
from database.db import get_db
from app.Controllers.email_controller import send_password_reset_email, send_password_reset_email_sync, send_2fa_code, send_2fa_code_sync, send_verification_email, send_verification_email_sync
from app.Controllers.sms_controller import send_2fa_sms, send_2fa_sms_sync, format_phone_number, validate_phone_number
from datetime import datetime, timedelta
import secrets
from fastapi_mail import MessageSchema
from pydantic import BaseModel
from jose import jwt, JWTError
import os

router = APIRouter(prefix="/auth", tags=["Authentication"])

# Security scheme for token authentication
security = HTTPBearer()

def get_current_user(token: str = Depends(security), db: Session = Depends(get_db)):
    """
    Dependency to get the current authenticated user from JWT token.
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        # Extract token from the credentials
        jwt_token = token.credentials if hasattr(token, 'credentials') else str(token)
        
        # Verify the token using utils
        payload = utils.verify_access_token(jwt_token)
        email: str = payload.get("sub")
        
        if email is None:
            raise credentials_exception
            
    except (ValueError, Exception):
        raise credentials_exception
    
    # Get user from database
    user = db.query(User).filter(User.email == email).first()
    if user is None:
        raise credentials_exception
        
    return user

# Shared logic for login
def authenticate_user(db: Session, email: str, password: str):
    user = db.query(User).filter(User.email == email).first()
    if not user or not utils.verify_password(password, user.password_hash):
        return None
    return user

# In-memory store for 2FA codes. For production, replace with persistent store.
two_fa_store: dict[str, dict] = {}

# Pydantic models for request validation
class Send2FACodeRequest(BaseModel):
    email: str
    method: str  # 'email' or 'sms'
    phone_number: str = None  # Required if method is 'sms' and user doesn't have one configured


@router.post("/login")
async def account_login(
    request: schemas.LoginRequest,
    db: Session = Depends(get_db),
    background_tasks: BackgroundTasks = None,
):
    """
    Authenticate user. If credentials are valid, check email verification status.
    If email is not verified, return a prompt to verify email.
    If email is verified, generate a 6-digit 2FA code, send it via email, 
    and return a response indicating 2FA is required.
    """
    user = authenticate_user(db, request.email, request.password)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials.")

    # Check if email is verified
    if not user.email_verified:
        # Send verification email
        try:
            if background_tasks is not None:
                background_tasks.add_task(
                    send_verification_email_sync, schemas.EmailSchema(email=[user.email])
                )
            else:
                # Use the sync wrapper when no background tasks available
                send_verification_email_sync(schemas.EmailSchema(email=[user.email]))
        except Exception as e:
            # Log the error but don't fail the login process
            print(f"Failed to send verification email: {e}")
        
        return {
            "email_verification_required": True, 
            "email": user.email,
            "message": "Please verify your email address. A verification link has been sent to your email."
        }

    # Determine available 2FA methods and get phone number from profile
    available_methods = ["email"]
    phone_masked = None
    user_phone = None
    
    # Check if user has a phone number in their profile
    if hasattr(user, 'waiter_profile') and user.waiter_profile and user.waiter_profile.phone:
        user_phone = user.waiter_profile.phone
        available_methods.append("sms")
    elif hasattr(user, 'restaurant_profile') and user.restaurant_profile and user.restaurant_profile.phone:
        user_phone = user.restaurant_profile.phone
        available_methods.append("sms")
    elif hasattr(user, 'phone_2fa') and user.phone_2fa:
        # Fallback to the 2FA-specific phone field if exists
        user_phone = user.phone_2fa
        available_methods.append("sms")
    
    if user_phone:
        phone_masked = user_phone[-4:] if len(user_phone) >= 4 else None

    # Return available methods for user to choose from
    return {
        "2fa_method_selection_required": True,
        "email": user.email,
        "available_methods": available_methods,
        "phone_masked": phone_masked
    }

@router.post("/send-2fa-code")
async def send_2fa_code_endpoint(
    request: Send2FACodeRequest,
    db: Session = Depends(get_db),
    background_tasks: BackgroundTasks = None,
):
    """
    Send 2FA code via the user's selected method (email or SMS).
    """
    user = db.query(User).filter(User.email == request.email).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

    # Generate 6-digit code (string, zero-padded)
    code = f"{secrets.randbelow(1000000):06d}"
    expires_at = datetime.utcnow() + timedelta(minutes=5)

    # Store code and expiry associated with the user's email
    two_fa_store[user.email] = {"code": code, "expires_at": expires_at}

    if request.method == 'sms':
        # Get phone number from user's profile
        phone_to_use = None
        
        # Check waiter profile first
        if hasattr(user, 'waiter_profile') and user.waiter_profile and user.waiter_profile.phone:
            phone_to_use = user.waiter_profile.phone
        # Then check restaurant profile
        elif hasattr(user, 'restaurant_profile') and user.restaurant_profile and user.restaurant_profile.phone:
            phone_to_use = user.restaurant_profile.phone
        # Fallback to phone_2fa field
        elif hasattr(user, 'phone_2fa') and user.phone_2fa:
            phone_to_use = user.phone_2fa
        # Last resort: use provided phone number
        elif request.phone_number:
            from app.Controllers.sms_controller import validate_phone_number
            if not validate_phone_number(request.phone_number):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Invalid phone number format"
                )
            phone_to_use = request.phone_number
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST, 
                detail="No phone number found for SMS verification"
            )
        
        # Send SMS
        try:
            formatted_phone = format_phone_number(phone_to_use)
            if background_tasks is not None:
                background_tasks.add_task(send_2fa_sms_sync, formatted_phone, code)
            else:
                # Use sync wrapper to avoid async event loop issues
                send_2fa_sms_sync(formatted_phone, code)
        except Exception as e:
            print(f"Failed to send SMS: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to send SMS code"
            )
    else:
        # Send email (default)
        try:
            if background_tasks is not None:
                background_tasks.add_task(
                    send_2fa_code_sync, schemas.EmailSchema(email=[user.email]), code
                )
            else:
                # Use sync wrapper to avoid async event loop issues
                send_2fa_code_sync(schemas.EmailSchema(email=[user.email]), code)
        except Exception as e:
            print(f"Failed to send email: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to send email code"
            )

    # Determine phone_masked for response
    phone_masked_response = None
    if request.method == 'sms' and phone_to_use:
        phone_masked_response = phone_to_use[-4:] if len(phone_to_use) >= 4 else None

    return {
        "2fa_required": True,
        "email": user.email,
        "method": request.method,
        "phone_masked": phone_masked_response,
        "message": f"Verification code sent via {request.method}"
    }


class TwoFactorVerifyRequest(BaseModel):
    email: str
    code: str


@router.post("/verify-2fa")
def verify_2fa(request: TwoFactorVerifyRequest, db: Session = Depends(get_db)):
    """
    Verify the 6-digit code for the given email. If valid and not expired,
    issue an access token.
    """
    record = two_fa_store.get(request.email)
    if not record:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="No 2FA code found for this email")

    if datetime.utcnow() > record["expires_at"]:
        # remove expired code
        two_fa_store.pop(request.email, None)
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="2FA code has expired")

    if record["code"] != request.code:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid 2FA code")

    # Valid — remove used code and issue token
    two_fa_store.pop(request.email, None)
    user = db.query(User).filter(User.email == request.email).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

    # include onboarding fields in jwt token
    token = utils.create_access_token({
        "sub": user.email,
        "user_id": user.id,
        "role": user.role,
        "status": user.status,
        "profile_complete": user.profile_complete,
        "onboarding_step": user.onboarding_step
    })
    return {
        "access_token": token,
        "token_type": "bearer",
        "role": user.role,
        "status": user.status,
        "profile_complete": user.profile_complete
    }

class ForgotPasswordRequest(BaseModel):
    email: str

class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str

@router.post("/forgot-password")
async def forgot_password(
    request: ForgotPasswordRequest,
    db: Session = Depends(get_db),
    background_tasks: BackgroundTasks = None,
):
    user = db.query(User).filter(User.email == request.email).first()
    if not user:
        # Return success even if user doesn't exist to prevent email enumeration
        return {"message": "If the email exists, a password reset link has been sent."}
    
    # Create a password reset token
    token = utils.create_password_reset_token(request.email, expires_hours=1)
    
    # Send password reset email in the background to avoid blocking
    if background_tasks is not None:
        background_tasks.add_task(
            send_password_reset_email_sync, schemas.EmailSchema(email=[request.email]), token
        )
    else:
        import asyncio
        asyncio.create_task(
            send_password_reset_email(schemas.EmailSchema(email=[request.email]), token)
        )
    
    return {"message": "If the email exists, a password reset link has been sent."}

@router.post("/reset-password")
async def reset_password(request: ResetPasswordRequest, db: Session = Depends(get_db)):
    try:
        # Verify token
        payload = utils.verify_password_reset_token(request.token)
        email = payload.get("email")
        
        if not email:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid reset token"
            )
        
        # Get user and update password
        user = db.query(User).filter(User.email == email).first()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )
        # Update password
        user.password_hash = utils.hash_password(request.new_password)
        db.add(user)
        db.commit()

        return {"message": "Password has been reset successfully"}
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )

class ResendVerificationRequest(BaseModel):
    email: str

class Update2FARequest(BaseModel):
    method: str  # 'email' or 'sms'
    phone_number: str = None  # Required if method is 'sms'

@router.post("/resend-verification")
async def resend_verification_email(
    request: ResendVerificationRequest,
    db: Session = Depends(get_db),
    background_tasks: BackgroundTasks = None,
):
    """
    Resend email verification link to the user.
    """
    user = db.query(User).filter(User.email == request.email).first()
    if not user:
        # Return success even if user doesn't exist to prevent email enumeration
        return {"message": "If the email exists and is not verified, a verification link has been sent."}
    
    if user.email_verified:
        return {"message": "Email is already verified."}
    
    # Send verification email
    try:
        if background_tasks is not None:
            background_tasks.add_task(
                send_verification_email_sync, schemas.EmailSchema(email=[user.email])
            )
        else:
            # Use the sync wrapper when no background tasks available
            send_verification_email_sync(schemas.EmailSchema(email=[user.email]))
    except Exception as e:
        # Log the error but don't fail the resend process
        print(f"Failed to send verification email: {e}")
    
    return {"message": "If the email exists and is not verified, a verification link has been sent."}

@router.post("/update-2fa-method")
async def update_2fa_method(
    request: Update2FARequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Update user's 2FA method preference.
    """
    if request.method not in ['email', 'sms']:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid 2FA method. Must be 'email' or 'sms'"
        )
    
    if request.method == 'sms':
        if not request.phone_number:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Phone number is required for SMS 2FA"
            )
        
        if not validate_phone_number(request.phone_number):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid phone number format"
            )
        
        current_user.phone_2fa = format_phone_number(request.phone_number)
    
    current_user.tfa_method = request.method
    db.add(current_user)
    db.commit()
    
    return {
        "message": f"2FA method updated to {request.method}",
        "method": request.method,
        "phone_masked": current_user.phone_2fa[-4:] if request.method == 'sms' and current_user.phone_2fa else None
    }

@router.get("/2fa-settings")
async def get_2fa_settings(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Get user's current 2FA settings.
    """
    return {
        "method": getattr(current_user, 'tfa_method', 'email'),
        "phone_configured": bool(current_user.phone_2fa),
        "phone_masked": current_user.phone_2fa[-4:] if current_user.phone_2fa else None
    }

class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str


@router.post("/change-password")
async def change_password(
    request: ChangePasswordRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Change password for authenticated user"""
    # Verify current password
    if not utils.verify_password(request.current_password, current_user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Current password is incorrect"
        )
    
    # Update to new password
    current_user.password_hash = utils.hash_password(request.new_password)
    db.add(current_user)
    db.commit()
    
    return {"message": "Password changed successfully"}


@router.get("/me")
async def get_current_user_info(
    current_user: User = Depends(get_current_user)
):
    """Get current authenticated user's information"""
    return {
        "id": current_user.id,
        "email": current_user.email,
        "role": current_user.role,
        "status": current_user.status,
        "email_verified": current_user.email_verified
    }
