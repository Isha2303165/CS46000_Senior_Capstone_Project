from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from sqlalchemy.orm import Session
from database.db import get_db
from database.models import StaffProfile, User, StaffDocument, StaffEmergencyContact, ClientProfile
from pydantic import BaseModel, Field
from typing import Optional
from datetime import date
import os
import shutil
from pathlib import Path
from app.Controllers.staff_billing_controller import assign_staff_billing
from app.Helper import utils
from app.Helper import utils

router = APIRouter(prefix="/profile", tags=["Profile"])

# Schema for getting staff profile data
class StaffProfileResponse(BaseModel):
    staff_id: int
    first_name: str
    middle_name: Optional[str]
    last_name: str
    date_of_birth: str
    phone: str
    profile_image: Optional[str]
    liquor_license_path: Optional[str]
    has_white_glove_certification: bool
    white_glove_certified_date: Optional[str]
    email: str
    status: str

    class Config:
        from_attributes = True

# Schema for updating staff profile
class StaffProfileUpdate(BaseModel):
    first_name: Optional[str] = Field(None, min_length=1, max_length=50)
    middle_name: Optional[str] = Field(None, max_length=50)
    last_name: Optional[str] = Field(None, min_length=1, max_length=50)
    phone: Optional[str] = Field(None, min_length=7, max_length=15)
    date_of_birth: Optional[str] = None
    SSN_hashed: Optional[str] = Field(None, min_length=9, max_length=15)  # Raw SSN from frontend, will be hashed
    short_bio: Optional[str] = Field(None, max_length=500)

# Create uploads directories if they don't exist
PROFILE_IMG_DIR = Path("static/profile_images")
PROFILE_IMG_DIR.mkdir(parents=True, exist_ok=True)

LICENSE_DIR = Path("static/licenses")
LICENSE_DIR.mkdir(parents=True, exist_ok=True)

RESUME_DIR = Path("static/resumes")
RESUME_DIR.mkdir(parents=True, exist_ok=True)

GOV_ID_DIR = Path("static/government_ids")
GOV_ID_DIR.mkdir(parents=True, exist_ok=True)


@router.get("/staff/{user_id}", response_model=StaffProfileResponse)
async def get_staff_profile(user_id: int, db: Session = Depends(get_db)):
    """Get staff profile data for the given user"""
    # Get user info
    user = db.query(User).filter(User.id == user_id).first()
    if not user or user.role != 2:  # 2 = staff role
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Staff user not found"
        )
    
    # Get staff profile
    staff = db.query(StaffProfile).filter(StaffProfile.staff_id == user_id).first()
    if not staff:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Staff profile not found"
        )
    
    # Get profile image from staff_documents
    profile_image_doc = db.query(StaffDocument).filter(
        StaffDocument.staff_id == user_id,
        StaffDocument.document_type == "profile_picture"
    ).first()
    
    # Get liquor license from staff_documents
    liquor_license_doc = db.query(StaffDocument).filter(
        StaffDocument.staff_id == user_id,
        StaffDocument.document_type == "liquor_license_doc"
    ).first()
    
    return StaffProfileResponse(
        staff_id=staff.staff_id,
        first_name=staff.first_name,
        middle_name=staff.middle_name,
        last_name=staff.last_name,
        date_of_birth=staff.date_of_birth,
        phone=staff.phone,
        profile_image=profile_image_doc.file_path if profile_image_doc else None,
        liquor_license_path=liquor_license_doc.file_path if liquor_license_doc else None,
        has_white_glove_certification=staff.has_white_glove_certification,
        white_glove_certified_date=staff.white_glove_certified_date,
        email=user.email,
        status=user.status
    )


@router.put("/staff/{user_id}")
async def update_staff_profile(
    user_id: int,
    profile_data: StaffProfileUpdate,
    db: Session = Depends(get_db)
):
    """Update staff profile data (creates profile if it doesn't exist)"""
    # Get user
    user = db.query(User).filter(User.id == user_id).first()
    if not user or user.role != 2:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Staff user not found"
        )
    
    # Get or create staff profile
    staff = db.query(StaffProfile).filter(StaffProfile.staff_id == user_id).first()
    is_new_profile = False
    
    if not staff:
        # Create new profile
        is_new_profile = True
        try:
            update_data = profile_data.model_dump(exclude_unset=True)
        except AttributeError:
            update_data = profile_data.dict(exclude_unset=True)
        
        # Hash SSN if provided and not empty
        if 'SSN_hashed' in update_data and update_data['SSN_hashed']:
            update_data['SSN_hashed'] = utils.hash_info(update_data['SSN_hashed'])
        elif 'SSN_hashed' in update_data:
            # Remove empty SSN from update data
            del update_data['SSN_hashed']
        
        staff = StaffProfile(
            staff_id=user_id,
            **update_data
        )
        db.add(staff)
        db.flush()  # Flush to get the profile ID
        
        # Assign billing for new profile
        try:
            billing_data = assign_staff_billing(user_id, db)
        except Exception as e:
            print(f"Failed to assign billing: {e}")
            # Continue even if billing fails
    else:
        # Update existing profile
        try:
            update_data = profile_data.model_dump(exclude_unset=True)
        except AttributeError:
            update_data = profile_data.dict(exclude_unset=True)
        
        # Hash SSN if provided and not empty
        if 'SSN_hashed' in update_data and update_data['SSN_hashed']:
            update_data['SSN_hashed'] = utils.hash_info(update_data['SSN_hashed'])
        elif 'SSN_hashed' in update_data:
            # Remove empty SSN from update data
            del update_data['SSN_hashed']
        
        for field, value in update_data.items():
            setattr(staff, field, value)
    
    db.commit()
    db.refresh(staff)
    
    return {
        "message": "Profile created successfully" if is_new_profile else "Profile updated successfully",
        "staff_id": staff.staff_id,
        "profile_complete": True
    }


@router.post("/upload-image/{user_id}")
async def upload_profile_image(
    user_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """Upload a profile image for the given user"""
    # Check if user exists and is staff
    staff = db.query(StaffProfile).filter(StaffProfile.staff_id == user_id).first()
    if not staff:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Staff profile not found"
        )

    # Validate file type
    if not file.content_type.startswith('image/'):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="File must be an image"
        )

    # Create unique filename
    file_ext = file.filename.split('.')[-1]
    filename = f"profile_{user_id}.{file_ext}"
    file_path = PROFILE_IMG_DIR / filename

    # Save file
    try:
        with file_path.open("wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    finally:
        file.file.close()

    # Check if profile picture document already exists
    existing_doc = db.query(StaffDocument).filter(
        StaffDocument.staff_id == user_id,
        StaffDocument.document_type == "profile_picture"
    ).first()

    image_url = f"/static/profile_images/{filename}"
    
    if existing_doc:
        # Update existing record
        existing_doc.file_path = image_url
        existing_doc.status = "approved"  # Profile pictures are auto-approved
    else:
        # Create new record
        new_doc = StaffDocument(
            staff_id=user_id,
            document_type="profile_picture",
            file_path=image_url,
            status="approved"  # Profile pictures are auto-approved
        )
        db.add(new_doc)

    db.commit()

    return {
        "message": "Profile image uploaded successfully",
        "image_url": image_url
    }

@router.get("/image/{user_id}")
async def get_profile_image(user_id: int, db: Session = Depends(get_db)):
    """Get the profile image URL for a user"""
    staff = db.query(StaffProfile).filter(StaffProfile.staff_id == user_id).first()
    if not staff:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Staff profile not found"
        )

    profile_image_doc = db.query(StaffDocument).filter(
        StaffDocument.staff_id == user_id,
        StaffDocument.document_type == "profile_picture"
    ).first()
    
    if not profile_image_doc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No profile image found"
        )

    return {"image_url": profile_image_doc.file_path}


@router.post("/upload-license/{user_id}")
async def upload_liquor_license(
    user_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """Upload a liquor license file (PDF or image) for the given user"""
    staff = db.query(StaffProfile).filter(StaffProfile.staff_id == user_id).first()
    if not staff:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Staff profile not found")

    # Allow PDFs and images
    allowed_types = ["application/pdf"]
    if not (file.content_type in allowed_types or file.content_type.startswith("image/")):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="File must be a PDF or image")

    # Sanitize and build filename
    ext = (file.filename or "").split(".")[-1]
    safe_ext = ext if ext else ("pdf" if file.content_type == "application/pdf" else "bin")
    filename = f"license_{user_id}.{safe_ext}"
    file_path = LICENSE_DIR / filename

    try:
        with file_path.open("wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    finally:
        file.file.close()

    # Check if liquor license document already exists
    existing_doc = db.query(StaffDocument).filter(
        StaffDocument.staff_id == user_id,
        StaffDocument.document_type == "liquor_license_doc"
    ).first()

    license_url = f"/static/licenses/{filename}"
    
    if existing_doc:
        # Update existing record
        existing_doc.file_path = license_url
        existing_doc.status = "pending"
    else:
        # Create new record
        new_doc = StaffDocument(
            staff_id=user_id,
            document_type="liquor_license_doc",
            file_path=license_url,
            status="pending"
        )
        db.add(new_doc)

    db.commit()

    return {"message": "Liquor license uploaded", "license_url": license_url}


@router.get("/license/{user_id}")
async def get_liquor_license(user_id: int, db: Session = Depends(get_db)):
    staff = db.query(StaffProfile).filter(StaffProfile.staff_id == user_id).first()
    if not staff:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Staff profile not found")
    
    liquor_license_doc = db.query(StaffDocument).filter(
        StaffDocument.staff_id == user_id,
        StaffDocument.document_type == "liquor_license_doc"
    ).first()
    
    if not liquor_license_doc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No liquor license uploaded")
    
    return {"license_url": liquor_license_doc.file_path}


# Emergency Contact endpoints
class EmergencyContactCreate(BaseModel):
    name: str
    relation: str
    phone: str
    email: Optional[str] = None
    address: str
    city: str
    state: str
    is_primary: bool = True


class EmergencyContactUpdate(BaseModel):
    name: Optional[str] = None
    relation: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    is_primary: Optional[bool] = None


@router.get("/emergency-contacts/{user_id}")
async def get_emergency_contacts(user_id: int, db: Session = Depends(get_db)):
    """Get all emergency contacts for a staff member"""
    staff = db.query(StaffProfile).filter(StaffProfile.staff_id == user_id).first()
    if not staff:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Staff profile not found")
    
    contacts = db.query(StaffEmergencyContact).filter(
        StaffEmergencyContact.staff_id == user_id
    ).all()
    
    return {
        "contacts": [
            {
                "id": contact.id,
                "name": contact.name,
                "relation": contact.relation,
                "phone": contact.phone,
                "email": contact.email,
                "address": contact.address,
                "city": contact.city,
                "state": contact.state,
                "is_primary": contact.is_primary
            }
            for contact in contacts
        ]
    }


@router.post("/emergency-contacts/{user_id}")
async def create_emergency_contact(
    user_id: int,
    contact_data: EmergencyContactCreate,
    db: Session = Depends(get_db)
):
    """Create a new emergency contact for a staff member"""
    staff = db.query(StaffProfile).filter(StaffProfile.staff_id == user_id).first()
    if not staff:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Staff profile not found")
    
    new_contact = StaffEmergencyContact(
        staff_id=user_id,
        name=contact_data.name,
        relation=contact_data.relation,
        phone=contact_data.phone,
        email=contact_data.email,
        address=contact_data.address,
        city=contact_data.city,
        state=contact_data.state,
        is_primary=contact_data.is_primary
    )
    
    db.add(new_contact)
    db.commit()
    db.refresh(new_contact)
    
    return {
        "message": "Emergency contact created successfully",
        "contact": {
            "id": new_contact.id,
            "name": new_contact.name,
            "relation": new_contact.relation,
            "phone": new_contact.phone,
            "email": new_contact.email,
            "address": new_contact.address,
            "city": new_contact.city,
            "state": new_contact.state,
            "is_primary": new_contact.is_primary
        }
    }


@router.put("/emergency-contacts/{contact_id}")
async def update_emergency_contact(
    contact_id: int,
    contact_data: EmergencyContactUpdate,
    db: Session = Depends(get_db)
):
    """Update an emergency contact"""
    contact = db.query(StaffEmergencyContact).filter(StaffEmergencyContact.id == contact_id).first()
    if not contact:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Emergency contact not found")
    
    # Update only provided fields
    update_data = contact_data.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(contact, field, value)
    
    db.commit()
    db.refresh(contact)
    
    return {
        "message": "Emergency contact updated successfully",
        "contact": {
            "id": contact.id,
            "name": contact.name,
            "relation": contact.relation,
            "phone": contact.phone,
            "email": contact.email,
            "address": contact.address,
            "city": contact.city,
            "state": contact.state,
            "is_primary": contact.is_primary
        }
    }


@router.delete("/emergency-contacts/{contact_id}")
async def delete_emergency_contact(contact_id: int, db: Session = Depends(get_db)):
    """Delete an emergency contact"""
    contact = db.query(StaffEmergencyContact).filter(StaffEmergencyContact.id == contact_id).first()
    if not contact:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Emergency contact not found")
    
    db.delete(contact)
    db.commit()
    
    return {"message": "Emergency contact deleted successfully"}


@router.post("/upload-resume/{user_id}")
async def upload_resume(
    user_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """Upload a resume file (PDF or DOC) for the given user"""
    staff = db.query(StaffProfile).filter(StaffProfile.staff_id == user_id).first()
    if not staff:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Staff profile not found")

    # Allow PDFs and Word documents
    allowed_types = ["application/pdf", "application/msword", 
                     "application/vnd.openxmlformats-officedocument.wordprocessingml.document"]
    if file.content_type not in allowed_types:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, 
            detail="File must be a PDF or Word document"
        )

    # Sanitize and build filename
    ext = (file.filename or "").split(".")[-1]
    safe_ext = ext if ext else "pdf"
    filename = f"resume_{user_id}.{safe_ext}"
    file_path = RESUME_DIR / filename

    try:
        with file_path.open("wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    finally:
        file.file.close()

    # Check if resume document already exists
    existing_doc = db.query(StaffDocument).filter(
        StaffDocument.staff_id == user_id,
        StaffDocument.document_type == "resume"
    ).first()

    if existing_doc:
        # Update existing record
        existing_doc.file_path = f"/static/resumes/{filename}"
        existing_doc.status = "pending"
    else:
        # Create new record
        new_doc = StaffDocument(
            staff_id=user_id,
            document_type="resume",
            file_path=f"/static/resumes/{filename}",
            status="pending"
        )
        db.add(new_doc)

    db.commit()

    return {"message": "Resume uploaded successfully", "resume_url": f"/static/resumes/{filename}"}


@router.get("/resume/{user_id}")
async def get_resume(user_id: int, db: Session = Depends(get_db)):
    """Get the resume URL for a user"""
    staff = db.query(StaffProfile).filter(StaffProfile.staff_id == user_id).first()
    if not staff:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Staff profile not found")
    
    resume_doc = db.query(StaffDocument).filter(
        StaffDocument.staff_id == user_id,
        StaffDocument.document_type == "resume"
    ).first()
    
    if not resume_doc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No resume uploaded")
    
    return {"resume_url": resume_doc.file_path, "status": resume_doc.status}


@router.post("/upload-gov-id/{user_id}")
async def upload_government_id(
    user_id: int,
    file: UploadFile = File(...),
    db: Session = Depends(get_db)
):
    """Upload a government ID file (PDF or image) for the given user"""
    staff = db.query(StaffProfile).filter(StaffProfile.staff_id == user_id).first()
    if not staff:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Staff profile not found")

    # Allow PDFs and images
    allowed_types = ["application/pdf"]
    if not (file.content_type in allowed_types or file.content_type.startswith("image/")):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, 
            detail="File must be a PDF or image"
        )

    # Sanitize and build filename
    ext = (file.filename or "").split(".")[-1]
    safe_ext = ext if ext else ("pdf" if file.content_type == "application/pdf" else "jpg")
    filename = f"gov_id_{user_id}.{safe_ext}"
    file_path = GOV_ID_DIR / filename

    try:
        with file_path.open("wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    finally:
        file.file.close()

    # Check if gov_id document already exists
    existing_doc = db.query(StaffDocument).filter(
        StaffDocument.staff_id == user_id,
        StaffDocument.document_type == "gov_id"
    ).first()

    if existing_doc:
        # Update existing record
        existing_doc.file_path = f"/static/government_ids/{filename}"
        existing_doc.status = "pending"
    else:
        # Create new record
        new_doc = StaffDocument(
            staff_id=user_id,
            document_type="gov_id",
            file_path=f"/static/government_ids/{filename}",
            status="pending"
        )
        db.add(new_doc)

    db.commit()

    return {"message": "Government ID uploaded successfully", "gov_id_url": f"/static/government_ids/{filename}"}


@router.get("/gov-id/{user_id}")
async def get_government_id(user_id: int, db: Session = Depends(get_db)):
    """Get the government ID URL for a user"""
    staff = db.query(StaffProfile).filter(StaffProfile.staff_id == user_id).first()
    if not staff:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Staff profile not found")
    
    gov_id_doc = db.query(StaffDocument).filter(
        StaffDocument.staff_id == user_id,
        StaffDocument.document_type == "gov_id"
    ).first()
    
    if not gov_id_doc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No government ID uploaded")
    
    return {"gov_id_url": gov_id_doc.file_path, "status": gov_id_doc.status}


# client profile endpoints

# schema for updating client profile during onboarding
class ClientProfileUpdateOnboarding(BaseModel):
    restaurant_type: Optional[str] = None
    phone: Optional[str] = None
    address_line1: Optional[str] = None
    address_line2: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    zipcode: Optional[int] = None
    website_url: Optional[str] = None
    EIN_hashed: Optional[str] = None


@router.put("/client/{user_id}")
async def update_client_profile(
    user_id: int,
    profile_data: ClientProfileUpdateOnboarding,
    db: Session = Depends(get_db)
):
    # update client profile with onboarding data
    # get client profile
    profile = db.query(ClientProfile).filter(ClientProfile.client_id == user_id).first()
    if not profile:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="client profile not found")

    # get user record
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="user not found")

    # update profile fields if provided
    if profile_data.restaurant_type:
        profile.restaurant_type = profile_data.restaurant_type
    if profile_data.phone:
        profile.phone = profile_data.phone
    if profile_data.address_line1:
        profile.address_line1 = profile_data.address_line1
    if profile_data.address_line2 is not None:
        profile.address_line2 = profile_data.address_line2
    if profile_data.city:
        profile.city = profile_data.city
    if profile_data.state:
        profile.state = profile_data.state
    if profile_data.zipcode:
        profile.zipcode = profile_data.zipcode
    if profile_data.website_url is not None:
        profile.website_url = profile_data.website_url
    if profile_data.EIN_hashed:
        # hash the ein before storing
        profile.EIN_hashed = utils.hash_info(profile_data.EIN_hashed)

    # check if all required fields are now filled (profile complete)
    required_fields_complete = (
        profile.restaurant_type not in ["ONBOARDING_INCOMPLETE", "", None] and
        profile.phone not in ["000-000-0000", "", None] and
        profile.address_line1 not in ["ONBOARDING_INCOMPLETE", "", None] and
        profile.city not in ["TBD", "", None] and
        profile.state not in ["NA", "", None] and
        profile.zipcode not in [0, None]
    )

    # if profile is complete, mark user's onboarding as complete
    if required_fields_complete:
        user.profile_complete = True
        user.onboarding_step = 2  # move to final step

    db.commit()
    db.refresh(profile)

    return {
        "message": "profile updated successfully",
        "profile_complete": user.profile_complete
    }
