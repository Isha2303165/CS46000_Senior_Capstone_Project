import stripe
import os
from fastapi import APIRouter, Request, HTTPException, Depends
from sqlalchemy.orm import Session
from database.db import get_db
from database import models

# stripe listen --forward-to http://127.0.0.1:8000/stripe/webhook
# stripe trigger checkout.session.completed

# Load secret key
stripe.api_key = os.getenv("STRIPE_SECRET_KEY")
WEBHOOK_SECRET = os.getenv("STRIPE_WEBHOOK_SECRET")

router = APIRouter(prefix="/stripe", tags=["Stripe"]) #added

@router.post("/webhook")
async def stripe_webhook(request: Request, db: Session = Depends(get_db)):
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")

    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, WEBHOOK_SECRET
        )
        print("RAW EVENT:", event["type"])
        
    except Exception as e:
        print("Webhook signature verification failed!", e)
        raise HTTPException(status_code=400, detail="Invalid signature")
    
    event_type = event["type"]
    data = event["data"]["object"]

    print(f"Stripe event received: {event_type}")

    # Handle checkout success
    if event_type == "checkout.session.completed":
        await handle_checkout_completed(db, data)

    # Handle subscription renewals
    if event_type == "invoice.paid":
        await handle_invoice_paid(db, data)

    # Handle subscription cancellations
    if event_type == "customer.subscription.deleted":
        await handle_subscription_deleted(db, data)

    return {"status": "success"}


async def handle_checkout_completed(db, session):
    customer_email = session.get("customer_details", {}).get("email")
    
    line_items = stripe.checkout.Session.list_line_items(session["id"])
    price_id = line_items.data[0].price.id

    print("Email:", customer_email)
    print("Price:", price_id)

    # Lookup user
    user = db.query(models.User).filter_by(email=customer_email).first()
    if not user:
        print("User not found for email", customer_email)
        return
    
    # Determine if it was one-time or subscription
    if session["mode"] == "payment":
        print("One-time payment successful.")

        db.add(models.ClientOneTimeFee(
            client_id=user.id,
            plan_id=None,
            amount=session["amount_total"]/100,
            status="paid"
        ))
        db.commit()

    elif session["mode"] == "subscription":
        print("Subscription created.")

        sub_id = session.get("subscription")

        db.add(models.ClientSubscription(
            client_id=user.id,
            plan_id=None,
            status="active",
            next_billing_date=None
        ))
        db.commit()


async def handle_invoice_paid(db, invoice):
    print("Invoice paid for subscription")
    sub_id = invoice.get("subscription")
    if not sub_id:
        print("No subscription ID found on invoice. likely a one-time or test invoice.")
        return

    amount = invoice["amount_paid"] / 100

    subscription = db.query(models.ClientSubscription)\
                     .filter_by(stripe_subscription_id=sub_id)\
                     .first()

    if subscription:
        subscription.next_billing_date = invoice.get("next_payment_attempt")
        db.commit()
        print("Updated subscription billing date.")
    else:
        print("Subscription not found in database:", sub_id)


async def handle_subscription_deleted(db, subscription_data):
    print("Subscription cancelled ")
    sub_id = subscription_data["id"]

    subscription = db.query(models.ClientSubscription).filter_by(stripe_subscription_id=sub_id).first()

    if subscription:
        subscription.status = "cancelled"
        db.commit()