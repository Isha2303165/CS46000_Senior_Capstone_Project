# Responsible for controling the billing for staff users
from sqlalchemy.orm import Session
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from database import models
from fastapi import HTTPException, status
from app.constants import UserRole


def assign_staff_billing(staff_id: int, db: Session):
    """Assign onboarding fee and default subscription to a newly registered staff member."""
    # One time onboarding fee
    one_time_plan = db.query(models.StaffOneTimePlan).filter_by(plan_name = "Staff Onboarding Fee").first()
    if not one_time_plan:
        raise ValueError("Staff Onboarding Fee plan not found - seed plans first.")
    
    onboarding_fee = models.StaffOneTimeFee(
        staff_id = staff_id,
        plan_id = one_time_plan.id,
        amount = one_time_plan.price,
        status = "pending", # This will be pending until we integrate Stripe/payment
        created_at = datetime.now(timezone.utc)
    )

    db.add(onboarding_fee)

    # Monthly subscription
    subscription_plan = db.query(models.StaffSubscriptionPlan).filter_by(plan_name = "Staff Basic Monthly").first()
    if not subscription_plan:
        raise ValueError("Staff Basic Monthly plan not found - seed plans first.")
    
    subscription = models.StaffSubscription(
        staff_id = staff_id,
        plan_id = subscription_plan.id,
        status = "active",
        start_date = datetime.now(timezone.utc),
        next_billing_date = datetime.now(timezone.utc) + timedelta(days = 30),
        created_at = datetime.now(timezone.utc)
    )

    db.add(subscription)

    db.commit()
    db.refresh(onboarding_fee)
    db.refresh(subscription)

    return{
        "one_time_fee_id": onboarding_fee.id,
        "subscription_id": subscription.id
    }

def activate_staff_profile_on_subscription(staff_id: int, db: Session):
    """
    Activate a staff member's profile when they complete their subscription payment.
    This function:
    - Marks the onboarding fee as paid
    - Changes the user status from 'pending' to 'active'
    - Verifies an active subscription exists
    """
    # Get the user
    user = db.query(models.User).filter(models.User.id == staff_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Staff member not found"
        )
    
    if user.role != UserRole.STAFF.value:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User is not a staff member"
        )
    
    # Verify staff profile exists
    staff_profile = db.query(models.StaffProfile).filter(
        models.StaffProfile.staff_id == staff_id
    ).first()
    if not staff_profile:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Staff profile not found"
        )
    
    # Check if there's an active subscription
    active_subscription = db.query(models.StaffSubscription).filter(
        models.StaffSubscription.staff_id == staff_id,
        models.StaffSubscription.status == "active"
    ).first()
    
    if not active_subscription:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No active subscription found for this staff member"
        )
    
    # Update onboarding fee status to paid
    onboarding_fee = db.query(models.StaffOneTimeFee).filter(
        models.StaffOneTimeFee.staff_id == staff_id,
        models.StaffOneTimeFee.status == "pending"
    ).first()
    
    if onboarding_fee:
        onboarding_fee.status = "paid"
        onboarding_fee.paid_date = datetime.now(timezone.utc)
    
    # Activate the user account
    user.status = "active"
    user.updated_at = datetime.now(timezone.utc)
    
    db.commit()
    db.refresh(user)
    
    return {
        "message": "Staff profile activated successfully",
        "staff_id": staff_id,
        "user_status": user.status,
        "subscription_status": active_subscription.status,
        "onboarding_fee_paid": onboarding_fee.status == "paid" if onboarding_fee else False
    }

def process_subscription_payment(staff_id: int, payment_method: str, db: Session):
    """
    Process a subscription payment and activate the staff profile.
    This can be called after receiving payment confirmation (e.g., from Stripe webhook).
    
    Args:
        staff_id: The ID of the staff member
        payment_method: The payment method used (e.g., 'stripe', 'credit_card', etc.)
        db: Database session
    
    Returns:
        Dictionary with payment and activation status
    """
    # Mark the onboarding fee as paid
    onboarding_fee = db.query(models.StaffOneTimeFee).filter(
        models.StaffOneTimeFee.staff_id == staff_id,
        models.StaffOneTimeFee.status == "pending"
    ).first()
    
    if onboarding_fee:
        onboarding_fee.status = "paid"
        onboarding_fee.paid_date = datetime.now(timezone.utc)
        db.commit()
    
    # Activate the profile
    activation_result = activate_staff_profile_on_subscription(staff_id, db)
    
    return {
        **activation_result,
        "payment_method": payment_method,
        "payment_processed_at": datetime.now(timezone.utc).isoformat()
    }
    