# import necessary modules
from fastapi import FastAPI, Depends, HTTPException, status, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from pydantic import BaseModel

from database import schemas
from database.db import SessionLocal
from database.models import User, StaffProfile
from app.Helper import utils
from database import models
from database.db import get_db
from app.Controllers.email_controller import send_verification_email, send_verification_email_sync

from app.Controllers.staff_billing_controller import assign_staff_billing

# Endpoint for staff sign up
def sign_up_staff(staff: schemas.StaffSignUp, db: Session = Depends(get_db), background_tasks: BackgroundTasks = None):
    #check if the email is already in use
    existing_user = db.query(models.User).filter(models.User.email == staff.email).first()
    if existing_user:
        raise HTTPException(status_code=400, detail="This email is already in use")
        
    #create the new user
    new_user = models.User(
        email=staff.email,
        password_hash = utils.hash_password(staff.password),
        role = 2, # the staff role
        status = "pending",
        profile_complete = False,  # user needs to complete onboarding
        onboarding_step = 0  # start at step 0 (welcome page)
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    # Send verification email
    try:
        if background_tasks is not None:
            background_tasks.add_task(
                send_verification_email_sync, schemas.EmailSchema(email=[staff.email])
            )
        else:
            # Use the sync wrapper when no background tasks available
            send_verification_email_sync(schemas.EmailSchema(email=[staff.email]))
    except Exception as e:
        # Log the error but don't fail the signup process
        print(f"Failed to send verification email: {e}")

    # Note: Billing will be assigned when profile is created during onboarding

    return {
        "message": "Staff registered successfully", 
        "staff_id": new_user.id,
        "email_verification_required": True,
        "profile_complete": False
        }

