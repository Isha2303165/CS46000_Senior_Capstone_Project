# Backend Documentation Index

## Overview
This directory contains comprehensive documentation for the Senior Capstone Project backend API. The backend is built with FastAPI and PostgreSQL, providing authentication, user management, and billing services for a restaurant staffing platform.

---

## Quick Start

### Prerequisites
- Python 3.11+
- PostgreSQL 14+
- pip and venv

### Setup
```bash
# Navigate to backend
cd backend

# Create virtual environment
python -m venv .venv

# Activate virtual environment
# Windows PowerShell:
.\.venv\Scripts\Activate.ps1
# Linux/Mac:
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Create .env file
echo "DB_URL=postgresql://postgres:password@localhost:5432/capstone_db" > .env
echo "SECRET_KEY=your-secret-key-here" >> .env
echo "MAIL_USERNAME=your-email@gmail.com" >> .env
echo "MAIL_PASSWORD=your-app-password" >> .env
echo "MAIL_FROM=your-email@gmail.com" >> .env

# Setup database
python -m database.scripts.reset

# Run server
uvicorn app.main:app --reload
```

---

## Documentation Files

### Core API
- **[Main API Documentation](MAIN_API_DOCUMENTATION.md)**
  - Application configuration
  - CORS settings
  - Static file serving
  - Main endpoints
  - Running the application

### Authentication & Security
- **[Authentication Documentation](AUTH_DOCUMENTATION.md)**
  - Login flow
  - Two-factor authentication (2FA)
  - Email verification
  - Password management
  - JWT token handling
  - Security best practices

- **[Utilities Documentation](UTILITIES_DOCUMENTATION.md)**
  - Password hashing (bcrypt)
  - Information hashing (SHA-256)
  - JWT token creation/verification
  - Email verification tokens
  - Password reset tokens

### Database
- **[Database Models Documentation](DATABASE_MODELS_DOCUMENTATION.md)**
  - Complete schema reference
  - User roles and permissions
  - Staff domain models
  - Client domain models
  - Billing and subscription models
  - Entity relationships

- **[Database Connection Documentation](DATABASE_CONNECTION_DOCUMENTATION.md)**
  - Connection setup
  - Session management
  - Transaction handling
  - Connection pooling
  - Error handling
  - Production considerations

- **[Database Schemas Documentation](DATABASE_SCHEMAS_DOCUMENTATION.md)**
  - Pydantic validation schemas
  - Input validation
  - Password requirements
  - Request/response models
  - API documentation generation

- **[Database Scripts Documentation](DATABASE_SCRIPTS_DOCUMENTATION.md)**
  - Create tables
  - Seed data
  - Reset database
  - Drop tables
  - Migration strategies

### Business Logic
- **[Controllers Documentation](CONTROLLERS_DOCUMENTATION.md)**
  - Staff controller
  - Client controller
  - Email controller
  - SMS controller
  - Profile controller
  - Dashboard controller
  - Billing controllers

---

## Architecture Overview

### Technology Stack
- **Framework**: FastAPI 0.104+
- **Database**: PostgreSQL 14+
- **ORM**: SQLAlchemy 2.0+
- **Authentication**: JWT (python-jose)
- **Password Hashing**: bcrypt (passlib)
- **Email**: FastAPI-Mail
- **SMS**: Twilio
- **Validation**: Pydantic

### Project Structure
```
backend/
├── app/
│   ├── Controllers/          # Business logic & endpoints
│   │   ├── auth.py
│   │   ├── client_controller.py
│   │   ├── staff_controller.py
│   │   ├── email_controller.py
│   │   ├── sms_controller.py
│   │   ├── profile_controller.py
│   │   ├── staff_dashboard_controller.py
│   │   ├── staff_billing_controller.py
│   │   └── client_billing_controller.py
│   ├── Helper/               # Utility functions
│   │   └── utils.py
│   └── main.py               # Application entry point
├── database/
│   ├── scripts/              # Database management
│   │   ├── create.py
│   │   ├── seed.py
│   │   ├── reset.py
│   │   └── drop.py
│   ├── db.py                 # Database connection
│   ├── models.py             # SQLAlchemy models
│   └── schemas.py            # Pydantic schemas
├── docs/                     # Documentation (this directory)
├── static/                   # Uploaded files
│   ├── profile_images/
│   ├── licenses/
│   ├── resumes/
│   └── government_ids/
├── Testing/                  # Test files
├── .env                      # Environment variables (create this)
├── requirements.txt          # Python dependencies
└── run_backend.ps1          # PowerShell run script
```

---

## Key Features

### User Management
- **Three User Roles**: Admin (0), Client (1), Staff (2)
- **Email Verification**: Required for account activation
- **Profile Management**: Extended profiles for staff and clients
- **Document Upload**: Resume, ID, liquor license, profile pictures

### Authentication & Security
- **Password Requirements**: 8-20 chars, mixed case, numbers, special characters
- **JWT Tokens**: 60-minute access tokens
- **Two-Factor Authentication**: Email or SMS-based
- **Password Reset**: Secure token-based flow
- **Data Hashing**: Bcrypt for passwords, SHA-256 for SSN/EIN

### Billing System
- **Staff Billing**: $30 onboarding + $5.95/month subscription
- **Client Billing**: Multiple plans and add-ons
- **Subscription Management**: Active, cancelled, past_due states
- **One-Time Fees**: Setup and expedited services

### Communication
- **Email**: FastAPI-Mail with Gmail SMTP
- **SMS**: Twilio integration for 2FA codes
- **Verification Links**: Token-based email verification
- **Password Reset**: Email-based secure flow

---

## API Endpoints Summary

### Authentication (`/auth`)
- `POST /auth/login` - User login
- `POST /auth/send-2fa-code` - Send 2FA code
- `POST /auth/verify-2fa` - Verify 2FA code
- `POST /auth/forgot-password` - Request password reset
- `POST /auth/reset-password` - Reset password
- `POST /auth/change-password` - Change password (authenticated)
- `POST /auth/update-2fa-method` - Update 2FA preference
- `GET /auth/2fa-settings` - Get 2FA settings
- `GET /auth/me` - Get current user info

### User Registration
- `POST /sign_up_staff` - Register staff member
- `POST /sign_up_client` - Register restaurant client

### Email (`/`)
- `POST /send-verification` - Send verification email
- `GET /verify/{token}` - Verify email address

### Profile (`/profile`)
- `GET /profile/staff/{user_id}` - Get staff profile
- `PUT /profile/staff/{user_id}` - Update staff profile
- `POST /profile/staff/{user_id}/upload-profile-image` - Upload profile picture
- `POST /profile/staff/{user_id}/upload-resume` - Upload resume
- `POST /profile/staff/{user_id}/upload-government-id` - Upload ID
- `POST /profile/staff/{user_id}/upload-liquor-license` - Upload license

### Dashboard (`/staff/dashboard`)
- `GET /staff/dashboard/{user_id}` - Get dashboard data

### Staff Management
- `POST /staff/activate_profile/{staff_id}` - Activate staff profile

---

## Environment Variables Reference

### Required Variables
```env
# Database
DB_URL=postgresql://user:password@host:port/database

# JWT Security
SECRET_KEY=your-secret-key-minimum-32-characters

# Email (Gmail)
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-gmail-app-password
MAIL_FROM=your-email@gmail.com
MAIL_FROM_NAME=Your App Name

# Frontend URL
FRONTEND_URL=http://localhost:5173

# Twilio (for SMS 2FA)
TWILIO_ACCOUNT_SID=your-twilio-sid
TWILIO_AUTH_TOKEN=your-twilio-token
TWILIO_PHONE_NUMBER=+15551234567
```

### Optional Variables
```env
# Token expiration (minutes)
ACCESS_TOKEN_EXPIRE_MINUTES=60

# Environment flag
ENVIRONMENT=development
```

---

## Testing

### Test Users
Created by `seed.py`:

**Staff Account:**
- Email: `capstone@pfw.edu`
- Password: `capstone`
- Role: Staff

**Client Account:**
- Email: `client@pfw.edu`
- Password: `clientpass`
- Role: Client

### Running Tests
```bash
pytest Testing/
```

---

## Common Tasks

### Reset Database
```bash
python -m database.scripts.reset
```

### Create New Tables Only
```bash
python -m database.scripts.create
```

### Seed Sample Data
```bash
python -m database.scripts.seed
```

### Run Development Server
```bash
uvicorn app.main:app --reload
```

### Run with PowerShell Script
```powershell
.\run_backend.ps1
```

---

## Troubleshooting

### Database Connection Issues
1. Verify PostgreSQL is running
2. Check `DB_URL` in `.env`
3. Test connection: `psql -U postgres`
4. Review [Database Connection Documentation](DATABASE_CONNECTION_DOCUMENTATION.md)

### Email Not Sending
1. Verify Gmail app password (not regular password)
2. Enable "Less secure app access" or use app-specific password
3. Check firewall/network settings
4. Review [Controllers Documentation](CONTROLLERS_DOCUMENTATION.md#email-controller)

### Authentication Errors
1. Check `SECRET_KEY` in `.env`
2. Verify token hasn't expired
3. Ensure email is verified
4. Review [Authentication Documentation](AUTH_DOCUMENTATION.md)

### Import Errors
1. Activate virtual environment
2. Install dependencies: `pip install -r requirements.txt`
3. Verify Python version: `python --version`

---

## Development Workflow

### Adding New Feature
1. **Create Model** (if needed) in `database/models.py`
2. **Create Schema** in `database/schemas.py`
3. **Reset Database** to apply changes
4. **Create Controller** in `app/Controllers/`
5. **Register Router** in `app/main.py`
6. **Test Endpoint** with Swagger UI
7. **Update Documentation**

### Making Schema Changes
1. Modify `database/models.py`
2. Run `python -m database.scripts.reset` (development only)
3. For production, use Alembic migrations

---

## Production Deployment

### Pre-Deployment Checklist
- [ ] Change `SECRET_KEY` to secure random value
- [ ] Use production database URL
- [ ] Enable HTTPS/SSL
- [ ] Configure proper CORS origins
- [ ] Set up database backups
- [ ] Use Alembic for migrations
- [ ] Configure logging
- [ ] Set up monitoring
- [ ] Review security settings

### Security Considerations
- Never commit `.env` file
- Use strong database passwords
- Enable SSL for database connections
- Implement rate limiting
- Use secure session management
- Regular security audits
- Keep dependencies updated

---

## Additional Resources

### Official Documentation
- [FastAPI Docs](https://fastapi.tiangolo.com/)
- [SQLAlchemy Docs](https://docs.sqlalchemy.org/)
- [Pydantic Docs](https://docs.pydantic.dev/)
- [PostgreSQL Docs](https://www.postgresql.org/docs/)

### Related Project Files
- `README.md` - Project overview
- `requirements.txt` - Python dependencies
- `IMPLEMENTATION_SUMMARY.md` - Feature implementation details
- `STAFF_ACTIVATION_README.md` - Staff activation workflow

---

## Support

### Getting Help
1. Check relevant documentation file
2. Review error messages and logs
3. Search existing issues
4. Contact development team

### Reporting Issues
Include:
- Error message and stack trace
- Steps to reproduce
- Environment details (OS, Python version)
- Relevant configuration (without secrets)

---

## Contributing

### Documentation Updates
When adding or modifying features:
1. Update relevant documentation file
2. Update this index if adding new docs
3. Keep code examples current
4. Test all commands/examples
5. Submit documentation with code changes

### Code Standards
- Follow PEP 8 style guide
- Add docstrings to functions
- Include type hints
- Write meaningful commit messages
- Test before committing

---

## License
[Add your license information here]

## Version
Documentation Version: 1.0  
Last Updated: December 4, 2025
