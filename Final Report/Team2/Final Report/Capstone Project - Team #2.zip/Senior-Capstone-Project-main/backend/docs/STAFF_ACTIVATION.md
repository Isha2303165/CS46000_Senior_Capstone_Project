# Staff Profile Activation on Subscription

## Overview

This feature automatically activates a staff member's profile once they complete their subscription payment. When a staff member signs up, their account is initially set to "pending" status with a pending onboarding fee. Once the subscription is paid, their profile becomes "active" and they can access all platform features.

## How It Works

### 1. Staff Registration Flow

When a staff member signs up (`POST /sign_up_staff`):
- User account is created with `status = "pending"`
- Staff profile is created with all required information
- One-time onboarding fee is created with `status = "pending"`
- Monthly subscription is created with `status = "active"`

### 2. Payment Processing

After the staff member completes payment (via Stripe or other payment gateway):

**Option A: Direct Activation (Manual/Testing)**
```python
from app.Controllers.staff_billing_controller import activate_staff_profile_on_subscription

# Call this after payment is confirmed
result = activate_staff_profile_on_subscription(staff_id, db)
```

**Option B: Process Payment and Activate (Recommended for Webhooks)**
```python
from app.Controllers.staff_billing_controller import process_subscription_payment

# Call this from your payment webhook handler
result = process_subscription_payment(staff_id, "stripe", db)
```

### 3. What Happens on Activation

- Onboarding fee status changes from `"pending"` to `"paid"`
- User status changes from `"pending"` to `"active"`
- User's `updated_at` timestamp is updated
- Returns confirmation with all status details

## API Endpoints

### POST /staff/activate_profile/{staff_id}

Activate a staff member's profile after subscription payment.

**Authentication Required:** Yes (Staff member or Admin)

**Authorization:**
- Staff members can only activate their own profile
- Admins can activate any staff profile

**Path Parameters:**
- `staff_id` (integer): The ID of the staff member to activate

**Response:**
```json
{
  "message": "Staff profile activated successfully",
  "staff_id": 123,
  "user_status": "active",
  "subscription_status": "active",
  "onboarding_fee_paid": true
}
```

**Error Responses:**
- `404 Not Found` - Staff member not found
- `400 Bad Request` - No active subscription found
- `403 Forbidden` - Not authorized to activate this profile

**Example Usage:**
```bash
# Login first
curl -X POST http://localhost:8000/login \
  -H "Content-Type: application/json" \
  -d '{"email": "staff@example.com", "password": "password"}'

# Use the token to activate profile
curl -X POST http://localhost:8000/staff/activate_profile/123 \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

## Backend Functions

### `activate_staff_profile_on_subscription(staff_id: int, db: Session)`

Core function that handles profile activation.

**Parameters:**
- `staff_id`: The ID of the staff member
- `db`: SQLAlchemy database session

**Validation:**
- Verifies staff member exists
- Ensures user has role = 2 (staff)
- Checks for active subscription
- Verifies staff profile exists

**Returns:** Dictionary with activation status and details

**Raises:**
- `HTTPException(404)` - Staff member or profile not found
- `HTTPException(400)` - Invalid staff member or no active subscription

### `process_subscription_payment(staff_id: int, payment_method: str, db: Session)`

Convenience function for payment webhook integration.

**Parameters:**
- `staff_id`: The ID of the staff member
- `payment_method`: Payment method used (e.g., "stripe", "credit_card")
- `db`: SQLAlchemy database session

**Returns:** Dictionary with payment and activation details including timestamp

**Use Case:** Call this from your Stripe webhook handler or payment confirmation endpoint.

## Integration with Payment Gateway

### Stripe Webhook Example

```python
@app.post("/webhooks/stripe")
async def stripe_webhook(request: Request, db: Session = Depends(get_db)):
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")
    
    # Verify webhook signature
    event = stripe.Webhook.construct_event(payload, sig_header, webhook_secret)
    
    # Handle successful payment
    if event["type"] == "checkout.session.completed":
        session = event["data"]["object"]
        staff_id = session["metadata"]["staff_id"]
        
        # Activate the profile
        result = process_subscription_payment(staff_id, "stripe", db)
        
        return {"status": "success", "result": result}
    
    return {"status": "ignored"}
```

## Testing

Run the test suite to verify functionality:

```bash
# From backend directory
pytest Testing/test_staff_activation.py -v
```

**Test Coverage:**
- ✅ Successful profile activation
- ✅ Activation fails without active subscription
- ✅ Activation fails for non-existent staff
- ✅ Payment processing workflow
- ✅ Endpoint authorization (staff can only activate own profile)
- ✅ Endpoint authorization (staff cannot activate others' profiles)

## Database Changes

The activation process modifies the following tables:

1. **users table**
   - `status`: "pending" → "active"
   - `updated_at`: Updated to current timestamp

2. **staff_one_time_fees table**
   - `status`: "pending" → "paid"
   - `paid_date`: Set to current timestamp

## Security Considerations

1. **Authentication Required**: All activation endpoints require valid JWT token
2. **Authorization**: Staff can only activate their own profiles (unless admin)
3. **Validation**: Verifies active subscription exists before activation
4. **Idempotency**: Can be called multiple times safely (already active profiles remain active)

## Future Enhancements

- [ ] Email notification on successful activation
- [ ] SMS notification option
- [ ] Grace period for failed payments
- [ ] Auto-deactivation on subscription cancellation
- [ ] Webhook retry mechanism for failed activations
- [ ] Admin dashboard for managing pending activations
