# Controllers Documentation

## Overview
Controllers handle business logic and API endpoints for different domains of the application. Each controller is responsible for a specific feature set.

---

## Staff Controller
**File**: `backend/app/Controllers/staff_controller.py`

### Purpose
Handles staff member registration and profile creation.

### Functions

#### `sign_up_staff(staff, db, background_tasks)`
**Purpose**: Register a new staff member.

**Parameters:**
- `staff`: StaffSignUp schema with registration data
- `db`: Database session
- `background_tasks`: FastAPI background tasks for email

**Process:**
1. Check if email already exists
2. Create User record (role=2, status="pending")
3. Hash password with bcrypt
4. Create StaffProfile record
5. Hash SSN with SHA-256
6. Assign billing (onboarding fee + monthly subscription)
7. Send verification email
8. Return confirmation with IDs

**Response:**
```json
{
  "message": "Staff registered successfully",
  "staff_id": 123,
  "billing_data": {
    "one_time_fee_id": 456,
    "subscription_id": 789
  },
  "email_verification_required": true
}
```

**Errors:**
- `400 Bad Request`: Email already in use

---

## Client Controller
**File**: `backend/app/Controllers/client_controller.py`

### Purpose
Handles client (restaurant) registration and profile creation.

### Functions

#### `sign_up_client(client, db, background_tasks)`
**Purpose**: Register a new restaurant/client.

**Parameters:**
- `client`: ClientSignUp schema with registration data
- `db`: Database session
- `background_tasks`: FastAPI background tasks for email

**Process:**
1. Check if email already exists
2. Create User record (role=1, status="pending")
3. Hash password with bcrypt
4. Create ClientProfile record
5. Hash EIN with SHA-256
6. Assign billing plans based on selections
7. Send verification email
8. Return confirmation with IDs

**Response:**
```json
{
  "message": "Client registered successfully. Please check your email to verify your account.",
  "client_id": 123,
  "email_verification_required": true,
  "billing_data": {
    "base_subscription_id": 1,
    "tablet_mainenance_id": 2,
    "tablet_setup_id": 3
  }
}
```

**Errors:**
- `400 Bad Request`: Email already in use

---

## Email Controller
**File**: `backend/app/Controllers/email_controller.py`

### Purpose
Handles all email-related operations including verification, password resets, and 2FA codes.

### Configuration
```python
conf = ConnectionConfig(
    MAIL_USERNAME = os.getenv("MAIL_USERNAME"),
    MAIL_PASSWORD = os.getenv("MAIL_PASSWORD"),
    MAIL_FROM = os.getenv("MAIL_FROM"),
    MAIL_PORT = 587,
    MAIL_SERVER = "smtp.gmail.com",
    MAIL_FROM_NAME = os.getenv("MAIL_FROM_NAME"),
    MAIL_STARTTLS = True,
    MAIL_SSL_TLS = False
)
```

### Endpoints

#### `POST /send-verification`
**Purpose**: Send email verification link.

**Request:**
```json
{
  "email": ["user@example.com"]
}
```

**Email Content:**
- Subject: "Verify Your Email Address"
- Contains clickable verification link
- Link expires in 24 hours

#### `GET /verify/{token}`
**Purpose**: Verify email address using token.

**Parameters:**
- `token`: JWT verification token from email link

**Response:**
- Browser: Redirects to frontend with success/failure status
- JSON (with ?json=true): Returns verification result

**Process:**
1. Decode and verify JWT token
2. Extract email from token payload
3. Find user in database
4. Set `email_verified = True`
5. Redirect or return JSON response

### Helper Functions

#### `send_verification_email_sync(email)`
**Purpose**: Synchronous wrapper for background task execution.

**Usage:**
```python
background_tasks.add_task(
    send_verification_email_sync,
    EmailSchema(email=[user.email])
)
```

---

## SMS Controller
**File**: `backend/app/Controllers/sms_controller.py`

### Purpose
Handles SMS messaging for 2FA using Twilio.

### Configuration
Requires environment variables:
- `TWILIO_ACCOUNT_SID`
- `TWILIO_AUTH_TOKEN`
- `TWILIO_PHONE_NUMBER`

### Functions

#### `send_2fa_sms(phone_number, code)`
**Purpose**: Send 2FA verification code via SMS.

**Parameters:**
- `phone_number`: E.164 formatted phone number
- `code`: 6-digit verification code

**Message Format:**
```
Your Shift Solutions verification code is: 123456. This code expires in 5 minutes.
```

**Returns:**
```json
{
  "status": "sent",
  "sid": "SM..."
}
```

#### `format_phone_number(phone: str) -> str`
**Purpose**: Convert phone number to E.164 format.

**Examples:**
- `"5551234567"` → `"+15551234567"`
- `"15551234567"` → `"+15551234567"`
- `"+15551234567"` → `"+15551234567"` (unchanged)

#### `validate_phone_number(phone: str) -> bool`
**Purpose**: Validate phone number format.

**Accepts:**
- 10-digit US numbers
- 11-digit numbers starting with 1

#### `send_2fa_sms_sync`
**Purpose**: Synchronous wrapper for background task execution.

---

## Profile Controller
**File**: `backend/app/Controllers/profile_controller.py`

### Purpose
Manages staff profile viewing and editing, including file uploads.

### Static Directories
```python
PROFILE_IMG_DIR = "static/profile_images"
LICENSE_DIR = "static/licenses"
RESUME_DIR = "static/resumes"
GOV_ID_DIR = "static/government_ids"
```

### Endpoints

#### `GET /profile/staff/{user_id}`
**Purpose**: Retrieve staff profile data.

**Response:**
```json
{
  "staff_id": 123,
  "first_name": "John",
  "middle_name": "A",
  "last_name": "Doe",
  "date_of_birth": "1990-01-01",
  "phone": "555-1234567",
  "profile_image": "/static/profile_images/123.jpg",
  "liquor_license_path": "/static/licenses/123.pdf",
  "has_white_glove_certification": false,
  "white_glove_certified_date": null,
  "email": "john@example.com",
  "status": "active"
}
```

**Errors:**
- `404 Not Found`: User or profile doesn't exist

#### `PUT /profile/staff/{user_id}`
**Purpose**: Update staff profile information.

**Request:**
```json
{
  "first_name": "John",
  "last_name": "Doe",
  "phone": "555-9876543"
}
```

#### `POST /profile/staff/{user_id}/upload-profile-image`
**Purpose**: Upload profile picture.

**Request:** Multipart form data with image file

**Accepted Formats:** .jpg, .jpeg, .png, .gif

**Max Size:** 5MB

#### `POST /profile/staff/{user_id}/upload-resume`
**Purpose**: Upload resume document.

**Accepted Formats:** .pdf, .doc, .docx

#### `POST /profile/staff/{user_id}/upload-government-id`
**Purpose**: Upload government-issued ID.

**Accepted Formats:** .pdf, .jpg, .jpeg, .png

#### `POST /profile/staff/{user_id}/upload-liquor-license`
**Purpose**: Upload liquor license documentation.

**Accepted Formats:** .pdf, .jpg, .jpeg, .png

---

## Staff Dashboard Controller
**File**: `backend/app/Controllers/staff_dashboard_controller.py`

### Purpose
Provides dashboard data for staff members.

### Endpoints

#### `GET /staff/dashboard/{user_id}`
**Purpose**: Get basic dashboard information.

**Response:**
```json
{
  "profile": {
    "first_name": "John",
    "last_name": "Doe",
    "status": "active",
    "profile_image_url": "/static/profile_images/123.jpg"
  },
  "personal": {
    "date_of_birth": "1990-01-01",
    "phone": "555-1234567",
    "email": "john@example.com",
    "address": null
  }
}
```

**Errors:**
- `404 Not Found`: Staff profile not found

---

## Staff Billing Controller
**File**: `backend/app/Controllers/staff_billing_controller.py`

### Purpose
Manages staff billing, subscriptions, and profile activation.

### Functions

#### `assign_staff_billing(staff_id, db)`
**Purpose**: Assign onboarding fee and subscription to new staff member.

**Creates:**
1. StaffOneTimeFee: $30.00 onboarding (status: "pending")
2. StaffSubscription: $5.95/month (status: "active")

**Returns:**
```json
{
  "one_time_fee_id": 456,
  "subscription_id": 789
}
```

#### `activate_staff_profile_on_subscription(staff_id, db)`
**Purpose**: Activate staff profile after subscription payment.

**Process:**
1. Verify user exists and is staff role
2. Check for active subscription
3. Mark onboarding fee as "paid"
4. Change user status from "pending" to "active"

**Returns:**
```json
{
  "message": "Staff profile activated successfully",
  "user_status": "active",
  "onboarding_fee_paid": true
}
```

**Errors:**
- `404 Not Found`: Staff member not found
- `400 Bad Request`: User is not staff or no active subscription

---

## Client Billing Controller
**File**: `backend/app/Controllers/client_billing_controller.py`

### Purpose
Manages client billing and subscription assignment.

### Functions

#### `assign_client_billing(client_id, db, expedited=False, white_glove=False)`
**Purpose**: Assign billing plans to new restaurant client.

**Base Plans (Always Assigned):**
1. Restaurant Setup Fee (subscription)
2. Tablet and Setup Fee (one-time)
3. Tablet Maintenance Fee (subscription)

**Optional Plans:**
4. Expedited Setup (one-time, if `expedited=True`)
5. White Glove Access (subscription, if `white_glove=True`)

**Returns:**
```json
{
  "base_subscription_id": 1,
  "tablet_mainenance_id": 2,
  "tablet_setup_id": 3
}
```

**All Plans Start:**
- `status`: "active" (subscriptions) or "paid" (one-time)
- `start_date`: Current UTC time
- `next_billing_date`: 30 days from start (for subscriptions)

---

## Controller Best Practices

### Error Handling
- Always use HTTPException with appropriate status codes
- Provide clear, user-friendly error messages
- Log errors for debugging but don't expose internals to users

### Database Sessions
- Always use `db` parameter from `Depends(get_db)`
- Call `db.commit()` after modifications
- Use `db.refresh()` to get updated data after commit
- Handle transaction rollbacks on errors

### Background Tasks
- Use for email sending to avoid blocking responses
- Check if background_tasks is None (for testing)
- Provide sync wrappers for async functions

### Security
- Hash sensitive data (passwords, SSN, EIN)
- Validate user input with Pydantic schemas
- Check user authorization before operations
- Use JWT tokens for authentication

### File Uploads
- Validate file types and sizes
- Use secure filenames (avoid user input directly)
- Store files outside web root when possible
- Reference files in database for tracking

## Related Documentation
- [Main API Documentation](MAIN_API_DOCUMENTATION.md)
- [Authentication Documentation](AUTH_DOCUMENTATION.md)
- [Database Models Documentation](DATABASE_MODELS_DOCUMENTATION.md)
- [Utilities Documentation](UTILITIES_DOCUMENTATION.md)
