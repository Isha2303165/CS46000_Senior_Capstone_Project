# Database Scripts Documentation

## Overview
The `backend/database/scripts/` directory contains utility scripts for managing the database lifecycle: creation, seeding, resetting, and dropping tables.

---

## Scripts Overview

| Script | Purpose | Destructive? |
|--------|---------|--------------|
| `create.py` | Create all tables | No |
| `seed.py` | Populate with sample data | No |
| `reset.py` | Drop and recreate everything | **Yes** |
| `drop.py` | Drop all tables | **Yes** |

---

## create.py

### Purpose
Creates all database tables based on SQLAlchemy models without deleting existing data.

### Usage
```bash
cd backend
python -m database.scripts.create
```

### Implementation
```python
from database.db import engine
from database.models import Base

if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    print("Tables created.")
```

### Behavior
- **Safe to run multiple times**: Won't overwrite existing tables
- **Creates missing tables only**: If a table already exists, it's skipped
- **No data loss**: Existing data remains intact
- **No schema updates**: Doesn't modify existing table structures

### When to Use
- Initial database setup
- After adding new models (creates new tables only)
- When database is empty

### Limitations
- **Doesn't update existing tables**: If you change a model, existing table won't be updated
- **Doesn't handle migrations**: Use Alembic for schema changes in production

---

## seed.py

### Purpose
Populates the database with initial data: test users, billing plans, and sample profiles.

### Usage
```bash
cd backend
python -m database.scripts.seed
```

### Implementation Highlights

#### Entry Point
```python
def init_db():
    db = SessionLocal()
    
    # Seed plans first
    init_staff_plans(db)
    init_client_plans(db)
    
    # Create sample users
    # ...
    
    db.commit()
    db.close()
```

### Seeded Data

#### Test Users

**Staff User:**
```python
Email: capstone@pfw.edu
Password: capstone
Role: 2 (Staff)
Status: Email verified
```

**Staff Profile:**
- Name: Shine K Zaw
- DOB: 00-00-0000 (placeholder)
- SSN: Hashed placeholder
- Phone: 000-000-0000

**Client User:**
```python
Email: client@pfw.edu
Password: clientpass
Role: 1 (Client)
Status: Email verified
```

**Client Profile:**
- Name: Shine's Bistro
- Type: Casual Dining
- Location: Fort Wayne, IN
- Phone: 123-456-7890

#### Staff Billing Plans

**One-Time Plan:**
```python
Plan: "Staff Onboarding Fee"
Price: $30.00
Description: "One-time onboarding charge for new staff members"
Status: Active
```

**Subscription Plan:**
```python
Plan: "Staff Basic Monthly"
Price: $5.95
Frequency: Monthly
Description: "Monthly access subscription for staff members"
Status: Active
```

#### Client Billing Plans

**Subscription Plans:**
```python
# Base Plans
"Restaurant Setup Fee" - Monthly subscription
"Tablet Maintenance Fee" - Monthly subscription

# Addon Plans
"White Glove Access" - Monthly subscription (optional)
```

**One-Time Plans:**
```python
"Tablet and Setup Fee" - One-time charge
"Expedited Setup" - One-time charge (optional)
```

### Key Functions

#### `init_staff_plans(db)`
**Purpose**: Create default staff billing plans if they don't exist.

**Logic:**
```python
if not db.query(models.StaffOneTimePlan).filter_by(plan_name="Staff Onboarding Fee").first():
    # Create plan
```

**Safety:** Checks for existing plans before creating (prevents duplicates).

#### `init_client_plans(db)`
**Purpose**: Create default client billing plans if they don't exist.

**Plans Created:**
1. Restaurant Setup Fee (subscription)
2. Tablet Maintenance Fee (subscription)
3. Tablet and Setup Fee (one-time)
4. Expedited Setup (one-time, optional)
5. White Glove Access (subscription, optional)

### When to Use
- Initial database setup
- After running `reset.py` (automatically included)
- Testing with known data
- When billing plans are missing

### Customization
To add more seed data:
```python
def init_db():
    db = SessionLocal()
    
    # Add your custom seed data
    admin_user = User(
        email="admin@example.com",
        password_hash=utils.pwd_context.hash("adminpass"),
        role=0,
        email_verified=True
    )
    db.add(admin_user)
    
    db.commit()
    db.close()
```

---

## reset.py

### Purpose
**DESTRUCTIVE**: Drops entire schema, recreates all tables, and seeds with initial data.

### Usage
```bash
cd backend
python -m database.scripts.reset
```

### ⚠️ WARNING
**This script:**
- Deletes ALL data in the database
- Drops ALL tables
- Drops the entire PUBLIC schema
- Cannot be undone

**DO NOT run in production without backups!**

### Implementation
```python
if __name__ == "__main__":
    # Drop entire schema (deletes everything)
    with engine.begin() as conn:
        conn.execute(text("DROP SCHEMA public CASCADE"))
        conn.execute(text("CREATE SCHEMA public"))
        conn.execute(text("GRANT ALL ON SCHEMA public TO public"))
    
    # Recreate tables
    Base.metadata.create_all(bind=engine)
    
    # Seed initial data
    seed.init_db()
    
    print("Database reset complete.")
```

### Process Flow
1. **Drop Schema**: Removes `public` schema and all objects within it
2. **Recreate Schema**: Creates fresh `public` schema
3. **Grant Permissions**: Ensures proper access rights
4. **Create Tables**: Builds all tables from models
5. **Seed Data**: Populates with initial users and plans

### When to Use
- Development environment setup
- After major model changes
- Clearing test data
- Starting fresh with clean database

### Database Reset Workflow
```bash
# 1. Backup data (if needed)
pg_dump capstone_db > backup.sql

# 2. Reset database
cd backend
python -m database.scripts.reset

# 3. Verify
python -c "from database.db import engine; print('Success!' if engine else 'Failed')"
```

---

## drop.py

### Purpose
**DESTRUCTIVE**: Drops all tables defined in models.

### Usage
```bash
cd backend
python -m database.scripts.drop
```

### Implementation
```python
from database.db import engine
from database.models import Base

if __name__ == "__main__":
    Base.metadata.drop_all(bind=engine)
    print("Tables dropped.")
```

### Behavior
- Drops all tables defined in `models.py`
- Cascade deletes all dependent objects
- Does NOT drop custom extensions or schemas
- Does NOT drop tables not in `Base.metadata`

### When to Use
- Before running migrations
- Cleaning up test databases
- Removing application tables only

### Difference from reset.py
- `drop.py`: Only drops tables, doesn't recreate or seed
- `reset.py`: Drops schema, recreates tables, and seeds data

---

## Script Execution Flow

### Complete Database Reset
```bash
# Step 1: Drop everything
python -m database.scripts.drop

# Step 2: Create tables
python -m database.scripts.create

# Step 3: Seed data
python -m database.scripts.seed
```

### Or Simply
```bash
# All-in-one reset
python -m database.scripts.reset
```

---

## Common Use Cases

### Initial Setup (New Project)
```bash
cd backend
python -m database.scripts.create
python -m database.scripts.seed
```

### Development Reset (Clean Slate)
```bash
python -m database.scripts.reset
```

### Production Migration (Use Alembic Instead)
```bash
# DON'T use these scripts in production
# Use proper migration tools
alembic upgrade head
```

### Testing Database Setup
```python
# In pytest fixture
def setup_test_db():
    from database.scripts.reset import reset_db
    reset_db()
```

---

## Script Customization

### Adding Custom Seed Data

**Edit `seed.py`:**
```python
def init_db():
    db = SessionLocal()
    
    # Existing seed code...
    
    # Add your custom data
    custom_user = User(
        email="custom@example.com",
        password_hash=utils.pwd_context.hash("password"),
        role=2,
        email_verified=True
    )
    db.add(custom_user)
    
    db.commit()
    db.close()
```

### Creating Custom Scripts

**Example: `backup.py`**
```python
import subprocess
from datetime import datetime

def backup_database():
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"backup_{timestamp}.sql"
    
    subprocess.run([
        "pg_dump",
        "-h", "localhost",
        "-U", "postgres",
        "-d", "capstone_db",
        "-f", filename
    ])
    
    print(f"Backup created: {filename}")

if __name__ == "__main__":
    backup_database()
```

---

## Error Handling

### Common Errors

#### Permission Denied
```
ERROR: must be owner of schema public
```

**Solution:** Run as database owner or grant permissions:
```sql
ALTER SCHEMA public OWNER TO your_user;
```

#### Database Not Found
```
sqlalchemy.exc.OperationalError: database "dbname" does not exist
```

**Solution:** Create database first:
```sql
CREATE DATABASE capstone_db;
```

#### Connection Error
```
sqlalchemy.exc.OperationalError: could not connect to server
```

**Solution:** 
1. Verify PostgreSQL is running
2. Check DB_URL in `.env`
3. Test connection: `psql -U postgres`

---

## Best Practices

### Development Workflow
1. **Use reset.py frequently**: Keep fresh database for testing
2. **Update seed data**: Add test scenarios as you develop
3. **Version control seed data**: Track changes in git
4. **Document seed users**: Keep credentials in README

### Production Workflow
1. **NEVER use reset.py**: Data loss is permanent
2. **Use Alembic migrations**: Track schema changes
3. **Backup before migrations**: Always have rollback option
4. **Test migrations on staging**: Never test on production first

### Safety Tips
```python
# Add confirmation for destructive operations
import os

if __name__ == "__main__":
    env = os.getenv("ENVIRONMENT", "development")
    
    if env == "production":
        response = input("⚠️  Are you sure? Type 'YES' to continue: ")
        if response != "YES":
            print("Aborted.")
            exit()
    
    # Run destructive operation
    reset_database()
```

---

## Migration Tools (Recommended for Production)

### Alembic Setup
```bash
pip install alembic
alembic init alembic
```

### Create Migration
```bash
alembic revision --autogenerate -m "Add profile_image column"
```

### Apply Migration
```bash
alembic upgrade head
```

### Rollback Migration
```bash
alembic downgrade -1
```

---

## Testing Scripts

### Unit Test Example
```python
import pytest
from database.scripts import create, seed, drop

def test_create_tables():
    # Drop existing
    drop.main()
    
    # Create tables
    create.main()
    
    # Verify tables exist
    from database.db import engine
    assert engine.table_names()

def test_seed_data():
    from database.db import SessionLocal
    from database.models import User
    
    seed.init_db()
    
    db = SessionLocal()
    users = db.query(User).all()
    assert len(users) > 0
    db.close()
```

---

## Related Documentation
- [Database Models Documentation](DATABASE_MODELS_DOCUMENTATION.md)
- [Database Connection Documentation](DATABASE_CONNECTION_DOCUMENTATION.md)
- [Main API Documentation](MAIN_API_DOCUMENTATION.md)
