# Database Models Documentation

## Overview
`backend/database/models.py` defines all SQLAlchemy ORM models that map to PostgreSQL database tables. This file creates the schema for the entire application.

## Database Architecture

### Technology Stack
- **Database**: PostgreSQL
- **ORM**: SQLAlchemy 2.0+ (using `Mapped` type hints)
- **Extension**: CITEXT (for case-insensitive text)

## User Roles
- **0**: Admin
- **1**: Client (Restaurant)
- **2**: Staff (Waiter/Server)

## Core Models

### User
**Table**: `users`  
**Purpose**: Central authentication and user management table

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer | Primary Key | Unique user identifier |
| email | CITEXT | Unique, Not Null | Case-insensitive email |
| password_hash | Text | Not Null | Bcrypt hashed password |
| role | SmallInteger | Not Null, 0-2 | User role (admin/client/staff) |
| email_verified | Boolean | Default: false | Email verification status |
| phone_2fa | Text | Nullable | Phone for 2FA |
| tfa_method | Text | Default: 'email' | Preferred 2FA method |
| status | Text | Default: 'active' | Account status |
| created_at | Timestamp(TZ) | Default: now() | Account creation time |
| last_login_at | Timestamp(TZ) | Default: now() | Last successful login |
| updated_at | Timestamp(TZ) | Default: now() | Last update time |

**Relationships:**
- One-to-one with `StaffProfile` (cascade delete)
- One-to-one with `ClientProfile` (cascade delete)

**Constraints:**
- `role IN (0, 1, 2)`
- `tfa_method IN ('email', 'sms')`

---

## Staff Domain Models

### StaffProfile
**Table**: `staff_profiles`  
**Purpose**: Extended profile information for staff members

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| staff_id | Integer | PK, FK(users.id) | References user |
| first_name | Text | Not Null | First name |
| middle_name | Text | Nullable | Middle name |
| last_name | Text | Not Null | Last name |
| date_of_birth | Text | Not Null | Date of birth |
| SSN_hashed | Text | Not Null | Hashed SSN (SHA-256) |
| phone | Text | Not Null | Contact phone |
| short_bio | Text | Nullable | Staff biography |
| has_white_glove_certification | Boolean | Default: false | Certification status |
| white_glove_certified_date | Timestamp(TZ) | Nullable | Certification date |
| updated_at | Timestamp(TZ) | Default: now() | Last update |

**Relationships:**
- One-to-many with `StaffSubscription`
- One-to-many with `StaffOneTimeFee`
- One-to-many with `StaffEmergencyContact`
- One-to-many with `StaffDocument`
- One-to-many with `StaffLiquorLicense`

### StaffSubscriptionPlan
**Table**: `staff_subscription_plans`  
**Purpose**: Reference table for available recurring staff subscription plans

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer | Primary Key | Plan identifier |
| plan_name | Text | Unique, Not Null | Plan name |
| price | Numeric(10,2) | Not Null | Plan price |
| billing_frequency | Text | Default: 'monthly' | Billing cycle |
| description | Text | Nullable | Plan description |
| is_active | Boolean | Default: true | Plan availability |
| created_at | Timestamp(TZ) | Default: now() | Creation time |
| updated_at | Timestamp(TZ) | Default: now() | Last update |

**Constraints:**
- `billing_frequency IN ('monthly', 'yearly')`

**Default Plan:**
- "Staff Basic Monthly" - $5.95/month

### StaffOneTimePlan
**Table**: `staff_one_time_plans`  
**Purpose**: Reference table for one-time fee plans

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer | Primary Key | Plan identifier |
| plan_name | Text | Unique, Not Null | Plan name |
| price | Numeric(10,2) | Not Null | Fee amount |
| description | Text | Nullable | Plan description |
| is_active | Boolean | Default: true | Plan availability |
| created_at | Timestamp(TZ) | Default: now() | Creation time |
| updated_at | Timestamp(TZ) | Default: now() | Last update |

**Default Plan:**
- "Staff Onboarding Fee" - $30.00

### StaffSubscription
**Table**: `staff_subscriptions`  
**Purpose**: Track active subscriptions per staff member

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer | Primary Key | Subscription ID |
| staff_id | Integer | FK(staff_profiles.staff_id) | Staff member |
| plan_id | Integer | FK(staff_subscription_plans.id) | Plan reference |
| status | Text | Default: 'active' | Subscription status |
| start_date | Timestamp(TZ) | Default: now() | Subscription start |
| end_date | Timestamp(TZ) | Nullable | Subscription end |
| next_billing_date | Timestamp(TZ) | Not Null | Next billing |
| created_at | Timestamp(TZ) | Default: now() | Creation time |
| updated_at | Timestamp(TZ) | Default: now() | Last update |

**Constraints:**
- `status IN ('active', 'inactive', 'cancelled')`

### StaffOneTimeFee
**Table**: `staff_one_time_fees`  
**Purpose**: Track one-time charges for staff members

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer | Primary Key | Fee ID |
| staff_id | Integer | FK(staff_profiles.staff_id) | Staff member |
| plan_id | Integer | FK(staff_one_time_plans.id) | Plan reference |
| amount | Numeric(10,2) | Not Null | Charge amount |
| paid_date | Timestamp(TZ) | Default: now() | Payment date |
| status | Text | Default: 'paid' | Payment status |
| created_at | Timestamp(TZ) | Default: now() | Creation time |

**Constraints:**
- `status IN ('paid', 'pending', 'refunded')`

### StaffEmergencyContact
**Table**: `staff_emergency_contacts`  
**Purpose**: Store emergency contact information

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer | Primary Key | Contact ID |
| staff_id | Integer | FK(staff_profiles.staff_id) | Staff member |
| name | Text | Not Null | Contact name |
| relation | Text | Not Null | Relationship type |
| phone | Text | Not Null | Contact phone |
| email | Text | Nullable | Contact email |
| address | Text | Not Null | Contact address |
| city | Text | Not Null | City |
| state | Text | Not Null | State |
| is_primary | Boolean | Default: true | Primary contact flag |
| created_at | Timestamp(TZ) | Default: now() | Creation time |
| updated_at | Timestamp(TZ) | Default: now() | Last update |

### StaffDocument
**Table**: `staff_documents`  
**Purpose**: Store file references for staff documents

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer | Primary Key | Document ID |
| staff_id | Integer | FK(staff_profiles.staff_id) | Staff member |
| document_type | Text | Not Null | Document category |
| file_path | Text | Not Null | File storage path |
| status | Text | Default: 'pending' | Verification status |
| uploaded_at | Timestamp(TZ) | Default: now() | Upload time |
| updated_at | Timestamp(TZ) | Default: now() | Last update |

**Constraints:**
- `document_type IN ('gov_id', 'resume', 'liquor_license_doc', 'profile_picture')`
- `status IN ('pending', 'approved', 'rejected', 'expired')`

### StaffLiquorLicense
**Table**: `staff_liquor_licenses`  
**Purpose**: Track liquor license details

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer | Primary Key | License ID |
| staff_id | Integer | FK(staff_profiles.staff_id) | Staff member |
| license_number | Text | Not Null | License number |
| license_state | Text | Not Null | Issuing state |
| expiration_date | Timestamp(TZ) | Not Null | Expiration date |
| document_id | Integer | FK(staff_documents.id) | Document reference |
| status | Text | Default: 'active' | License status |
| created_at | Timestamp(TZ) | Default: now() | Creation time |
| updated_at | Timestamp(TZ) | Default: now() | Last update |

**Constraints:**
- `status IN ('active', 'expired')`

---

## Client Domain Models

### ClientProfile
**Table**: `client_profiles`  
**Purpose**: Extended profile information for restaurants/clients

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| client_id | Integer | PK, FK(users.id) | References user |
| name | Text | Not Null | Restaurant name |
| EIN_hashed | Text | Not Null | Hashed EIN (SHA-256) |
| restaurant_type | Text | Not Null | Type of restaurant |
| phone | Text | Not Null | Contact phone |
| website_url | Text | Nullable | Website URL |
| address_line1 | Text | Not Null | Address line 1 |
| address_line2 | Text | Nullable | Address line 2 |
| city | Text | Not Null | City |
| state | Text | Not Null | State |
| zipcode | Integer | Not Null | ZIP code |
| updated_at | Timestamp(TZ) | Default: now() | Last update |

**Relationships:**
- One-to-many with `ClientManager`
- One-to-many with `BusinessHours`
- One-to-many with `ClientSubscription`
- One-to-many with `Tablet`
- One-to-many with `ClientOneTimeFee`
- One-to-many with `ClientDocument`

### ClientManager
**Table**: `client_managers`  
**Purpose**: Store additional managers for restaurant accounts

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer | Primary Key | Manager ID |
| client_id | Integer | FK(client_profiles.client_id) | Restaurant |
| first_name | Text | Not Null | First name |
| last_name | Text | Not Null | Last name |
| email | CITEXT | Not Null | Manager email |
| phone | Text | Not Null | Contact phone |

**Constraints:**
- Unique constraint on (client_id, email)

### BusinessHours
**Table**: `business_hours`  
**Purpose**: Store daily business hours per restaurant

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer | Primary Key | Hours ID |
| client_id | Integer | FK(client_profiles.client_id) | Restaurant |
| day_of_week | SmallInteger | Not Null | Day (0=Sunday, 6=Saturday) |

**Constraints:**
- `day_of_week BETWEEN 0 AND 6`

**Relationships:**
- One-to-many with `BusinessPeriod`

### BusinessPeriod
**Table**: `business_periods`  
**Purpose**: Store open/close times for each business hours entry

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer | Primary Key | Period ID |
| hours_id | Integer | FK(business_hours.id) | Business hours |
| open_time | Time | Not Null | Opening time |
| close_time | Time | Not Null | Closing time |

**Constraints:**
- `open_time <> close_time`

### ClientSubscriptionPlan
**Table**: `client_subscription_plans`  
**Purpose**: Reference table for available client subscription plans

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer | Primary Key | Plan ID |
| plan_name | Text | Unique, Not Null | Plan name |
| plan_type | Text | Not Null | Plan category |
| price | Numeric(10,2) | Not Null | Plan price |
| billing_frequency | Text | Default: 'monthly' | Billing cycle |
| description | Text | Nullable | Plan description |
| is_active | Boolean | Default: true | Plan availability |
| created_at | Timestamp(TZ) | Default: now() | Creation time |
| updated_at | Timestamp(TZ) | Default: now() | Last update |

**Constraints:**
- `plan_type IN ('base', 'addon')`
- `billing_frequency IN ('monthly', 'yearly')`

**Default Plans:**
- "Restaurant Setup Fee"
- "Tablet Maintenance Fee"
- "White Glove Access" (optional addon)

### ClientOneTimePlan
**Table**: `client_one_time_plans`  
**Purpose**: Reference table for one-time client fees

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer | Primary Key | Plan ID |
| plan_name | Text | Unique, Not Null | Plan name |
| price | Numeric(10,2) | Not Null | Fee amount |
| description | Text | Nullable | Plan description |
| is_active | Boolean | Default: true | Plan availability |
| created_at | Timestamp(TZ) | Default: now() | Creation time |
| updated_at | Timestamp(TZ) | Default: now() | Last update |

**Default Plans:**
- "Tablet and Setup Fee"
- "Expedited Setup" (optional)

### ClientSubscription
**Table**: `client_subscriptions`  
**Purpose**: Track active subscriptions per client

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer | Primary Key | Subscription ID |
| client_id | Integer | FK(client_profiles.client_id) | Restaurant |
| plan_id | Integer | FK(client_subscription_plans.id) | Plan reference |
| status | Text | Default: 'active' | Subscription status |
| start_date | Timestamp(TZ) | Default: now() | Subscription start |
| end_date | Timestamp(TZ) | Nullable | Subscription end |
| next_billing_date | Timestamp(TZ) | Not Null | Next billing |
| created_at | Timestamp(TZ) | Default: now() | Creation time |
| updated_at | Timestamp(TZ) | Default: now() | Last update |

**Constraints:**
- `status IN ('active', 'cancelled', 'past_due', 'trial')`

### Tablet
**Table**: `tablets`  
**Purpose**: Track physical tablets assigned to restaurants

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer | Primary Key | Tablet ID |
| client_id | Integer | FK(client_profiles.client_id) | Restaurant |
| serial_number | Text | Unique, Not Null | Device serial |
| purchase_date | Timestamp(TZ) | Default: now() | Purchase date |
| status | Text | Default: 'active' | Tablet status |
| has_maintenance_subscription | Boolean | Default: false | Maintenance plan |
| maintenance_start_date | Timestamp(TZ) | Nullable | Maintenance start |
| created_at | Timestamp(TZ) | Default: now() | Creation time |
| updated_at | Timestamp(TZ) | Default: now() | Last update |

**Constraints:**
- `status IN ('active', 'inactive', 'maintenance', 'retired')`

### ClientOneTimeFee
**Table**: `client_one_time_fees`  
**Purpose**: Track one-time charges for clients

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer | Primary Key | Fee ID |
| client_id | Integer | FK(client_profiles.client_id) | Restaurant |
| plan_id | Integer | FK(client_one_time_plans.id) | Plan reference |
| amount | Numeric(10,2) | Not Null | Charge amount |
| paid_date | Timestamp(TZ) | Default: now() | Payment date |
| status | Text | Default: 'paid' | Payment status |
| created_at | Timestamp(TZ) | Default: now() | Creation time |

**Constraints:**
- `status IN ('paid', 'pending', 'refunded')`

### ClientDocument
**Table**: `client_documents`  
**Purpose**: Store file references for client documents

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| id | Integer | Primary Key | Document ID |
| client_id | Integer | FK(client_profiles.client_id) | Restaurant |
| document_type | Text | Not Null | Document category |
| file_path | Text | Not Null | File storage path |
| status | Text | Default: 'pending' | Verification status |
| uploaded_at | Timestamp(TZ) | Default: now() | Upload time |
| updated_at | Timestamp(TZ) | Default: now() | Last update |

**Constraints:**
- `document_type IN ('logo', 'photo', 'floor_plan', 'other')`
- `status IN ('pending', 'approved', 'rejected')`

---

## Database Operations

### Creating Tables
```bash
cd backend
python -m database.scripts.create
```

### Resetting Database
```bash
cd backend
python -m database.scripts.reset
```
**Warning**: This drops all tables and data, then recreates and seeds them.

### Seeding Data
```bash
cd backend
python -m database.scripts.seed
```

## Entity Relationships

### User → Staff/Client (1:1)
Each user can be either staff OR client, not both.

### Staff → Documents (1:N)
Staff can have multiple documents (ID, resume, license, profile picture).

### Client → Subscriptions (1:N)
Clients can have multiple active subscriptions (base + addons).

### Profiles → Billing (1:N)
Both staff and clients have separate billing relationships.

## Security Considerations

### Hashed Fields
- **Passwords**: Bcrypt hashing (handled by utils.py)
- **SSN**: SHA-256 hashing
- **EIN**: SHA-256 hashing

### Cascade Deletes
All child records are automatically deleted when parent user is deleted:
- StaffProfile → Subscriptions, Documents, etc.
- ClientProfile → Managers, Subscriptions, etc.

## Database Schema Visualization
Refer to `DB_ERD.svg` for a visual representation of the database schema.

## Related Documentation
- [Database Connection Documentation](DATABASE_CONNECTION_DOCUMENTATION.md)
- [Database Schemas Documentation](DATABASE_SCHEMAS_DOCUMENTATION.md)
- [Database Scripts Documentation](DATABASE_SCRIPTS_DOCUMENTATION.md)
