# Authentication Documentation

## Overview
`backend/app/Controllers/auth.py` handles all authentication-related operations including login, two-factor authentication (2FA), password management, and user session management.

## Router Configuration
- **Prefix**: `/auth`
- **Tags**: `["Authentication"]`
- **Security**: HTTPBearer (JWT tokens)

## Authentication Flow

### 1. Login Flow
```
POST /auth/login
```

**Process:**
1. User provides email and password
2. System validates credentials
3. If email not verified, sends verification email
4. If email verified, returns available 2FA methods
5. User selects 2FA method
6. System sends 2FA code
7. User verifies code
8. System issues access token

### 2. Email Verification Flow
1. User signs up
2. System sends verification email with JWT token
3. User clicks link in email
4. Token is verified
5. User's `email_verified` status set to `true`

### 3. Two-Factor Authentication Flow
1. After successful credential verification
2. System generates 6-digit code
3. Code sent via email or SMS (based on user preference)
4. User enters code within 5 minutes
5. System verifies code and issues access token

## Core Functions

### `get_current_user(token, db)`
**Purpose**: Dependency function to extract and validate the current authenticated user from JWT token.

**Parameters:**
- `token`: HTTPBearer credentials containing JWT
- `db`: Database session

**Returns:** User object

**Raises:**
- `401 Unauthorized`: Invalid or expired token

**Usage:**
```python
@app.get("/protected")
def protected_route(current_user: User = Depends(get_current_user)):
    return {"user_id": current_user.id}
```

### `authenticate_user(db, email, password)`
**Purpose**: Verify user credentials.

**Parameters:**
- `db`: Database session
- `email`: User's email
- `password`: Plain text password

**Returns:** User object if valid, None otherwise

## API Endpoints

### Login
```
POST /auth/login
```

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "SecurePass123!"
}
```

**Responses:**

**Case 1: Email Not Verified**
```json
{
  "email_verification_required": true,
  "email": "user@example.com",
  "message": "Please verify your email address..."
}
```

**Case 2: Email Verified - 2FA Method Selection**
```json
{
  "2fa_method_selection_required": true,
  "email": "user@example.com",
  "available_methods": ["email", "sms"],
  "phone_masked": "5678"
}
```

### Send 2FA Code
```
POST /auth/send-2fa-code
```

**Request Body:**
```json
{
  "email": "user@example.com",
  "method": "email",
  "phone_number": "+15551234567"
}
```

**Response:**
```json
{
  "2fa_required": true,
  "email": "user@example.com",
  "method": "email",
  "phone_masked": "4567",
  "message": "Verification code sent via email"
}
```

**Notes:**
- Code expires in 5 minutes
- Phone number sources (in order): waiter_profile, restaurant_profile, phone_2fa field, request body
- SMS requires valid phone number in E.164 format

### Verify 2FA Code
```
POST /auth/verify-2fa
```

**Request Body:**
```json
{
  "email": "user@example.com",
  "code": "123456"
}
```

**Success Response:**
```json
{
  "access_token": "eyJhbGc...",
  "token_type": "bearer",
  "role": 2,
  "status": "active"
}
```

**Error Responses:**
- `400 Bad Request`: Invalid or expired code
- `404 Not Found`: User not found

### Forgot Password
```
POST /auth/forgot-password
```

**Request Body:**
```json
{
  "email": "user@example.com"
}
```

**Response:**
```json
{
  "message": "If the email exists, a password reset link has been sent."
}
```

**Notes:**
- Always returns success to prevent email enumeration
- Reset token expires in 1 hour

### Reset Password
```
POST /auth/reset-password
```

**Request Body:**
```json
{
  "token": "reset_token_from_email",
  "new_password": "NewSecurePass123!"
}
```

**Response:**
```json
{
  "message": "Password has been reset successfully"
}
```

### Change Password
```
POST /auth/change-password
Authentication Required: Yes
```

**Request Body:**
```json
{
  "current_password": "OldPass123!",
  "new_password": "NewPass123!"
}
```

**Response:**
```json
{
  "message": "Password changed successfully"
}
```

**Error:**
- `400 Bad Request`: Current password is incorrect

### Resend Verification Email
```
POST /auth/resend-verification
```

**Request Body:**
```json
{
  "email": "user@example.com"
}
```

**Response:**
```json
{
  "message": "If the email exists and is not verified, a verification link has been sent."
}
```

### Update 2FA Method
```
POST /auth/update-2fa-method
Authentication Required: Yes
```

**Request Body:**
```json
{
  "method": "sms",
  "phone_number": "+15551234567"
}
```

**Response:**
```json
{
  "message": "2FA method updated to sms",
  "method": "sms",
  "phone_masked": "4567"
}
```

**Validation:**
- Method must be 'email' or 'sms'
- Phone number required for SMS
- Phone number must be valid E.164 format

### Get 2FA Settings
```
GET /auth/2fa-settings
Authentication Required: Yes
```

**Response:**
```json
{
  "method": "email",
  "phone_configured": true,
  "phone_masked": "5678"
}
```

### Get Current User Info
```
GET /auth/me
Authentication Required: Yes
```

**Response:**
```json
{
  "id": 123,
  "email": "user@example.com",
  "role": 2,
  "status": "active",
  "email_verified": true
}
```

## In-Memory 2FA Code Storage

**Structure:**
```python
two_fa_store = {
  "user@example.com": {
    "code": "123456",
    "expires_at": datetime(2025, 12, 4, 15, 30, 0)
  }
}
```

**Important Notes:**
- **NOT suitable for production** - codes are lost on server restart
- Replace with Redis, Memcached, or database storage for production
- Codes expire after 5 minutes
- Used codes are immediately deleted

## Security Considerations

### Password Requirements
Passwords are validated by `schemas.PasswordValidator`:
- Minimum 8 characters
- Maximum 20 characters
- At least one uppercase letter
- At least one lowercase letter
- At least one digit
- At least one special character (@$!%*?&#)

### Token Security
- JWT tokens include user email, role, and status
- Access tokens expire after 60 minutes (configurable in utils.py)
- Verification tokens expire after 24 hours
- Password reset tokens expire after 1 hour

### Rate Limiting
**Not Currently Implemented** - Consider adding:
- Login attempt limits
- 2FA code generation limits
- Password reset request limits

## Integration with Other Controllers

### Email Controller
- `send_verification_email_sync`: Sends email verification links
- `send_2fa_code_sync`: Sends 2FA codes via email
- `send_password_reset_email_sync`: Sends password reset links

### SMS Controller
- `send_2fa_sms_sync`: Sends 2FA codes via SMS
- `format_phone_number`: Converts to E.164 format
- `validate_phone_number`: Validates phone number format

## Error Handling

All endpoints follow REST conventions:
- `400 Bad Request`: Invalid input or business logic errors
- `401 Unauthorized`: Authentication failures
- `404 Not Found`: User not found
- `500 Internal Server Error`: Unexpected errors

## Related Documentation
- [Utilities Documentation](UTILITIES_DOCUMENTATION.md)
- [Email Controller Documentation](EMAIL_CONTROLLER_DOCUMENTATION.md)
- [SMS Controller Documentation](SMS_CONTROLLER_DOCUMENTATION.md)
