# Staff Profile Activation System - Visual Flow

## System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     STAFF REGISTRATION FLOW                      │
└─────────────────────────────────────────────────────────────────┘

    Staff submits signup form
            │
            ▼
    ┌─────────────────┐
    │  POST           │
    │  /sign_up_staff │
    └────────┬────────┘
             │
             ▼
    ┌─────────────────────────────────────┐
    │  staff_controller.sign_up_staff()   │
    │                                      │
    │  Creates:                            │
    │  • User (status: "pending")         │
    │  • StaffProfile                     │
    │  • StaffOneTimeFee (pending)        │
    │  • StaffSubscription (active)       │
    └────────┬────────────────────────────┘
             │
             ▼
    Email verification sent
    Staff redirected to payment


┌─────────────────────────────────────────────────────────────────┐
│                   PAYMENT & ACTIVATION FLOW                      │
└─────────────────────────────────────────────────────────────────┘

    Payment Gateway (Stripe/etc)
            │
            ▼
    Payment successful
            │
            ├──────────────────┬───────────────────┐
            │                  │                   │
            ▼                  ▼                   ▼
    ┌──────────────┐  ┌─────────────────┐  ┌─────────────────┐
    │   Webhook    │  │   API Endpoint  │  │  Direct Call    │
    │   Handler    │  │   (with auth)   │  │  (internal)     │
    └──────┬───────┘  └────────┬────────┘  └────────┬────────┘
           │                   │                     │
           └───────────────────┴─────────────────────┘
                               │
                               ▼
           ┌─────────────────────────────────────────┐
           │  process_subscription_payment()         │
           │  • Updates onboarding fee → "paid"      │
           │  • Calls activation function            │
           └──────────────┬──────────────────────────┘
                          │
                          ▼
           ┌─────────────────────────────────────────┐
           │  activate_staff_profile_on_subscription()│
           │                                          │
           │  Validates:                              │
           │  ✓ Staff exists                          │
           │  ✓ Has staff role                        │
           │  ✓ Has active subscription               │
           │                                          │
           │  Updates:                                │
           │  • User.status → "active"                │
           │  • OneTimeFee.status → "paid"            │
           │  • User.updated_at → now()               │
           └──────────────┬───────────────────────────┘
                          │
                          ▼
               ┌─────────────────────┐
               │  Profile Activated  │
               │  Staff can now      │
               │  access platform    │
               └─────────────────────┘


┌─────────────────────────────────────────────────────────────────┐
│                      DATABASE STATE CHANGES                      │
└─────────────────────────────────────────────────────────────────┘

BEFORE ACTIVATION:
┌──────────────┬──────────────────┐
│ Table        │ Status           │
├──────────────┼──────────────────┤
│ users        │ status: pending  │
│ staff_one_   │ status: pending  │
│   time_fees  │                  │
│ staff_sub-   │ status: active   │
│   scriptions │                  │
└──────────────┴──────────────────┘

AFTER ACTIVATION:
┌──────────────┬──────────────────┐
│ Table        │ Status           │
├──────────────┼──────────────────┤
│ users        │ status: active ✅│
│ staff_one_   │ status: paid ✅  │
│   time_fees  │ paid_date: now() │
│ staff_sub-   │ status: active   │
│   scriptions │ (unchanged)      │
└──────────────┴──────────────────┘


┌─────────────────────────────────────────────────────────────────┐
│                      API ENDPOINT DETAILS                        │
└─────────────────────────────────────────────────────────────────┘

POST /staff/activate_profile/{staff_id}

Authentication: Required (JWT Bearer Token)
Authorization:
  • Staff (role=2): Can activate only their own profile
  • Admin (role=0): Can activate any profile
  • Client (role=1): Access denied

Request:
  Headers:
    Authorization: Bearer {jwt_token}
  Path Parameters:
    staff_id: integer

Response (200 OK):
  {
    "message": "Staff profile activated successfully",
    "staff_id": 123,
    "user_status": "active",
    "subscription_status": "active",
    "onboarding_fee_paid": true
  }

Errors:
  400: No active subscription found
  403: Not authorized to activate this profile
  404: Staff member not found


┌─────────────────────────────────────────────────────────────────┐
│                    INTEGRATION PATTERNS                          │
└─────────────────────────────────────────────────────────────────┘

PATTERN 1: Direct API Call (Frontend)
┌────────────┐    POST /staff/activate_profile/123    ┌─────────┐
│  Frontend  │────────────────────────────────────────>│ Backend │
│  (React)   │<────────────────────────────────────────│ (API)   │
└────────────┘   Response: {status: "active"}          └─────────┘

PATTERN 2: Webhook Integration (Stripe)
┌────────────┐   payment.success   ┌──────────┐   webhook   ┌─────────┐
│  Payment   │────────────────────>│  Stripe  │────────────>│ Backend │
│   Form     │                     │  Server  │             │ Webhook │
└────────────┘                     └──────────┘             └────┬────┘
                                                                 │
                                                                 ▼
                                                    process_subscription_payment()
                                                                 │
                                                                 ▼
                                                    Staff Profile Activated

PATTERN 3: Admin Dashboard
┌────────────┐   Click "Activate"   ┌─────────────┐   API Call   ┌─────────┐
│   Admin    │────────────────────> │   Admin     │─────────────>│ Backend │
│   User     │                      │  Dashboard  │              │   API   │
└────────────┘                      └─────────────┘              └─────────┘


┌─────────────────────────────────────────────────────────────────┐
│                      SECURITY LAYERS                             │
└─────────────────────────────────────────────────────────────────┘

Layer 1: Authentication
  └─> JWT Token Verification
      └─> Must be logged in user

Layer 2: Authorization  
  └─> Role Check (Admin or Staff)
      └─> Staff ID Match (if not admin)

Layer 3: Business Logic Validation
  └─> Active Subscription Required
      └─> Staff Profile Must Exist
          └─> Correct User Role (staff=2)

Layer 4: Data Integrity
  └─> Database Transaction
      └─> Atomic Updates
          └─> Rollback on Failure


┌─────────────────────────────────────────────────────────────────┐
│                       ERROR HANDLING                             │
└─────────────────────────────────────────────────────────────────┘

                    Error Occurs
                         │
         ┌───────────────┼───────────────┐
         ▼               ▼               ▼
   ┌─────────┐    ┌─────────┐    ┌─────────┐
   │   404   │    │   400   │    │   403   │
   │   Not   │    │  Invalid│    │  Not    │
   │  Found  │    │  Request│    │ Allowed │
   └────┬────┘    └────┬────┘    └────┬────┘
        │              │              │
        ▼              ▼              ▼
   Staff not     No active      Wrong user
   exists        subscription   trying to
                                activate
        │              │              │
        └──────────────┴──────────────┘
                       │
                       ▼
              HTTPException raised
                       │
                       ▼
              JSON error response
                       │
                       ▼
              Frontend displays error


┌─────────────────────────────────────────────────────────────────┐
│                    SUCCESS RESPONSE FLOW                         │
└─────────────────────────────────────────────────────────────────┘

  Validation Passes
         │
         ▼
  Update Database
    • User status
    • Fee status
    • Timestamps
         │
         ▼
  Commit Transaction
         │
         ▼
  Build Response
    {
      message: "...",
      staff_id: 123,
      user_status: "active",
      ...
    }
         │
         ▼
  Return to Client
         │
         ▼
  ┌─────────────────┐
  │ Frontend shows  │
  │ success message │
  │ Redirects to    │
  │ dashboard       │
  └─────────────────┘
