# Database Schemas Documentation

## Overview
`backend/database/schemas.py` defines Pydantic models for request/response validation. These schemas ensure data integrity before it reaches the database and provide automatic API documentation.

## Purpose of Schemas

### Input Validation
- Validate request data before processing
- Enforce data types, formats, and constraints
- Provide automatic error messages for invalid input

### API Documentation
- FastAPI automatically generates OpenAPI/Swagger docs from schemas
- Schemas define the expected request/response structure
- Examples appear in interactive API documentation

### Type Safety
- Enable IDE autocomplete and type checking
- Catch type errors during development
- Improve code maintainability

---

## Base Validators

### PasswordValidator
**Purpose**: Enforce strong password requirements for all user types.

**Requirements:**
- Minimum 8 characters
- Maximum 20 characters
- At least one uppercase letter
- At least one lowercase letter
- At least one digit
- At least one special character: `@$!%*?&#`

**Usage:**
```python
class PasswordValidator(BaseModel):
    password: str
    
    @validator("password")
    def strong_password(cls, v):
        # Validation logic
```

**Example Valid Passwords:**
- `SecurePass123!`
- `MyP@ssw0rd`
- `Test1234@abc`

**Example Invalid Passwords:**
- `short1!` - Too short
- `nouppercase123!` - No uppercase
- `NOLOWERCASE123!` - No lowercase
- `NoNumbers!` - No digits
- `NoSpecial123` - No special character

---

## Sign Up Schemas

### StaffSignUp
**Purpose**: Validate staff member registration data.

**Inherits**: PasswordValidator

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| email | EmailStr | Valid email | Staff email address |
| password | str | Strong password | Account password |
| first_name | str | 1-20 chars | First name |
| middle_name | str \| None | Optional | Middle name |
| last_name | str | 1-20 chars | Last name |
| date_of_birth | date | Valid date | Birth date |
| ssn | str | 9-15 chars | Social Security Number |
| phone | str | 7-15 chars | Phone number |

**Example Request:**
```json
{
  "email": "john.doe@example.com",
  "password": "SecurePass123!",
  "first_name": "John",
  "middle_name": "Andrew",
  "last_name": "Doe",
  "date_of_birth": "1990-05-15",
  "ssn": "123-45-6789",
  "phone": "555-123-4567"
}
```

**Validation Notes:**
- `middle_name` can be null or omitted
- `date_of_birth` must be valid date format (YYYY-MM-DD)
- SSN format is flexible (will be hashed before storage)
- Phone format is flexible (will be formatted/validated separately)

### ClientSignUp
**Purpose**: Validate restaurant/client registration data.

**Inherits**: PasswordValidator

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| email | EmailStr | Valid email | Client email |
| password | str | Strong password | Account password |
| EIN_hashed | str | 5-100 chars | Employer ID Number |
| name | str | 1-20 chars | Restaurant name |
| restaurant_type | str | 1-20 chars | Type of restaurant |
| phone | str | 7-15 chars | Contact phone |
| website_url | str \| None | Optional | Website URL |
| address_line1 | str | 5-100 chars | Street address |
| address_line2 | str \| None | Optional | Address line 2 |
| city | str | 2-20 chars | City |
| state | str | 2-20 chars | State |
| zipcode | int | Integer | ZIP code |
| expedited | bool | Default: False | Expedited setup |
| white_glove | bool | Default: False | White glove service |

**Example Request:**
```json
{
  "email": "manager@restaurant.com",
  "password": "SecurePass123!",
  "EIN_hashed": "12-3456789",
  "name": "Joe's Bistro",
  "restaurant_type": "Fine Dining",
  "phone": "555-987-6543",
  "website_url": "https://joesbistro.com",
  "address_line1": "123 Main Street",
  "address_line2": "Suite 100",
  "city": "Fort Wayne",
  "state": "Indiana",
  "zipcode": 46805,
  "expedited": false,
  "white_glove": true
}
```

**Validation Notes:**
- `restaurant_type` should ideally be a dropdown in frontend
- `website_url`, `address_line2` are optional
- `expedited` and `white_glove` affect billing
- EIN will be hashed before database storage

---

## Authentication Schemas

### LoginRequest
**Purpose**: Validate login credentials.

**Fields:**
| Field | Type | Description |
|-------|------|-------------|
| email | str | User email |
| password | str | User password |

**Example:**
```json
{
  "email": "user@example.com",
  "password": "MyPassword123!"
}
```

### TokenResponse
**Purpose**: Structure for JWT token responses.

**Fields:**
| Field | Type | Default | Description |
|-------|------|---------|-------------|
| access_token | str | - | JWT token |
| token_type | str | "bearer" | Token type |

**Example:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer"
}
```

---

## Email Schema

### EmailSchema
**Purpose**: Validate email addresses for email operations.

**Fields:**
| Field | Type | Description |
|-------|------|-------------|
| email | List[EmailStr] | List of email addresses |

**Example:**
```json
{
  "email": ["user1@example.com", "user2@example.com"]
}
```

**Usage:**
```python
EmailSchema(email=["john@example.com"])
```

**Note:** Supports multiple recipients for bulk emails.

---

## Profile Schemas

### StaffProfileResponse
**Purpose**: Structure for staff profile data in responses.

**Fields:**
| Field | Type | Description |
|-------|------|-------------|
| staff_id | int | Staff member ID |
| first_name | str | First name |
| middle_name | str \| None | Middle name |
| last_name | str | Last name |
| date_of_birth | str | Birth date |
| phone | str | Phone number |
| profile_image | str \| None | Image URL |
| liquor_license_path | str \| None | License document URL |
| has_white_glove_certification | bool | Certification status |
| white_glove_certified_date | str \| None | Certification date |
| email | str | Email address |
| status | str | Account status |

**Example:**
```json
{
  "staff_id": 123,
  "first_name": "John",
  "middle_name": "A",
  "last_name": "Doe",
  "date_of_birth": "1990-01-01",
  "phone": "555-1234567",
  "profile_image": "/static/profile_images/123.jpg",
  "liquor_license_path": "/static/licenses/123.pdf",
  "has_white_glove_certification": false,
  "white_glove_certified_date": null,
  "email": "john@example.com",
  "status": "active"
}
```

**Config:**
```python
class Config:
    from_attributes = True  # Allows ORM object conversion
```

### StaffProfileUpdate
**Purpose**: Validate partial staff profile updates.

**Fields:**
| Field | Type | Constraints | Description |
|-------|------|-------------|-------------|
| first_name | str \| None | 1-50 chars | First name |
| middle_name | str \| None | 1-50 chars | Middle name |
| last_name | str \| None | 1-50 chars | Last name |
| phone | str \| None | 7-15 chars | Phone number |
| date_of_birth | str \| None | - | Birth date |

**Example:**
```json
{
  "first_name": "Jonathan",
  "phone": "555-999-8888"
}
```

**Note:** All fields are optional for partial updates.

---

## Schema Validation Features

### Pydantic Field Validation

#### Using Annotated
```python
first_name: Annotated[str, Field(min_length=1, max_length=20)]
```

**Benefits:**
- Automatic validation
- Clear error messages
- Type hints for IDEs

#### Custom Validators
```python
@validator("password")
def strong_password(cls, v):
    if len(v) < 8:
        raise ValueError("Password too short")
    return v
```

### Automatic Error Responses

When validation fails, FastAPI returns:
```json
{
  "detail": [
    {
      "loc": ["body", "email"],
      "msg": "value is not a valid email address",
      "type": "value_error.email"
    }
  ]
}
```

---

## Schema Usage Patterns

### In Route Definitions
```python
@app.post("/sign_up_staff")
def sign_up_staff_route(
    staff: StaffSignUp,  # Automatic validation
    db: Session = Depends(get_db)
):
    # staff is validated and typed
    result = staff_controller.sign_up_staff(staff, db)
    return result
```

### In Responses
```python
@app.get("/profile/staff/{user_id}", response_model=StaffProfileResponse)
def get_staff_profile(user_id: int, db: Session = Depends(get_db)):
    # Response automatically validated and serialized
    return staff_profile
```

### Manual Validation
```python
# Convert dict to schema
data = {"email": ["test@example.com"]}
email_schema = EmailSchema(**data)

# Access validated data
email_schema.email  # ["test@example.com"]
```

---

## Best Practices

### Schema Design
1. **Use specific types**: `EmailStr`, `date`, not just `str`
2. **Add constraints**: `min_length`, `max_length`, `regex`
3. **Make optional fields explicit**: Use `str | None` or `Optional[str]`
4. **Use validators for complex rules**: Custom validation logic
5. **Inherit common validators**: Don't repeat password validation

### Error Messages
1. **Provide clear descriptions**: Help users understand requirements
2. **Use examples in docstrings**: Show valid input
3. **Return structured errors**: FastAPI does this automatically

### Performance
1. **Don't over-validate**: Trust database constraints for some checks
2. **Cache compiled validators**: Pydantic does this automatically
3. **Use response_model**: Reduces response payload size

### Security
1. **Never return passwords**: Even hashed ones
2. **Validate all user input**: Always use schemas for requests
3. **Use strict types**: Prevent type coercion attacks
4. **Sanitize string inputs**: Trim whitespace, normalize case

---

## Common Validation Patterns

### Email Validation
```python
from pydantic import EmailStr

email: EmailStr  # Automatic email format validation
```

### Date Validation
```python
from datetime import date

date_of_birth: date  # Validates YYYY-MM-DD format
```

### String Length
```python
from typing import Annotated
from pydantic import Field

name: Annotated[str, Field(min_length=1, max_length=50)]
```

### Optional Fields
```python
middle_name: str | None = None
website_url: str | None = None
```

### Nested Schemas
```python
class Address(BaseModel):
    street: str
    city: str

class Profile(BaseModel):
    name: str
    address: Address
```

---

## Testing Schemas

### Valid Data
```python
valid_data = {
    "email": "test@example.com",
    "password": "SecurePass123!",
    "first_name": "John",
    "last_name": "Doe",
    "date_of_birth": "1990-01-01",
    "ssn": "123-45-6789",
    "phone": "555-1234567"
}

staff = StaffSignUp(**valid_data)
assert staff.email == "test@example.com"
```

### Invalid Data
```python
from pydantic import ValidationError

invalid_data = {
    "email": "not-an-email",
    "password": "weak"
}

try:
    staff = StaffSignUp(**invalid_data)
except ValidationError as e:
    print(e.errors())
```

---

## Related Documentation
- [Main API Documentation](MAIN_API_DOCUMENTATION.md)
- [Controllers Documentation](CONTROLLERS_DOCUMENTATION.md)
- [Database Models Documentation](DATABASE_MODELS_DOCUMENTATION.md)
- [Authentication Documentation](AUTH_DOCUMENTATION.md)
