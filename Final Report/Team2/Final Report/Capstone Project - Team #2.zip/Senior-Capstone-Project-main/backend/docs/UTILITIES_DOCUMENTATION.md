# Utilities Documentation

## Overview
`backend/app/Helper/utils.py` provides shared utility functions for password hashing, JWT token management, and information hashing. These functions are used throughout the application for security and authentication.

## Environment Configuration

### Required Environment Variables
- `SECRET_KEY`: JWT signing key (default: "supersecretkey" - **change in production**)
- `ALGORITHM`: JWT algorithm (hardcoded: "HS256")
- `ACCESS_TOKEN_EXPIRE_MINUTES`: Token expiration time (default: 60 minutes)

## Password Management

### `verify_password(plain_password: str, hashed_password: str) -> bool`
**Purpose**: Verify a plain text password against a hashed password.

**Parameters:**
- `plain_password`: User-provided password
- `hashed_password`: Stored bcrypt hash

**Returns:** `True` if password matches, `False` otherwise

**Error Handling:** Returns `False` for unknown hash errors instead of raising exceptions

**Usage:**
```python
if verify_password(user_input, user.password_hash):
    print("Login successful")
```

### `hash_password(plain_password: str) -> str`
**Purpose**: Hash a plain text password using bcrypt.

**Parameters:**
- `plain_password`: Password to hash

**Returns:** Bcrypt hashed password string

**Usage:**
```python
new_user.password_hash = hash_password("MySecurePass123!")
```

**Security:**
- Uses bcrypt with automatic salt generation
- Deprecated schemes are marked for upgrades
- Hashes are one-way (cannot be decrypted)

## Information Hashing

### `hash_info(information: str) -> str`
**Purpose**: Hash sensitive information (SSN, EIN) using SHA-256 for database storage.

**Parameters:**
- `information`: Sensitive data to hash

**Returns:** SHA-256 hex digest

**Usage:**
```python
staff.SSN_hashed = hash_info(ssn_input)
client.EIN_hashed = hash_info(ein_input)
```

**Note:** SHA-256 is deterministic, meaning the same input always produces the same hash. This allows for equality checks but not reversal.

## JWT Token Management

### `create_access_token(data: dict, expires_delta: timedelta | None = None) -> str`
**Purpose**: Create a JWT access token with expiration.

**Parameters:**
- `data`: Payload dictionary (typically contains user email, role, status)
- `expires_delta`: Optional custom expiration time (default: 60 minutes)

**Returns:** Encoded JWT token string

**Token Payload Structure:**
```json
{
  "sub": "user@example.com",
  "role": 2,
  "status": "active",
  "exp": 1733420400
}
```

**Usage:**
```python
token = create_access_token({
    "sub": user.email,
    "role": user.role,
    "status": user.status
})
```

### `verify_access_token(token: str) -> dict`
**Purpose**: Verify and decode a JWT access token.

**Parameters:**
- `token`: JWT token string

**Returns:** Decoded payload dictionary

**Raises:** `ValueError` if token is invalid or expired

**Usage:**
```python
try:
    payload = verify_access_token(token)
    email = payload.get("sub")
except ValueError:
    raise HTTPException(status_code=401, detail="Invalid token")
```

## Email Verification Tokens

### `create_verification_token(email: str) -> str`
**Purpose**: Create a JWT token for email verification with 24-hour expiration.

**Parameters:**
- `email`: User's email address

**Returns:** JWT token containing email and verification flag

**Token Payload:**
```json
{
  "email": "user@example.com",
  "token": "random_secure_token",
  "type": "email_verification",
  "exp": 1733506800
}
```

**Usage:**
```python
verification_token = create_verification_token(user.email)
verification_url = f"{FRONTEND_URL}/verify-email?token={verification_token}"
```

### `verify_token(token: str) -> dict`
**Purpose**: Verify and decode an email verification token.

**Parameters:**
- `token`: Verification JWT token

**Returns:** Decoded payload dictionary

**Raises:** `ValueError` if token is invalid, expired, or wrong type

**Usage:**
```python
try:
    payload = verify_token(token)
    email = payload.get("email")
    # Mark email as verified
except ValueError as e:
    raise HTTPException(status_code=400, detail=str(e))
```

## Password Reset Tokens

### `create_password_reset_token(email: str, expires_hours: int = 1) -> str`
**Purpose**: Create a JWT token for password reset flows with configurable expiration.

**Parameters:**
- `email`: User's email address
- `expires_hours`: Token validity period (default: 1 hour)

**Returns:** JWT token for password reset

**Token Payload:**
```json
{
  "email": "user@example.com",
  "token": "random_secure_token",
  "type": "password_reset",
  "exp": 1733424000
}
```

**Usage:**
```python
reset_token = create_password_reset_token(user.email, expires_hours=1)
reset_url = f"{FRONTEND_URL}/reset-password?token={reset_token}"
```

### `verify_password_reset_token(token: str) -> dict`
**Purpose**: Verify and decode a password reset token.

**Parameters:**
- `token`: Password reset JWT token

**Returns:** Decoded payload dictionary

**Raises:** `ValueError` if token is invalid, expired, or wrong type

**Usage:**
```python
try:
    payload = verify_password_reset_token(token)
    email = payload.get("email")
    # Allow password reset
except ValueError as e:
    raise HTTPException(status_code=400, detail="Invalid or expired token")
```

## Token Types

The utility module supports three distinct token types:

1. **Access Tokens**: General authentication (no type field)
2. **Email Verification**: `type: "email_verification"`
3. **Password Reset**: `type: "password_reset"`

Each type has its own verification function to prevent token misuse.

## Security Best Practices

### Secret Key Management
```python
# ❌ BAD - Never hardcode in production
SECRET_KEY = "supersecretkey"

# ✅ GOOD - Use environment variables
SECRET_KEY = os.getenv("SECRET_KEY")
if not SECRET_KEY:
    raise RuntimeError("SECRET_KEY must be set")
```

### Password Requirements
Enforced by `schemas.PasswordValidator`:
- 8-20 characters
- Uppercase + lowercase
- Numbers + special characters

### Token Security
- Access tokens: 60 minutes
- Email verification: 24 hours
- Password reset: 1 hour
- All tokens include expiration claims

## Error Handling

All verification functions raise `ValueError` with descriptive messages:
- "Invalid token": Malformed JWT
- "Invalid token type": Wrong token used for operation
- Expired tokens: Automatic via JWT expiration check

## Dependencies

### External Libraries
- `jose`: JWT encoding/decoding
- `passlib`: Password hashing (bcrypt)
- `python-dotenv`: Environment variable loading
- `hashlib`: SHA-256 hashing (built-in)
- `secrets`: Secure random token generation (built-in)

### Internal Dependencies
- Uses `database.models` for type hints
- Uses `database.db.get_db` for database sessions (via imports in other files)

## Testing Considerations

### Password Hashing
```python
# Test password verification
hashed = hash_password("TestPass123!")
assert verify_password("TestPass123!", hashed) == True
assert verify_password("WrongPass", hashed) == False
```

### Token Creation/Verification
```python
# Test token lifecycle
data = {"sub": "test@example.com", "role": 2}
token = create_access_token(data)
payload = verify_access_token(token)
assert payload["sub"] == "test@example.com"
```

### Token Types
```python
# Ensure type validation works
email_token = create_verification_token("test@example.com")
try:
    verify_password_reset_token(email_token)
    assert False, "Should have raised ValueError"
except ValueError:
    pass  # Expected
```

## Performance Considerations

### Bcrypt Performance
- Bcrypt is intentionally slow (prevents brute force)
- Typical hash time: 100-300ms
- Don't hash passwords in loops or high-frequency operations

### Token Generation
- JWT creation is fast (<1ms)
- Verification includes signature check and expiration validation
- Cache decoded tokens when making multiple checks

## Related Documentation
- [Authentication Documentation](AUTH_DOCUMENTATION.md)
- [Database Models Documentation](DATABASE_MODELS_DOCUMENTATION.md)
- [Database Schemas Documentation](DATABASE_SCHEMAS_DOCUMENTATION.md)
