# Main API Documentation

## Overview
`backend/app/main.py` is the entry point for the FastAPI application. It initializes the server, configures middleware, and registers all API routes.

## Application Configuration

### Server Details
- **Framework**: FastAPI
- **Default Port**: 8000
- **Default Host**: 127.0.0.1

### CORS Configuration
The application allows cross-origin requests from:
- `http://localhost:5173` (Vite dev server - primary)
- `http://127.0.0.1:5173`
- `http://localhost:5174` (alternative port)
- `http://127.0.0.1:5174`

**Settings:**
- `allow_credentials`: True
- `allow_methods`: All
- `allow_headers`: All

### Static Files
- **Mount Path**: `/static`
- **Directory**: `static/`
- **Purpose**: Serves uploaded files (profile images, licenses, resumes, government IDs)

## Registered Routers

The application includes the following routers:
1. **Authentication Router** (`auth.router`) - `/auth/*`
2. **Email Controller** (`email_controller.router`) - `/send-verification`, `/verify/*`
3. **Profile Controller** (`profile_controller.router`) - `/profile/*`
4. **Staff Dashboard Controller** (`staff_dashboard_controller.router`) - `/staff/dashboard/*`

## Endpoints

### Health Check
```
GET /health
```
**Description**: Basic health check endpoint to verify the API is running.

**Response:**
```json
{
  "status": "ok"
}
```

### Staff Sign Up
```
POST /sign_up_staff
Status Code: 201 Created
```

**Description**: Register a new staff member and send verification email.

**Request Body** (StaffSignUp):
```json
{
  "email": "string",
  "password": "string",
  "first_name": "string",
  "middle_name": "string (optional)",
  "last_name": "string",
  "date_of_birth": "YYYY-MM-DD",
  "ssn": "string",
  "phone": "string"
}
```

**Response:**
```json
{
  "message": "Staff registered successfully",
  "staff_id": 123,
  "billing_data": {
    "one_time_fee_id": 456,
    "subscription_id": 789
  },
  "email_verification_required": true
}
```

### Client Sign Up
```
POST /sign_up_client
Status Code: 201 Created
```

**Description**: Register a new client (restaurant) and send verification email.

**Request Body** (ClientSignUp):
```json
{
  "email": "string",
  "password": "string",
  "EIN_hashed": "string",
  "name": "string",
  "restaurant_type": "string",
  "phone": "string",
  "website_url": "string (optional)",
  "address_line1": "string",
  "address_line2": "string (optional)",
  "city": "string",
  "state": "string",
  "zipcode": 12345,
  "expedited": false,
  "white_glove": false
}
```

**Response:**
```json
{
  "message": "Client registered successfully. Please check your email to verify your account.",
  "client_id": 123,
  "email_verification_required": true,
  "billing_data": {
    "base_subscription_id": 1,
    "tablet_mainenance_id": 2,
    "tablet_setup_id": 3
  }
}
```

### Activate Staff Profile
```
POST /staff/activate_profile/{staff_id}
Status Code: 200 OK
Authentication Required: Yes (Bearer Token)
```

**Description**: Activate a staff member's profile after subscription payment.

**Authorization**: 
- Staff members can only activate their own profile
- Admins can activate any staff profile

**Path Parameters:**
- `staff_id` (integer): The ID of the staff member to activate

**Response:**
```json
{
  "message": "Staff profile activated successfully",
  "user_status": "active"
}
```

**Error Responses:**
- `401 Unauthorized`: Invalid or missing authentication token
- `403 Forbidden`: Not authorized to activate this profile
- `404 Not Found`: Staff member or profile not found
- `400 Bad Request`: No active subscription found

## Startup Events

### Database Column Check
On startup, the application ensures the following columns exist in the `staff_profiles` table:
- `profile_image` (TEXT)
- `liquor_license_path` (TEXT)

**Note**: This is a safety check. All columns should be created via `database/scripts/reset.py` using the models defined in `database/models.py`.

## Dependencies

### Database Session
All endpoints that interact with the database use the `get_db()` dependency to obtain a SQLAlchemy session.

### Authentication
Protected endpoints use `auth.get_current_user` to verify JWT tokens and retrieve the authenticated user.

## Running the Application

### Development
```bash
uvicorn app.main:app --reload
```

### Production
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

### Using PowerShell Script
```powershell
.\run_backend.ps1
```

## Error Handling

All endpoints use FastAPI's built-in exception handling. Common HTTP status codes:
- `200 OK`: Successful request
- `201 Created`: Resource created successfully
- `400 Bad Request`: Invalid input or business logic error
- `401 Unauthorized`: Authentication required or invalid token
- `403 Forbidden`: Insufficient permissions
- `404 Not Found`: Resource not found
- `500 Internal Server Error`: Unexpected server error

## Related Documentation
- [Authentication Documentation](AUTH_DOCUMENTATION.md)
- [Database Models Documentation](DATABASE_MODELS_DOCUMENTATION.md)
- [Controllers Documentation](CONTROLLERS_DOCUMENTATION.md)
