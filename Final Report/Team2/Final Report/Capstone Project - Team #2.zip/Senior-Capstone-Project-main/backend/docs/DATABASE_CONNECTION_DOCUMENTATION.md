# Database Connection Documentation

## Overview
`backend/database/db.py` manages the database connection, session management, and ORM base class for SQLAlchemy models.

---

## Environment Configuration

### Required Environment Variables
Create a `.env` file in the `backend/` directory:

```env
DB_URL=postgresql://username:password@host:port/database
```

**Example:**
```env
DB_URL=postgresql://postgres:password@localhost:5432/shift_solutions
```

### Environment File Location
The script automatically locates the `.env` file:
```python
ENV_PATH = Path(__file__).resolve().parents[1] / ".env"
```

**Path Structure:**
```
backend/
├── .env              # Environment variables file
├── database/
│   ├── db.py         # This file (2 parents up = backend/)
```

---

## Database URL Format

### PostgreSQL URL Structure
```
postgresql://[user]:[password]@[host]:[port]/[database]
```

**Components:**
- `user`: PostgreSQL username
- `password`: User's password
- `host`: Server address (localhost for local, IP/domain for remote)
- `port`: PostgreSQL port (default: 5432)
- `database`: Database name

### Examples

**Local Development:**
```env
DB_URL=postgresql://postgres:admin@localhost:5432/capstone_db
```

**Docker Container:**
```env
DB_URL=postgresql://dbuser:dbpass@db:5432/production_db
```

**Cloud Database (e.g., AWS RDS):**
```env
DB_URL=postgresql://admin:securepass@mydb.abc123.us-east-1.rds.amazonaws.com:5432/maindb
```

---

## Core Components

### Database Engine
```python
engine = create_engine(DATABASE_URL, pool_pre_ping=True)
```

**Purpose**: Establishes connection to PostgreSQL database.

**Configuration:**
- `pool_pre_ping=True`: Tests connections before use to prevent stale connections

**Features:**
- Connection pooling (reuses connections for efficiency)
- Automatic reconnection on connection loss
- Thread-safe operations

### Session Factory
```python
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)
```

**Purpose**: Creates database sessions for transactions.

**Configuration:**
- `autocommit=False`: Must explicitly call `db.commit()` to save changes
- `autoflush=False`: Must explicitly call `db.flush()` to send changes to DB

**Benefits:**
- Explicit transaction control
- Prevents accidental commits
- Better error handling

### ORM Base Class
```python
Base = declarative_base()
```

**Purpose**: Base class for all SQLAlchemy models.

**Usage:**
```python
from database.db import Base

class User(Base):
    __tablename__ = "users"
    # Model definition
```

---

## Dependency Function

### `get_db()`
**Purpose**: Provides database session as a FastAPI dependency.

**Implementation:**
```python
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
```

**Usage in Routes:**
```python
@app.get("/users")
def get_users(db: Session = Depends(get_db)):
    users = db.query(User).all()
    return users
```

**Benefits:**
- Automatic session creation
- Guaranteed session cleanup (even on errors)
- Dependency injection pattern
- Testable (can be mocked)

**Lifecycle:**
1. Request comes in
2. `get_db()` creates new session
3. Session yielded to route function
4. Route uses session for database operations
5. Route returns response
6. `finally` block closes session

---

## Database Session Usage

### Basic Query
```python
def get_user_by_email(email: str, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == email).first()
    return user
```

### Create Record
```python
def create_user(user_data: dict, db: Session = Depends(get_db)):
    new_user = User(**user_data)
    db.add(new_user)
    db.commit()
    db.refresh(new_user)  # Get updated data from DB
    return new_user
```

### Update Record
```python
def update_user(user_id: int, updates: dict, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    for key, value in updates.items():
        setattr(user, key, value)
    db.commit()
    db.refresh(user)
    return user
```

### Delete Record
```python
def delete_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    db.delete(user)
    db.commit()
    return {"message": "User deleted"}
```

---

## Transaction Management

### Explicit Commit
```python
db.add(new_record)
db.commit()  # Saves changes to database
```

### Flush vs Commit
```python
# Flush: Send to DB but don't commit transaction
db.add(user)
db.flush()  # Generates user.id but doesn't commit
print(user.id)  # ID available for use

db.add(profile_linked_to_user)
db.commit()  # Both records saved together
```

### Rollback on Error
```python
try:
    db.add(new_user)
    db.add(new_profile)
    db.commit()
except Exception as e:
    db.rollback()  # Undo changes
    raise HTTPException(status_code=500, detail=str(e))
```

---

## Connection Pool Management

### Default Pool Settings
SQLAlchemy uses connection pooling automatically:
- **Pool Size**: 5 connections (default)
- **Max Overflow**: 10 additional connections
- **Pool Recycle**: 3600 seconds (1 hour)

### Custom Pool Configuration
```python
engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    pool_size=10,           # Base pool size
    max_overflow=20,        # Additional connections
    pool_recycle=3600,      # Recycle after 1 hour
    pool_timeout=30         # Wait 30s for connection
)
```

### Pool Pre-Ping
```python
pool_pre_ping=True
```
**Purpose**: Tests each connection before use.

**Benefits:**
- Detects stale connections
- Automatic reconnection
- Prevents "server closed connection" errors

**When to Use:**
- Production environments
- Long-running applications
- Network-unstable environments

---

## Error Handling

### Common Errors

#### Missing DB_URL
```python
if not DATABASE_URL:
    raise RuntimeError("DB_URL is missing...")
```

**Solution:** Create `.env` file with proper DB_URL.

#### Connection Refused
```
sqlalchemy.exc.OperationalError: could not connect to server
```

**Solutions:**
1. Verify PostgreSQL is running
2. Check host/port in DB_URL
3. Verify firewall settings
4. Check username/password

#### Database Not Found
```
sqlalchemy.exc.OperationalError: database "dbname" does not exist
```

**Solution:** Create database first:
```sql
CREATE DATABASE shift_solutions;
```

#### Authentication Failed
```
sqlalchemy.exc.OperationalError: password authentication failed
```

**Solution:** Verify username and password in DB_URL.

---

## Testing Database Connection

### Quick Test Script
```python
from database.db import engine
from sqlalchemy import text

try:
    with engine.connect() as conn:
        result = conn.execute(text("SELECT 1"))
        print("Database connection successful!")
except Exception as e:
    print(f"Connection failed: {e}")
```

### Test in Python REPL
```python
>>> from database.db import SessionLocal
>>> db = SessionLocal()
>>> db.execute(text("SELECT version()"))
>>> db.close()
```

---

## Best Practices

### Session Management
1. **Always use `get_db()` dependency**: Don't create sessions manually in routes
2. **Close sessions properly**: `get_db()` handles this automatically
3. **Avoid long-lived sessions**: Create per-request, not per-application
4. **Use transactions**: Commit explicitly after modifications

### Error Handling
```python
def safe_db_operation(db: Session):
    try:
        # Database operations
        db.commit()
    except Exception as e:
        db.rollback()
        raise
    finally:
        db.close()  # get_db() does this automatically
```

### Query Optimization
1. **Use `.first()` for single records**: More efficient than `.all()[0]`
2. **Eager load relationships**: Use `.options(joinedload(...))`
3. **Add indexes**: For frequently queried columns
4. **Limit results**: Use `.limit()` for pagination

### Security
1. **Never commit credentials**: Use environment variables
2. **Use parameterized queries**: SQLAlchemy prevents SQL injection
3. **Limit connection pool**: Prevent resource exhaustion
4. **Use read replicas**: For heavy read workloads (if applicable)

---

## Environment Setup Guide

### Step 1: Install PostgreSQL
```bash
# Windows: Download installer from postgresql.org
# macOS:
brew install postgresql

# Linux:
sudo apt-get install postgresql
```

### Step 2: Create Database
```sql
CREATE DATABASE shift_solutions;
CREATE USER dbuser WITH PASSWORD 'securepassword';
GRANT ALL PRIVILEGES ON DATABASE shift_solutions TO dbuser;
```

### Step 3: Create .env File
```bash
cd backend
echo "DB_URL=postgresql://dbuser:securepassword@localhost:5432/shift_solutions" > .env
```

### Step 4: Test Connection
```bash
cd backend
python -c "from database.db import engine; print('Connected!' if engine else 'Failed')"
```

---

## Production Considerations

### Connection Pooling
```python
engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    pool_size=20,          # Increase for high traffic
    max_overflow=40,
    pool_recycle=3600,
    echo=False             # Disable SQL logging in production
)
```

### SSL Connections
```python
DB_URL=postgresql://user:pass@host:5432/db?sslmode=require
```

### Connection Retry Logic
```python
from sqlalchemy import event
from sqlalchemy.pool import Pool

@event.listens_for(Pool, "connect")
def set_tcp_keepalive(dbapi_conn, connection_record):
    # Keep connections alive
    dbapi_conn.set_tcp_keepalive(True)
```

---

## Related Documentation
- [Database Models Documentation](DATABASE_MODELS_DOCUMENTATION.md)
- [Database Scripts Documentation](DATABASE_SCRIPTS_DOCUMENTATION.md)
- [Main API Documentation](MAIN_API_DOCUMENTATION.md)
