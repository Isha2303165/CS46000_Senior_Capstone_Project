from database.db import engine
from database.models import Base
import database.scripts.seed as seed
from sqlalchemy import text

if __name__ == "__main__":
    # Use CASCADE to drop all tables with dependencies
    with engine.begin() as conn:
        conn.execute(text("DROP SCHEMA public CASCADE"))
        conn.execute(text("CREATE SCHEMA public"))
        conn.execute(text("GRANT ALL ON SCHEMA public TO public"))
    
    Base.metadata.create_all(bind=engine)
    seed.init_db()
    print("Database reset complete.")