# import the session from db.py
from datetime import datetime, timezone
from ..db import SessionLocal
# import reset_db function from models.py
from ..models import User, StaffProfile, ClientProfile
from database import models
from decimal import Decimal
# import password hasher
from app.Helper import utils

# function to initialize the database and seed data
def init_db():
    
    # just in case if we need to manually minipulate the database
    db = SessionLocal()

    # Seed default plans first
    init_staff_plans(db)
    init_client_plans(db)
    
    hashed_pw = utils.pwd_context.hash("capstone")
    
    # Sample
    user1 = User(
        email="capstone@pfw.edu",
        password_hash= hashed_pw,
        role=2,
        email_verified=True,
        status="",
        profile_complete=True,
        onboarding_step=3
    )
    # Add staff_user to the session first to generate an id,
    # that could be use later for the StaffProfile instance.
    db.add(user1)
    db.flush()

    waiter1 = StaffProfile(
        staff_id=user1.id,
        first_name="Shine",
        middle_name="K",
        last_name="Zaw",
        date_of_birth="00-00-0000",
        SSN_hashed="000-00-0000",
        phone="000-000-0000",
    )
    
    db.add(waiter1)
    
    hashed_pw_client = utils.pwd_context.hash("clientpass")
    user2 = User(
        email="client@pfw.edu",
        password_hash=hashed_pw_client,
        role=1,
        email_verified=True,
        status="",
        profile_complete=True,
        onboarding_step=3
    )
    db.add(user2)
    db.flush()  # generate user2.id

    restaurant1 = ClientProfile(
        client_id=user2.id,
        name="Shine's Bistro",
        EIN_hashed="12-3456789",
        restaurant_type="Casual Dining",
        phone="123-456-7890",
        website_url="https://shinesbistro.com",
        address_line1="123 Main St",
        address_line2=None,
        city="Fort Wayne",
        state="IN",
        zipcode=46805,
    )
    db.add(restaurant1)

    # commit to save to the database
    db.commit()
    # close the session
    db.close()


def init_staff_plans(db):
    """Create default staff plans if they don't already exist."""
    # One-time plan
    if not db.query(models.StaffOneTimePlan).filter_by(plan_name="Staff Onboarding Fee").first():
        db.add(models.StaffOneTimePlan(
            plan_name = "Staff Onboarding Fee",
            price = Decimal("30.00"),
            description = "One-time onboarding charge for new staff members",
            is_active = True
        ))

    # Subscription Plan from workflow
    if not db.query(models.StaffSubscriptionPlan).filter_by(plan_name = "Staff Basic Monthly").first():
        db.add(models.StaffSubscriptionPlan(
            plan_name = "Staff Basic Monthly",
            price = Decimal("5.95"),
            billing_frequency = "monthly",
            description = "Monthly access subscription for staff members",
            is_active = True
        ))
    
    db.commit()

def init_client_plans(db):
    """Create default client (restaurant) plans if they don't already exist."""

    one_time_plans = [
        ("Tablet and Setup Fee", Decimal("300.00"), "One-time setup for restaurant tablet and account."),
        ("Expedited Setup", Decimal("25.00"), "Optional expedited account activation (within 48 hours)."),
    ]

    for name, price, desc in one_time_plans:
        if not db.query(models.ClientOneTimePlan).filter_by(plan_name = name).first():
            db.add(models.ClientOneTimePlan(
                plan_name = name,
                price = price,
                description = desc,
                is_active = True
            ))
            print(f"Added one-time plan: {name}")

    subscription_plans = [
        ("Restaurant Setup Fee", Decimal("49.95"), "Standard monthly access plan for restaurants."),
        ("White Glove Access", Decimal("69.95"), "Premium onboarding and staff matching (optional)."),
        ("Tablet Maintenance Fee", Decimal("9.95"), "Monthly tablet support and maintenance plan."),
    ]

    for name, price, desc in subscription_plans:
        if not db.query(models.ClientSubscriptionPlan).filter_by(plan_name = name).first():
            db.add(models.ClientSubscriptionPlan(
                plan_name = name,
                plan_type = "base",
                price = price,
                billing_frequency = "monthly",
                description = desc,
                is_active = True
            ))
            print(f"Added subscription plan: {name}")

    db.commit()

if __name__ == "__main__":
    init_db()