# Used to define data validation and provides rules for requests and responses.
# Ensures that inputs are valid before moving on to the other logic.
from pydantic import BaseModel, EmailStr, Field, validator
from datetime import date
from typing import Annotated, List

class PasswordValidator(BaseModel):
    password: str
    #Passwords must contain, 8 characters (min),
    #1 uppercase, 1 lowercase, 1 number, and 1 special character
    @validator("password")
    def strong_password(cls, v):
        import re
        pattern = r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&#]+$"
        if len(v) < 8 or len(v) > 20 or not re.match(pattern, v):
            raise ValueError(
                "Password must between 8 and 20 characters long" \
                "and contain an uppercase letter, lowercase letter, number" \
                "and special character."
            )
        return v

# Checks that all fields contain actual information and are not blank using Annotated
# minimal signup schema - only collect email and password upfront
class StaffSignUp(PasswordValidator):
    email: EmailStr

# full signup schema (kept for backwards compatibility if needed)
class StaffSignUpFull(PasswordValidator):
    email: EmailStr
    first_name: Annotated[str, Field(min_length=1, max_length=20)]
    middle_name: str | None = None
    last_name: Annotated[str, Field(min_length=1, max_length=20)]
    date_of_birth: date
    ssn: Annotated[str, Field(min_length=9, max_length=15)]
    phone: Annotated[str, Field(min_length=7, max_length=15)]

# minimal signup schema only collect 3 fields upfront
class ClientSignUpMinimal(PasswordValidator):
    email: EmailStr
    name: Annotated[str, Field(min_length=1, max_length=100)]  # business name

# full signup schema (kept for backwards compatibility if needed)
class ClientSignUp(PasswordValidator):
    email: EmailStr
    EIN_hashed: Annotated[str, Field(min_length=5, max_length=100)]
    name: Annotated[str, Field(min_length=1, max_length=20)]
    restaurant_type: Annotated[str, Field(min_length=1, max_length=20)] #this should probably be chosen via a drop-down box or something
    phone: Annotated[str, Field(min_length=7, max_length=15)]
    website_url: str | None = None
    address_line1: Annotated[str, Field(min_length=5, max_length=100)]
    address_line2: str | None = None
    city: Annotated[str, Field(min_length=2, max_length=20)]
    state: Annotated[str, Field(min_length=2, max_length=20)]
    zipcode: int
    # For subscription testing
    expedited: bool = False
    white_glove: bool = False

# schema for updating profile during onboarding
class ClientProfileUpdate(BaseModel):
    restaurant_type: str | None = None
    phone: str | None = None
    address_line1: str | None = None
    address_line2: str | None = None
    city: str | None = None
    state: str | None = None
    zipcode: int | None = None
    website_url: str | None = None
    EIN_hashed: str | None = None

class LoginRequest(BaseModel):
    email: str
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"

class EmailSchema(BaseModel):
    email: List[EmailStr]

class StaffProfileResponse(BaseModel):
    staff_id: int
    first_name: str
    middle_name: str | None
    last_name: str
    date_of_birth: str
    phone: str
    profile_image: str | None
    liquor_license_path: str | None
    has_white_glove_certification: bool
    white_glove_certified_date: str | None
    email: str
    status: str

    class Config:
        from_attributes = True

class StaffProfileUpdate(BaseModel):
    first_name: str | None = None
    middle_name: str | None = None
    last_name: str | None = None
    phone: str | None = None
    date_of_birth: str | None = None

# Staff preferences schema
class ClientStaffPreferenceCreate(BaseModel):
    role: str = "Server"
    minimum_tier_rating: List[str] = []
    dress_code_notes: str | None = None
    tip_policy: str | None = None

class ClientStaffPreferenceResponse(BaseModel):
    id: int
    client_id: int
    role: str
    minimum_tier_rating: List[str]
    dress_code_notes: str | None
    tip_policy: str | None
    created_at: str
    updated_at: str

    class Config:
        from_attributes = True
