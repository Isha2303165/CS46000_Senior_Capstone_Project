import os
from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from pathlib import Path

# locate .env file from backend folder
ENV_PATH = Path(__file__).resolve().parents[1] / ".env"

# load environment variables
load_dotenv(ENV_PATH)

# set the database URL
DATABASE_URL = os.getenv("DB_URL")
if not DATABASE_URL:
    raise RuntimeError("DB_URL is missing. Create backend/.env and configure DB_URL accordingly to .env_example")

# engine is the connection to Postgres
# pool_pre_ping=True checks if the connection is alive
engine = create_engine(DATABASE_URL, pool_pre_ping=True) 

# autocommit=False means we have to call commit() to save changes
# autoflush=False means we have to call flush() to send changes to the DB
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)


# Base is for ORM models
# ORM(Object Relational Mapping) maps Python classes to DB tables
Base = declarative_base()

# Dependency to get DB session
# It's going to try to get a session, yield it, and then close it
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()