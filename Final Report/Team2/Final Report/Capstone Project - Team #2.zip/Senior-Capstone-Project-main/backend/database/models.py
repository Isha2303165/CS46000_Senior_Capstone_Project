#############################################################
# This file creates the models (tables) in the database     #
# Use the DB_ERD.svg file for visualization                 #
# Don't format this file!                                   #
#############################################################

# Using Column vs Mapped, Column is older style, Mapped is newer style.
# With Column, IDE doesn't data know the type of the attribute, so no autocomplete.
# With Mapped, IDE knows the data type, so better autocomplete and less error-prone.

# import necessary modules
from sqlalchemy import (CheckConstraint, Column, ForeignKey, Integer, SmallInteger, Text, UniqueConstraint, TIMESTAMP, Time, Numeric, Boolean, text,)
from sqlalchemy.dialects.postgresql import CITEXT
from sqlalchemy.orm import relationship, Mapped, mapped_column
from sqlalchemy import DDL, event
from decimal import Decimal

# import Base and engine to create/reset tables
from .db import Base, engine

# Create the citext extension if it doesn't exist
event.listen(
    Base.metadata,
    "before_create",
    DDL("CREATE EXTENSION IF NOT EXISTS citext")
)

# User 
class User(Base):
    __tablename__ = "users"

    id:             Mapped[int] = mapped_column(Integer, primary_key=True)
    email:          Mapped[str] = mapped_column(CITEXT, nullable=False, unique=True)
    password_hash:  Mapped[str] = mapped_column(Text, nullable=False)
    role:           Mapped[int] = mapped_column(SmallInteger,nullable=False) # 0=admin, 1=client, 2=staff
    email_verified: Mapped[bool] = mapped_column(nullable=False, server_default=text("false"))
    phone_2fa:      Mapped[str] = mapped_column(Text, nullable=True)  # Phone number for 2FA
    tfa_method:     Mapped[str] = mapped_column(Text, nullable=False, server_default=text("'email'"))  # 'email' or 'sms'
    status:         Mapped[str] = mapped_column(Text, nullable=False, server_default=text("'active'"))
    profile_complete: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("false"))
    onboarding_step: Mapped[int] = mapped_column(Integer, nullable=False, server_default=text("0"))
    created_at:     Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    last_login_at:  Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    updated_at:     Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))

    # constraints 0=admin, 1=client, 2=staff
    __table_args__ = (
        CheckConstraint("role IN (0,1,2)", name="users_role_check"),
        CheckConstraint("tfa_method IN ('email', 'sms')", name="users_tfa_method_check"),
    )

    # Establish one-to-one relationship with StaffProfile
    staff_profile: Mapped["StaffProfile"] = relationship(
        back_populates="user", uselist=False, cascade="all, delete-orphan"
    )
    # Establish one-to-one relationship with ClientProfile
    client_profile: Mapped["ClientProfile"] = relationship(
        back_populates="user", uselist=False, cascade="all, delete-orphan"
    )

################
# STAFF DOMAIN #
################

# staff_profiles (1:1 users)
class StaffProfile(Base):
    __tablename__ = "staff_profiles"

    staff_id:                       Mapped[int] = mapped_column(Integer,ForeignKey("users.id", ondelete="CASCADE"),primary_key=True)
    first_name:                     Mapped[str] = mapped_column(Text, nullable=False)
    middle_name:                    Mapped[str] = mapped_column(Text, default=None, nullable=True)
    last_name:                      Mapped[str] = mapped_column(Text, nullable=False)
    date_of_birth:                  Mapped[str] = mapped_column(Text, nullable=False)
    SSN_hashed:                     Mapped[str] = mapped_column(Text, nullable=False)
    phone:                          Mapped[str] = mapped_column(Text, nullable=False)
    short_bio:                      Mapped[str] = mapped_column(Text, nullable=True)
    has_white_glove_certification:  Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("false"))
    white_glove_certified_date:     Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=True)
    updated_at:                     Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    user:                           Mapped[User] = relationship(back_populates="staff_profile")

    # relationships to children
    subscriptions: Mapped[list["StaffSubscription"]] = relationship(
        back_populates="staff", cascade="all, delete-orphan"
    )
    one_time_fees: Mapped[list["StaffOneTimeFee"]] = relationship(
        back_populates="staff", cascade="all, delete-orphan"
    )
    emergency_contacts: Mapped[list["StaffEmergencyContact"]] = relationship(
        back_populates="staff", cascade="all, delete-orphan"
    )
    documents: Mapped[list["StaffDocument"]] = relationship(
        back_populates="staff", cascade="all, delete-orphan"
    )
    liquor_licenses: Mapped[list["StaffLiquorLicense"]] = relationship(
        back_populates="staff", cascade="all, delete-orphan"
    )

# staff_subscription_plans (reference table for available staff recurring plans)
class StaffSubscriptionPlan(Base):
    __tablename__ = "staff_subscription_plans"

    id:                 Mapped[int] = mapped_column(Integer, primary_key=True)
    plan_name:          Mapped[str] = mapped_column(Text, nullable=False, unique=True)
    price:              Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    billing_frequency:  Mapped[str] = mapped_column(Text, nullable=False, server_default=text("'monthly'"))
    description:        Mapped[str] = mapped_column(Text, nullable=True)
    is_active:          Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("true"))
    created_at:         Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    updated_at:         Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))

    # constraints
    __table_args__ = (
        CheckConstraint("billing_frequency IN ('monthly', 'yearly')", name="staff_subscription_plans_frequency_check"),
    )

    # relationships
    subscriptions: Mapped[list["StaffSubscription"]] = relationship(back_populates="plan")

# staff_one_time_plans (reference table for available staff one-time fee plans)
class StaffOneTimePlan(Base):
    __tablename__ = "staff_one_time_plans"

    id:                 Mapped[int] = mapped_column(Integer, primary_key=True)
    plan_name:          Mapped[str] = mapped_column(Text, nullable=False, unique=True)
    price:              Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    description:        Mapped[str] = mapped_column(Text, nullable=True)
    is_active:          Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("true"))
    created_at:         Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    updated_at:         Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))

    # relationships
    one_time_fees: Mapped[list["StaffOneTimeFee"]] = relationship(back_populates="plan")

# staff_subscriptions (tracks active subscriptions per staff)
class StaffSubscription(Base):
    __tablename__ = "staff_subscriptions"

    id:                 Mapped[int] = mapped_column(Integer, primary_key=True)
    staff_id:           Mapped[int] = mapped_column(Integer, ForeignKey("staff_profiles.staff_id", ondelete="CASCADE"), nullable=False)
    plan_id:            Mapped[int] = mapped_column(Integer, ForeignKey("staff_subscription_plans.id"), nullable=False)
    status:             Mapped[str] = mapped_column(Text, nullable=False, server_default=text("'active'"))
    start_date:         Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    end_date:           Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=True)
    next_billing_date:  Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False)
    created_at:         Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    updated_at:         Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))

    # constraints
    __table_args__ = (
        CheckConstraint("status IN ('active', 'inactive', 'cancelled')", name="staff_subscriptions_status_check"),
    )

    # relationships
    staff:              Mapped[StaffProfile] = relationship(back_populates="subscriptions")
    plan:               Mapped[StaffSubscriptionPlan] = relationship(back_populates="subscriptions")

# staff_one_time_fees (tracks one-time charges per staff)
class StaffOneTimeFee(Base):
    __tablename__ = "staff_one_time_fees"

    id:                 Mapped[int] = mapped_column(Integer, primary_key=True)
    staff_id:           Mapped[int] = mapped_column(Integer, ForeignKey("staff_profiles.staff_id", ondelete="CASCADE"), nullable=False)
    plan_id:            Mapped[int] = mapped_column(Integer, ForeignKey("staff_one_time_plans.id"), nullable=False)
    amount:             Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    paid_date:          Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    status:             Mapped[str] = mapped_column(Text, nullable=False, server_default=text("'paid'"))
    created_at:         Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))

    # constraints
    __table_args__ = (
        CheckConstraint("status IN ('paid', 'pending', 'refunded')", name="staff_one_time_fees_status_check"),
    )

    # relationships
    staff:              Mapped[StaffProfile] = relationship(back_populates="one_time_fees")
    plan:               Mapped[StaffOneTimePlan] = relationship(back_populates="one_time_fees")

# staff emergency contacts
class StaffEmergencyContact(Base):
    __tablename__ = "staff_emergency_contacts"

    id:             Mapped[int] = mapped_column(Integer, primary_key=True)
    staff_id:       Mapped[int] = mapped_column(Integer, ForeignKey("staff_profiles.staff_id", ondelete="CASCADE"), nullable=False)
    name:           Mapped[str] = mapped_column(Text, nullable=False)
    relation:       Mapped[str] = mapped_column(Text, nullable=False) # 'relationship' is a reserved word of sqlalchemy
    phone:          Mapped[str] = mapped_column(Text, nullable=False)
    email:          Mapped[str] = mapped_column(Text, nullable=True)
    address:        Mapped[str] = mapped_column(Text, nullable=False)
    city:           Mapped[str] = mapped_column(Text, nullable=False)
    state:          Mapped[str] = mapped_column(Text, nullable=False)
    is_primary:     Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("true"))
    created_at:     Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    updated_at:     Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))

    # relationships
    staff:          Mapped[StaffProfile] = relationship(back_populates="emergency_contacts")

# staff_documents (file storage for all staff documents profile pics/resume/ID/license)
class StaffDocument(Base):
    __tablename__ = "staff_documents"

    id:             Mapped[int] = mapped_column(Integer, primary_key=True)
    staff_id:       Mapped[int] = mapped_column(Integer, ForeignKey("staff_profiles.staff_id", ondelete="CASCADE"), nullable=False)
    document_type:  Mapped[str] = mapped_column(Text, nullable=False)
    file_path:      Mapped[str] = mapped_column(Text, nullable=False)
    status:         Mapped[str] = mapped_column(Text, nullable=False, server_default=text("'pending'"))
    uploaded_at:    Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    updated_at:     Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))

    # constraints
    __table_args__ = (
        CheckConstraint("document_type IN ('gov_id', 'resume', 'liquor_license_doc', 'profile_picture')", name="staff_documents_type_check"),
        CheckConstraint("status IN ('pending', 'approved', 'rejected', 'expired')", name="staff_documents_status_check"),
    )

    # relationships
    staff:          Mapped[StaffProfile] = relationship(back_populates="documents")

# staff_liquor_licenses (liquor license details per staff)
class StaffLiquorLicense(Base):
    __tablename__ = "staff_liquor_licenses"

    id:                 Mapped[int] = mapped_column(Integer, primary_key=True)
    staff_id:           Mapped[int] = mapped_column(Integer, ForeignKey("staff_profiles.staff_id", ondelete="CASCADE"), nullable=False)
    license_number:     Mapped[str] = mapped_column(Text, nullable=False)
    license_state:      Mapped[str] = mapped_column(Text, nullable=False)
    expiration_date:    Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False)
    document_id:        Mapped[int] = mapped_column(Integer, ForeignKey("staff_documents.id", ondelete="SET NULL"), nullable=True)
    status:             Mapped[str] = mapped_column(Text, nullable=False, server_default=text("'active'"))
    created_at:         Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    updated_at:         Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))

    # constraints
    __table_args__ = (
        CheckConstraint("status IN ('active', 'expired')", name="staff_liquor_licenses_status_check"),
    )

    # relationships
    staff:              Mapped[StaffProfile] = relationship(back_populates="liquor_licenses")
    document:           Mapped["StaffDocument"] = relationship(foreign_keys=[document_id])

#################
# CLIENT DOMAIN #
#################

# client_profiles (1:1 users)
class ClientProfile(Base):
    __tablename__ = "client_profiles"

    client_id:          Mapped[int] = mapped_column(Integer,ForeignKey("users.id", ondelete="CASCADE"),primary_key=True)
    name:               Mapped[str] = mapped_column(Text, nullable=False)
    EIN_hashed:         Mapped[str] = mapped_column(Text, nullable=False)
    restaurant_type:    Mapped[str] = mapped_column(Text, nullable=False)
    phone:              Mapped[str] = mapped_column(Text, nullable=False)
    website_url:        Mapped[str] = mapped_column(Text, nullable=True)
    address_line1:      Mapped[str] = mapped_column(Text, nullable=False)
    address_line2:      Mapped[str] = mapped_column(Text, nullable=True)
    city:               Mapped[str] = mapped_column(Text, nullable=False)
    state:              Mapped[str] = mapped_column(Text, nullable=False)
    zipcode:            Mapped[int] = mapped_column(Integer, nullable=False)
    updated_at:         Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    user:               Mapped[User] = relationship(back_populates="client_profile")

    # relationships to children
    managers: Mapped[list["ClientManager"]] = relationship(
        back_populates="client", cascade="all, delete-orphan"
    )
    business_hours: Mapped[list["BusinessHours"]] = relationship(
        back_populates="client", cascade="all, delete-orphan"
    )
    subscriptions: Mapped[list["ClientSubscription"]] = relationship(
        back_populates="client", cascade="all, delete-orphan"
    )
    tablets: Mapped[list["Tablet"]] = relationship(
        back_populates="client", cascade="all, delete-orphan"
    )
    one_time_fees: Mapped[list["ClientOneTimeFee"]] = relationship(
        back_populates="client", cascade="all, delete-orphan"
    )
    documents: Mapped[list["ClientDocument"]] = relationship(
        back_populates="client", cascade="all, delete-orphan"
    )

# client_managers (many per client)
class ClientManager(Base):
    __tablename__ = "client_managers"

    id:             Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id:      Mapped[int] = mapped_column(Integer,ForeignKey("client_profiles.client_id", ondelete="CASCADE"),nullable=False)
    first_name:     Mapped[str] = mapped_column(Text,nullable=False)
    last_name:      Mapped[str] = mapped_column(Text, nullable=False)
    email:          Mapped[str] = mapped_column(CITEXT, nullable=False)
    phone:          Mapped[str] = mapped_column(Text, nullable=False)
    
    # constraints
    client:         Mapped[ClientProfile] = relationship(back_populates="managers")
    
    __table_args__ = (
        UniqueConstraint("client_id", "email",name="uq_client_manager_client_email"),
    )

# business_hours (one row per day per client)
class BusinessHours(Base):
    __tablename__ = "business_hours"

    id:             Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id:      Mapped[int] = mapped_column(Integer, ForeignKey("client_profiles.client_id",ondelete="CASCADE"),nullable=False)
    day_of_week:    Mapped[int] = mapped_column(SmallInteger, nullable=False)

    # constraints 
    __table_args__ = (
        CheckConstraint("day_of_week BETWEEN 0 AND 6",name="business_hours_day_of_week_check"),
    )

    client:         Mapped[ClientProfile] = relationship(back_populates="business_hours")
    periods:        Mapped[list["BusinessPeriod"]] = relationship(back_populates="hours", cascade="all, delete-orphan")

# business_periods
class BusinessPeriod(Base):
    __tablename__ = "business_periods"

    id:         Mapped[int] = mapped_column(Integer, primary_key=True)
    hours_id:   Mapped[int] = mapped_column(Integer,ForeignKey("business_hours.id", ondelete="CASCADE"),nullable=False)
    open_time:  Mapped[str] = mapped_column(Time, nullable=False)
    close_time: Mapped[str] = mapped_column(Time, nullable=False)

    # constraints
    __table_args__ = (
        CheckConstraint("open_time <> close_time",name="business_periods_open_close_check"),
    )

    hours:      Mapped[BusinessHours] = relationship(back_populates="periods")

# client_subscription_plans (reference table for available client recurring plans)
class ClientSubscriptionPlan(Base):
    __tablename__ = "client_subscription_plans"

    id:                 Mapped[int] = mapped_column(Integer, primary_key=True)
    plan_name:          Mapped[str] = mapped_column(Text, nullable=False, unique=True)
    plan_type:          Mapped[str] = mapped_column(Text, nullable=False)
    price:              Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    billing_frequency:  Mapped[str] = mapped_column(Text, nullable=False, server_default=text("'monthly'"))
    description:        Mapped[str] = mapped_column(Text, nullable=True)
    is_active:          Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("true"))
    created_at:         Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    updated_at:         Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))

    # constraints
    __table_args__ = (
        CheckConstraint("plan_type IN ('base', 'addon')", name="client_subscription_plans_type_check"),
        CheckConstraint("billing_frequency IN ('monthly', 'yearly')", name="client_subscription_plans_frequency_check"),
    )

    # relationships
    subscriptions: Mapped[list["ClientSubscription"]] = relationship(back_populates="plan")

# client_one_time_plans (reference table for available client one-time fee plans)
class ClientOneTimePlan(Base):
    __tablename__ = "client_one_time_plans"

    id:                 Mapped[int] = mapped_column(Integer, primary_key=True)
    plan_name:          Mapped[str] = mapped_column(Text, nullable=False, unique=True)
    price:              Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    description:        Mapped[str] = mapped_column(Text, nullable=True)
    is_active:          Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("true"))
    created_at:         Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    updated_at:         Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))

    # relationships
    one_time_fees: Mapped[list["ClientOneTimeFee"]] = relationship(back_populates="plan")

# client_subscriptions (tracks active subscriptions per client)
class ClientSubscription(Base):
    __tablename__ = "client_subscriptions"

    id:                 Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id:          Mapped[int] = mapped_column(Integer, ForeignKey("client_profiles.client_id", ondelete="CASCADE"), nullable=False)
    plan_id:            Mapped[int] = mapped_column(Integer, ForeignKey("client_subscription_plans.id"), nullable=False)
    status:             Mapped[str] = mapped_column(Text, nullable=False, server_default=text("'active'"))
    start_date:         Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    end_date:           Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=True)
    next_billing_date:  Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False)
    created_at:         Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    updated_at:         Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))

    # constraints
    __table_args__ = (
        CheckConstraint("status IN ('active', 'cancelled', 'past_due', 'trial')", name="client_subscriptions_status_check"),
    )

    # relationships
    client:             Mapped[ClientProfile] = relationship(back_populates="subscriptions")
    plan:               Mapped[ClientSubscriptionPlan] = relationship(back_populates="subscriptions")

# tablets (tracks physical tablets per client)
class Tablet(Base):
    __tablename__ = "tablets"

    id:                             Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id:                      Mapped[int] = mapped_column(Integer, ForeignKey("client_profiles.client_id", ondelete="CASCADE"), nullable=False)
    serial_number:                  Mapped[str] = mapped_column(Text, nullable=False, unique=True)
    purchase_date:                  Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    status:                         Mapped[str] = mapped_column(Text, nullable=False, server_default=text("'active'"))
    has_maintenance_subscription:   Mapped[bool] = mapped_column(Boolean, nullable=False, server_default=text("false"))
    maintenance_start_date:         Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=True)
    created_at:                     Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    updated_at:                     Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))

    # constraints
    __table_args__ = (
        CheckConstraint("status IN ('active', 'inactive', 'maintenance', 'retired')", name="tablets_status_check"),
    )

    # relationships
    client:             Mapped[ClientProfile] = relationship(back_populates="tablets")

# client_one_time_fees (tracks one-time charges per client)
class ClientOneTimeFee(Base):
    __tablename__ = "client_one_time_fees"

    id:                 Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id:          Mapped[int] = mapped_column(Integer, ForeignKey("client_profiles.client_id", ondelete="CASCADE"), nullable=False)
    plan_id:            Mapped[int] = mapped_column(Integer, ForeignKey("client_one_time_plans.id"), nullable=False)
    amount:             Mapped[Decimal] = mapped_column(Numeric(10, 2), nullable=False)
    paid_date:          Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    status:             Mapped[str] = mapped_column(Text, nullable=False, server_default=text("'paid'"))
    created_at:         Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))

    # constraints
    __table_args__ = (
        CheckConstraint("status IN ('paid', 'pending', 'refunded')", name="client_one_time_fees_status_check"),
    )

    # relationships
    client:             Mapped[ClientProfile] = relationship(back_populates="one_time_fees")
    plan:               Mapped[ClientOneTimePlan] = relationship(back_populates="one_time_fees")

# client_documents (file storage for client business documents logo, photo, floor plan, etc.)
class ClientDocument(Base):
    __tablename__ = "client_documents"

    id:             Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id:      Mapped[int] = mapped_column(Integer, ForeignKey("client_profiles.client_id", ondelete="CASCADE"), nullable=False)
    document_type:  Mapped[str] = mapped_column(Text, nullable=False)
    file_path:      Mapped[str] = mapped_column(Text, nullable=False)
    status:         Mapped[str] = mapped_column(Text, nullable=False, server_default=text("'pending'"))
    uploaded_at:    Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    updated_at:     Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))

    # constraints
    __table_args__ = (
        CheckConstraint("document_type IN ('logo', 'photo', 'floor_plan', 'other')", name="client_documents_type_check"),
        CheckConstraint("status IN ('pending', 'approved', 'rejected')", name="client_documents_status_check"),
    )

    # relationships
    client:         Mapped[ClientProfile] = relationship(back_populates="documents")

# client_staff_preferences (staff preferences per client)
class ClientStaffPreference(Base):
    __tablename__ = "client_staff_preferences"

    id:                     Mapped[int] = mapped_column(Integer, primary_key=True)
    client_id:              Mapped[int] = mapped_column(Integer, ForeignKey("client_profiles.client_id", ondelete="CASCADE"), nullable=False, unique=True)
    role:                   Mapped[str] = mapped_column(Text, nullable=False, server_default=text("'Server'"))
    minimum_tier_rating:    Mapped[str] = mapped_column(Text, nullable=True)  # JSON array stored as text
    dress_code_notes:       Mapped[str] = mapped_column(Text, nullable=True)
    tip_policy:             Mapped[str] = mapped_column(Text, nullable=True)
    created_at:             Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))
    updated_at:             Mapped[str] = mapped_column(TIMESTAMP(timezone=True), nullable=False, server_default=text("now()"))

    # relationships
    client:                 Mapped[ClientProfile] = relationship(backref="staff_preferences")