# define script parameters
Param(
  # valid actions that can be passed  as parameters
  [ValidateSet("create","drop","seed","reset")]
  [string]$Action = "",
  [switch]$NoVenv
)

# file and folder locations
$Root         = $PSScriptRoot
$Backend      = Join-Path $Root "backend"
$VenvDir      = Join-Path $Backend ".venv"
$VenvPython   = Join-Path $VenvDir "Scripts\python.exe"
$ReqFile      = Join-Path $Backend "requirements.txt"

# check if backend folder exists, exit if not found
if (-not (Test-Path $Backend)) {
  Write-Error "backend folder not found at $Backend"
  exit 1
}

# check if the virtual environment 
function Ensure-Venv {
  param([switch]$NoVenv)
  if ($NoVenv) { return }
  if (-not (Test-Path $VenvPython)) {
    Write-Host "Creating virtual environment in backend\.venv ..." -ForegroundColor Cyan
    Push-Location $Backend
    try {
      # Use system Python to create venv
      python -m venv .venv
      if (-not (Test-Path $VenvPython)) {
        Write-Error "Failed to create virtual environment."
        exit 1
      }
      Write-Host "Virtual environment created." -ForegroundColor Green
    } finally { Pop-Location }
  }
}

# determine which python program to use
function Get-Python {
  param([switch]$NoVenv)
  # Use virtual env 
  if (-not $NoVenv -and (Test-Path $VenvPython)) { return $VenvPython }

  # fallback if python not found in PATH
  try {
    & python -V *>$null
    if ($LASTEXITCODE -eq 0) { return "python" }
  } catch {}
  try {
    & py -3 -V *>$null
    if ($LASTEXITCODE -eq 0) { return "py -3" }
  } catch {}
  Write-Error "No Python interpreter found. Install Python or use a virtual environment."
  exit 1
}

# install python dependencies if requirements file exits
function Install-Requirements {
  param([string]$PythonPath, [string]$RequirementsFile)
  if (Test-Path $RequirementsFile) {
    Write-Host "Installing Python dependencies from backend\requirements.txt ..." -ForegroundColor Cyan
    & $PythonPath -m pip install -r $RequirementsFile --quiet
    if (-not $?) { Write-Error "Failed to install dependencies."; exit 1 }
    Write-Host "Dependencies installed." -ForegroundColor Green
  } else {
    Write-Host "backend\requirements.txt not found. Skipping dependency install." -ForegroundColor Yellow
  }
}

# action
function Invoke-DbAction {
  param(
    [ValidateSet("create","drop","seed","reset")][string]$Action,
    [string]$PythonPath
  )
  # Run from backend so 'database.scripts.*' resolves
  Push-Location $Backend
  try {
    switch ($Action) {
      "create" { & $PythonPath "-m" "database.scripts.create" }
      "drop"   { & $PythonPath "-m" "database.scripts.drop" }
      "seed"   { & $PythonPath "-m" "database.scripts.seed" }
      "reset"  { & $PythonPath "-m" "database.scripts.reset" }
    }
    if (-not $?) { exit 1 }
  } finally {
    Pop-Location
  }
}

# Setup Python/venv
Ensure-Venv -NoVenv:$NoVenv
$Python = Get-Python -NoVenv:$NoVenv

# install python dependcies 
Install-Requirements -PythonPath $Python -RequirementsFile $ReqFile

if ($Action) {
  Invoke-DbAction -Action $Action -PythonPath $Python
  exit $LASTEXITCODE
}

# INTERACTIVE MENU
:MENU while ($true) {
  Clear-Host
  Write-Host "----------------------- Database CLI (PostgreSQL) -----------------------" -ForegroundColor Cyan
  Write-Host ""
  Write-Host "Make sure PostgreSQL is running before you use this!" -ForegroundColor Magenta
  Write-Host ""
  Write-Host "Also need a valid .env file with your PostgreSQL connection URL." -ForegroundColor Magenta
  Write-Host ""
  Write-Host "Start DB (run Command Prompt as Administrator):" -ForegroundColor Magenta
  Write-Host "  net start postgresql-x64-18" -ForegroundColor Magenta
  Write-Host ""
  Write-Host "Stop DB when you are done to save resources:" -ForegroundColor Magenta
  Write-Host "  net stop postgresql-x64-18" -ForegroundColor Magenta
  Write-Host ""
  Write-Host "--------------------------------------------------------------------------" -ForegroundColor Cyan
  Write-Host "Location: $Root"
  Write-Host ""
  Write-Host "1) Create tables"
  Write-Host "2) Drop tables"
  Write-Host "3) Seed data"
  Write-Host "4) Reset (drop + create + seed)"
  Write-Host "5) Exit"
  $choice = Read-Host "Choose 1-5"

  switch ($choice) {
    "1" { Invoke-DbAction -Action "create" -PythonPath $Python;  Write-Host ""; [void](Read-Host "Press Enter to continue...") }
    "2" { Invoke-DbAction -Action "drop"   -PythonPath $Python;  Write-Host ""; [void](Read-Host "Press Enter to continue...") }
    "3" { Invoke-DbAction -Action "seed"   -PythonPath $Python;  Write-Host ""; [void](Read-Host "Press Enter to continue...") }
    "4" { Invoke-DbAction -Action "reset"  -PythonPath $Python;  Write-Host ""; [void](Read-Host "Press Enter to continue...") }
    "5" { break MENU }
    default { Write-Host "Invalid choice."; Start-Sleep -Seconds 1 }
  }
}

return
