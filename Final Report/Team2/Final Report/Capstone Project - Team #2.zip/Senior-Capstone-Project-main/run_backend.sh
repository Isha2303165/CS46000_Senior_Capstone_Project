#!/bin/bash

# Backend setup script for Linux/macOS

echo ""
echo "------------------ Starting backend ------------------"
echo ""
cd "$(dirname "$0")/backend" # Change to backend directory
echo "Current directory: $PWD"

# Create virtual environment if it doesn't exist
if [ ! -d ".venv" ]; then
    echo "Creating virtual environment this may take a while..."
    python3 -m venv .venv 
    echo "Virtual environment created."
fi

# Activate virtual environment
source .venv/bin/activate
echo "Virtual environment activated."

# Install Python dependencies
pip install -r requirements.txt --quiet # --quiet hide the installation logs for cleaner output in terminal
echo ""
echo "Python dependencies from requirements.txt installed."
echo ""
echo "Ctrl+C in terminal to stop the backend server."
echo ""

# Start backend server
python -m uvicorn app.main:app --reload --port 8000 --host 127.0.0.1
