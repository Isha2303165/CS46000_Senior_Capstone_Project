# Install powershell extension for VS Code for better experience.

# Bypass execution policy for this script
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

# Backend setup
Write-Host ""
Write-Host "------------------ Starting backend ------------------" -ForegroundColor DarkMagenta
Write-Host ""
Set-Location "$PSScriptRoot\backend" # Change to backend directory
Write-Host "Current directory: $PWD" -ForegroundColor DarkYellow

# Create virtual environment if it doesn't exist
if (-Not (Test-Path ".\.venv")) {
    Write-Host "Creating virtual environment this may take a while..." -ForegroundColor Cyan
    python -m venv .venv 
    Write-Host "Virtual environment created." -ForegroundColor Cyan
}

# Activate virtual environment
.\.venv\Scripts\activate
Write-Host "Virtual environment activated." -ForegroundColor Cyan

# Install Python dependencies
pip install -r requirements.txt --quiet # --quiet hide the installation logs for cleaner output in terminal
Write-Host ""
Write-Host "Python dependencies from requirements.txt installed." -ForegroundColor Cyan
Write-Host ""
# Start backend server in background
.\.venv\Scripts\activate
python -m uvicorn app.main:app --reload --port 8000 --host 127.0.0.1
