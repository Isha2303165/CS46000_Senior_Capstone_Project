import Paper from '@mui/material/Paper';
import axios from 'axios';
import DOMPurify from 'dompurify';
import { jwtDecode as jwt_decode } from 'jwt-decode';
import React, { useLayoutEffect, useRef, useState } from 'react';
import NavBar from '../shared/NavBar.jsx';
import './Module.css';
import ModuleQuestion from './ModuleQuestion.jsx';

const ModulePiece = ({
  moduleContent,
  currentPage,
  moduleId,
  onUpdateTime,
  moduleCompleted,
  pagePaths,
  onPath,
  modulePageCount,
  updateCanMoveNext,
}) => {
  const [timeToOpen, setTimeToOpen] = useState();
  const [dataPipe, setDataPipe] = useState();
  const [pathObject, setPathObject] = useState({});
  const [questionsCompleted, setQuestionsCompleted] = useState([]);
  const [questions, setQuestions] = useState([]);
  const [decodedUserId, setDecodedUserId] = useState();
  const questionsCompletedRef = useRef(questionsCompleted);
  const questionsRef = useRef(questions);
  const normalizedLayout =
    typeof moduleContent?.layout === 'string' ? moduleContent.layout.trim() : '';
  const hasLayout = normalizedLayout.length > 0;

  const updateTime = newTime => {
    const updatedTime = { ...moduleContent, time: newTime };
    onUpdateTime(updatedTime);
  };

  useLayoutEffect(() => {
    const updateCurrentPage = async () => {
      const token = localStorage.getItem('token');
      if (token) {
        try {
          const decoded = jwt_decode(token);
          setDecodedUserId(decoded.uname);
          if (decoded.uname && moduleId) {
            axios
              .put(`${process.env.REACT_APP_API_BASE_URL}/api/user/module`, {
                uname: decoded.uname,
                module: moduleId,
                type: decoded.type,
                id: decoded.id,
              })
              .then(response => {
                const { token } = response.data;
                localStorage.setItem('token', token);
              });
          }
          setDataPipe('');
          if (moduleContent.questiontopipe) {
            let cleanQuestion = moduleContent.questiontopipe.replace(/<\/[^>]+(>|$)/g, '');
            try {
              const response = await axios.get(
                `${process.env.REACT_APP_API_BASE_URL}/api/answers/${moduleId}/${decoded.uname}/${cleanQuestion}`
              );
              setDataPipe(response.data.response);
            } catch {}
          }

          if (moduleContent.content === 'End of Module Activity') {
            if (moduleContent.time) {
              try {
                await axios.post(`${process.env.REACT_APP_API_BASE_URL}/api/time/create`, {
                  uname: decoded.uname,
                  module: moduleId,
                  time: moduleContent.time,
                });
              } catch (error) {
                console.error(
                  'Error creating time entry:',
                  error.response ? error.response.data : error.message
                );
              }
            }

            try {
              const timeToOpenResponse = await axios.get(
                `${process.env.REACT_APP_API_BASE_URL}/api/time?uname=${decoded.uname}&module=${moduleId}`,
                {
                  validateStatus: status => status === 200 || status === 404,
                }
              );

              if (
                timeToOpenResponse.status === 200 &&
                timeToOpenResponse.data?.date &&
                !Number.isNaN(new Date(timeToOpenResponse.data.date).getTime())
              ) {
                const currentTime = new Date(timeToOpenResponse.data.date);
                const readable = currentTime.toLocaleString();
                setTimeToOpen(readable);
                updateTime(readable);
              }
            } catch (error) {
              console.error(
                'Error fetching time entry:',
                error.response ? error.response.data : error.message
              );
            }
          }

          if (pagePaths) {
            Object.entries(pagePaths).forEach(entry => {
              const [question, path] = entry;

              const keys = Object.keys(path);
              const pathWithoutLastKey = keys.slice(0, -1).reduce((acc, key) => {
                acc[key] = path[key];
                return acc;
              }, {});

              const pageNumber = path[keys[keys.length - 1]];

              if (pageNumber === currentPage) {
                pathObject[question] = pathWithoutLastKey;
              }
            });
          }

          setPathObject(pathObject);

          if (currentPage >= 1 && modulePageCount > 0) {
            await axios.put(
              `${process.env.REACT_APP_API_BASE_URL}/api/module/updateProgress/${moduleId}`,
              {
                userId: decoded.uname,
                currentPage: currentPage,
                progressPercentage: (currentPage / modulePageCount) * 100,
              }
            );
          }

          questionsRef.current = [];
          questionsCompletedRef.current = [];

          if (moduleContent.option1 === 'question') {
            if (!questionsRef.current.includes(moduleContent['option1-questionDescription']))
              questionsRef.current.push(moduleContent['option1-questionDescription']);
          }

          if (moduleContent.option2 === 'question') {
            if (!questionsRef.current.includes(moduleContent['option2-questionDescription']))
              questionsRef.current.push(moduleContent['option2-questionDescription']);
          }

          if (moduleContent.option3 === 'question') {
            if (!questionsRef.current.includes(moduleContent['option3-questionDescription']))
              questionsRef.current.push(moduleContent['option3-questionDescription']);
          }

          if (moduleContent.option4 === 'question') {
            if (!questionsRef.current.includes(moduleContent['option4-questionDescription']))
              questionsRef.current.push(moduleContent['option4-questionDescription']);
          }

          const res = await axios.get(
            `${process.env.REACT_APP_API_BASE_URL}/api/allAnswers/${moduleId}/${decoded.uname}`
          );

          const matchingResponses = res.data.filter(response =>
            questionsRef.current.some(question => response.response.question === question)
          );

          let canMoveNext = false;

          if (
            matchingResponses.length >= questionsRef.current.length ||
            matchingResponses.length + questionsCompletedRef.current.length >=
              questionsRef.current.length
          ) {
            canMoveNext = true;
          }

          if (questionsCompletedRef.current.length === questionsRef.current.length) {
            canMoveNext = true;
          }

          updateCanMoveNext(canMoveNext);
          setQuestions([...questionsRef.current]);
        } catch (error) {
          console.error('Invalid token', error);
        }
      }
    };

    updateCurrentPage();
  }, [currentPage]);

  const handleUpdateFromModuleQuestion = async newData => {
    if (!questionsCompletedRef.current.includes(newData.question)) {
      questionsCompletedRef.current.push(newData.question);

      let canMoveNext = false;

      const res = await axios.get(
        `${process.env.REACT_APP_API_BASE_URL}/api/allAnswers/${moduleId}/${decodedUserId}`
      );

      const matchingResponses = res.data.filter(response =>
        questionsRef.current.some(question => response.response.question === question)
      );

      if (
        matchingResponses.length >= questionsRef.current.length ||
        matchingResponses.length + questionsCompletedRef.current.length >=
          questionsRef.current.length
      ) {
        canMoveNext = true;
      }

      if (questionsCompletedRef.current.length === questions.length) {
        canMoveNext = true;
      }

      updateCanMoveNext(canMoveNext);
      if (newData.question in pathObject) {
        onPath(pathObject[newData.question][newData.answer]);
      }
      setQuestionsCompleted([...questionsCompletedRef.current]);
    }
  };

  return (
    <div className="master-div">
      <NavBar />

      {!hasLayout && (
        <Paper style={emptyPage}>
          <div style={{ textAlign: 'center' }}>
            <h2>This page has no content yet.</h2>
            <p style={{ marginBottom: 0 }}>Please check back later for updates.</p>
          </div>
        </Paper>
      )}

      {moduleContent.layout === 'top-center-bottom' && (
        <Paper style={{ topCenterBottom, width: '50vw', height: '30vw', overflowY: 'auto' }}>
          <div style={{ textAlign: 'center' }}>
            <h2>{moduleContent.content}</h2>

            {moduleContent.content === 'End of Module Activity' && (
              <h2>Reflection Available At: {timeToOpen}</h2>
            )}

            <h3
              style={{ fontSize: '1rem' }}
              dangerouslySetInnerHTML={{
                __html: DOMPurify.sanitize(moduleContent.pageDescription),
              }}
            />

            {dataPipe && (
              <div>
                <h3>
                  Previously, we saw you selected this response:{' '}
                  {dataPipe.answer.includes(',')
                    ? dataPipe.answer
                        .split(',')
                        .map(item => item.trim())
                        .join(', ')
                    : dataPipe.answer}
                  , to this question:
                  <span> {dataPipe.question.slice(3, -4)}</span>
                </h3>
              </div>
            )}
          </div>

          {moduleContent.content === 'End of Module Activity Questions' && (
            <ModuleQuestion
              question={{
                value: moduleContent.questionDescription,
                type: moduleContent.type,
                options: moduleContent.value,
                questions: moduleContent.questions,
                orientation: moduleContent.orientation,
              }}
              currentPage={currentPage}
              moduleId={moduleId}
              title={moduleContent.content}
            />
          )}

          {moduleContent.option1 === 'media' && (
            <div className="content-div">
              <img
                src={moduleContent['option1-media']}
                alt=""
                style={{ maxWidth: '15vw', maxHeight: '15vw' }}
              />
            </div>
          )}

          {moduleContent.option1 === 'question' && !moduleCompleted && (
            <ModuleQuestion
              question={{
                value: moduleContent['option1-questionDescription'],
                type: moduleContent['option1-type'],
                options: moduleContent['option1-value'],
                questions: moduleContent.questions,
                orientation: moduleContent['option1-orientation'],
              }}
              currentPage={currentPage}
              moduleId={moduleId}
              title={moduleContent.content}
            />
          )}

          {moduleContent.option1 === 'rich-text' && (
            <h2
              dangerouslySetInnerHTML={{
                __html: DOMPurify.sanitize(moduleContent['option1-rich-text']),
              }}
            />
          )}

          {moduleContent.option2 === 'media' && (
            <div className="content-div">
              <img
                src={moduleContent['option2-media']}
                alt=""
                style={{ maxWidth: '15vw', maxHeight: '15vw' }}
              />
            </div>
          )}

          {moduleContent.option2 === 'question' && !moduleCompleted && (
            <ModuleQuestion
              question={{
                value: moduleContent['option2-questionDescription'],
                type: moduleContent['option2-type'],
                options: moduleContent['option2-value'],
                questions: moduleContent.questions,
                orientation: moduleContent['option2-orientation'],
              }}
              currentPage={currentPage}
              moduleId={moduleId}
              title={moduleContent.content}
            />
          )}

          {moduleContent.option2 === 'rich-text' && (
            <h2
              dangerouslySetInnerHTML={{
                __html: DOMPurify.sanitize(moduleContent['option2-rich-text']),
              }}
            />
          )}

          <br />

          {moduleContent.option3 === 'media' && (
            <div className="content-div">
              <img
                src={moduleContent['option3-media']}
                alt=""
                style={{ maxWidth: '15vw', maxHeight: '15vw' }}
              />
            </div>
          )}

          {moduleContent.option3 === 'question' && !moduleCompleted && (
            <ModuleQuestion
              question={{
                value: moduleContent['option3-questionDescription'],
                type: moduleContent['option3-type'],
                options: moduleContent['option3-value'],
                questions: moduleContent.questions,
                orientation: moduleContent['option3-orientation'],
              }}
              currentPage={currentPage}
              moduleId={moduleId}
              title={moduleContent.content}
            />
          )}

          {moduleContent.option3 === 'rich-text' && (
            <h2
              dangerouslySetInnerHTML={{
                __html: DOMPurify.sanitize(moduleContent['option3-rich-text']),
              }}
            />
          )}
        </Paper>
      )}

      {moduleContent.layout === 'top-bottom' && (
        <Paper style={{ topBottom, width: '50vw', height: '30vw', overflowY: 'auto' }}>
          <div style={{ textAlign: 'center' }}>
            <h2>{moduleContent.content}</h2>

            {moduleContent.content === 'End of Module Activity' && (
              <h2>Reflection Available At: {timeToOpen}</h2>
            )}

            <h3
              style={{ fontSize: '1rem' }}
              dangerouslySetInnerHTML={{
                __html: DOMPurify.sanitize(moduleContent.pageDescription),
              }}
            />

            {dataPipe && (
              <div>
                <h3>
                  Previously, we saw you selected this response:{' '}
                  {dataPipe.answer.includes(',')
                    ? dataPipe.answer
                        .split(',')
                        .map(item => item.trim())
                        .join(', ')
                    : dataPipe.answer}
                  , to this question:
                  <span> {dataPipe.question.slice(3, -4)}</span>
                </h3>
              </div>
            )}
          </div>

          {moduleContent.option1 === 'media' && (
            <div className="content-div">
              <img
                src={moduleContent['option1-media']}
                alt=""
                style={{ maxWidth: '15vw', maxHeight: '15vw' }}
              />
            </div>
          )}

          {moduleContent.option1 === 'question' && !moduleCompleted && (
            <ModuleQuestion
              question={{
                value: moduleContent['option1-questionDescription'],
                type: moduleContent['option1-type'],
                options: moduleContent['option1-value'],
                questions: moduleContent.questions,
                orientation: moduleContent['option1-orientation'],
              }}
              currentPage={currentPage}
              moduleId={moduleId}
              title={moduleContent.content}
              onUpdate={handleUpdateFromModuleQuestion}
            />
          )}

          {moduleContent.option1 === 'rich-text' && (
            <h2
              dangerouslySetInnerHTML={{
                __html: DOMPurify.sanitize(moduleContent['option1-rich-text']),
              }}
            />
          )}

          {moduleContent.option2 === 'media' && (
            <div className="content-div">
              <img
                src={moduleContent['option2-media']}
                alt=""
                style={{ maxWidth: '15vw', maxHeight: '15vw' }}
              />
            </div>
          )}

          {moduleContent.option2 === 'question' && !moduleCompleted && (
            <ModuleQuestion
              question={{
                value: moduleContent['option2-questionDescription'],
                type: moduleContent['option2-type'],
                options: moduleContent['option2-value'],
                questions: moduleContent.questions,
                orientation: moduleContent['option2-orientation'],
              }}
              currentPage={currentPage}
              moduleId={moduleId}
              title={moduleContent.content}
              onUpdate={handleUpdateFromModuleQuestion}
            />
          )}

          {moduleContent.option2 === 'rich-text' && (
            <h2
              dangerouslySetInnerHTML={{
                __html: DOMPurify.sanitize(moduleContent['option2-rich-text']),
              }}
            />
          )}
        </Paper>
      )}

      {moduleContent.layout === 'left-center-right' && (
        <Paper style={{ leftCenterRight, width: '50vw', height: '30vw', overflowY: 'auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '20px' }}>
            <h2>{moduleContent.content}</h2>

            {moduleContent.content === 'End of Module Activity' && (
              <h2>Reflection Available At: {timeToOpen}</h2>
            )}

            <h3
              style={{ fontSize: '1rem' }}
              dangerouslySetInnerHTML={{
                __html: DOMPurify.sanitize(moduleContent.pageDescription),
              }}
            />

            {dataPipe && (
              <div>
                <h3>
                  Previously, we saw you selected this response:{' '}
                  {dataPipe.answer.includes(',')
                    ? dataPipe.answer
                        .split(',')
                        .map(item => item.trim())
                        .join(', ')
                    : dataPipe.answer}
                  , to this question:
                  <span> {dataPipe.question.slice(3, -4)}</span>
                </h3>
              </div>
            )}
          </div>

          <div
            style={{
              display: 'flex',
              width: '100%',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <div style={{ flex: 1, textAlign: 'left', padding: '20px' }}>
              {moduleContent.option1 === 'media' && (
                <div
                  style={{
                    width: '15vw',
                    height: '15vw',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <img
                    src={moduleContent['option1-media']}
                    alt=""
                    style={{ maxWidth: '15vw', maxHeight: '15vw' }}
                  />
                </div>
              )}

              {moduleContent.option1 === 'question' && !moduleCompleted && (
                <ModuleQuestion
                  question={{
                    value: moduleContent['option1-questionDescription'],
                    type: moduleContent['option1-type'],
                    options: moduleContent['option1-value'],
                    questions: moduleContent.questions,
                    orientation: moduleContent['option1-orientation'],
                  }}
                  currentPage={currentPage}
                  moduleId={moduleId}
                  title={moduleContent.content}
                  onUpdate={handleUpdateFromModuleQuestion}
                />
              )}

              {moduleContent.option1 === 'rich-text' && (
                <h2
                  dangerouslySetInnerHTML={{
                    __html: DOMPurify.sanitize(moduleContent['option1-rich-text']),
                  }}
                />
              )}
            </div>

            <div
              style={{
                flex: 1,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                padding: '20px',
              }}
            >
              {moduleContent.option2 === 'media' && (
                <div
                  style={{
                    width: '15vw',
                    height: '15vw',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <img
                    src={moduleContent['option2-media']}
                    alt=""
                    style={{ maxWidth: '15vw', maxHeight: '15vw' }}
                  />
                </div>
              )}

              {moduleContent.option2 === 'question' && !moduleCompleted && (
                <ModuleQuestion
                  question={{
                    value: moduleContent['option2-questionDescription'],
                    type: moduleContent['option2-type'],
                    options: moduleContent['option2-value'],
                    questions: moduleContent.questions,
                    orientation: moduleContent['option2-orientation'],
                  }}
                  currentPage={currentPage}
                  moduleId={moduleId}
                  title={moduleContent.content}
                  onUpdate={handleUpdateFromModuleQuestion}
                />
              )}

              {moduleContent.option2 === 'rich-text' && (
                <h2
                  dangerouslySetInnerHTML={{
                    __html: DOMPurify.sanitize(moduleContent['option2-rich-text']),
                  }}
                />
              )}
            </div>

            <div style={{ flex: 1, textAlign: 'right', padding: '20px' }}>
              {moduleContent.option3 === 'media' && (
                <div
                  style={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <img
                    src={moduleContent['option3-media']}
                    alt=""
                    style={{ maxWidth: '15vw', maxHeight: '15vw' }}
                  />
                </div>
              )}

              {moduleContent.option3 === 'question' && !moduleCompleted && (
                <ModuleQuestion
                  question={{
                    value: moduleContent['option3-questionDescription'],
                    type: moduleContent['option3-type'],
                    options: moduleContent['option3-value'],
                    questions: moduleContent.questions,
                    orientation: moduleContent['option3-orientation'],
                  }}
                  currentPage={currentPage}
                  moduleId={moduleId}
                  title={moduleContent.content}
                  onUpdate={handleUpdateFromModuleQuestion}
                />
              )}

              {moduleContent.option3 === 'rich-text' && (
                <h2
                  dangerouslySetInnerHTML={{
                    __html: DOMPurify.sanitize(moduleContent['option3-rich-text']),
                  }}
                />
              )}
            </div>
          </div>
        </Paper>
      )}

      {moduleContent.layout === 'left-right-centerbottom' && (
        <Paper style={{ leftRightCenterBottom, width: '50vw', height: '30vw', overflowY: 'auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '20px' }}>
            <h2>{moduleContent.content}</h2>

            {moduleContent.content === 'End of Module Activity' && (
              <h2>Reflection Available At: {timeToOpen}</h2>
            )}

            <h3
              style={{ fontSize: '1rem' }}
              dangerouslySetInnerHTML={{
                __html: DOMPurify.sanitize(moduleContent.pageDescription),
              }}
            />

            {dataPipe && (
              <div>
                <h3>
                  Previously, we saw you selected this response:{' '}
                  {dataPipe.answer.includes(',')
                    ? dataPipe.answer
                        .split(',')
                        .map(item => item.trim())
                        .join(', ')
                    : dataPipe.answer}
                  , to this question:
                  <span> {dataPipe.question.slice(3, -4)}</span>
                </h3>
              </div>
            )}
          </div>

          <div
            style={{
              display: 'flex',
              width: '100%',
              marginBottom: '20px',
            }}
          >
            <div style={{ flex: 1, textAlign: 'left', padding: '20px' }}>
              {moduleContent.option1 === 'media' && (
                <div
                  style={{
                    width: '15vw',
                    height: '15vw',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <img
                    src={moduleContent['option1-media']}
                    alt=""
                    style={{ maxWidth: '15vw', maxHeight: '15vw' }}
                  />
                </div>
              )}
              {moduleContent.option1 === 'question' && !moduleCompleted && (
                <ModuleQuestion
                  question={{
                    value: moduleContent['option1-questionDescription'],
                    type: moduleContent['option1-type'],
                    options: moduleContent['option1-value'],
                    questions: moduleContent.questions,
                    orientation: moduleContent['option1-orientation'],
                  }}
                  currentPage={currentPage}
                  moduleId={moduleId}
                  title={moduleContent.content}
                  onUpdate={handleUpdateFromModuleQuestion}
                />
              )}
              {moduleContent.option1 === 'rich-text' && (
                <h2
                  dangerouslySetInnerHTML={{
                    __html: DOMPurify.sanitize(moduleContent['option1-rich-text']),
                  }}
                />
              )}
            </div>

            <div style={{ flex: 1, textAlign: 'right', padding: '20px' }}>
              {moduleContent.option2 === 'media' && (
                <div
                  style={{
                    width: '15vw',
                    height: '15vw',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <img
                    src={moduleContent['option2-media']}
                    alt=""
                    style={{ maxWidth: '15vw', maxHeight: '15vw' }}
                  />
                </div>
              )}
              {moduleContent.option2 === 'question' && !moduleCompleted && (
                <ModuleQuestion
                  question={{
                    value: moduleContent['option2-questionDescription'],
                    type: moduleContent['option2-type'],
                    options: moduleContent['option2-value'],
                    questions: moduleContent.questions,
                    orientation: moduleContent['option2-orientation'],
                  }}
                  currentPage={currentPage}
                  moduleId={moduleId}
                  title={moduleContent.content}
                  onUpdate={handleUpdateFromModuleQuestion}
                />
              )}
              {moduleContent.option2 === 'rich-text' && (
                <h2
                  dangerouslySetInnerHTML={{
                    __html: DOMPurify.sanitize(moduleContent['option2-rich-text']),
                  }}
                />
              )}
            </div>
          </div>

          <div
            style={{
              width: '100%',
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              padding: '20px',
            }}
          >
            {moduleContent.option3 === 'media' && (
              <div
                style={{
                  width: '15vw',
                  height: '15vw',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <img
                  src={moduleContent['option3-media']}
                  alt=""
                  style={{ maxWidth: '15vw', maxHeight: '15vw' }}
                />
              </div>
            )}
            {moduleContent.option3 === 'question' && !moduleCompleted && (
              <ModuleQuestion
                question={{
                  value: moduleContent['option3-questionDescription'],
                  type: moduleContent['option3-type'],
                  options: moduleContent['option3-value'],
                  questions: moduleContent.questions,
                  orientation: moduleContent['option3-orientation'],
                }}
                currentPage={currentPage}
                moduleId={moduleId}
                title={moduleContent.content}
                onUpdate={handleUpdateFromModuleQuestion}
              />
            )}
            {moduleContent.option3 === 'rich-text' && (
              <h2
                dangerouslySetInnerHTML={{
                  __html: DOMPurify.sanitize(moduleContent['option3-rich-text']),
                }}
              />
            )}
          </div>
        </Paper>
      )}

      {moduleContent.layout === 'left-right' && (
        <Paper style={{ leftRight, width: '50vw', height: '30vw', overflowY: 'auto' }}>
          <div style={{ textAlign: 'center', marginBottom: '20px' }}>
            <h2>{moduleContent.content}</h2>

            {moduleContent.content === 'End of Module Activity' && (
              <h2>Reflection Available At: {timeToOpen}</h2>
            )}

            <h3
              style={{ fontSize: '1rem' }}
              dangerouslySetInnerHTML={{
                __html: DOMPurify.sanitize(moduleContent.pageDescription),
              }}
            />

            {dataPipe && (
              <div>
                <h3>
                  Previously, we saw you selected this response:{' '}
                  {dataPipe.answer.includes(',')
                    ? dataPipe.answer
                        .split(',')
                        .map(item => item.trim())
                        .join(', ')
                    : dataPipe.answer}
                  , to this question:
                  <span> {dataPipe.question.slice(3, -4)}</span>
                </h3>
              </div>
            )}
          </div>

          <div
            style={{
              display: 'flex',
              width: '100%',
              marginBottom: '20px',
            }}
          >
            <div style={{ flex: 1, textAlign: 'left', padding: '20px' }}>
              {moduleContent.option1 === 'media' && (
                <div
                  style={{
                    width: '15vw',
                    height: '15vw',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <img
                    src={moduleContent['option1-media']}
                    alt=""
                    style={{ maxWidth: '15vw', maxHeight: '15vw' }}
                  />
                </div>
              )}
              {moduleContent.option1 === 'question' && !moduleCompleted && (
                <ModuleQuestion
                  question={{
                    value: moduleContent['option1-questionDescription'],
                    type: moduleContent['option1-type'],
                    options: moduleContent['option1-value'],
                    questions: moduleContent.questions,
                    orientation: moduleContent['option1-orientation'],
                  }}
                  currentPage={currentPage}
                  moduleId={moduleId}
                  title={moduleContent.content}
                  onUpdate={handleUpdateFromModuleQuestion}
                />
              )}
              {moduleContent.option1 === 'rich-text' && (
                <h2
                  dangerouslySetInnerHTML={{
                    __html: DOMPurify.sanitize(moduleContent['option1-rich-text']),
                  }}
                />
              )}
            </div>

            <div style={{ flex: 1, alignContent: 'center', width: 'clamp(15vw, 50%, 600px)' }}>
              {moduleContent.option2 === 'media' && (
                <div
                  style={{
                    width: '15vw',
                    height: '15vw',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <img
                    src={moduleContent['option2-media']}
                    alt=""
                    style={{ maxWidth: '15vw', maxHeight: '15vw' }}
                  />
                </div>
              )}
              {moduleContent.option2 === 'question' && !moduleCompleted && (
                <ModuleQuestion
                  question={{
                    value: moduleContent['option2-questionDescription'],
                    type: moduleContent['option2-type'],
                    options: moduleContent['option2-value'],
                    questions: moduleContent.questions,
                    orientation: moduleContent['option2-orientation'],
                  }}
                  currentPage={currentPage}
                  moduleId={moduleId}
                  title={moduleContent.content}
                  onUpdate={handleUpdateFromModuleQuestion}
                />
              )}
              {moduleContent.option2 === 'rich-text' && (
                <h2
                  dangerouslySetInnerHTML={{
                    __html: DOMPurify.sanitize(moduleContent['option2-rich-text']),
                  }}
                />
              )}
            </div>
          </div>
        </Paper>
      )}

      {moduleContent.layout === 'four-squares' && (
        <Paper style={{ fourSquares, width: '50vw', height: '30vw', overflowY: 'auto' }}>
          <div
            style={{
              gridColumn: '1 / -1',
              textAlign: 'center',
              marginBottom: '20px',
            }}
          >
            <h2>{moduleContent.content}</h2>

            {moduleContent.content === 'End of Module Activity' && (
              <h2>Reflection Available At: {timeToOpen}</h2>
            )}

            <h3
              style={{ fontSize: '1rem' }}
              dangerouslySetInnerHTML={{
                __html: DOMPurify.sanitize(moduleContent.pageDescription),
              }}
            />

            {dataPipe && (
              <div>
                <h3>
                  Previously, we saw you selected this response:{' '}
                  {dataPipe.answer.includes(',')
                    ? dataPipe.answer
                        .split(',')
                        .map(item => item.trim())
                        .join(', ')
                    : dataPipe.answer}
                  , to this question:
                  <span> {dataPipe.question.slice(3, -4)}</span>
                </h3>
              </div>
            )}
          </div>

          <div style={{ gridRow: '2 / 3', gridColumn: '1 / 2', textAlign: 'left' }}>
            {moduleContent.option1 === 'media' && (
              <div
                style={{
                  width: '15vw',
                  height: '15vw',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <img
                  src={moduleContent['option1-media']}
                  alt=""
                  style={{ maxWidth: '15vw', maxHeight: '15vw' }}
                />
              </div>
            )}
            {moduleContent.option1 === 'question' && !moduleCompleted && (
              <ModuleQuestion
                question={{
                  value: moduleContent['option1-questionDescription'],
                  type: moduleContent['option1-type'],
                  options: moduleContent['option1-value'],
                  questions: moduleContent.questions,
                  orientation: moduleContent['option1-orientation'],
                }}
                currentPage={currentPage}
                moduleId={moduleId}
                title={moduleContent.content}
                onUpdate={handleUpdateFromModuleQuestion}
              />
            )}
            {moduleContent.option1 === 'rich-text' && (
              <h2
                dangerouslySetInnerHTML={{
                  __html: DOMPurify.sanitize(moduleContent['option1-rich-text']),
                }}
              />
            )}
          </div>

          <div style={{ gridRow: '2 / 3', gridColumn: '2 / 3', textAlign: 'right' }}>
            {moduleContent.option2 === 'media' && (
              <div
                style={{
                  width: '15vw',
                  height: '15vw',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <img
                  src={moduleContent['option2-media']}
                  alt=""
                  style={{ maxWidth: '15vw', maxHeight: '15vw' }}
                />
              </div>
            )}
            {moduleContent.option2 === 'question' && !moduleCompleted && (
              <ModuleQuestion
                question={{
                  value: moduleContent['option2-questionDescription'],
                  type: moduleContent['option2-type'],
                  options: moduleContent['option2-value'],
                  questions: moduleContent.questions,
                  orientation: moduleContent['option2-orientation'],
                }}
                currentPage={currentPage}
                moduleId={moduleId}
                title={moduleContent.content}
                onUpdate={handleUpdateFromModuleQuestion}
              />
            )}
            {moduleContent.option2 === 'rich-text' && (
              <h2
                dangerouslySetInnerHTML={{
                  __html: DOMPurify.sanitize(moduleContent['option2-rich-text']),
                }}
              />
            )}
          </div>

          <div style={{ gridRow: '3 / 4', gridColumn: '1 / 2', textAlign: 'left' }}>
            {moduleContent.option3 === 'media' && (
              <div
                style={{
                  width: '15vw',
                  height: '15vw',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <img
                  src={moduleContent['option3-media']}
                  alt=""
                  style={{ maxWidth: '15vw', maxHeight: '15vw' }}
                />
              </div>
            )}
            {moduleContent.option3 === 'question' && !moduleCompleted && (
              <ModuleQuestion
                question={{
                  value: moduleContent['option3-questionDescription'],
                  type: moduleContent['option3-type'],
                  options: moduleContent['option3-value'],
                  questions: moduleContent.questions,
                  orientation: moduleContent['option3-orientation'],
                }}
                currentPage={currentPage}
                moduleId={moduleId}
                title={moduleContent.content}
                onUpdate={handleUpdateFromModuleQuestion}
              />
            )}
            {moduleContent.option3 === 'rich-text' && (
              <h2
                dangerouslySetInnerHTML={{
                  __html: DOMPurify.sanitize(moduleContent['option3-rich-text']),
                }}
              />
            )}
          </div>

          <div style={{ gridRow: '3 / 4', gridColumn: '2 / 3', textAlign: 'right' }}>
            {moduleContent.option4 === 'media' && (
              <div
                style={{
                  width: '15vw',
                  height: '15vw',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <img
                  src={moduleContent['option4-media']}
                  alt=""
                  style={{ maxWidth: '15vw', maxHeight: '15vw' }}
                />
              </div>
            )}
            {moduleContent.option4 === 'question' && !moduleCompleted && (
              <ModuleQuestion
                question={{
                  value: moduleContent['option4-questionDescription'],
                  type: moduleContent['option4-type'],
                  options: moduleContent['option4-value'],
                  questions: moduleContent.questions,
                  orientation: moduleContent['option4-orientation'],
                }}
                currentPage={currentPage}
                moduleId={moduleId}
                title={moduleContent.content}
                onUpdate={handleUpdateFromModuleQuestion}
              />
            )}
            {moduleContent.option4 === 'rich-text' && (
              <h2
                dangerouslySetInnerHTML={{
                  __html: DOMPurify.sanitize(moduleContent['option4-rich-text']),
                }}
              />
            )}
          </div>
        </Paper>
      )}
    </div>
  );
};

/*Styles for Paper depending on what orientation is chosen */
const topCenterBottom = {
  width: '90wh',
  aspectRatio: '1 / 1',
  margin: '30px auto',
  padding: '20px',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
};

const topBottom = {
  width: '90wh',
  aspectRatio: '1 / 1',
  margin: '25px auto',
  padding: '20px',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
};

const leftCenterRight = {
  width: '90wh',
  aspectRatio: '1 / 1',
  margin: '25px auto',
  padding: '20px',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
};

const leftRightCenterBottom = {
  width: '90wh',
  aspectRatio: '1 / 1',
  margin: '25px auto',
  padding: '20px',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
};

const leftRight = {
  width: '90wh',
  aspectRatio: '1 / 1',
  margin: '25px auto',
  padding: '20px',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
};

const fourSquares = {
  width: '90wh',
  margin: '25px auto',
  padding: '20px',
  display: 'grid',
  gridTemplateRows: 'auto 1fr',
  gridTemplateColumns: '1fr 1fr',
  gap: '20px',
};

const emptyPage = {
  width: '90wh',
  margin: '25px auto',
  padding: '40px',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  minHeight: '200px',
};

export default ModulePiece;
