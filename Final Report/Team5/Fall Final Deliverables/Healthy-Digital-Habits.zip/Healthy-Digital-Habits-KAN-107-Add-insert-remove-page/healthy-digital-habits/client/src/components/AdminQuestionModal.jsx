import React from 'react';
import {
  Modal,
  Box,
  Button,
  Checkbox,
  Switch,
  FormControlLabel,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Typography,
} from '@mui/material';
import ReactQuill from 'react-quill';
import TextField from '@mui/material/TextField';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import ForkRightIcon from '@mui/icons-material/ForkRight';
import WarningIcon from '@mui/icons-material/Warning';

const noop = () => {};

const AdminQuestionModal = ({
  open,
  onClose,
  onConfirm,
  itemName,
  itemType = 'item',
  AddModuleButton = 'Add Module',
  SaveExitButton = 'Cancel',
  initialQuestionData = null,
  onConvertToLesson = noop,
}) => {
  const [questions, setQuestions] = React.useState(['', '']);
  const [isMultipleChoice, setIsMultipleChoice] = React.useState(true);
  const [isShortAnswer, setIsShortAnswer] = React.useState(false);
  const [questionText, setQuestionText] = React.useState('');
  const [correctAnswers, setCorrectAnswers] = React.useState({}); // For multiple choice: track which answers are correct
  const [enableBranching, setEnableBranching] = React.useState(false); // State for branching toggle
  const [warningDialogOpen, setWarningDialogOpen] = React.useState(false);
  const [pendingChange, setPendingChange] = React.useState(null); // Store the pending checkbox change
  const [convertSwitchChecked, setConvertSwitchChecked] = React.useState(true);

  React.useEffect(() => {
    if (!open) return;

    const resolvedType =
      initialQuestionData?.questionType === 'short-answer' ? 'short-answer' : 'multiple-choice';
    setIsMultipleChoice(resolvedType === 'multiple-choice');
    setIsShortAnswer(resolvedType === 'short-answer');
    setQuestionText(initialQuestionData?.questionText || '');
    setEnableBranching(!!initialQuestionData?.enableBranching);

    if (resolvedType === 'short-answer') {
      setQuestions([initialQuestionData?.shortAnswer || '']);
      setCorrectAnswers({});
    } else {
      const initialChoices =
        Array.isArray(initialQuestionData?.choices) && initialQuestionData.choices.length
          ? initialQuestionData.choices
          : ['', ''];
      setQuestions(initialChoices);
      const initialCorrectAnswers = {};
      (initialQuestionData?.correctAnswers || []).forEach(index => {
        initialCorrectAnswers[index] = true;
      });
      setCorrectAnswers(initialCorrectAnswers);
    }
    setConvertSwitchChecked(true);
  }, [open, initialQuestionData]);

  const handleClose = event => {
    event?.stopPropagation();
    onClose();
  };

  const handleConfirm = () => {
    // Check if multiple choice and short answer are not selected at the same time
    if (isMultipleChoice && isShortAnswer) {
      // Handle the condition where both are not selected
      return;
    }

    const normalizedChoices = questions.map(choice => choice.trim());
    const payload = {
      questionText: questionText.trim(),
      questionType: isShortAnswer ? 'short-answer' : 'multiple-choice',
      choices: isMultipleChoice ? normalizedChoices : [],
      shortAnswer: isShortAnswer ? normalizedChoices[0] || '' : '',
      correctAnswers: isMultipleChoice
        ? Object.keys(correctAnswers)
            .filter(key => correctAnswers[key])
            .map(key => Number(key))
        : [],
      enableBranching,
    };

    onConfirm(payload);
    handleClose();
  };

  // Check if there's any data that would be lost
  const hasDataFilled = () => {
    const hasQuestionText = questionText.trim().length > 0;
    const hasChoices = questions.some(q => q.trim().length > 0);
    const hasCorrectAnswers = Object.keys(correctAnswers).some(key => correctAnswers[key]);
    return hasQuestionText || hasChoices || hasCorrectAnswers;
  };

  const handleMultipleChoiceChange = event => {
    const checked = event.target.checked;

    // Prevent unchecking if it would leave both unchecked
    if (!checked && !isShortAnswer) {
      return; // Don't allow unchecking if short answer is also unchecked
    }

    // If switching from short answer to multiple choice and there's data, show warning
    if (checked && isShortAnswer && hasDataFilled()) {
      setPendingChange({ type: 'multipleChoice', checked: true });
      setWarningDialogOpen(true);
      return;
    }

    // No data or same category, proceed with change
    setIsMultipleChoice(checked);
    if (checked) {
      setIsShortAnswer(false);
      // Reset questions for multiple choice format
      setQuestions(['', '']);
      setCorrectAnswers({});
    }
  };

  const handleShortAnswerChange = event => {
    const checked = event.target.checked;

    // Prevent unchecking if it would leave both unchecked
    if (!checked && !isMultipleChoice) {
      return; // Don't allow unchecking if multiple choice is also unchecked
    }

    // If switching from multiple choice to short answer and there's data, show warning
    if (checked && isMultipleChoice && hasDataFilled()) {
      setPendingChange({ type: 'shortAnswer', checked: true });
      setWarningDialogOpen(true);
      return;
    }

    // No data or same category, proceed with change
    setIsShortAnswer(checked);
    if (checked) {
      setIsMultipleChoice(false);
      // Reset questions for short answer format
      setQuestions(['']);
      setCorrectAnswers({});
    }
  };

  const handleConfirmWarning = () => {
    if (pendingChange) {
      if (pendingChange.type === 'multipleChoice') {
        setIsMultipleChoice(true);
        setIsShortAnswer(false);
        setQuestions(['', '']);
        setCorrectAnswers({});
      } else if (pendingChange.type === 'shortAnswer') {
        setIsShortAnswer(true);
        setIsMultipleChoice(false);
        setQuestions(['']);
        setCorrectAnswers({});
      }
    }
    setWarningDialogOpen(false);
    setPendingChange(null);
  };

  const handleCancelWarning = () => {
    setWarningDialogOpen(false);
    setPendingChange(null);
  };

  const handleCorrectAnswerToggle = index => {
    setCorrectAnswers(prev => ({
      ...prev,
      [index]: !prev[index],
    }));
  };

  const handleConvertSwitchChange = event => {
    const { checked } = event.target;
    if (!checked) {
      onConvertToLesson({
        questionText,
        questionType: isShortAnswer ? 'short-answer' : 'multiple-choice',
        choices: [...questions],
        shortAnswer: isShortAnswer ? questions[0] || '' : '',
        correctAnswers: Object.keys(correctAnswers)
          .filter(key => correctAnswers[key])
          .map(key => Number(key)),
        enableBranching,
      });
      setConvertSwitchChecked(true);
    }
  };
  return (
    <>
      <Modal open={open} onClose={handleClose}>
        <Box
          sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            height: 700,
            width: 800,
            maxHeight: '90vh',
            bgcolor: 'background.paper',
            boxShadow: 24,
            borderRadius: 2,
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
          }}
        >
          {/* Header Section - Fixed */}
          <Box sx={{ p: 4, pb: 2, flexShrink: 0 }}>
            <TextField
              fullWidth
              label="Page Title"
              variant="outlined"
              sx={{
                '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'success.main',
                },
                '& .MuiInputLabel-root.Mui-focused': {
                  color: 'success.main',
                },
              }}
            />
            <Box
              sx={{
                display: 'flex',
                marginTop: '1rem',
                flexDirection: 'column',
                alignItems: 'flex-end',
                gap: 1,
              }}
            >
              <FormControlLabel
                control={
                  <Switch
                    color="success"
                    checked={convertSwitchChecked}
                    onChange={handleConvertSwitchChange}
                  />
                }
                label="Convert to Question"
              />
              <FormControlLabel
                control={
                  <Switch
                    checked={enableBranching}
                    onChange={e => setEnableBranching(e.target.checked)}
                    color="success"
                  />
                }
                label="Enable Branching"
              />
            </Box>
            <Box sx={{ mt: 2, display: 'flex', gap: 2, alignItems: 'center' }}>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={isMultipleChoice}
                    onChange={handleMultipleChoiceChange}
                    color="success"
                  />
                }
                label="Multiple Choice"
              />
              <FormControlLabel
                control={
                  <Checkbox
                    checked={isShortAnswer}
                    onChange={handleShortAnswerChange}
                    color="success"
                  />
                }
                label="Short Answer"
              />
            </Box>
            <Typography variant="subtitle2" sx={{ mb: 1 }}>
              Question Field
            </Typography>
            <ReactQuill
              theme="snow"
              fullWidth
              label="Question"
              variant="outlined"
              sx={{
                mt: 2,
                '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
                  borderColor: 'success.main',
                },
                '& .MuiInputLabel-root.Mui-focused': {
                  color: 'success.main',
                },
              }}
              onChange={e => setQuestionText(e)}
            />
          </Box>

          {/* Scrollable Content Section */}
          <Box
            sx={{
              flex: 1,
              overflowY: 'auto',
              px: 4,
              pb: 2,
            }}
          >
            {/* Multiple Choice Question Input */}
            {isMultipleChoice && (
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                {questions.map((question, i) => (
                  <Box
                    key={i}
                    sx={{ display: 'flex', alignItems: 'center', gap: 2, position: 'relative' }}
                  >
                    <Checkbox
                      checked={correctAnswers[i] || false}
                      onChange={() => handleCorrectAnswerToggle(i)}
                      sx={{ mt: 0 }}
                      color="success"
                    />
                    <TextField
                      style={{ flex: 1 }}
                      label={`Choice ${i + 1}`}
                      variant="outlined"
                      value={questions[i]}
                      onChange={e =>
                        setQuestions(prevQuestions => [
                          ...prevQuestions.slice(0, i),
                          e.target.value,
                          ...prevQuestions.slice(i + 1),
                        ])
                      }
                      sx={{
                        '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
                          borderColor: 'success.main',
                        },
                        '& .MuiInputLabel-root.Mui-focused': {
                          color: 'success.main',
                        },
                      }}
                    />
                    {questions.length > 2 && (
                      <Button
                        onClick={() => {
                          setQuestions(prevQuestions =>
                            prevQuestions.filter((_, idx) => idx !== i)
                          );
                          const newCorrectAnswers = { ...correctAnswers };
                          delete newCorrectAnswers[i];
                          // Reindex correct answers
                          const reindexed = {};
                          Object.keys(newCorrectAnswers).forEach(key => {
                            const keyNum = parseInt(key);
                            if (keyNum > i) {
                              reindexed[keyNum - 1] = newCorrectAnswers[key];
                            } else if (keyNum < i) {
                              reindexed[keyNum] = newCorrectAnswers[key];
                            }
                          });
                          setCorrectAnswers(reindexed);
                        }}
                        variant="outlined"
                        color="error"
                        sx={{ minWidth: '40px' }}
                      >
                        <DeleteIcon />
                      </Button>
                    )}
                    {enableBranching && (
                      <>
                        <select
                          id={`dropdown-${i}`}
                          style={{
                            width: '10rem',
                            height: '2.5rem',
                            borderRadius: '5px',
                          }}
                        >
                          <option value="">Select Path</option>
                        </select>
                        <ForkRightIcon />
                      </>
                    )}
                  </Box>
                ))}
                <Button
                  onClick={() => setQuestions(prev => [...prev, ''])}
                  variant="outlined"
                  color="success"
                  startIcon={<AddIcon />}
                  sx={{ alignSelf: 'flex-start', mt: 1 }}
                >
                  Add Choice
                </Button>
              </Box>
            )}

            {/* Short Answer Question Input */}
            {isShortAnswer && (
              <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <TextField
                  fullWidth
                  label="Answer (for reference - do not fill in)"
                  variant="outlined"
                  multiline
                  rows={4}
                  value={questions[0] || ''}
                  onChange={e => setQuestions([e.target.value])}
                  placeholder="Enter the expected answer or leave blank for open-ended response"
                  sx={{
                    '& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
                      borderColor: 'success.main',
                    },
                    '& .MuiInputLabel-root.Mui-focused': {
                      color: 'success.main',
                    },
                  }}
                />
              </Box>
            )}
          </Box>

          {/* Footer Section - Fixed */}
          <Box
            sx={{
              p: 4,
              pt: 2,
              display: 'flex',
              justifyContent: 'flex-end',
              gap: 2,
              borderTop: '1px solid',
              borderColor: 'divider',
              flexShrink: 0,
            }}
          >
            <Button style={{ color: 'green' }} onClick={onClose}>
              {SaveExitButton}
            </Button>
            <Button onClick={onConfirm} variant="contained" color="success">
              {AddModuleButton}
            </Button>
          </Box>
        </Box>
      </Modal>

      {/* Warning Dialog - Outside Modal to avoid nesting issues */}
      <Dialog open={warningDialogOpen} onClose={handleCancelWarning}>
        <DialogTitle>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
            <WarningIcon sx={{ color: 'error.main' }} />
            <Typography variant="h6">Warning</Typography>
          </Box>
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            You have filled out fields in this question. Switching will cause this data to be lost
            (Question field will remain unchanged).
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button style={{ color: 'black' }} onClick={handleCancelWarning}>
            Cancel
          </Button>
          <Button onClick={handleConfirmWarning} variant="contained" color="success">
            I Understand
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default AdminQuestionModal;
