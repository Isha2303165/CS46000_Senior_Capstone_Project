import useMediaQuery from '@mui/material/useMediaQuery';
import { jwtDecode as jwt_decode } from 'jwt-decode';
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import NavBar from '../shared/NavBar';
import CurrentModule from './CurrentModule';
import Feed from './Feed';
import ProgressReport from './ProgressReport';
import ToDoList from './ToDoList';
import { CardOverflow } from '@mui/joy';

const DashboardContent = () => {
  const navigate = useNavigate();
  const isSmallScreen = useMediaQuery('(max-width:600px)');

  const containerStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    marginTop: '5rem',
    maxWidth: '100vw',
    maxheight: '80vh',
    paddingBottom: '1rem',
    backgroundColor: '#F5F5F5', // Light gray background
    minHeight: '100vh',
  };

  const sideBySideContainerStyle = {
    display: 'flex',
    flexDirection: isSmallScreen ? 'column' : 'row',
    gap: '.8rem',
    justifyContent: 'space-between',
    height: '30vh',
    marginTop: '3.8rem',
    marginBottom: '.8rem',
    width: '90vw',
  };

  useEffect(() => {
    const token = localStorage.getItem('token');

    // Check if token exists
    if (!token) {
      // Redirect to login if token is missing
      navigate('/login');
      return;
    }

    try {
      // Decode the token to check if it's valid
      const decodedToken = jwt_decode(token);

      // Optionally, you can check if the token is expired
      const currentTime = Date.now() / 1000;
      if (decodedToken.exp < currentTime) {
        // Token is expired, redirect to login
        localStorage.removeItem('token');
        navigate('/login');
      } else if (decodedToken.type !== 'parent') {
        localStorage.removeItem('token');
        navigate('/login');
      }
    } catch (err) {
      console.error('Invalid token', err);
      localStorage.removeItem('token');
      navigate('/login');
    }
  }, [navigate]);

  return (
    <div style={containerStyle}>
      <NavBar />
      <Feed />
      <div style={sideBySideContainerStyle}>
        <CurrentModule />
        <ToDoList />
      </div>
      <ProgressReport />
    </div>
  );
};

export default DashboardContent;
