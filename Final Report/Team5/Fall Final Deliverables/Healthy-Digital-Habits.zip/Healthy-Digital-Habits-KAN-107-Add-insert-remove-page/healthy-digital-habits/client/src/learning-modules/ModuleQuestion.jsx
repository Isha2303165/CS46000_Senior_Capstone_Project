import Button from '@mui/material/Button';
import Checkbox from '@mui/material/Checkbox';
import FormControl from '@mui/material/FormControl';
import FormControlLabel from '@mui/material/FormControlLabel';
import Paper from '@mui/material/Paper';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import Snackbar from '@mui/material/Snackbar';
import TextField from '@mui/material/TextField';
import axios from 'axios';
import DOMPurify from 'dompurify';
import { jwtDecode as jwt_decode } from 'jwt-decode';
import React, { useEffect, useState } from 'react';
import './Module.css';

const ModuleQuestion = ({ question, currentPage, moduleId, title, onUpdate }) => {
  const [answer, setAnswer] = useState();
  const [defaultAnswer, setDefaultAnswer] = useState('');
  const [multiAnswer, setMultiAnswer] = useState([]);
  const [answerData, setAnswerData] = useState();
  const [userId, setDecodedUserId] = useState();
  const [optionsArray, setOptionsArray] = useState([]);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [course, setCourse] = useState('');
  const [topic, setTopic] = useState('');
  const processedFillInBlanks = (question?.value || '').replace(/___/g, (_, index) => {
    return `<input type="text" id="blank-${index} style="border: 1px solid #ccc; padding: 4px;" />`;
  });

  useEffect(() => {
    if (question && Array.isArray(question.options)) {
      setOptionsArray(question.options);
    } else {
      setOptionsArray([]);
    }
  }, [question]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get(
          `${process.env.REACT_APP_API_BASE_URL}/api/allAnswers/${moduleId}/${userId}`
        );
        setAnswerData(res.data);

        const firstMatchingResponse = res.data.find(
          response => response.response.question === question.value
        );
        if (firstMatchingResponse) {
          setDefaultAnswer(firstMatchingResponse.response.answer);
        }

        const coursesRes = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/courses/all`);

        let topicOfModule = 'No Topic';
        let courseOfModule = 'No Course';
        for (const course of coursesRes.data) {
          for (const topic of course.topics) {
            const res = await axios.get(
              `${process.env.REACT_APP_API_BASE_URL}/api/topics/oneTopic?topic=${topic}`
            );
            for (const module of res.data.modules) {
              if (module === moduleId) {
                topicOfModule = topic;
                courseOfModule = course.title;
              }
            }
          }
        }

        setTopic(topicOfModule);
        setCourse(courseOfModule);
      } catch (error) {
        console.error('Error: ', error);
      }
    };

    fetchData();
  }, [moduleId, userId]);

  useEffect(() => {
    const updateCurrentPage = async () => {
      const token = localStorage.getItem('token');
      if (token) {
        try {
          const decoded = jwt_decode(token);
          setDecodedUserId(decoded.uname);
        } catch (error) {
          console.error('Invalid token', error);
        }
      }
    };

    updateCurrentPage();
  }, []);

  const handleChange = e => {
    let val = e.target.value;
    setAnswer(val);
  };

  const handleChangeMulti = option => {
    setMultiAnswer(prevAnswers => {
      if (prevAnswers.includes(option)) {
        return prevAnswers.filter(answer => answer !== option);
      } else {
        return [...prevAnswers, option];
      }
    });
  };

  const handleSave = (q, a) => {
    onUpdate({ question: q, answer: a });

    let data = {
      course: course,
      topic: topic,
      moduleId: moduleId,
      userId: userId,
      response: {
        pages: currentPage,
        question: q,
        answer: a,
      },
    };

    axios
      .post(`${process.env.REACT_APP_API_BASE_URL}/api/answer`, { data: data })
      .then(() => {
        setSnackbarMessage('Answer saved successfully!');
        setSnackbarOpen(true);
      })
      .catch(err => console.log(err));
  };

  const handleSnackbarClose = () => {
    setSnackbarOpen(false);
  };

  if (question.type != '') {
    if (question?.type === 'Essay' && title != 'End of Module Activity') {
      if (defaultAnswer) {
        return (
          <div className="mq-container">
            <Paper style={{ display: 'flex', flexDirection: 'column', textAlign: 'center' }}>
              <div
                style={{ minWidth: '20%', fontSize: '18px' }}
                dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(question.value) }}
              />
              <TextField
                onChange={handleChange}
                label=""
                multiline
                rows={3}
                value={defaultAnswer}
              />
              <Button
                disabled={Boolean(defaultAnswer)}
                variant="contained"
                onClick={() => handleSave(question.value, answer)}
              >
                Save
              </Button>
            </Paper>

            {/* Snackbar for confirmation */}
            <Snackbar
              open={snackbarOpen}
              autoHideDuration={6000}
              onClose={handleSnackbarClose}
              message={snackbarMessage}
            />
          </div>
        );
      } else {
        return (
          <div className="mq-container">
            <Paper style={{ display: 'flex', flexDirection: 'column', textAlign: 'center' }}>
              <div
                style={{ minWidth: '20%', fontSize: '18px' }}
                dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(question.value) }}
              />
              <TextField onChange={handleChange} label="Type Here" multiline rows={3} />
              <Button
                disabled={Boolean(defaultAnswer)}
                variant="contained"
                onClick={() => handleSave(question.value, answer)}
              >
                Save
              </Button>
            </Paper>

            {/* Snackbar for confirmation */}
            <Snackbar
              open={snackbarOpen}
              autoHideDuration={6000}
              onClose={handleSnackbarClose}
              message={snackbarMessage}
            />
          </div>
        );
      }
    }

    if (question?.type === 'Single' && title != 'End of Module Activity') {
      if (defaultAnswer) {
        return (
          <div style={containerStyle}>
            <Paper>
              <FormControl>
                <div
                  className="mq-container"
                  dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(question.value) }}
                />
                <div style={{ color: 'white' }}>{defaultAnswer}</div>
                {question?.orientation === 'horizontal' && (
                  <RadioGroup row aria-label="Horizontal button group" value={defaultAnswer}>
                    {optionsArray.map((options, index) => (
                      <FormControlLabel
                        key={index}
                        onChange={handleChange}
                        value={options}
                        control={<Radio />}
                        label={options}
                      />
                    ))}
                  </RadioGroup>
                )}
                {question?.orientation !== 'horizontal' && (
                  <RadioGroup aria-label="Vertical button group" value={defaultAnswer}>
                    {optionsArray.map((options, index) => (
                      <FormControlLabel
                        key={index}
                        onChange={handleChange}
                        value={options}
                        control={<Radio />}
                        label={options}
                      />
                    ))}
                  </RadioGroup>
                )}
              </FormControl>
              <br />
              <Button
                disabled={Boolean(defaultAnswer)}
                onClick={() => handleSave(question.value, answer)}
                variant="contained"
                style={{ width: '100%' }}
              >
                Save
              </Button>
            </Paper>

            {/* Snackbar for confirmation */}
            <Snackbar
              open={snackbarOpen}
              autoHideDuration={6000}
              onClose={handleSnackbarClose}
              message={snackbarMessage}
            />
          </div>
        );
      } else {
        return (
          <div style={containerStyle}>
            <Paper>
              <FormControl>
                <div
                  className="mq-container"
                  dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(question.value) }}
                />
                {question?.orientation === 'horizontal' && (
                  <RadioGroup row aria-label="Horizontal button group">
                    {optionsArray.map((options, index) => (
                      <FormControlLabel
                        key={index}
                        onChange={handleChange}
                        value={options}
                        control={<Radio />}
                        label={options}
                      />
                    ))}
                  </RadioGroup>
                )}
                {question?.orientation !== 'horizontal' && (
                  <RadioGroup aria-label="Vertical button group">
                    {optionsArray.map((options, index) => (
                      <FormControlLabel
                        key={index}
                        onChange={handleChange}
                        value={options}
                        control={<Radio />}
                        label={options}
                      />
                    ))}
                  </RadioGroup>
                )}
              </FormControl>
              <br />
              <Button
                onClick={() => handleSave(question.value, answer)}
                variant="contained"
                style={{ width: '100%' }}
              >
                Save
              </Button>
            </Paper>

            {/* Snackbar for confirmation */}
            <Snackbar
              open={snackbarOpen}
              autoHideDuration={6000}
              onClose={handleSnackbarClose}
              message={snackbarMessage}
            />
          </div>
        );
      }
    }

    if (question?.type === 'Multi' && title !== 'End of Module Activity') {
      return (
        <div style={containerStyle}>
          <Paper>
            <FormControl>
              <div
                className="mq-container"
                dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(question.value) }}
              />
              {question?.orientation === 'horizontal' && (
                <RadioGroup row aria-label="Horizontal button group">
                  {optionsArray.map((option, index) => (
                    <FormControlLabel
                      key={index}
                      control={
                        <Checkbox
                          checked={multiAnswer.includes(option) || defaultAnswer.includes(option)}
                          onChange={() => handleChangeMulti(option)}
                        />
                      }
                      label={option}
                    />
                  ))}
                </RadioGroup>
              )}
              {question?.orientation !== 'horizontal' && (
                <RadioGroup aria-label="Vertical button group">
                  {optionsArray.map((option, index) => (
                    <FormControlLabel
                      key={index}
                      control={
                        <Checkbox
                          checked={multiAnswer.includes(option) || defaultAnswer == option}
                          onChange={() => handleChangeMulti(option)}
                        />
                      }
                      label={option}
                    />
                  ))}
                </RadioGroup>
              )}
            </FormControl>
            <br />
            <Button
              disabled={Boolean(defaultAnswer)}
              onClick={() => handleSave(question.value, multiAnswer.join(', '))}
              variant="contained"
              style={{ width: '100%' }}
            >
              Save
            </Button>
          </Paper>

          {/* Snackbar for confirmation */}
          <Snackbar
            open={snackbarOpen}
            autoHideDuration={6000}
            onClose={handleSnackbarClose}
            message={snackbarMessage}
          />
        </div>
      );
    }

    if (question?.type === 'FillInBlank' && title !== 'End of Module Activity') {
      return (
        <div className="fill-blank-prompt">
          <Paper
            style={{
              display: 'flex',
              flexDirection: 'column',
              textAlign: 'center',
              border: '2px solid #fff',
            }}
          >
            <div
              style={{ minWidth: '30%', marginBottom: '5px', fontSize: 'auto' }}
              dangerouslySetInnerHTML={{
                __html: DOMPurify.sanitize(
                  defaultAnswer ? question.value + defaultAnswer : processedFillInBlanks
                ),
              }}
            />
            <Button
              disabled={Boolean(defaultAnswer)}
              variant="contained"
              onClick={() => {
                const answers = Array.from(document.querySelectorAll('[id^=blank-]')).map(
                  input => input.value.trim() || ''
                );
                const formatted = answers.join(', ');
                handleSave(question.value, formatted);
              }}
              style={{ paddingRight: '1rem' }}
            >
              Save
            </Button>
          </Paper>

          <Snackbar
            open={snackbarOpen}
            autoHideDuration={6000}
            onClose={handleSnackbarClose}
            message={snackbarMessage}
          />
        </div>
      );
    }

    if (question?.type !== 'Empty' && title != 'End of Module Activity') {
      return <h2>Problem finding question.</h2>;
    }
  }

  if (question?.type === '' && title !== 'End of Module Activity') {
    const reflectionQuestions = Array.isArray(question.questions) ? question.questions : [];

    if (!reflectionQuestions.length) {
      return <div>No reflection questions available.</div>;
    }

    return reflectionQuestions.map((reflectionQuestion, idx) => {
      const reflectionOptions = Array.isArray(reflectionQuestion?.value)
        ? reflectionQuestion.value
        : [];

      if (reflectionQuestion?.type === 'Essay') {
        return (
          <div style={{ padding: '10px' }} key={`essay-${idx}`}>
            <Paper style={{ display: 'flex', flexDirection: 'column', textAlign: 'center' }}>
              <div
                style={{ minWidth: '20%', fontSize: '18px' }}
                dangerouslySetInnerHTML={{
                  __html: DOMPurify.sanitize(reflectionQuestion.description),
                }}
              />
              <TextField
                onChange={e => handleChange(e)}
                label="Type Here"
                multiline
                rows={3}
                value={defaultAnswer}
              />
              <Button
                variant="contained"
                onClick={() => handleSave(reflectionQuestion.description, answer)}
              >
                Save
              </Button>
            </Paper>

            {/* Snackbar for confirmation */}
            <Snackbar
              open={snackbarOpen}
              autoHideDuration={6000}
              onClose={handleSnackbarClose}
              message={snackbarMessage}
            />
          </div>
        );
      }

      if (reflectionQuestion?.type === 'Single') {
        return (
          <div style={{ padding: '10px' }} key={`single-${idx}`}>
            <Paper>
              <FormControl>
                <div
                  style={{ minWidth: '60%' }}
                  dangerouslySetInnerHTML={{
                    __html: DOMPurify.sanitize(reflectionQuestion.description),
                  }}
                />
                {reflectionQuestion?.orientation === 'horizontal' && (
                  <RadioGroup
                    row
                    aria-label="Horizontal button group"
                    onChange={e => handleChange(e)}
                  >
                    {reflectionOptions.map(option => (
                      <FormControlLabel
                        key={option}
                        value={option}
                        control={<Radio />}
                        label={option}
                      />
                    ))}
                  </RadioGroup>
                )}
                {reflectionQuestion?.orientation !== 'horizontal' && (
                  <RadioGroup aria-label="Vertical button group" onChange={e => handleChange(e)}>
                    {reflectionOptions.map(option => (
                      <FormControlLabel
                        key={option}
                        value={option}
                        control={<Radio />}
                        label={option}
                      />
                    ))}
                  </RadioGroup>
                )}
              </FormControl>
              <br />
              <Button
                onClick={() => handleSave(reflectionQuestion.description, answer)}
                variant="contained"
                style={{ width: '100%' }}
              >
                Save
              </Button>
            </Paper>

            {/* Snackbar for confirmation */}
            <Snackbar
              open={snackbarOpen}
              autoHideDuration={6000}
              onClose={handleSnackbarClose}
              message={snackbarMessage}
            />
          </div>
        );
      }

      if (reflectionQuestion?.type === 'Multi') {
        return (
          <div style={{ padding: '10px' }} key={`multi-${idx}`}>
            <Paper>
              <FormControl>
                <div
                  style={{ minWidth: '60%' }}
                  dangerouslySetInnerHTML={{
                    __html: DOMPurify.sanitize(reflectionQuestion.description),
                  }}
                />
                {reflectionQuestion?.orientation === 'horizontal' && (
                  <RadioGroup row aria-label="Horizontal button group">
                    {reflectionOptions.map(option => (
                      <FormControlLabel
                        key={option}
                        control={
                          <Checkbox
                            checked={multiAnswer.includes(option)}
                            onChange={() => handleChangeMulti(option)}
                          />
                        }
                        label={option}
                      />
                    ))}
                  </RadioGroup>
                )}
                {reflectionQuestion?.orientation !== 'horizontal' && (
                  <RadioGroup aria-label="Vertical button group">
                    {reflectionOptions.map(option => (
                      <FormControlLabel
                        key={option}
                        control={
                          <Checkbox
                            checked={multiAnswer.includes(option)}
                            onChange={() => handleChangeMulti(option)}
                          />
                        }
                        label={option}
                      />
                    ))}
                  </RadioGroup>
                )}
              </FormControl>
              <br />
              <Button
                onClick={() => handleSave(reflectionQuestion.description, multiAnswer.join(', '))}
                variant="contained"
                style={{ width: '100%' }}
              >
                Save
              </Button>
            </Paper>

            {/* Snackbar for confirmation */}
            <Snackbar
              open={snackbarOpen}
              autoHideDuration={6000}
              onClose={handleSnackbarClose}
              message={snackbarMessage}
            />
          </div>
        );
      }
    });
  }
};

const containerStyle = {
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  minHeight: '10%',
};

export default ModuleQuestion;
