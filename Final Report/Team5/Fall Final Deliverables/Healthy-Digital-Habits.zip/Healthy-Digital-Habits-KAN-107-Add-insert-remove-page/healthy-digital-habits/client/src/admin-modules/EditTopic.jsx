import { Button, Card, FormControl, MenuItem, Select, TextField, Typography } from '@mui/material';
import React from 'react';

const EditTopic = ({
  selectedTopicToEdit,
  handleTopicModuleFill,
  topics,
  selectedModulesForEdit,
  setSelectedModulesForEdit,
  convertModuleIdsToTitles,
  modules,
  moveUpModules,
  moveDownModules,
  selectedModulesForEditTitles,
  handleUpdateTopic,
  newTopicName,
  setNewTopicName,
}) => {
  return (
    <Card
      sx={{
        marginTop: '20px',
        padding: '20px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Typography variant="h6" sx={{ marginBottom: '20px' }}>
        Edit Topic
      </Typography>
      <FormControl
        fullWidth
        sx={{
          display: 'flex',
          alignItems: 'center',
        }}
      >
        <Typography variant="body1">Select Topic to Edit</Typography>
        <Select
          labelId="topic-edit-select-label"
          value={selectedTopicToEdit}
          onChange={e => handleTopicModuleFill(e)}
          style={{ width: '100%' }}
        >
          {topics.map(topic => (
            <MenuItem key={topic._id} value={topic.title}>
              {topic.title}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <br />
      <TextField
        label="New Topic Name"
        value={newTopicName}
        onChange={e => setNewTopicName(e.target.value)}
        style={{ width: '100%' }}
      />
      <br />
      <FormControl
        fullWidth
        sx={{
          display: 'flex',
          alignItems: 'center',
        }}
      >
        <Typography variant="body1">Select Modules</Typography>
        <Select
          labelId="modules-edit-select-label"
          multiple
          value={selectedModulesForEdit}
          onChange={e => {
            setSelectedModulesForEdit(e.target.value);
            convertModuleIdsToTitles(e.target.value);
          }}
          style={{ width: '100%' }}
        >
          {modules.map((mod, index) => (
            <MenuItem key={mod._id} value={mod._id}>
              <div
                style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}
              >
                {mod.title}
                <div>
                  <Button
                    onMouseDown={e => e.stopPropagation()}
                    onClick={() => moveUpModules(index)}
                    disabled={index === 0}
                  >
                    ↑
                  </Button>
                  <Button
                    onMouseDown={e => e.stopPropagation()}
                    onClick={() => moveDownModules(index)}
                    disabled={index === selectedModulesForEdit.length - 1}
                  >
                    ↓
                  </Button>
                </div>
              </div>
            </MenuItem>
          ))}
        </Select>
        {selectedModulesForEditTitles.length > 0 && (
          <Typography
            variant="body1"
            sx={{ margin: 'auto', marginTop: '10px', marginBottom: '10px' }}
          >
            Current Ordering: {selectedModulesForEditTitles.join(', ')}
          </Typography>
        )}
      </FormControl>
      <br />
      <Button variant="contained" onClick={handleUpdateTopic}>
        Update Topic
      </Button>
    </Card>
  );
};

export default EditTopic;
