import { jwtDecode as jwt_decode } from 'jwt-decode';
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import NavBar from '../shared/NavBar';
import ActiveUsers from './ActiveUsers';
import AverageLogins from './AverageLogins';
import PhoneUse from './AveragePhoneUse';
import ModuleCompletion from './ModuleCompletion';

const AdminDashboardContent = () => {
  const navigate = useNavigate();

  const containerStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'flex-start',
    minHeight: '100vh', // ensures full height
    width: '100vw', // ensures full width
    background: 'linear-gradient(180deg, #ffffff, #f4faf4)',
    backgroundRepeat: 'no-repeat',
    backgroundSize: 'cover', // makes gradient fill everything
  };

  useEffect(() => {
    const token = localStorage.getItem('token');

    // Check if token exists
    if (!token) {
      navigate('/login');
      return;
    }

    try {
      const decodedToken = jwt_decode(token);
      const currentTime = Date.now() / 1000;

      if (decodedToken.exp < currentTime || decodedToken.type === 'parent') {
        localStorage.removeItem('token');
        navigate('/login');
      }
    } catch (err) {
      console.error('Invalid token', err);
      localStorage.removeItem('token');
      navigate('/login');
    }
  }, [navigate]);

  return (
    <div style={containerStyle}>
      <NavBar />
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          marginTop: '5rem',
          paddingBottom: '5rem',
        }}
      >
        <PhoneUse />
        <div
          style={{
            display: 'flex',
            justifyContent: 'space-between',
            marginTop: '5rem',
            gap: '2vw',
            alignItems: 'center',
          }}
        >
          <ModuleCompletion />
          <ActiveUsers />
          <AverageLogins />
        </div>
      </div>
    </div>
  );
};

export default AdminDashboardContent;
