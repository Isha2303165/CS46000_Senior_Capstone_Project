import React, { createContext, useContext, useState } from 'react';

const CourseContext = createContext();

export const useCourse = () => {
  const context = useContext(CourseContext);
  if (!context) {
    throw new Error('useCourse must be used within a CourseProvider');
  }
  return context;
};

export const CourseProvider = ({ children }) => {
  const [coursesData, setCoursesData] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [topicsData, setTopicsData] = useState({});
  const [moduleDetails, setModuleDetails] = useState({});
  const [completedModules, setCompletedModules] = useState([]);
  const [completedTopics, setCompletedTopics] = useState([]);
  const [completedCourses, setCompletedCourses] = useState([]);
  //greys out behind modal
  const overlayStyle = {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    backgroundColor: 'rgba(0, 0, 0, 0.2)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  };

  //modal **will migreate the overlayStyle and modelStyle into a separate jsx for reusability**
  const modalStyle = {
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.2)',
    textAlign: 'center',
    width: '400px',
  };
  const value = {
    coursesData,
    setCoursesData,
    selectedCourse,
    setSelectedCourse,
    topicsData,
    setTopicsData,
    moduleDetails,
    setModuleDetails,
    completedModules,
    setCompletedModules,
    completedTopics,
    setCompletedTopics,
    completedCourses,
    setCompletedCourses,
    overlayStyle,
    modalStyle,
  };

  return <CourseContext.Provider value={value}>{children}</CourseContext.Provider>;
};
