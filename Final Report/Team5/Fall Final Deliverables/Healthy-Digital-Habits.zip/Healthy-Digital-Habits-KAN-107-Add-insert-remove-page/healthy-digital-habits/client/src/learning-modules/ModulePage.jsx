import React from 'react';
import DailyAffirmations from '../parent-dashboard/DailyAffirmations';
import NavBar from '../shared/NavBar';
import TopicsModule from './TopicsModule';
import { minHeight } from '@mui/system';

const ModulePage = () => {
  return (
    <>
      <NavBar />
      <div style={containerStyle}>
        <TopicsModule />
      </div>
    </>
  );
};

const containerStyle = {
  display: 'flex',
  flexDirection: 'column', // Stack content vertically
  minHeight: '100vh', // Ensure container takes up the full height of the viewport
  justifyContent: 'center', // Center content vertically
  alignItems: 'center', // Center content horizontally
  paddingBottom: '50px', // Add padding to the bottom of the page
};

export default ModulePage;
