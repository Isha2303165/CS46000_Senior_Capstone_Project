import { Button } from '@mui/material';
import EditNoteIcon from '@mui/icons-material/EditNote';

const editButtonSx = {
  width: '20rem',
  height: '4rem',
  borderRadius: 3,
  textTransform: 'none',
  fontSize: '1.1rem',
  fontWeight: 600,
  borderColor: '#6aa57a',
  borderWidth: '2px',
  color: '#6aa57a',
  '&:hover': {
    borderColor: '#5a936a',
    borderWidth: '2px',
    backgroundColor: 'rgba(106,165,122,0.1)',
  },
  boxShadow: '0px 2px 6px rgba(0,0,0,0.15)',
};

const noop = () => {};

export default function LayoutEditButtons({ layout, sections, onEditSection = noop }) {
  const sectionEntries = sections.map((label, index) => ({
    label,
    index,
    optionKey: `option${index + 1}`,
  }));

  // Special 3-part layout rule for "Left / Right / CenterBottom"
  const isLeftRightCenter = layout === 'option4';

  if (isLeftRightCenter) {
    const left = sectionEntries.find(s => s.label.toLowerCase().includes('left'));
    const right = sectionEntries.find(s => s.label.toLowerCase().includes('right'));
    const center = sectionEntries.find(s => s.label.toLowerCase().includes('center'));

    return (
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '1rem',
          marginTop: '2rem',
        }}
      >
        {/* Left + Right row */}
        <div style={{ display: 'flex', flexDirection: 'row', gap: '1rem' }}>
          {left && (
            <EditButton
              label={left.label}
              optionKey={left.optionKey}
              onEditSection={onEditSection}
            />
          )}
          {right && (
            <EditButton
              label={right.label}
              optionKey={right.optionKey}
              onEditSection={onEditSection}
            />
          )}
        </div>

        {/* Center section below */}
        {center && (
          <EditButton
            label={center.label}
            optionKey={center.optionKey}
            onEditSection={onEditSection}
          />
        )}
      </div>
    );
  }

  // Default dynamic layout (Top/Middle/Bottom, Left/Middle/Right, etc.)
  const isHorizontal = layout === 'option1' || layout === 'option3'; // LMR or LR

  return (
    <div
      style={{
        display: 'flex',
        flexDirection: isHorizontal ? 'row' : 'column',
        gap: '1rem',
        marginTop: '2rem',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      {sectionEntries.map(section => (
        <EditButton
          key={section.optionKey}
          label={section.label}
          optionKey={section.optionKey}
          onEditSection={onEditSection}
        />
      ))}
    </div>
  );
}

// Small subcomponent for consistent button styling
function EditButton({ label, optionKey, onEditSection }) {
  const handleClick = () => {
    onEditSection(optionKey, label);
  };

  return (
    <Button variant="outlined" sx={editButtonSx} endIcon={<EditNoteIcon />} onClick={handleClick}>
      {`Edit ${label}`}
    </Button>
  );
}
