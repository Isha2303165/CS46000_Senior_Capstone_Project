import { Box, Button, Container, createTheme, TextField, ThemeProvider, Typography } from '@mui/material';
import axios from 'axios';
import { jwtDecode as jwt_decode } from 'jwt-decode';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const PWD_REGEX =
  /^(?=.*[!@#$%^&*()_+[\]{};':"\\|,.<>?/-])[a-zA-Z0-9!@#$%^&*()_+[\]{};':"\\|,.<>?/-]{8,15}$/;

const interactableTheme = createTheme({
  palette: {
    primary: {
      main: '#4caf50',
    },
    tonalOffset: '0.3',
  }
});

const LoginPage = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [securityQuestion, setSecurityQuestion] = useState('');
  const [possibleSecurityAnswer, setPossibleSecurityAnswer] = useState('');
  const [securityAnswer, setSecurityAnswer] = useState('');
  const [response, setResponse] = useState('');
  const [errMsg, setErrMsg] = useState('');
  const navigate = useNavigate();

  const fetchUserData = async () => {
    try {
      setErrMsg('');
      const getResponse = await axios.get(
        `${process.env.REACT_APP_API_BASE_URL}/api/user?uname=${username}`
      );

      if (getResponse.status === 200) {
        setSecurityQuestion(getResponse.data[0].secq);
        setSecurityAnswer(getResponse.data[0].seca);
        setResponse(getResponse.data[0]);
      } else {
        setErrMsg("Can't find user");
      }
    } catch (error) {
      setErrMsg("Can't find user");
    }
  };

  const handleLogin = async () => {
    try {
      const response = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/login`, {
        params: { uname: username, upass: password },
      });

      const token = response.data.token;
      localStorage.setItem('token', token);

      // If login is successful, navigate to the dashboard and pass the username
      if (response.status === 200) {
        const decodedToken = jwt_decode(token);
        await axios.post(`${process.env.REACT_APP_API_BASE_URL}/api/user/logins?uname=${username}`);
        if (decodedToken.type === 'parent') {
          navigate('/dashboard');
        } else {
          navigate('/admin/dashboard');
        }
      }
    } catch (err) {
      console.error(err);
      setErrMsg('Username or password is incorrect');
    }
  };

  const checkSecurityAnswer = async () => {
    setErrMsg('');
    if (possibleSecurityAnswer == securityAnswer) {
      if (password != '' && password == confirmPassword && PWD_REGEX.test(password)) {
        const postResponse = await axios.put(
          `${process.env.REACT_APP_API_BASE_URL}/api/user/password?uname=${username}&password=${password}`
        );

        if (postResponse.status == 200) {
          handleLogin();
        }
      } else {
        setErrMsg("Password is not valid or passwords don't match");
      }
    } else {
      setErrMsg('Incorrect security answer');
    }
  };

  return (
    <Box component="main" sx={{
      p: 2, width: '100%', height: '100%',
      display: 'flex', justifyContent: 'center', alignItems: 'center',
      backgroundImage: "url('/loginbackground.jpeg')", backgroundSize: 'cover',
      backgroundPosition: 'center', backgroundAttachment: 'fixed'
    }}>
      <Container maxWidth="xs" sx={{ p: 2, border: '1px black', bgcolor: 'white', borderRadius: '5px' }}>
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
          <img
            src="/HDHLogo.png"
            alt="HDH Logo"
            style={{
              height: '50px',
              width: 'auto',
              objectFit: 'contain',
            }}
          />
          <div style={{ padding: '30px', textAlign: 'center' }}>
            {errMsg && (
              <Typography style={{ color: 'firebrick', fontWeight: 'bold' }} sx={{ mt: 2 }}>
                {errMsg}
              </Typography>
            )}
            <Box component="form" noValidate sx={{ mt: 1 }}>
              <ThemeProvider theme={interactableTheme}>
                {!securityQuestion && (
                  <>
                    <TextField
                      margin="normal"
                      required
                      fullWidth
                      id="username"
                      label="Username"
                      name="username"
                      autoComplete="username"
                      autoFocus
                      value={username}
                      onChange={e => setUsername(e.target.value)}
                    />
                    <Button
                      fullWidth
                      variant="contained"
                      color="primary"
                      sx={{ mt: 3, mb: 2, width: '100%', color: 'white', bgcolor: 'primary', ":hover": { bgcolor: 'primary.light' } }}
                      onClick={fetchUserData}
                    >
                      Search
                    </Button>
                  </>
                )}
                {securityQuestion && (
                  <>
                    <Typography sx={{ mt: 2 }}>{securityQuestion}</Typography>
                    <TextField
                      margin="normal"
                      required
                      fullWidth
                      id="securityAnswer"
                      label="Security Answer"
                      name="securityAnswer"
                      autoComplete="securityAnswer"
                      autoFocus
                      value={possibleSecurityAnswer}
                      onChange={e => setPossibleSecurityAnswer(e.target.value)}
                    />
                    <TextField
                      margin="normal"
                      required
                      fullWidth
                      name="password"
                      label="Password"
                      type="password"
                      id="password"
                      autoComplete="new-password"
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      helperText={
                        !PWD_REGEX.test(password)
                          ? 'Password must be 8-15 characters long and include at least one special character (!@#$%^&*)'
                          : ''
                      }
                    />
                    <TextField
                      margin="normal"
                      required
                      fullWidth
                      name="confirmPassword"
                      label="Confirm Password"
                      type="password"
                      id="confirmPassword"
                      autoComplete="new-password"
                      value={confirmPassword}
                      onChange={e => setConfirmPassword(e.target.value)}
                      error={password != confirmPassword}
                      helperText={password != confirmPassword ? 'Passwords do not match' : ''}
                    />
                    <Button
                      fullWidth
                      variant="contained"
                      color="primary"
                      sx={{ mt: 3, mb: 2, width: '100%' }}
                      onClick={checkSecurityAnswer}
                    >
                      Reset Password
                    </Button>
                  </>
                )}
              </ThemeProvider>
            </Box>
          </div>
        </Box>
      </Container>
    </Box>
  );
};

export default LoginPage;
