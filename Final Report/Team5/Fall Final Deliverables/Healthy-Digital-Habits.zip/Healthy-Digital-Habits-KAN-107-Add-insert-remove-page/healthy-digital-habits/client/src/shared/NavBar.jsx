import AccountCircle from '@mui/icons-material/AccountCircle';
import MenuIcon from '@mui/icons-material/Menu';
import Notifications from '@mui/icons-material/Notifications';
import {
  AppBar,
  Box,
  Button,
  Divider,
  FormControlLabel,
  Menu,
  MenuItem,
  Modal,
  Radio,
  RadioGroup,
  Slider,
  Stack,
  styled,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Toolbar,
  Typography,
  useMediaQuery,
} from '@mui/material';
import axios from 'axios';
import { jwtDecode as jwt_decode } from 'jwt-decode';
import React, { useCallback, useEffect, useLayoutEffect, useState, useRef } from 'react';
import { Link, useLocation } from 'react-router-dom';
import SurveyConfirmationModal from './DailySurvey';
import LogoutModal from './Logout';
import DailyAffirmations from '../parent-dashboard/DailyAffirmations';

export const APP_BAR_HEIGHT = 70;
const StyledAppBar = styled(AppBar)({
  maxWidth: '100%',
  height: `${APP_BAR_HEIGHT}px`,
  backgroundColor: '#FFFFFF',
  color: '#000000', // This will make inherit buttons use this color
});
const StyledToolbar = styled(Toolbar)({
  display: 'flex',
  justifyContent: 'space-between',
});

const closeButtonStyle = {
  position: 'absolute',
  top: '5%',
  right: '3%',
  color: 'white',
  backgroundColor: '#1A477F',
  fontSize: '20px',
  fontStyle: 'bold',
  height: '27px',
  borderRadius: '5px',
};

const SurveyModal = ({ isOpen, onClose }) => {
  const [decodedUsername, setDecodedUsername] = useState(null);
  const [submitAttempted, setSubmitAttempted] = useState(false);
  const [submitMessage, setSubmitMessage] = useState("");

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      try {
        const decoded = jwt_decode(token);
        setDecodedUsername(decoded.uname);
      } catch (error) {
        console.error('Invalid token', error);
      }
    }
  }, []);

  const fieldRefs = {
    question1: useRef(null),
    question2: useRef(null),
    question3: useRef(null),
    question4: useRef(null),
    question5: useRef(null),
    question6: useRef(null),
  }

  const [responses, setResponses] = useState({
    question1: '',
    question2: '',
    question3: '',
    question4: '',
    question5: '',
    question6: '',
  });

  const getFirstInvalidField = () => {
    if (!responses.question1) return fieldRefs.question1;
    if (!responses.question2) return fieldRefs.question2;
    if (!responses.question3) return fieldRefs.question3;
    if (!responses.question4) return fieldRefs.question4;
    if (!responses.question5) return fieldRefs.question5;
    if (!responses.question6) return fieldRefs.question6;
    return null;
  }

  const handleResponseChange = (question, value) => {
    setResponses(prevResponses => ({
      ...prevResponses,
      [question]: value,
    }));
  };

  const handleSubmit = () => {
    setSubmitAttempted(true);

    const firstInvalid = getFirstInvalidField();

    if (firstInvalid) {
      setSubmitMessage("Please respond to all questions.");
      firstInvalid.current?.scrollIntoView({
        behavior: "smooth",
        block: "center",
      })
      firstInvalid.current?.focus();
      return;
    }

    axios
      .post(`${process.env.REACT_APP_API_BASE_URL}/api/dashboard`, {
        Focus: responses.question1,
        Control: responses.question2,
        Empowerment: responses.question3,
        Guilt: responses.question4,
        ability: responses.question5,
        story: responses.question6,
        uname: decodedUsername,
      })
      .then(() => {
        // Refresh both the current dashboard page and the admin dashboard page after successful form submission
        window.location.reload();

        // Send a message to other tabs to reload the admin dashboard
        const reloadChannel = new BroadcastChannel('adminDashboardReload');
        reloadChannel.postMessage('reload');
      })
      .catch(err => console.log(err));
  };

  return (
    <Modal
      open={isOpen}
      onClose={onClose}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
      style={{ height: '80%', padding: '10px' }}
    >
      <Box
        sx={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '90%', // Responsive width
          maxWidth: '1500px',
          maxHeight: '70vh', // Responsive height
          bgcolor: 'background.paper',
          border: '2px solid white',
          boxShadow: 24,
          p: 4,
          overflowY: 'auto', // Enables scrolling
        }}
      >
        <Typography
          variant="h6"
          gutterBottom
          align="center"
          sx={{ fontWeight: 'bold', textDecoration: 'underline' }}
        >
          DAILY REFLECTION
        </Typography>

        <button onClick={onClose} style={closeButtonStyle}>
          X
        </button>

        <br />

        {/* Question 1 */}
        <Box sx={{ backgroundColor: '#CDE5F0', p: 2 }} ref={fieldRefs.question1}>
          <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
            Today, how focused were you on being <u>"fully present and aware"</u> when around your
            child?
          </Typography>
          <Typography variant="subtitle1">
            (e.g. avoided distraction, phone use did not interfere with your focus, etc.)
          </Typography>
          <br />

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 'bold', fontSize: '.75em' }}>
              Not at all focused / Very distracted
            </Typography>

            <Typography
              variant="subtitle2"
              sx={{ fontWeight: 'bold', fontSize: '.75em', textAlign: 'right' }}
            >
              Completely focused
            </Typography>
          </div>

          <Box sx={{ px: 2, py: 1 }}>
            <Slider
              aria-label="Question 1 slider"
              sx={{ color: '#4caf50' }}
              valueLabelDisplay="auto"
              valueLabelFormat={(value) =>
                responses.question1 === ''
                  ? "Select a number..."
                  : value
              }
              onChange={(e, val) => handleResponseChange('question1', `${val}`)}
              min={1}
              max={10}
              step={1}
              marks={[
                { value: 1, label: '1' },
                { value: 2, label: '2' },
                { value: 3, label: '3' },
                { value: 4, label: '4' },
                { value: 5, label: '5' },
                { value: 6, label: '6' },
                { value: 7, label: '7' },
                { value: 8, label: '8' },
                { value: 9, label: '9' },
                { value: 10, label: '10' },
              ]}
              error={!responses.question1}
            />
          </Box>

          <Typography sx={{ fontWeight: 'bold', fontSize: '2em', textAlign: 'center' }}>
            {responses.question1 === '' ? '--' : Number(responses.question1)}
          </Typography>

          <br />
        </Box>

        {/* Question 2 */}
        <Box sx={{ backgroundColor: 'white', p: 2 }} ref={fieldRefs.question2}>
          <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
            Today, how much did you feel <u>"in control"</u> of your phone use?
          </Typography>
          <Typography variant="subtitle1">
            (e.g., time spent, pick ups, getting stuck scrolling, avoiding unintended use)
          </Typography>
          <br />

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 'bold', fontSize: '.75em' }}>
              Phone use easily got
              <br /> away from me /<br /> fell into use
            </Typography>
            <Typography
              variant="subtitle2"
              sx={{ fontWeight: 'bold', fontSize: '.75em', textAlign: 'right' }}
            >
              Phone use was
              <br /> always my choice
              <br /> and intentional
            </Typography>
          </div>

          <Box sx={{ px: 2, py: 1 }}>
            <Slider
              aria-label="Question 2 slider"
              sx={{ color: '#4caf50' }}
              valueLabelDisplay="auto"
              valueLabelFormat={(value) =>
                responses.question2 === ''
                  ? "Select a number..."
                  : value
              }
              onChange={(e, val) => handleResponseChange('question2', `${val}`)}
              min={1}
              max={10}
              step={1}
              marks={[
                { value: 1, label: '1' },
                { value: 2, label: '2' },
                { value: 3, label: '3' },
                { value: 4, label: '4' },
                { value: 5, label: '5' },
                { value: 6, label: '6' },
                { value: 7, label: '7' },
                { value: 8, label: '8' },
                { value: 9, label: '9' },
                { value: 10, label: '10' },
              ]}
              error={!responses.question2}
            />
          </Box>

          <Typography sx={{ fontWeight: 'bold', fontSize: '2em', textAlign: 'center' }}>
            {responses.question2 === '' ? '--' : Number(responses.question2)}
          </Typography>

          <br />
        </Box>

        {/* Question 3 */}
        <Box sx={{ backgroundColor: '#CDE5F0', p: 2 }} ref={fieldRefs.question3}>
          <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
            Today, how much did you feel like your phone use <u>empowered/supported you</u> in your
            life and parenting?
          </Typography>
          <Typography variant="subtitle1">
            (e.g., connected you to others, helped with parenting info, helped you calm down, etc.)
          </Typography>
          <br />

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 'bold', fontSize: '.75em' }}>
              Not at all
            </Typography>
            <Typography variant="subtitle2" sx={{ fontWeight: 'bold', fontSize: '.75em' }}>
              Always
            </Typography>
          </div>

          <Box sx={{ px: 2, py: 1 }}>
            <Slider
              aria-label="Question 3 slider"
              sx={{ color: '#4caf50' }}
              valueLabelDisplay="auto"
              valueLabelFormat={(value) =>
                responses.question3 === ''
                  ? "Select a number..."
                  : value
              }
              onChange={(e, val) => handleResponseChange('question3', `${val}`)}
              min={1}
              max={10}
              step={1}
              marks={[
                { value: 1, label: '1' },
                { value: 2, label: '2' },
                { value: 3, label: '3' },
                { value: 4, label: '4' },
                { value: 5, label: '5' },
                { value: 6, label: '6' },
                { value: 7, label: '7' },
                { value: 8, label: '8' },
                { value: 9, label: '9' },
                { value: 10, label: '10' },
              ]}
              error={!responses.question3}
            />
          </Box>

          <Typography sx={{ fontWeight: 'bold', fontSize: '2em', textAlign: 'center' }}>
            {responses.question3 === '' ? '--' : Number(responses.question3)}
          </Typography>

          <br />
        </Box>

        {/* Question 4 */}
        <Box sx={{ backgroundColor: 'white', p: 2 }} ref={fieldRefs.question4}>
          <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
            Today, how much did you feel "guilty" about your phone use?
          </Typography>
          <br />

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 'bold', fontSize: '.75em' }}>
              Not at all
            </Typography>
            <Typography variant="subtitle2" sx={{ fontWeight: 'bold', fontSize: '.75em' }}>
              A lot
            </Typography>
          </div>

          <Box sx={{ px: 2, py: 1 }}>
            <Slider
              aria-label="Question 4 slider"
              sx={{ color: '#4caf50' }}
              valueLabelDisplay="auto"
              valueLabelFormat={(value) =>
                responses.question4 === ''
                  ? "Select a number..."
                  : value
              }
              onChange={(e, val) => handleResponseChange('question4', `${val}`)}
              min={1}
              max={10}
              step={1}
              marks={[
                { value: 1, label: '1' },
                { value: 2, label: '2' },
                { value: 3, label: '3' },
                { value: 4, label: '4' },
                { value: 5, label: '5' },
                { value: 6, label: '6' },
                { value: 7, label: '7' },
                { value: 8, label: '8' },
                { value: 9, label: '9' },
                { value: 10, label: '10' },
              ]}
              error={!responses.question4}
            />
          </Box>

          <Typography sx={{ fontWeight: 'bold', fontSize: '2em', textAlign: 'center' }}>
            {responses.question4 === '' ? '--' : Number(responses.question4)}
          </Typography>

          <br />
        </Box>

        {/* Question 5 */}
        <Box sx={{ backgroundColor: '#CDE5F0', p: 2 }} ref={fieldRefs.question5}>
          <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
            Today, when you wanted to change your phone use (or if you had wanted to), how much did
            you feel like you had the ability to change your use?
          </Typography>
          <br />

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 'bold', fontSize: '.75em' }}>
              Could not do
              <br /> at all
            </Typography>
            <Typography
              variant="subtitle2"
              sx={{ fontWeight: 'bold', fontSize: '.75em', textAlign: 'right' }}
            >
              Highly certain
              <br /> could do
            </Typography>
          </div>

          <Box sx={{ px: 2, py: 1 }}>
            <Slider
              aria-label="Question 5 slider"
              sx={{ color: '#4caf50' }}
              valueLabelDisplay="auto"
              valueLabelFormat={(value) =>
                responses.question5 === ''
                  ? "Select a number..."
                  : value
              }
              onChange={(e, val) => handleResponseChange('question5', `${val}`)}
              min={1}
              max={10}
              step={1}
              marks={[
                { value: 1, label: '1' },
                { value: 2, label: '2' },
                { value: 3, label: '3' },
                { value: 4, label: '4' },
                { value: 5, label: '5' },
                { value: 6, label: '6' },
                { value: 7, label: '7' },
                { value: 8, label: '8' },
                { value: 9, label: '9' },
                { value: 10, label: '10' },
              ]}
              error={!responses.question5}
            />
          </Box>

          <Typography sx={{ fontWeight: 'bold', fontSize: '2em', textAlign: 'center' }}>
            {responses.question5 === '' ? '--' : Number(responses.question5)}
          </Typography>

          <br />
        </Box>

        {/* Question 6 */}
        <Box sx={{ backgroundColor: 'white', p: 2 }} ref={fieldRefs.question6}>
          <Typography variant="subtitle1" sx={{ fontWeight: 'bold' }}>
            Please take a moment to describe why you felt and responded the way you did to these
            items today.
          </Typography>
          <br />
          <textarea
            style={{
              width: '100%',
              border: '1px solid black',
              padding: '10px',
              fontFamily: 'inherit',
              fontSize: 'inherit',
            }}
            value={responses.question6}
            onChange={e => handleResponseChange('question6', e.target.value)}
            rows={4}
            error={!responses.question6}
          />
          <br />
        </Box>

        {submitAttempted && getFirstInvalidField() && (
          <Typography
            variant="body2"
            color="error"
            sx={{ mb: 2, textAlign: "center" }}
          >
            {submitMessage}
          </Typography>)}

        {/* Submit and Close Buttons */}
        <Stack direction="row" spacing={2} sx={{ mt: 2, justifyContent: 'center' }}>
          <Button
            variant="contained"
            color="primary"
            onClick={handleSubmit}
            sx={{
              opacity: getFirstInvalidField() ? 0.5 : 1,
              pointerEvents: "auto",
            }}
          >
            Submit
          </Button>
        </Stack>
      </Box>
    </Modal>
  );
};

const NavBar = () => {
  const [isSurveyModalOpen, setIsSurveyModalOpen] = useState(false);
  const [isSurveyAllowed, setSurveyAllowed] = useState(false);
  const [decodedUsername, setDecodedUsername] = useState(null);
  const [decodedType, setDecodedType] = useState(null);

  const handleOpenSurveyModal = useCallback(() => {
    if (isSurveyAllowed) {
      setIsSurveyModalOpen(true);
    }
  }, [isSurveyAllowed]);

  const handleCloseSurveyModal = () => {
    setIsSurveyModalOpen(false);
  };

  useLayoutEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem('token');
      if (token) {
        try {
          const decoded = jwt_decode(token);
          setDecodedUsername(decoded.uname);
          setDecodedType(decoded.type);
          await checkSurveyTimestamp(decoded.uname);
          handleOpenSurveyModal();
        } catch (error) {
          console.error('Invalid token', error);
        }
      }
    };

    fetchData();
  }, [handleOpenSurveyModal]);

  const checkSurveyTimestamp = uname => {
    axios
      .get(`${process.env.REACT_APP_API_BASE_URL}/api/dashboard?uname=${uname}`)
      .then(response => {
        if (response.data.length > 0) {
          const lastSurveyTimestamp = new Date(response.data[response.data.length - 1].createdAt);
          const currentTime = new Date();

          const timeDifference = currentTime - lastSurveyTimestamp;
          const hoursDifference = timeDifference / (1000 * 60 * 60);

          if (hoursDifference >= 24) {
            setSurveyAllowed(true);
          } else {
            setSurveyAllowed(false);
          }
        } else {
          setSurveyAllowed(true);
        }
      })
      .catch(err => {
        console.log(err);
      });
  };

  const location = useLocation();
  const width = useMediaQuery('(max-width:600px)');

  // Helps determine what the active path is, also will find the path if its not an exact match in case there are other URL args.
  const isPathActive = path => {
    if (!path) return false;
    return location.pathname === path || location.pathname.startsWith(path + '/');
  };

  const dashboardPath = decodedType === 'parent' ? '/dashboard' : '/admin/dashboard';
  const activeColor = '#2E7D32';

  const [anchorEl, setAnchorEl] = useState(null);
  const [logoutModalOpen, setLogoutModalOpen] = useState(false);

  const [openSurveyModal, setOpenSurveyModal] = useState(false);

  const handleMenuClick = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleLogoutClick = event => {
    setLogoutModalOpen(true);
    handleCloseMenu();
  };

  const handleLogoutModalClose = () => {
    setLogoutModalOpen(false);
  };

  const handleCloseMenu = () => {
    setAnchorEl(null);
  };

  const handleStartSurvey = () => {
    handleOpenSurveyModal();
    setOpenSurveyModal(false);
  };

  const handleOpenSurveyConfirmation = () => {
    setOpenSurveyModal(true);
  };

  return (
    <div>
      <StyledAppBar>
        <StyledToolbar>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <Link
              to={dashboardPath}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '16px',
                textDecoration: 'none',
              }}
            >
              <img
                src="/HDHLogo.png"
                alt="HDH Logo"
                style={{
                  height: '50px',
                  width: 'auto',
                  objectFit: 'contain',
                  cursor: 'pointer',
                }}
              />
              <DailyAffirmations />
            </Link>
          </div>

          <div>
            <LogoutModal isOpen={logoutModalOpen} onClose={handleLogoutModalClose} />
            <SurveyConfirmationModal
              isOpen={openSurveyModal}
              onClose={() => setOpenSurveyModal(false)}
              handleStartSurvey={handleStartSurvey}
            />
          </div>
          {!width && (
            //!WIDTH is for the desktop version, this is because we have const width = useMediaQuery('(max-width:600px)'); and this evals false one desktop
            //Any changes made to desktop will need similar for mobile
            <>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Button
                  color="inherit"
                  component={Link}
                  to={dashboardPath}
                  size="large"
                  sx={{
                    color: isPathActive(dashboardPath) ? activeColor : 'inherit',
                    '&:hover': {
                      backgroundColor: '#E8F5E8',
                    },
                  }}
                >
                  Dashboard
                </Button>
                {decodedType === 'admin' && (
                  <Button
                    color="inherit"
                    component={Link}
                    to="/admin/modules"
                    size="large"
                    sx={{
                      color: isPathActive('/admin/modules') ? activeColor : 'inherit',
                    }}
                  >
                    Admin Management
                  </Button>
                )}
                {(decodedType === 'admin' || decodedType === 'researcher') && (
                  <Button
                    color="inherit"
                    component={Link}
                    to="/admin/exports"
                    size="large"
                    sx={{
                      color: isPathActive('/admin/exports') ? activeColor : 'inherit',
                    }}
                  >
                    Exports
                  </Button>
                )}
                <Button
                  color="inherit"
                  component={Link}
                  to="/module"
                  size="large"
                  sx={{
                    color: isPathActive('/module') ? activeColor : 'inherit',
                  }}
                >
                  Modules
                </Button>
                {decodedType === 'parent' && (
                  <Button
                    variant="contained"
                    sx={{
                      backgroundColor: '#FF6B35',
                      boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.3)',
                      '&:hover': {
                        backgroundColor: '#E55A2B',
                      },
                    }}
                    onClick={handleOpenSurveyConfirmation}
                    size="large"
                  >
                    Daily Survey
                  </Button>
                )}
                <Button color="inherit" onClick={handleLogoutClick} size="large">
                  Log Out
                </Button>
                <Button
                  color="inherit"
                  component={Link}
                  to=""
                  startIcon={<Notifications style={{ fontSize: '2rem' }} />}
                  style={{ marginRight: -30 }}
                ></Button>
                <Button
                  color="inherit"
                  component={Link}
                  to="/profile"
                  startIcon={<AccountCircle style={{ fontSize: '2rem' }} />}
                  style={{ marginRight: -30 }}
                ></Button>
              </div>
            </>
          )}

          {width && (
            <>
              {/* WIDTH is for mobile view; changes here may need mirrored for desktop */}
              <div style={{ display: 'flex', alignItems: 'center', marginTop: '.5rem' }}>
                <Button
                  color="inherit"
                  component={Link}
                  to=""
                  startIcon={<MenuIcon style={{ fontSize: '2rem' }} />}
                  onClick={handleMenuClick}
                  style={{ marginLeft: -160 }}
                />

                <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={handleCloseMenu}>
                  <MenuItem
                    component={Link}
                    to={dashboardPath}
                    sx={{ color: isPathActive(dashboardPath) ? activeColor : 'inherit' }}
                  >
                    Dashboard
                  </MenuItem>
                  {decodedType === 'admin' && (
                    <MenuItem
                      component={Link}
                      to="/admin/modules"
                      sx={{ color: isPathActive('/admin/modules') ? activeColor : 'inherit' }}
                    >
                      Admin Management
                    </MenuItem>
                  )}
                  {(decodedType === 'admin' || decodedType === 'researcher') && (
                    <MenuItem
                      component={Link}
                      to="/admin/exports"
                      sx={{ color: isPathActive('/admin/exports') ? activeColor : 'inherit' }}
                    >
                      Exports
                    </MenuItem>
                  )}
                  <MenuItem
                    component={Link}
                    to="/module"
                    sx={{ color: isPathActive('/module') ? activeColor : 'inherit' }}
                  >
                    Modules
                  </MenuItem>
                  {decodedType === 'parent' && (
                    <MenuItem onClick={handleOpenSurveyConfirmation}>Daily Survey</MenuItem>
                  )}
                  <Divider />
                  <MenuItem onClick={handleLogoutClick}>Log Out</MenuItem>
                </Menu>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', marginTop: '.5rem' }}>
                <Button
                  color="inherit"
                  component={Link}
                  to=""
                  startIcon={<Notifications style={{ fontSize: '2rem' }} />}
                  style={{ marginRight: -20 }}
                />
                <Button
                  color="inherit"
                  component={Link}
                  to="/profile"
                  startIcon={<AccountCircle style={{ fontSize: '2rem' }} />}
                  style={{ marginRight: -20 }}
                />
              </div>
            </>
          )}
        </StyledToolbar>
      </StyledAppBar>

      {/* Survey Modal */}
      {isSurveyModalOpen && decodedType === 'parent' && location.pathname === '/dashboard' && (
        <SurveyModal isOpen={isSurveyModalOpen} onClose={handleCloseSurveyModal} />
      )}
    </div>
  );
};

export default NavBar;
