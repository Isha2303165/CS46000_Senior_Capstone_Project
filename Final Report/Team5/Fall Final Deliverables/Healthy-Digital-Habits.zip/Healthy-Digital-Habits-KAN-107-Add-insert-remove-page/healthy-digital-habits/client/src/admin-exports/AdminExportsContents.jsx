import React from 'react';
import NavBar from '../shared/NavBar';
import AdminExports from './AdminExports';

const AdminExportsContents = () => (
  <div>
    <NavBar />
    <div
      style={{ display: 'flex', alignitems: 'center', justifyContent: 'center', marginTop: '5rem' }}
    >
      <AdminExports />
    </div>
  </div>
);

export default AdminExportsContents;
