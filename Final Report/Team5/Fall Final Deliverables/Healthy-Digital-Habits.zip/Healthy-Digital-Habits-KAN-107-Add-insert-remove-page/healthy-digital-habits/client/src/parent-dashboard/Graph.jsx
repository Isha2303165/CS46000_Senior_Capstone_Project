import Box from '@mui/material/Box';
import { borderRadius, display } from '@mui/system';
import zIndex from '@mui/material/styles/zIndex';
import { fontSize, fontStyle } from '@mui/system';
import axios from 'axios';
import Chart from 'chart.js/auto';
import { jwtDecode as jwt_decode } from 'jwt-decode';
import React, { useEffect, useRef, useState } from 'react';

const Graph = ({ onClose, notHidden }) => {
  const [data, setData] = useState();
  const [daysOfData, setDays] = useState();
  const [selectedIncrement, setSelectedIncrement] = useState(7);
  const [chartInstance, setChartInstance] = useState(null);
  const [isAverageChart, setAverageChart] = useState(false);

  const chartRef = useRef(null);
  const today = new Date();

  function convertISOToDate(str) {
    let tmp = new Date(str);
    tmp.setDate(tmp.getDate());
    return tmp;
  }

  const BoxStyle = {
    position: 'absolute',
    top: '51%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    backgroundColor: '#F5F5F5',
    height: '56vh',
    width: '50vw',
    padding: '16px',
    border: '2px white',
    borderRadius: '25px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: '10',
  };

  const closeButtonStyle = {
    position: 'absolute',
    top: '5%',
    right: '5%',
    color: 'white',
    backgroundColor: '#1A477F',
    fontSize: '20px',
    fontStyle: 'bold',
    height: '27px',
    borderRadius: '5px',
    // hover: {
    //     background: '#2163b5'
    // }
  };

  const createAverageChart = () => {
    const ctx = chartRef.current.getContext('2d');
    const numberOfDaysToDisplay = selectedIncrement;
    const average = 3;

    const date = data.dateData;
    const focus = data.focusData.map(item => item.y);
    const control = data.controlData.map(item => item.y);
    const empowerment = data.empowermentData.map(item => item.y);
    const guilt = data.guiltData.map(item => item.y);

    const slicedDate = date.slice(-numberOfDaysToDisplay);
    const slicedFocus = focus[0].slice(-numberOfDaysToDisplay);
    const slicedControl = control[0].slice(-numberOfDaysToDisplay);
    const slicedEmpowerment = empowerment[0].slice(-numberOfDaysToDisplay);
    const slicedGuilt = guilt[0].slice(-numberOfDaysToDisplay);

    let xAverageArray = [];
    let focusMovingAvereage = [];
    let controlMovingAvereage = [];
    let empowermentMovingAvereage = [];
    let guiltMovingAvereage = [];

    for (let i = 0; i < 5; i++) {
      //fill out four data averages and date array
      if (i === 0) {
        //calculate control moving average
        for (let j = 0; j < numberOfDaysToDisplay - 2; j++) {
          const controlDataPoints = slicedControl.slice(j, average + j);
          controlMovingAvereage.push(
            controlDataPoints.reduce((total, num) => total + num) / average
          );
        }
        continue;
      }
      if (i === 1) {
        //calculate empowerment moving average
        for (let j = 0; j < numberOfDaysToDisplay - 2; j++) {
          const empowermentDataPoints = slicedEmpowerment.slice(j, average + j);
          empowermentMovingAvereage.push(
            empowermentDataPoints.reduce((total, num) => total + num) / average
          );
        }
        continue;
      }
      if (i === 2) {
        //calculate focus moving average
        for (let j = 0; j < numberOfDaysToDisplay - 2; j++) {
          const focusDataPoints = slicedFocus.slice(j, average + j);
          focusMovingAvereage.push(focusDataPoints.reduce((total, num) => total + num) / average);
        }
        continue;
      }
      if (i === 3) {
        //calculate guilt moving average
        for (let j = 0; j < numberOfDaysToDisplay - 2; j++) {
          const guiltDataPoints = slicedGuilt.slice(j, average + j);
          guiltMovingAvereage.push(guiltDataPoints.reduce((total, num) => total + num) / average);
        }
        continue;
      }
      if (i === 4) {
        //make date array
        for (let j = 0; j < numberOfDaysToDisplay - 2; j++) {
          let tempDates = slicedDate.slice(j, average + j);
          xAverageArray.push(
            convertISOToDate(tempDates[0]).toDateString().substring(4, 10) +
              '-' +
              convertISOToDate(tempDates[2]).toDateString().substring(4, 10)
          );
        }
        continue;
      }
    }

    const newChartInstance = new Chart(ctx, {
      type: 'line',
      data: {
        labels: xAverageArray,
        datasets: [
          {
            label: 'Focus',
            borderColor: 'rgb(50, 205, 50)',
            borderWidth: 2,
            data: focusMovingAvereage,
            tension: 0.1,
            pointStyle: 'triangle',
            pointRadius: 6,
            pointBackgroundColor: 'rgb(50, 205, 50)',
          },
          {
            label: 'Control',
            borderColor: 'rgb(75, 192, 192)',
            borderWidth: 2,
            data: controlMovingAvereage,
            tension: 0.1,
            pointStyle: 'rect',
            pointRadius: 6,
            pointBackgroundColor: 'rgb(75, 192, 192)',
          },
          {
            label: 'Empowerment',
            borderColor: 'rgb(255,105,180)',
            borderWidth: 2,
            data: empowermentMovingAvereage,
            tension: 0.1,
            pointStyle: 'circle',
            pointRadius: 6,
            pointBackgroundColor: 'rgb(255,105,180)',
          },
          {
            label: 'Guilt',
            borderColor: 'rgb(155,155,155)',
            borderWidth: 2,
            data: guiltMovingAvereage,
            tension: 0.1,
            pointStyle: 'rectRot',
            pointRadius: 6,
            pointBackgroundColor: 'rgb(155,155,155)',
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          y: {
            min: 1,
            max: 10,
          },
        },
        plugins: {
          legend: {
            display: true,
            position: 'top',
            labels: {
              font: {
                weight: 'bold',
              },
              usePointStyle: true,
            },
          },
        },
      },
    });

    // Set the Chart.js instance
    setChartInstance(newChartInstance);

    // Cleanup
    return () => {
      newChartInstance.destroy();
    };
  };

  const createChart = () => {
    const ctx = chartRef.current.getContext('2d');
    const numberOfDaysToDisplay = selectedIncrement;

    const date = data.focusData.map(item => item.x);
    const focus = data.focusData.map(item => item.y);
    const control = data.controlData.map(item => item.y);
    const empowerment = data.empowermentData.map(item => item.y);
    const guilt = data.guiltData.map(item => item.y);

    const slicedDate = date[0].slice(-numberOfDaysToDisplay);
    const slicedFocus = focus[0].slice(-numberOfDaysToDisplay);
    const slicedControl = control[0].slice(-numberOfDaysToDisplay);
    const slicedEmpowerment = empowerment[0].slice(-numberOfDaysToDisplay);
    const slicedGuilt = guilt[0].slice(-numberOfDaysToDisplay);

    let referenceDate = today;
    let xDateArray = [];
    let yFocus = [];
    let yControl = [];
    let yEmpowerment = [];
    let yGuilt = [];

    let j = 0; //increments through saved dates in data
    for (let i = 0; i < numberOfDaysToDisplay; i++) {
      referenceDate = new Date(new Date().setDate(today.getDate() - i));
      xDateArray.push(referenceDate.toDateString().substring(4, 10));
      if (
        referenceDate.toISOString().substring(5, 10) === slicedDate[slicedDate.length - (j + 1)]
      ) {
        yFocus.push(slicedFocus[slicedDate.length - (j + 1)]);
        yControl.push(slicedControl[slicedDate.length - (j + 1)]);
        yEmpowerment.push(slicedEmpowerment[slicedDate.length - (j + 1)]);
        yGuilt.push(slicedGuilt[slicedDate.length - (j + 1)]);
        j++;
      } else {
        yFocus.push(null);
        yControl.push(null);
        yEmpowerment.push(null);
        yGuilt.push(null);
      }
    }
    xDateArray.reverse();
    yFocus.reverse();
    yControl.reverse();
    yEmpowerment.reverse();
    yGuilt.reverse();
    console.log();

    const newChartInstance = new Chart(ctx, {
      type: 'line',
      data: {
        labels: xDateArray,
        datasets: [
          {
            label: 'Focus',
            borderColor: 'rgb(50, 205, 50)',
            borderWidth: 2,
            data: yFocus,
            tension: 0.1,
            pointStyle: 'triangle',
            pointRadius: 6,
            pointBackgroundColor: 'rgb(50, 205, 50)',
          },
          {
            label: 'Control',
            borderColor: 'rgb(75, 192, 192)',
            borderWidth: 2,
            data: yControl,
            tension: 0.1,
            pointStyle: 'rect',
            pointRadius: 6,
            pointBackgroundColor: 'rgb(75, 192, 192)',
          },
          {
            label: 'Empowerment',
            borderColor: 'rgb(255,105,180)',
            borderWidth: 2,
            data: yEmpowerment,
            tension: 0.1,
            pointStyle: 'circle',
            pointRadius: 6,
            pointBackgroundColor: 'rgb(255,105,180)',
          },
          {
            label: 'Guilt',
            borderColor: 'rgb(155,155,155)',
            borderWidth: 2,
            data: yGuilt,
            tension: 0.1,
            pointStyle: 'rectRot',
            pointRadius: 6,
            pointBackgroundColor: 'rgb(155,155,155)',
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        spanGaps: true,
        scales: {
          y: {
            min: 1,
            max: 10,
          },
        },
        plugins: {
          legend: {
            display: true,
            position: 'top',
            labels: {
              font: {
                weight: 'bold',
              },
              usePointStyle: true,
            },
          },
        },
      },
    });

    // Set the Chart.js instance
    setChartInstance(newChartInstance);

    // Cleanup
    return () => {
      newChartInstance.destroy();
    };
  };

  const fetchDataAndUpdateGraph = async () => {
    try {
      const token = localStorage.getItem('token');
      const decoded = jwt_decode(token);
      const response = await axios.get(
        `${process.env.REACT_APP_API_BASE_URL}/api/dashboard?uname=${decoded.uname}`
      );
      if (response.data) {
        setDays(response.data.length);
        if (response.data.length >= 12) {
          //Default to average graph with 12 or more days of data
          setSelectedIncrement(12);
          setAverageChart(true);
        }
        const surveyDate = response.data.map(dat => dat.createdAt);
        const surveyDateSubstring = response.data.map(dat => dat.createdAt.substring(5, 10));
        const focus = response.data.map(dat => parseInt(dat.mood?.Focus || 0));
        const control = response.data.map(dat => parseInt(dat.mood?.Control || 0));
        const empowerment = response.data.map(dat => parseInt(dat.mood?.Empowerment || 0));
        const guilt = response.data.map(dat => parseInt(dat.mood?.Guilt || 0));
        setData({
          controlData: [{ x: surveyDateSubstring, y: control }],
          empowermentData: [{ x: surveyDateSubstring, y: empowerment }],
          focusData: [{ x: surveyDateSubstring, y: focus }],
          guiltData: [{ x: surveyDateSubstring, y: guilt }],
          dateData: surveyDate,
        });
      }
    } catch (err) {
      console.log(err);
    }
  };
  useEffect(() => {
    fetchDataAndUpdateGraph();
  }, []);

  useEffect(() => {
    if (data) {
      // Destroy the existing chart instance
      if (chartInstance) {
        chartInstance.destroy();
      }

      // Create a new chart, if isAverageChart is true, display the moving average chart
      if (!isAverageChart) {
        createChart();
      } else if (isAverageChart) {
        createAverageChart();
      }
    }
  }, [selectedIncrement, data]);

  const handleChangeIncrement = event => {
    setSelectedIncrement(Number(event.target.value));
    setAverageChart(false);
  };

  const handleAverage = event => {
    setSelectedIncrement(Number(event.target.value));
    setAverageChart(true);
  };

  const handleGraphClose = () => {
    if (onClose) {
      onClose();
    }
  };

  return (
    <Box sx={BoxStyle}>
      <div style={{ width: '50vw', height: '50vh', minWidth: '300px', margin: 'auto' }}>
        <button onClick={handleGraphClose} style={closeButtonStyle}>
          X
        </button>
        <canvas id="lineChart" key={chartRef} ref={chartRef} />

        <div style={{ marginTop: '20px', position: 'absolute', left: '30%' }}>
          <label>
            <input
              type="radio"
              value="12"
              checked={selectedIncrement === 12}
              onChange={handleAverage}
              disabled={daysOfData < 12 ? true : false}
            />
            3 Day Moving Average
          </label>
          <label>
            <input
              type="radio"
              value="7"
              checked={selectedIncrement === 7}
              onChange={handleChangeIncrement}
            />
            7 Days
          </label>
          <label>
            <input
              type="radio"
              value="14"
              checked={selectedIncrement === 14}
              onChange={handleChangeIncrement}
            />
            14 Days
          </label>
          <label>
            <input
              type="radio"
              value="30"
              checked={selectedIncrement === 30}
              onChange={handleChangeIncrement}
            />
            30 Days
          </label>
        </div>
      </div>
    </Box>
  );
};

export default Graph;
