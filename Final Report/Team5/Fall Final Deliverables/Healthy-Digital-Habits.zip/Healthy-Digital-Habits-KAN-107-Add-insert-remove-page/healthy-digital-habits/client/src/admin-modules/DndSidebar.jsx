import { useState, useCallback, useEffect, useRef } from 'react';
import { APP_BAR_HEIGHT } from '../shared/NavBar.jsx';
import axios from 'axios';
import {
  Box,
  Drawer,
  List,
  IconButton,
  ListItem,
  ListItemText,
  ListSubheader,
  ListItemButton,
  ListItemIcon,
  Collapse,
  Snackbar,
  Alert,
  Modal,
  Typography,
  TextField,
  Stack,
  Button,
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import DragIndicator from '@mui/icons-material/DragIndicator';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import KeyboardArrowDown from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowRight from '@mui/icons-material/KeyboardArrowRight';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import DeleteConfirmationModal from '../components/DeleteConfirmationModal';

const OPEN_W = 'max(25vw, 150px)'; // open drawer width
const TAB_PAD = 24;

const DndSidebar = ({
  onDrawerChange,
  courseTree = [], // [{courseId, courseTitle, topicId, topicTitle, modules:[{moduleId,moduleTitle}]}, ...]
  courseInfo = null,
  selectedModuleToEdit,
  setSelectedModuleToEdit,
  onSelectModule,
  liveModuleTitle,
  selectedModuleId,
  onReorder, // function(payload) -> persist any changes from dnd
  onRenameTopic, // function({topicId, oldTitle, newTitle, modules})
  onRefreshCourseTree,
}) => {
  const [isDrawerOpen, setIsDrawerOpen] = useState(true);
  const [openSet, setOpenSet] = useState(new Set());
  const [tree, setTree] = useState(courseTree);
  const [notice, setNotice] = useState({ open: false, message: '', severity: 'warning' });
  const menuBtnRef = useRef(null);
  const [renameState, setRenameState] = useState({
    open: false,
    idx: null,
    topic: null,
    value: '',
  });
   const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [courseElementToDelete, setCourseElementToDelete] = useState(null);

  const openDeleteModal = (courseElementType, courseElement) => {
    setCourseElementToDelete({ courseElementType, data: courseElement });
    setIsDeleteModalOpen(true);
  };
  const closeDeleteModal = () => {
    setIsDeleteModalOpen(false);
    setCourseElementToDelete(null);
  };

  const handleDeleteCourseElement = async () => {

    try {
      // If a topic is selected
      if (courseElementToDelete.courseElementType === 'topic') {
        // note: variable names here are not entirely accurate
        await axios.put(`${process.env.REACT_APP_API_BASE_URL}/api/courses/removeTopic`, {
          title: courseElementToDelete.data.courseTitle,
          topicId: courseElementToDelete.data.topicTitle
        });
        await axios.delete(
          `${process.env.REACT_APP_API_BASE_URL}/api/topics/delete?title=${courseElementToDelete.data.topicTitle}`
        );
        

        // If a module is selected
      } else if (courseElementToDelete.courseElementType === 'module') {
        const moduleId = courseElementToDelete.data.moduleId;

        // Find the topic that owns this module
        const parentTopic = tree.find(item =>
          item.modules?.some(m => m.moduleId === moduleId)
        );

        if (!parentTopic) {
          console.error("Parent topic not found for module:", moduleId);
          return;
        }
        await axios.delete(
          `${process.env.REACT_APP_API_BASE_URL}/api/module/?id=${courseElementToDelete.data.moduleId}`
        );
        await axios.put(`${process.env.REACT_APP_API_BASE_URL}/api/topics/removeModule`, {
          title: parentTopic.topicTitle,
          moduleId: moduleId
        });
      }

      // Update the tree state by removing the deleted topic
      let updatedTree;

      if (courseElementToDelete.courseElementType === "topic") {
        // remove whole topic
        updatedTree = tree.filter(
          item => item.topicTitle !== courseElementToDelete.data.topicTitle
        );
      }

      if (courseElementToDelete.courseElementType === "module") {
        // remove a module from the modules array inside each topic
        updatedTree = tree.map(item => {
          return {
            ...item,
            modules: item.modules.filter(
              m => m.moduleId !== courseElementToDelete.data.moduleId
            ),
          };
        });
      }

      setTree(updatedTree);

      // Show confirmation message
      setNotice({ open: true, message: 'Element deleted successfully', severity: 'success' });
    } catch (error) {
      console.error('Error while deleting element:', error);
      // Show error message
      setNotice({ open: true, message: 'Error deleting element', severity: 'error' });
    }

    closeDeleteModal();
  };

  // New state for Add Topic modal
  const [addTopicState, setAddTopicState] = useState({
    open: false,
    title: '',
  });
  // Track if the current tree already has topics so we can gate module actions.
  const hasTopics = tree.length > 0;
  const isEmptyTree = !hasTopics;

  useEffect(() => {
    setTree(courseTree);
  }, [courseTree]);

  useEffect(() => {
    if (!selectedModuleId) return;

    setTree(prev =>
      prev.map(topic => {
        const updatedModules = topic.modules.map(mod => {
          if (String(mod.moduleId) === String(selectedModuleId)) {
            return { ...mod, moduleTitle: liveModuleTitle };
          }
          return mod;
        });
        return { ...topic, modules: updatedModules };
      })
    );
  }, [liveModuleTitle, selectedModuleId]);

  const handleSelectModule = (topicId, mod) => {
    const moduleId = mod?.moduleId ?? mod?.id;
    const moduleTitle = mod?.moduleTitle ?? mod?.title ?? '';
    if (!moduleId) return;
    if (onSelectModule) {
      onSelectModule(moduleId, moduleTitle, topicId);
    } else {
      setSelectedModuleToEdit?.(moduleId);
    }
  };

  const handleAddBlankModule = async (topic, moduleData) => {
    try {
      if (tree.length === 0) {
        console.log('No topics available to add the module to.');
        notify('Please add a topic before creating modules.', 'info');
        return;
      } else {
        console.log('Creating module on server:', moduleData);
        const res = await axios.post(
          `${process.env.REACT_APP_API_BASE_URL}/api/createmodule`,
          moduleData
        );
        console.log('Module created:', res.data.module._id);
        const targetTopic = topic || tree[tree.length - 1] || {};
        const moduleIds = Array.isArray(targetTopic.modules)
          ? targetTopic.modules
              .map(mod => (typeof mod === 'string' ? mod : mod?.moduleId))
              .filter(Boolean)
          : [];
        const payload = {
          title: targetTopic.topicTitle,
          modules: moduleIds.concat(res.data.module._id),
        };
        console.log('Adding module to topic:', payload);
        const newres = await axios.put(
          `${process.env.REACT_APP_API_BASE_URL}/api/topics/addModule`,
          payload
        );
        //Extracting the data out of the newly made module using res
        const newModule = { moduleId: res.data.module._id, moduleTitle: moduleData.title };
        //Calling the module selector giving the topic and the newly created module
        handleSelectModule(targetTopic.topicId, newModule);
        //Find the index of the topic given to add the new module into
        const topicIdx = tree.findIndex(t => String(t.topicId) === String(targetTopic.topicId));
        if (topicIdx >= 0) {
          setOpenSet(prev => {
            const next = new Set(prev);
            next.add(topicIdx);
            return next;
          });
        }
        console.log('Topic Added:', newres.data);
        onRefreshCourseTree?.();
      }
    } catch (err) {
      console.error('Error creating or updating module:', err.response?.data || err.message);
    }
  };

  const openRenameModal = (topic, idx) => {
    setRenameState({
      open: true,
      idx,
      topic,
      value: topic.topicTitle ?? '',
    });
  };

  const closeRenameModal = () => {
    setRenameState({ open: false, idx: null, topic: null, value: '' });
  };

  const handleRenameSubmit = event => {
    event?.preventDefault();
    const trimmed = renameState.value.trim();
    if (!renameState.topic || !trimmed) {
      closeRenameModal();
      return;
    }

    setTree(prev => {
      if (renameState.idx == null) return prev;
      const draft = prev.slice();
      if (draft[renameState.idx]) {
        draft[renameState.idx] = { ...draft[renameState.idx], topicTitle: trimmed };
      }
      return draft;
    });

    onRenameTopic?.({
      topicId: renameState.topic.topicId,
      oldTitle: renameState.topic.topicTitle,
      newTitle: trimmed,
      modules: (renameState.topic.modules || []).map(m => m.moduleId),
    });

    closeRenameModal();
  };

  useEffect(() => {
    console.log('Tree updated:', JSON.parse(JSON.stringify(tree)));
  }, [tree]);

  const toggleDrawer = () => {
    setIsDrawerOpen(prev => {
      const next = !prev;
      if (prev && !next) {
        setTimeout(() => menuBtnRef.current?.focus(), 0);
      }
      onDrawerChange(next);
      return next;
    });
  };

  //prop for giving notifications to user (specifically when a topic has the made module)
  const notify = (message, severity = 'warning') => {
    setNotice({ open: true, message, severity });
  };

  const toggleExpand = useCallback(idx => {
    setOpenSet(prev => {
      const next = new Set(prev);
      next.has(idx) ? next.delete(idx) : next.add(idx);
      return next;
    });
  }, []);

  const reorderArray = (arr, start, end) => {
    const copy = arr.slice();
    const [item] = copy.splice(start, 1);
    copy.splice(end, 0, item);
    return copy;
  };

  const moveModuleBetween = (sourceModules, destModules, sourceIdx, destIdx) => {
    const from = sourceModules.slice();
    const to = destModules.slice();
    const [moved] = from.splice(sourceIdx, 1);
    to.splice(destIdx, 0, moved);
    return { from, to, moved };
  };

  // Map droppableId back to topic index; supports fallback to index-based IDs
  // This fixes issues with topics not having an id in current state
  const topicIndexById = id => tree.findIndex((t, idx) => String(t.topicId ?? idx) === String(id));
  //string is unique even when two topics contain modules with the same title or moduleId, preventing drag collisions.
  const moduleDraggableId = (topic, module, tIdx, mIdx) =>
    `${topic.topicId ?? tIdx}::${module.moduleId ?? mIdx}`;

  // ------- DnD handler -------
  const onDragEnd = result => {
    const { destination, source, draggableId, type } = result;
    if (!destination) return;

    if (type === 'TOPIC') {
      if (destination.index === source.index) return;
      const newTree = reorderArray(tree, source.index, destination.index);
      setTree(newTree);

      const topicsForPersist = newTree.map(t => t.topicTitle);
      onReorder?.({
        kind: 'topics',
        courseId: newTree[0]?.courseId,
        topics: topicsForPersist,
      });
      return;
    }

    const fromTopicId = source.droppableId;
    const toTopicId = destination.droppableId;

    const fromIdx = topicIndexById(fromTopicId);
    const toIdx = topicIndexById(toTopicId);
    if (fromIdx < 0 || toIdx < 0) return;

    const fromTopic = tree[fromIdx];
    const toTopic = tree[toIdx];

    const fromModules = fromTopic.modules || [];
    const toModules = toTopic.modules || [];

    let newFromModules, newToModules, moved;

    if (fromTopicId === toTopicId) {
      if (destination.index === source.index) return;
      newFromModules = reorderArray(fromModules, source.index, destination.index);
      newToModules = newFromModules;
      moved = newFromModules[destination.index];
    } else {
      // Prevent moving into a topic that already has a module with the same title (case-insensitive)
      const normalize = s => (s || '').trim().toLowerCase();
      const moving = fromModules[source.index];
      const movingName = normalize(moving?.moduleTitle);
      const hasDuplicateByName = (toTopic.modules || []).some(
        m => normalize(m.moduleTitle) === movingName
      );

      if (hasDuplicateByName) {
        notify(
          `Module "${moving?.moduleTitle || 'Untitled'}" already exists in "${toTopic.topicTitle}"`,
          'info'
        );
        return; // cancel drop
      }
      const res = moveModuleBetween(fromModules, toModules, source.index, destination.index);
      newFromModules = res.from;
      newToModules = res.to;
      moved = res.moved;
    }

    const newTree = tree.slice();
    newTree[fromIdx] = { ...fromTopic, modules: newFromModules };
    newTree[toIdx] = { ...toTopic, modules: newToModules };
    setTree(newTree);

    // Persist using two updates
    // - For now, we pass moduleId arrays to keep backend simple.
    const toIds = arr => arr.map(m => m.moduleId);
    //sending state to adminmodules.jsx
    onReorder?.({
      kind: 'modules',
      move: {
        moduleId: moved.moduleId,
        fromTopicId,
        toTopicId,
        newFromModules: toIds(newFromModules),
        newToModules: toIds(newToModules),
      },
    });
  };

  return (
    <Box>
      <Box
        sx={{
          position: 'fixed',
          top: `${APP_BAR_HEIGHT + 4}px`,
          left: 0,
          width: isDrawerOpen ? `calc(${OPEN_W} + 40px + ${TAB_PAD}px)` : 68,
          height: 57,
          borderTopRightRadius: 60,
          borderBottomRightRadius: 60,
          background: '#4c4c4cff',
          zIndex: t => t.zIndex.drawer,
          transition: t =>
            t.transitions.create('width', { duration: t.transitions.duration.shorter }),
        }}
      />

      <IconButton
        ref={menuBtnRef}
        onClick={toggleDrawer}
        sx={{
          position: 'fixed',
          top: `${APP_BAR_HEIGHT + 12}px`,
          left: isDrawerOpen ? `calc(${OPEN_W} + 16px)` : 16,
          zIndex: t => t.zIndex.drawer + 1,
          transition: t =>
            t.transitions.create('left', { duration: t.transitions.duration.shorter }),
        }}
      >
        <MenuIcon sx={{ color: '#ffffffff' }} />
      </IconButton>

      <Drawer
        variant="persistent"
        anchor="left"
        open={isDrawerOpen}
        onClose={toggleDrawer}
        PaperProps={{
          sx: {
            boxShadow: 'none !important',
            marginTop: `${APP_BAR_HEIGHT + 5}px`,
            borderRadius: '15px',
            border: '10px solid #4c4c4cff',
            backgroundColor: '#4c4c4cff',
            width: OPEN_W,
            height: `calc(100vh - ${APP_BAR_HEIGHT + 5}px)`,
            overflowY: 'hidden',
          },
        }}
        ModalProps={{ BackdropProps: { invisible: true }, keepMounted: true }}
      >
        <Box
          sx={{
            width: OPEN_W,
            height: '100%',
            display: 'flex',
            flexDirection: 'column',
          }}
        >
          <Box sx={{ flex: 1, overflowY: 'auto', pb: 2 }}>
            <DragDropContext onDragEnd={onDragEnd}>
              <Droppable droppableId="topics-root" type="TOPIC">
                {prov => (
                  <List
                    ref={prov.innerRef}
                    {...prov.droppableProps}
                    dense
                    subheader={
                      <ListSubheader
                        sx={{ fontSize: '22px', fontWeight: 700, color: 'text.primary' }}
                      >
                        {tree.length > 0
                          ? `Selected Course: ${tree[0].courseTitle}`
                          : 'No content to display!'}
                      </ListSubheader>
                    }
                    sx={{
                      bgcolor: 'background.paper',
                      borderRadius: '15px',
                      fontSize: '16px',
                      fontWeight: 'bold',
                    }}
                  >
                    {tree.map((topic, tIdx) => (
                      <Draggable
                        key={String(topic.topicId ?? tIdx)}
                        draggableId={String(topic.topicId ?? tIdx)}
                        index={tIdx}
                      >
                        {dragProv => (
                          <Box
                            ref={dragProv.innerRef}
                            {...dragProv.draggableProps}
                            sx={{ pt: tIdx === 0 ? '10px' : 0 }}
                          >
                            <ListItemButton onClick={() => toggleExpand(tIdx)}>
                              <ListItemIcon
                                sx={{ minWidth: 32, cursor: 'grab' }}
                                {...dragProv.dragHandleProps}
                              >
                                <DragIndicator />
                              </ListItemIcon>
                              <ListItemText
                                primary={topic.topicTitle}
                                primaryTypographyProps={{ fontSize: '18px', fontWeight: 'bold' }}
                              />
                              <IconButton
                              size="small"
                              onClick={e => {
                                e.stopPropagation();
                                openDeleteModal('topic', topic);
                              }}
                            >
                              <DeleteIcon fontSize="small" />
                            </IconButton>
                              <IconButton
                                size="small"
                                onClick={e => {
                                  e.stopPropagation();
                                  openRenameModal(topic, tIdx);
                                }}
                              >
                                <EditIcon fontSize="small" />
                              </IconButton>
                              <Box>
                                <ListItemIcon sx={{ minWidth: 40 }}>
                                  {openSet.has(tIdx) ? (
                                    <KeyboardArrowDown sx={{ fontSize: 28 }} />
                                  ) : (
                                    <KeyboardArrowRight sx={{ fontSize: 28 }} />
                                  )}
                                </ListItemIcon>
                              </Box>
                            </ListItemButton>

                            <Collapse in={openSet.has(tIdx)} timeout="auto" unmountOnExit>
                              <Droppable droppableId={String(topic.topicId ?? tIdx)} type="MODULE">
                                {(modsProv, modsSnapshot) => (
                                  <List
                                    ref={modsProv.innerRef}
                                    {...modsProv.droppableProps}
                                    component="div"
                                    disablePadding
                                    sx={{
                                      minHeight: 8,
                                      bgcolor: modsSnapshot.isDraggingOver
                                        ? 'action.hover'
                                        : undefined,
                                    }}
                                  >
                                    {(topic.modules || []).map((module, mIdx) => {
                                      const draggableId = moduleDraggableId(
                                        topic,
                                        module,
                                        tIdx,
                                        mIdx
                                      );
                                      return (
                                        <Draggable
                                          key={draggableId}
                                          draggableId={draggableId}
                                          index={mIdx}
                                        >
                                          {mProv => (
                                            <ListItemButton
                                              ref={mProv.innerRef}
                                              {...mProv.draggableProps}
                                              sx={{ pl: 4 }}
                                              onClick={() =>
                                                handleSelectModule(topic.topicId, module)
                                              }
                                              selected={
                                                String(selectedModuleToEdit) ===
                                                String(module.moduleId)
                                              }
                                            >
                                              <ListItemIcon
                                                sx={{ minWidth: 32, cursor: 'grab' }}
                                                {...mProv.dragHandleProps}
                                              >
                                                <DragIndicator fontSize="small" />
                                              </ListItemIcon>
                                              <ListItemText primary={module.moduleTitle} />
                                              <IconButton
                                              size="small"
                                              onClick={e => {
                                                e.stopPropagation();
                                                openDeleteModal('module', module);
                                              }}
                                            >
                                              <DeleteIcon fontSize="small" />
                                            </IconButton>
                                            </ListItemButton>
                                          )}
                                        </Draggable>
                                      );
                                    })}
                                    {modsProv.placeholder}
                                  </List>
                                )}
                              </Droppable>
                            </Collapse>
                          </Box>
                        )}
                      </Draggable>
                    ))}
                    {prov.placeholder}
                  </List>
                )}
              </Droppable>
            </DragDropContext>
          </Box>

          {/* Bottom buttons */}
          <Box
            sx={{
              borderTop: '1px solid #f5f5f5',
              display: 'flex',
              justifyContent: 'space-between',
              gap: 1,
              p: 2,
              backgroundColor: '#4c4c4c',
              flexShrink: 0,
            }}
          >
            <Button
              variant="outlined"
              sx={{
                fontWeight: 'bold',
                flex: 1,
                height: 36,
                borderColor: '#ccc',
                color: '#000',
                textTransform: 'none',
                backgroundColor: '#fff',
                '&:hover': {
                  backgroundColor: '#02542D',
                  borderColor: '#02542D',
                  color: '#fff',
                },
              }}
              onClick={() => setAddTopicState({ ...addTopicState, open: true })}
            >
              + Topic
            </Button>
            <Button
              variant="outlined"
              sx={{
                fontWeight: 'bold',
                flex: 1,
                height: 36,
                borderColor: hasTopics ? '#ccc' : '#d0d0d0',
                color: hasTopics ? '#000' : '#9e9e9e',
                textTransform: 'none',
                backgroundColor: hasTopics ? '#fff' : '#f5f5f5',
                '&:hover': hasTopics
                  ? {
                      backgroundColor: '#02542D',
                      borderColor: '#02542D',
                      color: '#fff',
                    }
                  : {
                      backgroundColor: '#f5f5f5',
                      borderColor: '#d0d0d0',
                      color: '#9e9e9e',
                    },
              }}
              onClick={() => {
                if (!hasTopics) {
                  notify('Please add a topic before creating modules.', 'info');
                  return;
                }
                const moduleData = {
                  title: 'New Module',
                  description: '<p>A new module.</p>',
                  image:
                    'https://www.thesprucepets.com/thmb/sIEOwVzqzREg2yG9FwganfReCao=/5184x0/filters:no_upscale():strip_icc()/scarlet-macaw-518723208-0ffc75547e024e84af234bc999f82e4c.jpg',
                  prereqs: [],
                  pages: [
                    {
                      content: '',
                      pageDescription: '',
                      questionDescription: '',
                      type: '',
                      value: '',
                      media: '',
                      layout: '',
                    },
                    {
                      content: '',
                      pageDescription: '',
                      questionDescription: '',
                      type: '',
                      value: '',
                      media: '',
                      layout: '',
                    },
                    {
                      content: 'End of Module Activity',
                      pageDescription: '',
                      questionDescription: '',
                      type: '',
                      value: '',
                      media: '',
                      layout: '',
                    },
                  ],
                  pagePaths: {},
                  incompleted: [],
                  completed: [],
                  progress: [],
                };
                console.log('Adding new blank module to topic:', tree);
                handleAddBlankModule(tree[tree.length - 1], moduleData);
              }}
            >
              + Module
            </Button>
          </Box>
        </Box>
      </Drawer>

      {/* Delete Confirmation Modal */}
      <DeleteConfirmationModal
        open={isDeleteModalOpen}
        onClose={closeDeleteModal}
        onConfirm={handleDeleteCourseElement}
        itemName={courseElementToDelete?.title}
        itemType={'element'}
      />

      {/* Rename Topic Modal */}
      <Modal open={renameState.open} onClose={closeRenameModal}>
        <Box
          component="form"
          onSubmit={handleRenameSubmit}
          sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: '33vw',
            bgcolor: 'background.paper',
            boxShadow: 24,
            borderRadius: 2,
            p: 4,
            display: 'flex',
            flexDirection: 'column',
            gap: 3,
          }}
        >
          <Box>
            <Typography variant="h6" component="h2" sx={{ mb: 2 }}>
              Rename Topic
            </Typography>
            <Stack spacing={2}>
              <TextField
                label="Topic Name"
                variant="outlined"
                value={renameState.value}
                onChange={e => setRenameState(prev => ({ ...prev, value: e.target.value }))}
                fullWidth
                autoFocus
              />
            </Stack>
          </Box>

          <Stack direction="row" spacing={2} justifyContent="flex-end">
            <Button
              variant="outlined"
              onClick={closeRenameModal}
              sx={{
                borderColor: '#02542D',
                color: '#02542D',
                backgroundColor: '#fff',
                '&:hover': {
                  backgroundColor: '#02542D',
                  color: '#fff',
                },
              }}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="outlined"
              sx={{
                borderColor: '#02542D',
                color: '#02542D',
                backgroundColor: '#fff',
                '&:hover': {
                  backgroundColor: '#02542D',
                  color: '#fff',
                },
              }}
            >
              Save
            </Button>
          </Stack>
        </Box>
      </Modal>

      {/* Add Topic Modal */}
      <Modal open={addTopicState.open} onClose={() => setAddTopicState({ open: false, title: '' })}>
        <Box
          component="form"
          onSubmit={async e => {
            e.preventDefault();
            const trimmedTitle = addTopicState.title.trim();
            if (!trimmedTitle) return;

            // Pull course metadata from props or whatever we have locally.
            const fallbackMeta = courseInfo || {};
            const courseMeta = tree[0] || courseTree[0] || fallbackMeta;
            const courseTitle = courseMeta?.courseTitle;
            const courseId = courseMeta?.courseId;

            if (!courseTitle) {
              console.error('Cannot determine course to add topic to.');
              return;
            }

            try {
              const response = await axios.post(
                `${process.env.REACT_APP_API_BASE_URL}/api/topics/create`,
                { title: trimmedTitle, modules: [] }
              );

              const newTopic = response.data.topic;

              const normalizedTopic = {
                courseId: courseId ?? fallbackMeta?.courseId ?? null,
                courseTitle: courseTitle ?? fallbackMeta?.courseTitle,
                topicId: newTopic._id,
                topicTitle: newTopic.title,
                modules: [],
                createdAt: newTopic.createdAt,
                updatedAt: newTopic.updatedAt,
              };

              const deriveTitles = source =>
                (Array.isArray(source) ? source : [])
                  .map(item => {
                    if (typeof item === 'string') return item;
                    if (item && typeof item === 'object') {
                      return item.topicTitle ?? item.title ?? '';
                    }
                    return '';
                  })
                  .map(title => title?.trim())
                  .filter(Boolean);

              let existingCourseTopics = deriveTitles(tree);
              if (!existingCourseTopics.length) {
                existingCourseTopics = deriveTitles(courseTree);
              }

              let courseImage = courseMeta?.courseImage ?? fallbackMeta?.courseImage;
              try {
                const courseRes = await axios.get(
                  `${process.env.REACT_APP_API_BASE_URL}/api/courses/oneCourse?course=${encodeURIComponent(
                    courseTitle
                  )}`
                );
                const serverCourse = courseRes?.data;
                if (serverCourse) {
                  const fromServer = deriveTitles(serverCourse.topics);
                  if (fromServer.length) {
                    existingCourseTopics = fromServer;
                  }
                  courseImage = serverCourse.image ?? courseImage;
                }
              } catch (fetchErr) {
                console.warn(
                  'Unable to fetch latest course data, falling back to local state.',
                  fetchErr
                );
              }

              if (!existingCourseTopics.includes(newTopic.title)) {
                existingCourseTopics = [...existingCourseTopics, newTopic.title];
              }

              await axios.put(`${process.env.REACT_APP_API_BASE_URL}/api/courses/addTopic`, {
                title: courseTitle,
                topics: existingCourseTopics,
                image: courseImage,
              });

              setTree(prev => [...prev, normalizedTopic]);
              onRefreshCourseTree?.();
            } catch (err) {
              console.error('Error creating topic or updating course:', err);
            }

            setAddTopicState({ open: false, title: '' });
          }}
          sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: '33vw',
            bgcolor: 'background.paper',
            boxShadow: 24,
            borderRadius: 2,
            p: 4,
            display: 'flex',
            flexDirection: 'column',
            gap: 3,
          }}
        >
          <Typography variant="h6" component="h2">
            Add Topic
          </Typography>
          <TextField
            label="Topic Title"
            variant="outlined"
            value={addTopicState.title}
            onChange={e => setAddTopicState(prev => ({ ...prev, title: e.target.value }))}
            fullWidth
            autoFocus
          />
          <Stack direction="row" spacing={2} justifyContent="flex-end">
            <Button
              variant="outlined"
              onClick={() => setAddTopicState({ open: false, title: '' })}
              sx={{
                borderColor: '#ccc',
                color: '#333',
                backgroundColor: '#fff',
                '&:hover': {
                  backgroundColor: '#eee',
                },
              }}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="contained"
              sx={{
                backgroundColor: '#02542D',
                color: '#fff',
                '&:hover': {
                  backgroundColor: '#01411b',
                },
              }}
            >
              Create
            </Button>
          </Stack>
        </Box>
      </Modal>

      <Snackbar
        open={notice.open}
        autoHideDuration={4000}
        onClose={() => setNotice(s => ({ ...s, open: false }))}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
      >
        <Alert
          onClose={() => setNotice(s => ({ ...s, open: false }))}
          severity={notice.severity}
          sx={{ width: '100%' }}
        >
          {notice.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default DndSidebar;
