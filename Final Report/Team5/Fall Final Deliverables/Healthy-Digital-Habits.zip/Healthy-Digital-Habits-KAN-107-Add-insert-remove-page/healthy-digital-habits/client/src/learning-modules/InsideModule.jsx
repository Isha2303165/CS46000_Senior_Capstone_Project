import Button from '@mui/material/Button';
import Pagination from '@mui/material/Pagination';
import PaginationItem from '@mui/material/PaginationItem';
import axios from 'axios';
import { jwtDecode as jwt_decode } from 'jwt-decode';
import React, { useLayoutEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './Module.css';
import ModulePiece from './ModulePiece';

const InsideModule = () => {
  const [moduleData, setModuleData] = useState();
  const [decodedUname, setDecodedUname] = useState();
  const [currentPage, setCurrentPage] = useState(1);
  const [previousPages, setPreviousPages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [nextAllow, setNextAllow] = useState(true);
  const [moduleTime, setModuleTime] = useState('');
  let { id } = useParams();
  const navigate = useNavigate();
  const [moduleCompleted, setModuleCompleted] = useState(true);
  const [path, setPath] = useState([]);
  const [canMoveNext, setCanMoveNext] = useState(false);

  const handleChange = newPage => {
    if (newPage > 0) {
      setPreviousPages(prevPages => [...prevPages, currentPage]);
      setCurrentPage(newPage);
    }
  };

  const handleCloseModule = () => {
    axios.put(
      `${process.env.REACT_APP_API_BASE_URL}/api/modulecomplete?uname=${decodedUname}&id=${id}`
    );
    navigate('/module');
  };

  const handleUpdateTime = updatedTime => {
    setModuleTime(updatedTime);
    try {
      const currentTime = new Date();
      const futureTime = new Date(updatedTime.time);
      if (currentTime >= futureTime) {
        setNextAllow(true);
      } else {
        setNextAllow(false);
      }
    } catch (error) {
      console.error(
        'Error fetching time entry:',
        error.response ? error.response.data : error.message
      );
    }
  };

  useLayoutEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem('token');
        if (token) {
          const decoded = jwt_decode(token);
          setDecodedUname(decoded.uname);

          let userCurrentPage = 1;

          try {
            const userRes = await axios.get(
              `${process.env.REACT_APP_API_BASE_URL}/api/module/progress/${id}/${decoded.uname}`
            );
            const fetchedPage = Number(userRes.data.currentPage) || 1;
            userCurrentPage = Math.max(1, fetchedPage);
          } catch (error) {
            if (error.response && error.response.status === 404) {
              userCurrentPage = 1;
            } else {
              console.error('Error fetching progress:', error);
            }
          }

          const moduleRes = await axios.get(
            `${process.env.REACT_APP_API_BASE_URL}/api/module/${id}`
          );
          const modulePayload = moduleRes.data;
          setModuleData(modulePayload);

          const totalPages = modulePayload.pages?.length ?? 0;

          if (userCurrentPage < totalPages) {
            setCurrentPage(userCurrentPage);
          } else {
            setCurrentPage(1);
            userCurrentPage = 1;
          }

          let defaultPath;
          if (userCurrentPage === 1) {
            defaultPath = Array.from({ length: totalPages }, (_, index) => index + 1);
          } else {
            setPreviousPages(Array.from({ length: userCurrentPage - 1 }, (_, index) => index + 1));
            defaultPath = Array.from(
              { length: totalPages - userCurrentPage + 1 },
              (_, index) => userCurrentPage + index
            );
          }
          setPath(defaultPath);

          const completedModuleRes = await axios.get(
            `${process.env.REACT_APP_API_BASE_URL}/api/user/modulecomplete?uname=${decoded.uname}&id=${id}`
          );
          if (completedModuleRes.data.message === 'Completed') {
            setModuleCompleted(true);
          } else {
            setModuleCompleted(false);
          }

          const alreadyMarkedIncomplete = Array.isArray(modulePayload?.incompleted)
            ? modulePayload.incompleted.includes(decoded.uname)
            : false;

          if (!alreadyMarkedIncomplete) {
            try {
              await axios.put(
                `${process.env.REACT_APP_API_BASE_URL}/api/moduleincomplete?uname=${decoded.uname}&id=${id}`
              );
            } catch (err) {
              if (err?.response?.status !== 400) {
                console.error('Error marking module incomplete:', err);
              }
            }
          }
        }
      } catch (error) {
        console.error('Error: ', error);
        setError('Failed to fetch data.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id]);

  const handleNext = () => {
    const currentPageIndex = path.indexOf(currentPage);
    let nextPage = path[currentPageIndex + 1];
    path.splice(currentPageIndex, 1);
    if (nextPage) {
      if (previousPages[-1] != currentPage) {
        previousPages.push(currentPage);
      }
      setCurrentPage(nextPage);
    }

  };

  const handleBack = () => {
    const lastPage = previousPages[previousPages.length - 1];
    if (lastPage) {
      setPreviousPages(prevPages => prevPages.slice(0, -1));
      path.unshift(currentPage - 1);
      setCurrentPage(lastPage);
    }
  };

  const handlePathUpdate = newPath => {
    if (newPath) {
      const pathArray = [currentPage, ...newPath.split(',').map(num => parseInt(num, 10))];
      setPath(pathArray);
    }
  };

  const updateCanMoveNext = newCanMoveNext => {
    setCanMoveNext(newCanMoveNext);
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  const pages = moduleData?.pages || [];
  const currentPageData = pages[currentPage - 1] || null;

  if (!pages.length) {
    return <div>No module content available.</div>;
  }

  return (
    <div className="container-style">
      <div>
        <ModulePiece
          moduleContent={currentPageData || {}}
          pagePaths={moduleData?.pagePaths || {}}
          moduleId={id}
          currentPage={currentPage}
          onUpdateTime={
            currentPageData?.content === 'End of Module Activity' ? handleUpdateTime : ''
          }
          moduleCompleted={moduleCompleted}
          onPath={handlePathUpdate}
          updateCanMoveNext={updateCanMoveNext}
          modulePageCount={pages.length}
        />
        <div className="pagination-container">
          <Pagination
            disabled={!nextAllow}
            count={pages.length}
            page={currentPage}
            onChange={handleChange}
            renderItem={item => (
              <PaginationItem
                slots={{
                  previous: props => (
                    <div
                      {...props}
                      style={{ cursor: 'pointer', display: 'inline-block', padding: '10px' }}
                      onClick={handleBack}
                    >
                      Back
                    </div>
                  ),
                  next: props => (
                    <div
                      {...props}
                      style={{
                        cursor: canMoveNext ? 'pointer' : 'not-allowed',
                        display: 'inline-block',
                        padding: '10px',
                      }}
                      onClick={canMoveNext ? handleNext : null}
                    >
                      Next
                    </div>
                  ),
                }}
                {...item}
              />
            )}
          />
        </div>
        {currentPageData?.content === 'End of Module Activity Questions' && !moduleCompleted && (
          <div style={{ display: 'flex', justifyContent: 'center' }}>
            <Button variant="contained" color="primary" onClick={handleCloseModule}>
              Close Module
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default InsideModule;
