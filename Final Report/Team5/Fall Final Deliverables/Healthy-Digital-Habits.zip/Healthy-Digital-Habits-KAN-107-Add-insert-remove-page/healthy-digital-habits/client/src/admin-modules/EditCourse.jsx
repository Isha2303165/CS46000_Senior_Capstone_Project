import { Button, Card, FormControl, MenuItem, Select, TextField, Typography } from '@mui/material';
import React from 'react';

const EditCourse = ({
  selectedCourseToEdit,
  handleCourseTopicFill,
  courseImage,
  setCourseImage,
  courses,
  selectedTopicsForEdit,
  setSelectedTopicsForEdit,
  topics,
  moveUpTopics,
  moveDownTopics,
  handleUpdateCourse,
  setNewCourseName,
  newCourseName,
}) => {
  return (
    <Card
      sx={{
        marginTop: '20px',
        padding: '20px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Typography variant="h6" sx={{ marginBottom: '20px' }}>
        Edit Course
      </Typography>
      <FormControl
        fullWidth
        sx={{
          display: 'flex',
          alignItems: 'center',
        }}
      >
        <Typography variant="body1">Select Course to Edit</Typography>
        <Select
          labelId="topic-edit-select-label"
          value={selectedCourseToEdit}
          onChange={handleCourseTopicFill}
          style={{ width: '100%' }}
        >
          {courses.map(course => (
            <MenuItem key={course.title} value={course.title}>
              {course.title}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <br />
      <TextField
        label="New Course Name"
        value={newCourseName}
        onChange={e => setNewCourseName(e.target.value)}
        style={{ width: '100%' }}
      />
      <br />
      <TextField
        label="Course Image"
        value={courseImage}
        onChange={e => setCourseImage(e.target.value)}
        style={{ width: '100%' }}
      />
      <FormControl
        fullWidth
        sx={{
          display: 'flex',
          alignItems: 'center',
        }}
      >
        <br />
        <Typography variant="body1">Select Topics</Typography>
        <Select
          labelId="modules-edit-select-label"
          multiple
          value={selectedTopicsForEdit}
          onChange={e => setSelectedTopicsForEdit(e.target.value)}
          style={{ width: '100%' }}
        >
          {topics.map((topic, index) => (
            <MenuItem key={topic.title} value={topic.title}>
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}
              >
                {topic.title}
                <div>
                  <Button
                    onMouseDown={e => e.stopPropagation()}
                    onClick={() => moveUpTopics(index)}
                    disabled={index === 0}
                  >
                    ↑
                  </Button>
                  <Button
                    onMouseDown={e => e.stopPropagation()}
                    onClick={() => moveDownTopics(index)}
                    disabled={index === selectedTopicsForEdit.length - 1}
                  >
                    ↓
                  </Button>
                </div>
              </div>
            </MenuItem>
          ))}
        </Select>
        {selectedTopicsForEdit.length > 0 && (
          <Typography
            variant="body1"
            sx={{ margin: 'auto', marginTop: '10px', marginBottom: '10px' }}
          >
            Current Ordering: {selectedTopicsForEdit.join(', ')}
          </Typography>
        )}
      </FormControl>
      <br />
      <Button variant="contained" onClick={handleUpdateCourse}>
        Update Course
      </Button>
    </Card>
  );
};

export default EditCourse;
