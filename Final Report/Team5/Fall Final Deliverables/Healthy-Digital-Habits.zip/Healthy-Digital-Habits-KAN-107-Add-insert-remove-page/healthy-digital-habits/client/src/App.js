import React from 'react';
import { Navigate, Route, BrowserRouter as Router, Routes } from 'react-router-dom';
import AdminDashboardContent from './admin-dashboard/AdminDashboardContent';
import AdminExportsContents from './admin-exports/AdminExportsContents';
import AdminManagementPage from './admin-modules/AdminManagementPage';
import AdminModulesContents from './admin-modules/AdminModulesContents';
import InsideModule from './learning-modules/InsideModule';
import ModulePage from './learning-modules/ModulePage';
import ForgotPasswordContents from './login/ForgotContents';
import LogInContents from './login/LogInContents';
import DashboardContent from './parent-dashboard/DashboardContent';
import ProfilePageContent from './profile/ProfilePageContent';
import RegisterContents from './registration/RegisterContents';
import AdminModuleRouter from './admin-modules/AdminModuleRouter';
import { CourseProvider } from './contexts/CourseContext';


const App = () => (
  <CourseProvider>
    <Router>
      <Routes>
      <Route path="/" element={<Navigate to="/login" />} />
      <Route path="/login" element={<LogInContents />} />
      <Route path="/forgot" element={<ForgotPasswordContents />} />
      <Route path="/register" element={<RegisterContents />} />

      <Route path="/module" element={<ModulePage />} />
      <Route path="/module/:id" element={<InsideModule />} />

      <Route path="/dashboard" element={<DashboardContent />} />
      <Route path="/profile" element={<ProfilePageContent />} />

      <Route path="/admin/dashboard" element={<AdminDashboardContent />} />
      {/*
      Editmodules currently routes to AdminModulesContents which is the old edit modules page
      Once new edit modules page is done, change this to route to the new edit modules page
      */}
      {/*Old*/}
      {/* <Route path="/admin/Editmodules" element={<AdminModulesContents />} /> */}
      {/*New*/}
      <Route path="/admin/NewEditModules" element={<AdminModuleRouter />} />
      <Route path="/admin/modules" element={<AdminManagementPage />} />
      <Route path="/admin/exports" element={<AdminExportsContents />} />


      </Routes>
    </Router>
  </CourseProvider>
);

export default App;
