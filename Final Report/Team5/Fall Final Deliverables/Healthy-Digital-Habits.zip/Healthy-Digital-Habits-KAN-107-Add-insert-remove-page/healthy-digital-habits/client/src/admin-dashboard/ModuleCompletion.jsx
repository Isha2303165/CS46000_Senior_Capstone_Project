import Card from '@mui/material/Card';
import { MenuItem, Select, Typography } from '@mui/material';
import Box from '@mui/material/Box';
import axios from 'axios';
import { jwtDecode as jwt_decode } from 'jwt-decode';
import React, { useLayoutEffect, useState } from 'react';

const ActiveUsers = () => {
  // State to track selected module and its data
  const [selectedModule, setSelectedModule] = useState('');
  const [modulesList, setModulesList] = useState([]);
  const [incomplete, setIncomplete] = useState(0);
  const [complete, setComplete] = useState(0);
  const [decodedUname, setDecodedUname] = useState(null);

  const boxStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'center',
    fontFamily: 'Helvetica, sans-serif',
    fontWeight: '775',
    fontSize: '30px',
    color: 'white',
    border: '4px solid #4caf50', // medium green
    borderRadius: '12px', // rounded corners look smoother
    padding: '1rem',
  };

  const titleTextStyle = {
    marginTop: '0px',
    fontFamily: 'system-ui',
    fontWeight: '775',
    fontSize: '1.5vw',
    color: 'black',
  };

  const numBoxStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    margin: '20px',
  };

  // Fetch modules
  const fetchModules = async () => {
    try {
      const response = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/module`);
      setModulesList(response.data);
    } catch (error) {
      console.error('Error fetching modules:', error);
    }
  };

  // Fetch incomplete users for the selected module
  const fetchIncomplete = async moduleId => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_API_BASE_URL}/api/moduleincomplete?id=${moduleId}`
      );
      setIncomplete(response.data);
    } catch (error) {
      console.error('Error fetching incomplete users:', error);
    }
  };

  // Fetch complete users for the selected module
  const fetchComplete = async moduleId => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_API_BASE_URL}/api/modulecomplete?id=${moduleId}`
      );
      setComplete(response.data);
    } catch (error) {
      console.error('Error fetching complete users:', error);
    }
  };

  // Handle module selection
  const handleModuleChange = event => {
    const moduleId = event.target.value;
    setSelectedModule(moduleId);
    fetchIncomplete(moduleId);
    fetchComplete(moduleId);
  };

  // Decode user token and fetch modules
  useLayoutEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem('token');
      if (token) {
        try {
          const decoded = jwt_decode(token);
          setDecodedUname(decoded.uname);
          fetchModules();
        } catch (error) {
          console.error('Invalid token', error);
        }
      }
    };

    fetchData();
  }, []);

  return (
    <Card
      elevation={2}
      sx={{
        padding: '10px',
        width: '20vw',
        height: 'inherit',
        backgroundColor: '#FFFFFF',
        borderRadius: '15px',
      }}
    >
      <Box sx={boxStyle} style={{ display: 'flex', flexDirection: 'column' }}>
        <Box>
          <Typography style={titleTextStyle}> Module Completion </Typography>
        </Box>

        <Select
          value={selectedModule}
          onChange={handleModuleChange}
          style={{
            marginTop: '10px',
            color: 'rgb(0, 14, 36)',
            width: '10vw',
            height: '45px',
            backgroundColor: 'white',
            fontFamily: 'system-ui',
            borderRadius: '5px',
            textAlign: 'left',
            border: '2px solid #000000',
          }}
        >
          {modulesList.map(module => (
            <MenuItem key={module._id} value={module._id} style={{ color: 'black' }}>
              {module.title}
            </MenuItem>
          ))}
        </Select>

        <div style={{ display: 'flex', justifyContent: 'center', flexWrap: 'wrap' }}>
          <div style={numBoxStyle}>
            <Typography
              style={{
                fontSize: '2vw',
                color: 'black',
                fontFamily: 'system-ui',
                fontWeight: '775',
              }}
            >
              {incomplete}
            </Typography>
            <Typography
              style={{
                fontSize: '1vw',
                color: 'black',
                fontFamily: 'system-ui',
                fontWeight: '775',
              }}
            >
              Incomplete
            </Typography>
          </div>

          <div style={numBoxStyle}>
            <Typography
              style={{
                fontSize: '2vw',
                color: 'black',
                fontFamily: 'system-ui',
                fontWeight: '775',
              }}
            >
              {complete}
            </Typography>
            <Typography
              style={{
                fontSize: '1vw',
                color: 'black',
                fontFamily: 'system-ui',
                fontWeight: '775',
              }}
            >
              Completed
            </Typography>
          </div>
        </div>
      </Box>
    </Card>
  );
};

export default ActiveUsers;
