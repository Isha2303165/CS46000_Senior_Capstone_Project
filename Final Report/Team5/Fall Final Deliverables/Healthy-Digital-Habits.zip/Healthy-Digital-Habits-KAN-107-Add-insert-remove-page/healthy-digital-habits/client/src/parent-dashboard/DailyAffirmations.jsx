import Box from '@mui/material/Box';
import React, { useEffect, useState } from 'react';

const DailyAffirmations = () => {
  const [currentPhraseIndex, setCurrentPhraseIndex] = useState(0);

  const phrases = [
    'Transform your habits, transform your life.',
    'Break free from the screen, embrace reality.',
    'Change your behavior, change your destiny.',
    'Unlock your potential by locking away your phone.',
    'Reclaim your time, rewire your mind.',
    'Embrace the present, let go of the virtual.',
    'Small changes, big impact—start with your phone.',
    'Disconnect to reconnect with yourself.',
    'Your future self will thank you for putting down the phone today.',
    'Break the chains of digital distraction, forge a path to focus.',
    'Ditch the screen, live your dream.',
    'Mindful moments trump mindless scrolling.',
    'Switch off to switch on your inner brilliance.',
    'Phone down, head up—embrace the real world.',
    'Challenge yourself to change, one swipe at a time.',
    'Elevate your life by lowering your screen time.',
    'New habits, new heights—rise above the phone.',
    'Rewrite your story, one conscious choice at a time.',
    'Step away from the screen, step into a better you.',
    'Break the digital chains, find freedom in the real world.',
    'Phone addiction fades, your true self cascades.',
    'Awaken your potential, silence your phone.',
    'Choose presence over pixels.',
    'The power to change is in your hands, not in your phone.',
    'Trade scrolling for strolling—walk into a new chapter.',
    'Unplug to unleash your untapped potential.',
    'Redefine your reality by disconnecting from the virtual.',
    'Phone off, life on—ignite the spark within.',
    'Mindful moments are the keystones to behavioral change.',
    'Break the screen spell, rewrite your own story.',
    'In the silence between notifications, find the symphony of your life.',
    'Pause, reflect, transform—break the cycle.',
    'Digital detox: the key to unlocking your true self.',
    'Craft a life beyond the screen, sculpt a new you.',
    'Outsmart the smartphone, reclaim your mind.',
    'Behold the beauty beyond the screen, the real world awaits.',
    'Swipe left on old habits, swipe right on a new you.',
    'Shed the digital cocoon, emerge as a butterfly of change.',
    'Phone in pockets, dreams in motion—let the transformation begin.',
    'Less scrolling, more soaring—take flight from the virtual cage.',
  ];

  const BoxStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    paddingRight: '1rem',
  };

  const quoteTextStyle = {
    fontSize: 'clamp(1rem, 1.5vw, 2rem)',
    textAlign: 'center',
    fontFamily: 'Helvetica, sans-serif',
    fontStyle: 'italic',
    fontWeight: '300',
    color: 'black',
  };

  useEffect(() => {
    // Retrieve the last displayed phrase index from localStorage
    const lastPhraseIndex = localStorage.getItem('lastPhraseIndex');

    // Generate a new random index different from the last one
    const randomIndex = getRandomIndex(phrases.length, lastPhraseIndex);

    // Update the current phrase index and store the new index in localStorage
    setCurrentPhraseIndex(randomIndex);
    localStorage.setItem('lastPhraseIndex', randomIndex);
  }, []); // Empty dependency array ensures it runs only once on component mount

  const getRandomIndex = (max, exclude) => {
    let randomIndex = Math.floor(Math.random() * max);
    // Make sure the new random index is different from the excluded one
    while (randomIndex === parseInt(exclude)) {
      randomIndex = Math.floor(Math.random() * max);
    }
    return randomIndex;
  };

  return (
    <Box sx={BoxStyle}>
      <div style={quoteTextStyle}>{phrases[currentPhraseIndex]}</div>
    </Box>
  );
};

export default DailyAffirmations;
