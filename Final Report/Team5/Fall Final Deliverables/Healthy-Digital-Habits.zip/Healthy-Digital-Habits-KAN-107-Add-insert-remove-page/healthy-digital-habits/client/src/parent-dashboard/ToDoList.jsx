import { Typography, Card } from '@mui/material/';
import Box from '@mui/material/Box';
import axios from 'axios';
import { jwtDecode as jwt_decode } from 'jwt-decode';
import React, { useLayoutEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const ToDoList = () => {
  const BoxStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    marginTop: '-3rem',
    width: '50%',
    border: '2px solid rgb(206, 206, 206)',
    padding: '1rem',
    backgroundColor: '#F1EFEC',
  };

  const titleboxStyle = {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'center',
    paddingBottom: '4rem',
  };

  const titleTextStyle = {
    fontFamily: 'system-ui',
    fontWeight: '775',
    fontSize: 'clamp(2.5rem, 1.5vw, 2rem)',
    color: 'black',
  };

  const textStyle = {
    fontFamily: 'system-ui',
    fontWeight: '775',
    fontSize: 'clamp(1.25rem, 1.5vw, 2rem)',
    color: 'black',
    cursor: 'pointer',
  };

  const taskTextStyle = {
    fontFamily: 'system-ui',
    fontWeight: '775',
    fontSize: 'clamp(1.25rem, 1.5vw, 2rem)',
    color: 'black',
    textDecoration: 'underline',
    cursor: 'pointer',
  };

  const [decodedModule, setDecodedModule] = useState(null);
  const [decodedModuleId, setDecodedModuleId] = useState(null);
  const navigate = useNavigate();

  useLayoutEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem('token');
      if (token) {
        try {
          const decoded = jwt_decode(token);
          setDecodedModuleId(decoded.module);
          const response = await axios.get(
            `${process.env.REACT_APP_API_BASE_URL}/api/user/modulestring?uname=${decoded.uname}`
          );
          setDecodedModule(response.data);
          checkSurveyTimestamp(decoded.uname);
        } catch (error) {
          console.error('Invalid token', error);
        }
      }
    };

    fetchData();
  }, []);

  const handleNavigate = () => {
    if (decodedModuleId) {
      navigate(`/module/${decodedModuleId}`);
    }
  };

  const [isSurveyAllowed, setSurveyAllowed] = useState(false);
  const checkSurveyTimestamp = uname => {
    axios
      .get(`${process.env.REACT_APP_API_BASE_URL}/api/dashboard?uname=${uname}`)
      .then(response => {
        if (response.data.length > 0) {
          const lastSurveyTimestamp = new Date(response.data[response.data.length - 1].createdAt);
          const currentTime = new Date();

          const timeDifference = currentTime - lastSurveyTimestamp;
          const hoursDifference = timeDifference / (1000 * 60 * 60);

          if (hoursDifference >= 24) {
            setSurveyAllowed(true);
          } else {
            setSurveyAllowed(false);
          }
        } else {
          setSurveyAllowed(true);
        }
      })
      .catch(err => {
        console.log(err);
      });
  };

  return (
    <Card elevation={2} sx={BoxStyle}>
      <Box style={titleboxStyle}>
        <Typography style={titleTextStyle}>To-Do List</Typography>
      </Box>

      <div style={taskTextStyle} onClick={handleNavigate}>
        - Complete your Current Module: {decodedModule}
      </div>
      {isSurveyAllowed && <div style={textStyle}> - Daily Reflection</div>}
    </Card>
  );
};

export default ToDoList;
