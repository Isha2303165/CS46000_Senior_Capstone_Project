import {
  Alert,
  Box,
  Button,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  Snackbar,
  TextField,
} from '@mui/material';
import axios from 'axios';
import React, { useEffect, useState } from 'react';

const AdminExports = () => {
  const [selectedUser, setSelectedUser] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [selectedCourse, setSelectedCourse] = useState('');
  const [selectedTopic, setSelectedTopic] = useState('');
  const [selectedModule, setSelectedModule] = useState('');
  const [users, setUsers] = useState([]);
  const [modules, setModules] = useState([]);
  const [topics, setTopics] = useState([]);
  const [courses, setCourses] = useState([]);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');
  const [snackbarSeverity, setSnackbarSeverity] = useState('success');

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/user/all`);
        setUsers([{ uname: 'All Users' }, ...response.data]);
        const topicsRes = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/topics/all`);
        setTopics(topicsRes.data);
        const coursesRes = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/courses/all`);
        setCourses(coursesRes.data);
        const modulesRes = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/module`);
        setModules(modulesRes.data);
      } catch (error) {
        console.error('Error fetching users:', error);
        triggerSnackbar('Failed to fetch users', 'error');
      }
    };

    fetchUsers();
  }, []);

  const triggerSnackbar = (message, severity = 'success') => {
    setSnackbarMessage(message);
    setSnackbarSeverity(severity);
    setSnackbarOpen(true);
  };

  const handleSnackbarClose = () => {
    setSnackbarOpen(false);
  };

  function jsonToCsv(jsonData) {
    if (!Array.isArray(jsonData) || jsonData.length === 0) {
      return '';
    }

    const flattenObject = (obj, parentKey = '', result = {}) => {
      for (const key in obj) {
        if (Object.hasOwnProperty.call(obj, key)) {
          const propName = parentKey ? `${parentKey}.${key}` : key;

          // Rename specific keys
          let newKey =
            propName === 'response.answer'
              ? 'answer'
              : propName === 'response.question'
                ? 'question'
                : propName;

          if (propName === 'mood.Focus') {
            newKey = 'focus';
          } else if (propName === 'mood.Control') {
            newKey = 'control';
          } else if (propName === 'mood.Empowerment') {
            newKey = 'empowerment';
          } else if (propName === 'mood.Guilt') {
            newKey = 'guilt';
          }

          if (typeof obj[key] === 'object' && obj[key] !== null && !Array.isArray(obj[key])) {
            flattenObject(obj[key], newKey, result); // Recursive call for nested objects
          } else if (!['__v', '_id', 'updatedAt'].includes(key)) {
            result[newKey] = obj[key]; // Assign value with the renamed key
          }
        }
      }
      return result;
    };

    // Flatten all objects in the array
    const flattenedData = jsonData.map(item => flattenObject(item));

    // Extract unique headers from all flattened objects
    const headers = Array.from(new Set(flattenedData.flatMap(item => Object.keys(item))));

    // Construct CSV
    let csv = headers.join(',') + '\n';
    flattenedData.forEach(item => {
      if (item.moduleId !== selectedModule && selectedModule !== '') {
        return;
      }

      if (item.topic !== selectedTopic && selectedTopic !== '') {
        return;
      }

      if (item.course !== selectedCourse && selectedCourse !== '') {
        return;
      }

      const row = headers.map(header => {
        let value = item[header] !== undefined ? item[header] : '';
        // Wrap values with commas or double quotes in double quotes
        if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
          value = `"${value.replace(/"/g, '""')}"`; // Escape double quotes by doubling them
        }
        return value;
      });
      csv += row.join(',') + '\n';
    });

    return csv;
  }

  function downloadBlob(content, filename, contentType) {
    // Create a blob
    var blob = new Blob([content], { type: contentType });
    var url = URL.createObjectURL(blob);

    // Create a link to download it
    var pom = document.createElement('a');
    pom.href = url;
    pom.setAttribute('download', filename);
    pom.click();
  }

  const handleResponses = async () => {
    try {
      if (selectedUser === 'All Users') {
        let aggregatedData = [];
        for (const user of users) {
          if (user.uname !== 'All Users') {
            const response = await axios.get(
              `${process.env.REACT_APP_API_BASE_URL}/api/userAnswers/${user.uname}`
            );
            aggregatedData = aggregatedData.concat(response.data);
          }
        }
        const csv = jsonToCsv(aggregatedData);
        downloadBlob(csv, 'AllUsers-responses-export.csv', 'text/csv;charset=utf-8;');
      } else {
        const response = await axios.get(
          `${process.env.REACT_APP_API_BASE_URL}/api/userAnswers/${selectedUser}`
        );

        const csv = jsonToCsv(response.data);
        downloadBlob(csv, selectedUser + '-responses-export.csv', 'text/csv;charset=utf-8;');
      }
    } catch (error) {
      console.error('Error exporting responses:', error);
      triggerSnackbar('Failed to export responses', 'error');
    }
  };

  const handleData = async () => {
    try {
      if (selectedUser === 'All Users') {
        let aggregatedData = [];
        let aggregatedDailySurveys = [];
        for (const user of users) {
          if (user.uname !== 'All Users') {
            const module = await axios.get(
              `${process.env.REACT_APP_API_BASE_URL}/api/user/modulestring?uname=${user.uname}`
            );
            const currentpage = await axios.get(
              `${process.env.REACT_APP_API_BASE_URL}/api/user/currentpage?uname=${user.uname}`
            );
            const userLogins = await axios.get(
              `${process.env.REACT_APP_API_BASE_URL}/api/user/loginsSum?uname=${user.uname}`
            );
            const dailySurvey = await axios.get(
              `${process.env.REACT_APP_API_BASE_URL}/api/dashboard?uname=${user.uname}&startDate=${fromDate}&endDate=${toDate}`
            );

            aggregatedData.push({
              uname: user.uname,
              currentModule: module.data,
              currentPage: currentpage.data,
              userLogins: userLogins.data.count,
            });
            aggregatedDailySurveys.push(dailySurvey.data);
          }
        }

        const mergedCsv = jsonToCsv(aggregatedData);
        const dailySurveyCsv = jsonToCsv(aggregatedDailySurveys);
        const csv = mergedCsv + '\n' + dailySurveyCsv;

        downloadBlob(csv, 'AllUsers-data-export.csv', 'text/csv;charset=utf-8;');
      } else {
        const module = await axios.get(
          `${process.env.REACT_APP_API_BASE_URL}/api/user/modulestring?uname=${selectedUser}`
        );
        const currentpage = await axios.get(
          `${process.env.REACT_APP_API_BASE_URL}/api/user/currentpage?uname=${selectedUser}`
        );
        const userLogins = await axios.get(
          `${process.env.REACT_APP_API_BASE_URL}/api/user/loginsSum?uname=${selectedUser}`
        );
        const dailySurvey = await axios.get(
          `${process.env.REACT_APP_API_BASE_URL}/api/dashboard?uname=${selectedUser}&startDate=${fromDate}&endDate=${toDate}`
        );

        const dailySurveyCsv = jsonToCsv([dailySurvey.data]);

        const mergedData = {
          currentModule: module.data,
          currentPage: currentpage.data,
          userLogins: userLogins.data.count,
        };

        const mergedCsv = jsonToCsv([mergedData]);
        const csv = mergedCsv + '\n' + dailySurveyCsv;

        downloadBlob(csv, selectedUser + '-data-export.csv', 'text/csv;charset=utf-8;');
      }
    } catch (error) {
      console.error('Error exporting data:', error);
      triggerSnackbar('Failed to export data', 'error');
    }
  };

  const handleExportResponses = () => {
    triggerSnackbar(`Exporting responses for user: ${selectedUser}`, 'info');
    handleResponses();
  };

  const handleExportData = () => {
    triggerSnackbar(`Exporting data for user: ${selectedUser}`, 'info');
    handleData();
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3, p: 3, minWidth: 300 }}>
      {/* User Selection */}
      <FormControl fullWidth>
        <InputLabel id="user-select-label">Select User</InputLabel>
        <Select
          labelId="user-select-label"
          value={selectedUser}
          onChange={e => setSelectedUser(e.target.value)}
          label="Select User"
        >
          {users.map(user => (
            <MenuItem key={user.uname} value={user.uname}>
              {user.uname}
            </MenuItem>
          ))}
        </Select>
      </FormControl>

      {/* Date Range Selection */}
      <Box sx={{ display: 'flex', flexDirection: 'row', gap: 2 }}>
        <FormControl fullWidth>
          <TextField
            label="From Date"
            type="date"
            value={fromDate}
            onChange={e => setFromDate(e.target.value)}
            InputLabelProps={{ shrink: true }}
          />
        </FormControl>
        <FormControl fullWidth>
          <TextField
            label="To Date"
            type="date"
            value={toDate}
            onChange={e => setToDate(e.target.value)}
            InputLabelProps={{ shrink: true }}
          />
        </FormControl>
      </Box>

      {/* Course Selection */}
      <FormControl fullWidth>
        <InputLabel id="course-select-label">Select Course</InputLabel>
        <Select
          labelId="course-select-label"
          value={selectedCourse}
          onChange={e => setSelectedCourse(e.target.value)}
          label="Select Course"
        >
          {courses.map(course => (
            <MenuItem key={course._id} value={course.title}>
              {course.title}
            </MenuItem>
          ))}
        </Select>
      </FormControl>

      {/* Topic Selection */}
      <FormControl fullWidth>
        <InputLabel id="topic-select-label">Select Topic</InputLabel>
        <Select
          labelId="topic-select-label"
          value={selectedTopic}
          onChange={e => setSelectedTopic(e.target.value)}
          label="Select Topic"
        >
          {topics.map(topic => (
            <MenuItem key={topic._id} value={topic.title}>
              {topic.title}
            </MenuItem>
          ))}
        </Select>
      </FormControl>

      {/* Module Selection */}
      <FormControl fullWidth>
        <InputLabel id="module-select-label">Select Module</InputLabel>
        <Select
          labelId="module-select-label"
          value={selectedModule}
          onChange={e => setSelectedModule(e.target.value)}
          label="Select Module"
        >
          {modules.map(module => (
            <MenuItem key={module._id} value={module._id}>
              {module.title}
            </MenuItem>
          ))}
        </Select>
      </FormControl>

      {selectedUser && (
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          <Button variant="contained" color="primary" onClick={handleExportResponses}>
            Export Responses
          </Button>
          <Button variant="contained" color="primary" onClick={handleExportData}>
            Export Data
          </Button>
        </Box>
      )}

      {/* Snackbar Component */}
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={3000}
        onClose={handleSnackbarClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert onClose={handleSnackbarClose} severity={snackbarSeverity} sx={{ width: '100%' }}>
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default AdminExports;
