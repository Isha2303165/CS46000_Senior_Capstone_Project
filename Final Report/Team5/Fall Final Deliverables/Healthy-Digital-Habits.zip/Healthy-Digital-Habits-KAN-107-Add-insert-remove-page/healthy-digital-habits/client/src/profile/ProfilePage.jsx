import EmailRoundedIcon from '@mui/icons-material/EmailRounded';
import {
  Alert,
  Box,
  Button,
  Card,
  CardActions,
  Container,
  FormControl,
  FormLabel,
  Grid,
  Input,
  MenuItem,
  Select,
  Snackbar,
  Typography,
} from '@mui/material';
import axios from 'axios';
import { jwtDecode as jwt_decode } from 'jwt-decode';
import React, { useEffect, useState } from 'react';
import ConfirmationCheck from '../shared/ConfirmationCheck';

const EMAIL_REGEX = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
const NAME_REGEX = /^[A-Za-z-]+$/;
const PHONE_REGEX = /^(?:\+?1[-. ]?)?(?:(\(\d{3}\))|\d{3})[-. ]?\d{3}[-. ]?\d{4}$/;

export default function ProfilePage() {
  const [user, setUser] = useState({});
  const [isAdmin, setIsAdmin] = useState(false);
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [formData, setFormData] = useState({ first: '', last: '', email: '', phone: '', type: '' });
  const [errors, setErrors] = useState({});
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [confirmationMessage, setConfirmationMessage] = useState('');
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const token = localStorage.getItem('token');
        const decoded = jwt_decode(token);
        setIsAdmin(decoded.type === 'admin');

        const res = await axios.get(
          `${process.env.REACT_APP_API_BASE_URL}/api/user?uname=${decoded.uname}`
        );
        const result = res.data[res.data.length - 1];
        setUser(result);
        setFormData({
          first: result.fname,
          last: result.lname,
          email: result.email,
          phone: result.ph,
          type: result.type,
        });

        if (decoded.type === 'admin') {
          const allUsersRes = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/user/all`);
          setUsers(allUsersRes.data);
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    };

    fetchUserData();
  }, []);

  const handleUserSelect = event => {
    const selected = users.find(u => u.uname === event.target.value);
    setSelectedUser(selected);
    setFormData({
      first: selected.fname,
      last: selected.lname,
      email: selected.email,
      phone: selected.ph,
      type: selected.type,
    });
  };

  const validateInputs = () => {
    const newErrors = {};
    if (!NAME_REGEX.test(formData.first)) newErrors.first = 'Invalid first name.';
    if (!NAME_REGEX.test(formData.last)) newErrors.last = 'Invalid last name.';
    if (!EMAIL_REGEX.test(formData.email)) newErrors.email = 'Invalid email.';
    if (!PHONE_REGEX.test(formData.phone)) newErrors.phone = 'Invalid phone number.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleUpdate = async () => {
    if (!validateInputs()) return;
    setIsConfirmationOpen(false);

    try {
      await axios.put(`${process.env.REACT_APP_API_BASE_URL}/api/user/update`, {
        ...formData,
        uname: selectedUser ? selectedUser.uname : user.uname,
      });
      setConfirmationMessage('Profile updated successfully!');
    } catch (error) {
      setConfirmationMessage('Error updating profile!');
    } finally {
      setOpenSnackbar(true);
    }
  };

  const handleCancel = () => {
    const fallback = selectedUser || user;
    setFormData({
      first: fallback.fname,
      last: fallback.lname,
      email: fallback.email,
      phone: fallback.ph,
      type: fallback.type,
    });
    setErrors({});
  };

  const handleCloseSnackbar = () => setOpenSnackbar(false);

  return (
    <Container>
      {isAdmin && (
        <Box sx={{ margin: 2, maxWidth: 300, justifySelf: 'center' }}>
          <FormControl fullWidth>
            <FormLabel>Select User</FormLabel>
            <Select value={selectedUser?.uname || ''} onChange={handleUserSelect} displayEmpty>
              <MenuItem value="" disabled>
                Select a user
              </MenuItem>
              {users.map(u => (
                <MenuItem key={u.uname} value={u.uname}>
                  {`${u.fname} ${u.lname}`}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Box>
      )}
      <Card sx={{ boxShadow: 'none', border: 'none', padding: 2 }}>
        <Box sx={{ justifySelf: 'center' }}>
          {Object.values(errors).map((error, index) => (
            <Typography key={index} sx={{ color: 'firebrick', fontWeight: 'bold' }}>
              {error}
            </Typography>
          ))}
        </Box>
        <Grid
          container
          direction="column"
          spacing={2}
          alignItems="center"
          sx={{ maxWidth: 400, margin: '0 auto' }}
        >
          <Grid item xs={12}>
            <FormControl fullWidth>
              <FormLabel>First Name</FormLabel>
              <Input
                value={formData.first}
                onChange={e => setFormData({ ...formData, first: e.target.value })}
                sx={{ maxWidth: 300 }}
              />
            </FormControl>
          </Grid>
          <Grid item xs={12}>
            <FormControl fullWidth>
              <FormLabel>Last Name</FormLabel>
              <Input
                value={formData.last}
                onChange={e => setFormData({ ...formData, last: e.target.value })}
                sx={{ maxWidth: 300 }}
              />
            </FormControl>
          </Grid>
          <Grid item xs={12}>
            <FormControl fullWidth>
              <FormLabel>Email</FormLabel>
              <Input
                type="email"
                startDecorator={<EmailRoundedIcon />}
                value={formData.email}
                onChange={e => setFormData({ ...formData, email: e.target.value })}
                sx={{ maxWidth: 300 }}
              />
            </FormControl>
          </Grid>
          <Grid item xs={12}>
            <FormControl fullWidth>
              <FormLabel>Phone</FormLabel>
              <Input
                value={formData.phone}
                onChange={e => setFormData({ ...formData, phone: e.target.value })}
                sx={{ maxWidth: 300 }}
              />
            </FormControl>
          </Grid>
          {isAdmin && (
            <Grid item xs={12}>
              <FormControl fullWidth>
                <FormLabel>Account Type</FormLabel>
                <Select
                  value={formData.type}
                  onChange={e => setFormData({ ...formData, type: e.target.value })}
                  sx={{ minWidth: 200 }}
                >
                  <MenuItem value="parent">Parent</MenuItem>
                  <MenuItem value="researcher">Researcher</MenuItem>
                  <MenuItem value="admin">Admin</MenuItem>
                </Select>
              </FormControl>
            </Grid>
          )}
        </Grid>
        <CardActions sx={{ display: 'flex', justifyContent: 'center', gap: 2, marginTop: 2 }}>
          <Button variant="contained" color="primary" onClick={() => setIsConfirmationOpen(true)}>
            Save
          </Button>
          <Button variant="outlined" color="primary" onClick={handleCancel}>
            Reset
          </Button>
        </CardActions>
      </Card>

      <Snackbar open={openSnackbar} autoHideDuration={6000} onClose={handleCloseSnackbar}>
        <Alert
          severity={confirmationMessage.includes('Error') ? 'error' : 'success'}
          onClose={handleCloseSnackbar}
        >
          {confirmationMessage}
        </Alert>
      </Snackbar>

      <ConfirmationCheck
        open={isConfirmationOpen}
        onClose={() => setIsConfirmationOpen(false)}
        onConfirm={handleUpdate}
        title="Confirm Profile Update?"
        message="Are you sure you want to save these changes?"
      />
    </Container>
  );
}
