import { CircularProgress, Dialog, DialogContent, DialogTitle, TextField, IconButton } from '@mui/material';
import Box from '@mui/material/Box';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import Button from '@mui/material/Button';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import LinearProgress from '@mui/material/LinearProgress';
import Typography from '@mui/material/Typography';
import axios from 'axios';
import { jwtDecode as jwt_decode } from 'jwt-decode';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Navigate } from 'react-router-dom';
import './Module.css';
import AdminModuleEditor from '../admin-modules/AdminModuleEditor';
import { useCourse } from '../contexts/CourseContext';
import CourseCreationModal from '../admin-modules/CourseCreationModal';
import DeleteConfirmationModal from '../components/DeleteConfirmationModal';

const NextModule = () => {
  const {
    coursesData,
    setCoursesData,
    selectedCourse,
    setSelectedCourse,
    topicsData,
    setTopicsData,
    moduleDetails,
    setModuleDetails,
    completedModules,
    setCompletedModules,
    completedTopics,
    setCompletedTopics,
    completedCourses,
    setCompletedCourses,
    overlayStyle,
    modalStyle,
  } = useCourse();
  const [selected, setSelected] = useState('All');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const openModal = () => setIsModalOpen(true);
  const closeModal = () => setIsModalOpen(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [courseToDelete, setCourseToDelete] = useState(null);
  const openDeleteModal = course => {
    setCourseToDelete(course);
    setIsDeleteModalOpen(true);
  };
  const closeDeleteModal = () => {
    setIsDeleteModalOpen(false);
    setCourseToDelete(null);
  };

  const handleDeleteConfirm = async () => {
    try {
      const title = courseToDelete.title;
      console.log('Deleting course:', title);
      const response = await axios.delete(
        `${process.env.REACT_APP_API_BASE_URL}/api/courses/delete?title=${encodeURIComponent(title)}`
      );
      console.log('Course deleted successfully:', response.data);
      setSelectedCourse(null);
      closeDeleteModal();
    } catch (error) {
      console.error('Error deleting course:', error);
    }
    window.location.reload();
  };

  const handleToggleHidden = async (course, event) => {
    event.stopPropagation(); // Prevent opening the course dialog
    // Normalize hidden value (handle both boolean and string)
    const currentHidden = course.hidden === true || course.hidden === 'true';
    const newHidden = !currentHidden;

    try {
      const response = await axios.put(
        `${process.env.REACT_APP_API_BASE_URL}/api/courses/toggle-hidden/${course._id || course.title}`,
        { hidden: newHidden }
      );

      // Update the course in the local state
      setCoursesData(prevCourses =>
        prevCourses.map(c =>
          c._id === course._id || c.title === course.title ? { ...c, hidden: newHidden } : c
        )
      );

      console.log('Course visibility updated:', response.data);
    } catch (error) {
      console.error('Error updating course visibility:', error);
      alert('Failed to update course visibility');
    }
  };

  const [decodedType, setDecodedType] = useState(null);
  const [loadingCourses, setLoadingCourses] = useState(true);

  function LinearProgressWithLabel(props) {
    return (
      <Box sx={{ display: 'flex', flexDirection: 'column', width: '100%' }}>
        <Typography
          variant="body1"
          sx={{
            color: 'text.secondary',
            marginBottom: '4px',
            textAlign: 'left',
            fontWeight: 'bold',
          }}
        >
          {`${Math.round(props.value)}%`}
        </Typography>
        <Box sx={{ width: '100%' }}>
          <LinearProgress
            variant="determinate"
            {...props}
            sx={{
              height: 10,
              borderRadius: '5px',
              backgroundColor: '#e6f4ea',
              '& .MuiLinearProgress-bar': {
                backgroundColor: '#0f9d58',
              },
            }}
          />
        </Box>
      </Box>
    );
  }

  useEffect(() => {
    const fetchTopicsData = async () => {
      setLoadingCourses(true);
      try {
        const token = localStorage.getItem('token');
        if (token) {
          const decoded = jwt_decode(token);
          await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/user?uname=${decoded.uname}`);
          setDecodedType(decoded.type);
          const coursesRes = await axios.get(
            `${process.env.REACT_APP_API_BASE_URL}/api/courses/all`
          );
          let updatedCourses = [];

          for (const course of coursesRes.data) {
            try {
              // Hide courses from parents if hidden is true (check for both boolean true and string "true")
              // Treat undefined/null as false (visible)
              const isHidden = course.hidden === true || course.hidden === 'true';
              if (decoded.type === 'parent' && isHidden) {
                continue;
              }

              let allTopicsCompleted = 1;
              let completedTopicCount = 0;
              let totalTopics = course.topics.length;
              let totalModules = 0;
              let totalModulesProgress = 0;

              for (const topic of course.topics) {
                try {
                  const res = await axios.get(
                    `${process.env.REACT_APP_API_BASE_URL}/api/topics/oneTopic?topic=${topic}`
                  );
                  let allModulesCompleted = 1;
                  let completedModuleCount = 0;
                  totalModules += res.data.modules?.length ?? 0;

                  for (const module of res.data.modules ?? []) {
                    try {
                      const moduleRes = await axios.get(
                        `${process.env.REACT_APP_API_BASE_URL}/api/module/${module}`
                      );
                      const completedModuleRes = await axios.get(
                        `${process.env.REACT_APP_API_BASE_URL}/api/user/modulecomplete?uname=${decoded.uname}&id=${module}`
                      );

                      moduleRes.data.completedMessage = completedModuleRes.data.message;
                      if (completedModuleRes.data.message === 'Completed') {
                        setCompletedModules(prevCompleted => [...prevCompleted, module]);
                        completedModuleCount++;
                      } else {
                        allModulesCompleted = 0;
                      }

                      // Fetch progress - handle 404 gracefully (module not started yet)
                      // Wrap in try-catch to ensure it never blocks page loading
                      try {
                        const progressRes = await axios.get(
                          `${process.env.REACT_APP_API_BASE_URL}/api/module/progress/${module}/${decoded.uname}`,
                          {
                            validateStatus: status => status === 200 || status === 404,
                          }
                        );
                        if (
                          progressRes.status === 200 &&
                          progressRes.data?.progressPercentage !== undefined
                        ) {
                          const progress = Number(progressRes.data.progressPercentage) || 0;
                          moduleRes.data.progressPercentage = progress;
                          totalModulesProgress += progress;
                        } else {
                          // 404 is expected for modules that haven't been started yet
                          moduleRes.data.progressPercentage = 0;
                        }
                      } catch (error) {
                        // Silently handle all errors - don't let progress fetching block page load
                        moduleRes.data.progressPercentage = 0;
                      }

                      setModuleDetails(prevState => ({
                        ...prevState,
                        [module]: moduleRes.data,
                      }));
                      setTopicsData(prevState => ({
                        ...prevState,

                        //I found an issue (on my side) w/ topics appearing multiple times. This checks for any existing duplicates.
                        //Find out if there's an existing module in the array; if true, return none so it doesn't show on page.
                        [topic]: prevState[topic]?.some(m => m._id === moduleRes.data._id)
                          ? prevState[topic]
                          : [...(prevState[topic] || []), moduleRes.data],
                      }));
                    } catch (error) {
                      console.error(`Error fetching data for module ${module}:`, error);
                    }
                  }

                  if (allModulesCompleted === 1) {
                    setCompletedTopics(prevCompleted => [...prevCompleted, topic]);
                    completedTopicCount++;
                  } else {
                    allTopicsCompleted = 0;
                  }
                } catch (error) {
                  console.error(`Error fetching topic ${topic}:`, error);
                  // Continue processing other topics even if one fails
                }
              }

              if (allTopicsCompleted === 1) {
                setCompletedCourses(prevCompleted => [...prevCompleted, course.title]);
              }

              // Calculate progress, handling division by zero
              const progress = totalModules > 0 ? totalModulesProgress / totalModules : 0;

              // Normalize hidden property to boolean (handle boolean, string, undefined, null)
              const normalizedHidden = course.hidden === true || course.hidden === 'true';

              updatedCourses.push({
                ...course,
                hidden: normalizedHidden,
                progress,
                numTopicsCompleted: completedTopicCount,
              });
            } catch (error) {
              console.error(`Error processing course ${course.title}:`, error);
              // Add course with default values even if processing failed
              const normalizedHidden = course.hidden === true || course.hidden === 'true';
              updatedCourses.push({
                ...course,
                hidden: normalizedHidden,
                progress: 0,
                numTopicsCompleted: 0,
              });
            }
          }

          setCoursesData(updatedCourses);
        }
      } catch (error) {
        console.error('Error fetching topic or module data:', error);
      } finally {
        setLoadingCourses(false);
      }
    };
    fetchTopicsData();
    setSelectedCourse(null);
  }, []);

  const buttonStyles = name => ({
    border: selected === name ? '2px solid #0f9d58' : '2px solid transparent',
    backgroundColor: 'transparent',
    color: '#0f9d58',
    marginBottom: '10px',
    maxWidth: '150px',
    fontWeight: selected === name ? 'bold' : 'normal',
  });

  const handleCourseClick = course => {
    setSelectedCourse(course);
  };

  const handleClose = () => {
    setSelectedCourse(null);
  };

  const [selectedCourseName, setSelectedCourseName] = useState('');

  const handleSearchChange = event => {
    setSelectedCourseName(event.target.value);
  };

  const filteredCourses = coursesData.filter(course => {
    const matchesName = selectedCourseName
      ? course.title.toLowerCase().includes(selectedCourseName.toLowerCase())
      : true;

    if (selected === 'In Progress') {
      return matchesName && course.progress > 0 && course.progress < 100;
    } else if (selected === 'Completed') {
      return matchesName && course.progress === 100;
    }
    return matchesName;
  });

  const handleAddTopics = () => {
    localStorage.setItem('lastCourseId', selectedCourse._id);

    return <Navigate to="/admin/editModules" state={{ courseName: selectedCourse.title }} />;
  };

  return (
    <div style={flexWrapperStyle}>
      <h1 style={{ textAlign: 'center', marginTop: '4rem' }}>Select a Course, Topic, and Module</h1>
      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '1rem' }}>
        {['All', 'In Progress', 'Completed'].map(status => (
          <Button
            key={status}
            variant="outlined"
            onClick={() => setSelected(status)}
            style={buttonStyles(status)}
          >
            {status}
          </Button>
        ))}
      </div>

      {/* Wrap Search + Button */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' }}>
        <TextField
          label="Search Courses"
          variant="outlined"
          fullWidth
          value={selectedCourseName}
          onChange={handleSearchChange}
        />
        {(decodedType === 'admin' || decodedType === 'researcher') && (
          <Button
            variant="contained"
              onClick={() => setIsModalOpen(true)} // opens the CourseCreationModal
            sx={{
            whiteSpace: 'nowrap',
            backgroundColor: '#0f9d58',
            '&:hover': {
              backgroundColor: '#0c7a44',
            },
          }}
          >
            + Course
          </Button>
        )}
      </div>

      {/* Course Creation Modal */}
      <CourseCreationModal open={isModalOpen} onClose={() => setIsModalOpen(false)} />
      <div
        className="courseContainer"
        style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
          gap: '75px',
          justifyContent: 'center',
          justifyItems: 'center',
          padding: '30px',
          maxWidth: '750px',
          margin: '0 auto',
          minHeight: '250px',
        }}
      >
        {loadingCourses ? (
          <Box
            sx={{
              gridColumn: '1 / -1',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              minHeight: '200px',
              gap: 2,
            }}
          >
            <CircularProgress sx={{ color: '#0f9d58' }} />
            <Typography variant="body1" sx={{ color: '#0f9d58', fontWeight: 500 }}>
              Loading courses...
            </Typography>
          </Box>
        ) : (
          filteredCourses.map(course => (
            <div
              key={course.title}
              className="courseSection"
              style={{
                boxShadow: '2px 2px 10px rgba(0, 0, 0, 0.2)',
                borderRadius: '8px',
                padding: '20px',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between',
                cursor: 'pointer',
                width: '100%',
              }}
              onClick={() => {
                // Don't open course dialog if delete modal is open
                if (!isDeleteModalOpen) {
                  handleCourseClick(course);
                }
              }}
            >
              <img
                src={course.image}
                alt={course.title}
                style={{
                  width: '100%',
                  height: '200px',
                  borderRadius: '5px',
                }}
              />

              <div style={{ marginTop: 'auto' }}>
                <h2 style={{ textAlign: 'left' }}>{course.title}</h2>
                <p style={{ textAlign: 'right', marginBottom: '-20px' }}>
                  {course.numTopicsCompleted} / {course.topics.length} topics
                </p>
                <div>
                  {(decodedType === 'admin' || decodedType === 'researcher') && (
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '10px',
                        marginBottom: '10px',
                      }}
                    >
                      <Link
                        to={`/admin/newEditModules`}
                        state={{ courseId: course._id, courseTitle: course.title, course: course }}
                        onClick={() => {
                          localStorage.setItem('lastCourseId', course._id);
                          setSelectedCourse(course);
                        }}
                      >
                        <Box
                          sx={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            padding: '6px 12px',
                            marginRight: '8px',
                            backgroundColor: '#fff',
                            border: '1px solid #dcdcdc',
                            borderRadius: '6px',
                            transition: 'background-color 0.2s ease, box-shadow 0.2s ease',
                            '&:hover': {
                              backgroundColor: '#f2f2f2',
                              boxShadow: '0 1px 4px rgba(0,0,0,0.15)',
                            },
                          }}
                        >
                          <EditIcon
                            sx={{
                              color: '#2f2f2f',
                              transition: 'color 0.2s ease',
                              '&:hover': { color: '#000' },
                            }}
                          />
                        </Box>
                      </Link>
                      <Box
                        onClick={event => {
                          event.stopPropagation();
                          openDeleteModal(course); // Open the modal with the course
                        }}
                        sx={{
                          cursor: 'pointer',
                          display: 'inline-flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          padding: '6px 12px',
                          backgroundColor: '#fff',
                          border: '1px solid #dcdcdc',
                          borderRadius: '6px',
                          transition: 'background-color 0.2s ease, box-shadow 0.2s ease',
                          '&:hover': {
                            backgroundColor: '#f2f2f2',
                            boxShadow: '0 1px 4px rgba(0,0,0,0.15)',
                          },
                        }}
                      >
                        <DeleteIcon
                          sx={{
                            color: '#2f2f2f',
                            transition: 'color 0.2s ease',
                            '&:hover': { color: '#000' },
                          }}
                        />
                      </Box>
                      <Box
                        sx={{ display: 'flex', alignItems: 'center', gap: 1 }}
                        onClick={e => e.stopPropagation()}
                      >
                        <IconButton
                          aria-label={
                            course.hidden === true || course.hidden === 'true'
                              ? 'Set course visible'
                              : 'Set course hidden'
                          }
                          onClick={e => handleToggleHidden(course, e)}
                          sx={{ color: '#000' }}
                        >
                          {course.hidden === true || course.hidden === 'true' ? (
                            <VisibilityOff />
                          ) : (
                            <Visibility />
                          )}
                        </IconButton>
                        <Typography variant="body2" fontWeight="bold">
                          {course.hidden === true || course.hidden === 'true' ? 'Hidden' : 'Visible'}
                        </Typography>
                      </Box>
                    </div>
                  )}
                  <LinearProgressWithLabel value={course.progress} />
                </div>
              </div>
            </div>
          ))
        )}

        {/* Delete Confirmation Modal */}
        <DeleteConfirmationModal
          open={isDeleteModalOpen}
          onClose={closeDeleteModal}
          onConfirm={handleDeleteConfirm}
          itemName={courseToDelete?.title}
          itemType="course"
        />

        {/* Dialog Popup */}
        <Dialog open={!!selectedCourse} onClose={handleClose} fullWidth maxWidth="md">
          <DialogTitle
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}
          >
            <span style={{ textAlign: 'left' }}>{selectedCourse?.title}</span>
            <Button onClick={handleClose}>Close</Button>
          </DialogTitle>
          <DialogContent>
            {selectedCourse?.topics.length > 0 ? (
              selectedCourse.topics.map(topic => (
                <React.Fragment key={topic}>
                  <h3 style={{ textAlign: 'center' }}>{topic}</h3>
                  <div
                    className="topicSection"
                    style={{
                      display: 'grid',
                      gridTemplateColumns: 'repeat(auto-fit, minmax(50px, .5fr))',
                      gap: '75px',
                      justifyContent: 'center',
                      padding: '20px',
                      margin: '0 auto',
                    }}
                  >
                    {topicsData[topic] ? (
                      topicsData[topic].map(module => {
                        const moduleData = moduleDetails[module._id];

                        return moduleData ? (
                          <Card
                            key={module._id}
                            style={{
                              boxShadow: '2px 2px 10px rgba(0, 0, 0, 0.2)',
                              borderRadius: '8px',
                              padding: '20px',
                              display: 'flex',
                              flexDirection: 'column',
                              height: '90%', // Ensure the card takes full height
                            }}
                          >
                            <CardContent
                              style={{
                                flexGrow: 1,
                                display: 'flex',
                                flexDirection: 'column',
                              }}
                            >
                              <img
                                src={module.image}
                                alt={module.title}
                                style={{
                                  width: '100%',
                                  height: 'auto',
                                  borderRadius: '5px',
                                }}
                              />

                              <div
                                style={{
                                  display: 'flex',
                                  justifyContent: 'center',
                                }}
                              >
                                {moduleData.prereqs.every(
                                  prereq =>
                                    completedModules.includes(prereq) ||
                                    completedTopics.includes(prereq) ||
                                    completedCourses.includes(prereq)
                                ) ? (
                                  <Link
                                    to={`/module/${module._id}`}
                                    style={{ textDecoration: 'none' }}
                                  >
                                    <Button
                                      variant="outlined"
                                      style={{ margin: '10px auto' }}
                                      size="small"
                                    >
                                      {moduleData.title}
                                    </Button>
                                  </Link>
                                ) : (
                                  <Button
                                    variant="outlined"
                                    style={{
                                      margin: '10px auto',
                                      cursor: 'not-allowed',
                                    }}
                                    size="small"
                                    disabled
                                  >
                                    {moduleData.title}
                                  </Button>
                                )}
                              </div>

                              <Typography
                                variant="body2"
                                color="te-xtSecondary"
                                dangerouslySetInnerHTML={{
                                  __html: moduleData.description,
                                }}
                              />
                              <div style={{ marginTop: 'auto' }}>
                                <p
                                  style={{
                                    textAlign: 'right',
                                    marginBottom: '-20px',
                                  }}
                                >
                                  {moduleData.completedMessage === 'Completed'
                                    ? 'Completed'
                                    : 'Not Completed'}
                                </p>
                                <LinearProgressWithLabel value={moduleData.progressPercentage} />
                              </div>
                            </CardContent>
                          </Card>
                        ) : (
                          <Typography key={module}>Loading module...</Typography>
                        );
                      })
                    ) : (
                      <>
                        <h3 style={{ textAlign: 'center' }}>
                          No modules has been added to this course yet!
                        </h3>
                        {(decodedType === 'admin' || decodedType === 'researcher') && (
                          <Box
                            sx={{
                              display: 'flex',
                              flexDirection: 'column',
                              alignItems: 'center',
                              justifyContent: 'center',
                              height: '100%',
                            }}
                          >
                            <Box
                              sx={{ display: 'flex', justifyContent: 'center', marginTop: '20px' }}
                            >
                              <Link to="/admin/editModules" style={{ textDecoration: 'none' }}>
                                <Button
                                  variant="contained"
                                  color="primary"
                                  style={{ display: 'flex', justifyContent: 'center' }}
                                  onClick={handleAddTopics}
                                >
                                  Click Here to Add Topics
                                </Button>
                              </Link>
                            </Box>
                          </Box>
                        )}
                      </>
                    )}
                  </div>
                </React.Fragment>
              ))
            ) : (
              <>
                <h3 style={{ textAlign: 'center' }}>
                  No content has been added to this course yet!
                </h3>
                {(decodedType === 'admin' || decodedType === 'researcher') && (
                  <Box
                    sx={{
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      justifyContent: 'center',
                      height: '100%',
                    }}
                  >
                    <Box sx={{ display: 'flex', justifyContent: 'center', marginTop: '20px' }}>
                      <Link to="/admin/neweditModules" style={{ textDecoration: 'none' }}>
                        <Button
                          variant="contained"
                          color="primary"
                          style={{ display: 'flex', justifyContent: 'center' }}
                          onClick={handleAddTopics}
                        >
                          Click Here to Add Content
                        </Button>
                      </Link>
                    </Box>
                  </Box>
                )}
              </>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

// Styling
const flexWrapperStyle = {
  backgroundColor: 'white',
  padding: '1rem',
};

export default NextModule;
