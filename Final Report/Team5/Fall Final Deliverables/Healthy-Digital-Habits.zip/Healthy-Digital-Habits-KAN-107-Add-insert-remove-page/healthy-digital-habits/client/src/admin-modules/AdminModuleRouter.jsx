import React from 'react';
import NavBar from '../shared/NavBar';
import AdminModuleEditor from './AdminModuleEditor';

const AdminModuleRouter = () => (
  <div>
    <NavBar />
    <div
      style={{ display: 'flex', alignitems: 'center', justifyContent: 'center', marginTop: '3rem' }}
    >
      <AdminModuleEditor />
    </div>
  </div>
);

export default AdminModuleRouter;
