import ForgotPasswordPage from './ForgotPasswordPage';

const ForgotContents = () => (
  <div
    style={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      height: '100vh',
    }}
  >
    <ForgotPasswordPage />
  </div>
);

export default ForgotContents;
