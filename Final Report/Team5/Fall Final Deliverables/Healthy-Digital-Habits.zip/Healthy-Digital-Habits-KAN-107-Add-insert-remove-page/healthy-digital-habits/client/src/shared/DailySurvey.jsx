import { Box, Button, Modal, Stack, Typography } from '@mui/material';
import React from 'react';

const textStyle = {
  textAlign: 'center',
  marginTop: '8px',
  fontFamily: 'Helvetica, sans-serif',
  fontWeight: '750',
  fontSize: '20px',
  position: 'relative',
  color: 'black',
};

const SurveyConfirmationModal = ({ isOpen, onClose, handleStartSurvey }) => {
  return (
    <Modal
      open={isOpen}
      onClose={onClose}
      aria-labelledby="survey-modal-title"
      aria-describedby="survey-modal-description"
    >
      <Box
        sx={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: 400,
          bgcolor: 'background.paper',
          border: '2px solid white',
          borderRadius: '20px',
          boxShadow: 24,
          p: 4,
        }}
      >
        <Typography id="survey-modal-description" style={textStyle} sx={{ mt: 2 }}>
          Do you want to do the daily survey now?
        </Typography>

        <Stack direction="row" spacing={2} sx={{ mt: 3, justifyContent: 'center' }}>
          {/* Do Survey Now */}
          <Button variant="contained" color="primary" onClick={handleStartSurvey}>
            Do Daily Survey
          </Button>

          {/* Do Survey Later */}
          <Button variant="contained" color="primary" onClick={onClose}>
            Do This Later
          </Button>
        </Stack>
      </Box>
    </Modal>
  );
};

export default SurveyConfirmationModal;
