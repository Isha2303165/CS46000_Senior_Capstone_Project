import { Button, Card, FormControl, MenuItem, Select, TextField, Typography } from '@mui/material';
import React from 'react';

const EditModule = ({
  selectedModuleToEdit,
  setSelectedModuleToEdit,
  modules,
  handleModuleSelect,
  handleUpdateModule,
  newModuleName,
  setNewModuleName,
}) => {
  return (
    <Card
      sx={{
        marginTop: '20px',
        padding: '20px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Typography variant="h6" sx={{ marginBottom: '20px' }}>
        Edit Module
      </Typography>
      <FormControl
        fullWidth
        sx={{
          display: 'flex',
          alignItems: 'center',
        }}
      >
        <Typography variant="body1">Select Module to Edit</Typography>
        <Select
          labelId="module-edit-select-label"
          value={selectedModuleToEdit}
          onChange={e => handleModuleSelect(e)}
          style={{ width: '100%', textAlign: 'left' }}
        >
          {modules.map(mod => (
            <MenuItem key={mod._id} value={mod._id}>
              {mod.title}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <br />
      <TextField
        label="New Module Name"
        value={newModuleName}
        onChange={e => setNewModuleName(e.target.value)}
        style={{ width: '100%' }}
      />
      <br />
      <Button variant="contained" onClick={handleUpdateModule}>
        Update Module
      </Button>
    </Card>
  );
};

export default EditModule;
