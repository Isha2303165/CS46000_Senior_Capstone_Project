import React from 'react';
import NavBar from '../shared/NavBar';
import AdminModules from './AdminModules';

const AdminModulesContents = () => (
  <div>
    <NavBar />
    <div
      style={{ display: 'flex', alignitems: 'center', justifyContent: 'center', marginTop: '3rem' }}
    >
      <AdminModules />
    </div>
  </div>
);

export default AdminModulesContents;
