import { Button, Card, FormControl, MenuItem, Select, Typography } from '@mui/material';
import React from 'react';

const DeleteCourse = ({
  selectedCourseToDelete,
  setSelectedCourseToDelete,
  courses,
  handleDeleteCourse,
}) => {
  return (
    <Card
      sx={{
        marginTop: '20px',
        padding: '20px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Typography variant="h6" sx={{ marginBottom: '20px' }}>
        Delete Course
      </Typography>
      <FormControl
        fullWidth
        sx={{
          display: 'flex',
          alignItems: 'center',
        }}
      >
        <Typography variant="body1">Select Course to Delete</Typography>
        <Select
          labelId="topic-delete-select-label"
          value={selectedCourseToDelete}
          onChange={e => setSelectedCourseToDelete(e.target.value)}
          style={{ width: '100%' }}
        >
          {courses.map(course => (
            <MenuItem key={course.title} value={course.title}>
              {course.title}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <br />
      <Button variant="contained" color="error" onClick={handleDeleteCourse}>
        Delete Course
      </Button>
    </Card>
  );
};

export default DeleteCourse;
