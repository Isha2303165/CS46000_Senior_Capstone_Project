import RegisterPage from './RegisterPage';

const RegisterContents = () => (
  <div
    style={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      height: '170vh',
    }}
  >
    <RegisterPage />
  </div>
);

export default RegisterContents;
