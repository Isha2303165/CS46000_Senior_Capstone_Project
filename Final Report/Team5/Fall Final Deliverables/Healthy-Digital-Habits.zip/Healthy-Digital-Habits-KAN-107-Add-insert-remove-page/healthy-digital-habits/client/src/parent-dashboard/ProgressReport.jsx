import { FormControl, InputLabel, MenuItem, Select, Typography, Card } from '@mui/material/';
import Box from '@mui/material/Box';
import axios from 'axios';
import { jwtDecode as jwt_decode } from 'jwt-decode';
import React, { useEffect, useState } from 'react';

const ProgressReport = () => {
  const [decodedUname, setDecodedUname] = useState(null);
  useEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem('token');
      if (token) {
        try {
          const decoded = jwt_decode(token);
          setDecodedUname(decoded.uname);
        } catch (error) {
          console.error('Invalid token', error);
        }
      }
    };

    fetchData();
  }, []);

  const [selectedModule, setSelectedModule] = useState(''); // State to track the selected module from the dropdown
  const [modulesList, setModulesList] = useState([]); // State to store the fetched module list
  const [answersList, setAnswersList] = useState([]);

  const BoxStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    border: '2px solid rgb(206, 206, 206)',
    width: '90%',
    backgroundColor: '#F1EFEC',
  };

  const titleboxStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  };

  const titleTextStyle = {
    fontFamily: 'system-ui',
    fontWeight: '775',
    fontSize: '40px',
    color: 'black',
  };

  const fetchModules = async () => {
    try {
      const response = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/module`);
      setModulesList(response.data); // Assuming the data is an array of modules
    } catch (error) {
      console.error('Error fetching modules:', error);
    }
  };

  const fetchAnswers = async moduleId => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_API_BASE_URL}/api/allAnswers/${moduleId}/${decodedUname}`
      );
      setAnswersList(response.data);
    } catch (error) {
      console.error('Error fetching answers:', error);
    }
  };

  useEffect(() => {
    fetchModules(); // Fetch the module list when the component mounts
  }, []);

  const handleModuleChange = event => {
    const selectedModuleId = event.target.value;
    setSelectedModule(selectedModuleId);
    fetchAnswers(selectedModuleId);
  };

  return (
    <Card elevation={2} sx={BoxStyle}>
      <Box style={titleboxStyle}>
        <Typography style={titleTextStyle}> What I Have Learned </Typography>
      </Box>

      <FormControl>
        <InputLabel>Select Module</InputLabel>
        <Select
          value={selectedModule}
          onChange={handleModuleChange}
          style={{ width: '300px', backgroundColor: 'white', borderRadius: '8px' }}
        >
          {modulesList.map((module, index) => (
            <MenuItem key={index} value={module._id}>
              {module.title}
            </MenuItem>
          ))}
        </Select>
      </FormControl>

      <Box>
        {answersList.length > 0 ? (
          answersList.map((answer, index) => (
            <Box key={index}>
              <Typography variant="body1">
                Question: {answer.response.question.slice(3, -4)}
              </Typography>

              <Typography variant="body1">Answer: {answer.response.answer}</Typography>
            </Box>
          ))
        ) : (
          <Typography variant="h6">No answers available</Typography>
        )}
      </Box>
    </Card>
  );
};

export default ProgressReport;
