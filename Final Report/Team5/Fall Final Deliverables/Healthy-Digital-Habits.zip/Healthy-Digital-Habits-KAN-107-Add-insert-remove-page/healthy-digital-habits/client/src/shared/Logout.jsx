import { Box, Button, Modal, Stack, Typography } from '@mui/material';
import React from 'react';
import ConfirmationCheck from './ConfirmationCheck';
import { useNavigate } from 'react-router-dom';

const LogoutModal = ({ isOpen, onClose }) => {
  const navi = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('token');
    onClose();
    navi('/');
  };

  return (
    <ConfirmationCheck
      open={isOpen}
      onClose={onClose}
      onConfirm={handleLogout}
      title={'Log Out'}
      message={'Are you sure you wish to log out?'}
    ></ConfirmationCheck>
  );
};

export default LogoutModal;
