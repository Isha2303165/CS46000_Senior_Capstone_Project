import { useMemo, useState, useLayoutEffect } from 'react';
import {
  Modal,
  Button,
  Typography,
  Box,
  TextField,
  Switch,
  FormControlLabel,
  Checkbox,
  Divider,
} from '@mui/material';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';

const noop = () => {};

export default function AdminLessonModal({
  //noop is nice for no-operation function (simple toggle)
  open = false,
  onClose = noop,
  onConvertToQuestion = noop,
  module,
  pageIndex = 0,
  sectionKey,
  sectionLabel,
  initialSectionContent = '',
  sectionType = '',
  onSave = noop,
}) {
  const [pageTitle, setPageTitle] = useState('');
  const [pageDescription, setPageDescription] = useState('');
  const [contentValue, setContentValue] = useState('');
  const [convertToQuestion, setConvertToQuestion] = useState(false);
  const [enableBranching, setEnableBranching] = useState(false);
  const [questionTypes, setQuestionTypes] = useState({
    multipleChoice: false,
    shortAnswer: false,
  });

  // Memoized current page based on module and pageIndex, (we aren't given just the page, we are given the entire module and index)
  const page = useMemo(() => {
    if (!module || !Array.isArray(module.pages)) {
      return null;
    }
    const safeIndex = Math.max(0, pageIndex);
    return module.pages[safeIndex] ?? null;
  }, [module, pageIndex]);

  // Resolves section type (question, rich-text, media, etc), we can infer from page data or use passed prop because it can be changed.
  //Ideally we will add safety checks and clear the section data if the type changes to avoid stale data.
  const resolveSectionType = () => {
    if (typeof sectionType === 'string' && sectionType.length) {
      return sectionType;
    }
    if (page && sectionKey) {
      const rawType = page[sectionKey];
      if (typeof rawType === 'string' && rawType.length) {
        return rawType;
      }
    }
    return '';
  };

  //Because we are going to change the layout of the modal based on section type, we need to resolve how the content is stored.
  const resolveSectionContent = () => {
    if (page && sectionKey) {
      const candidates = [
        page[`${sectionKey}-rich-text`],
        page[`${sectionKey}-questionDescription`],
        page[`${sectionKey}-media`],
      ];
      const found = candidates.find(value => typeof value === 'string' && value.length);
      if (typeof found === 'string') return found;
    }
    return typeof initialSectionContent === 'string' ? initialSectionContent : '';
  };

  const sectionContentKey = `${module?._id ?? 'module'}-${pageIndex}-${sectionKey || 'none'}`;

  //This effect runs when the modal opens or when the page/section changes to initialize state.
  //think of it as a "reset" for the modal content. (this is needed or stale content will persist between section opens and closes)
  useLayoutEffect(() => {
    if (!open) return;
    if (page) {
      setPageTitle(page.content || '');
      setPageDescription(page.pageDescription || '');
      setContentValue(resolveSectionContent());
      const resolvedType = resolveSectionType();
      const isQuestion = resolvedType === 'question';
      setConvertToQuestion(isQuestion);
      if (!isQuestion) {
        setEnableBranching(false);
        setQuestionTypes({ multipleChoice: false, shortAnswer: false });
      }
    } else {
      setPageTitle('');
      setPageDescription('');
      setContentValue('');
      setConvertToQuestion(false);
      setEnableBranching(false);
      setQuestionTypes({ multipleChoice: false, shortAnswer: false });
    }
  }, [page, sectionKey, open, initialSectionContent, sectionType]);

  const handleToggleConvert = (_, checked) => {
    if (checked) {
      onConvertToQuestion({
        sectionKey,
        sectionLabel,
        pageIndex,
        contentValue,
      });
      return;
    }
    setConvertToQuestion(false);
    setEnableBranching(false);
    setQuestionTypes({ multipleChoice: false, shortAnswer: false });
  };

  const handleToggleBranching = (_, checked) => {
    setEnableBranching(checked);
  };

  const handleToggleQuestionType = key => (_, checked) => {
    setQuestionTypes(prev => ({ ...prev, [key]: checked }));
  };

  //Just dumps the data into onSave callback
  const handleSave = () => {
    onSave({
      pageTitle,
      pageDescription,
      contentValue,
      sectionKey,
      pageIndex,
      convertToQuestion,
      sectionType: resolveSectionType(),
    });
  };

  return (
    <Modal open={open} onClose={onClose}>
      <Box
        sx={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: 800,
          maxWidth: '90vw',
          maxHeight: '90vh',
          bgcolor: 'background.paper',
          boxShadow: 24,
          borderRadius: 2,
          p: 4,
          display: 'flex',
          flexDirection: 'column',
          gap: 3,
        }}
      >
        <Typography variant="h6" sx={{ fontWeight: 600 }}>
          {`Editing ${sectionLabel || 'Section'}`}
          {module?.title ? ` — ${module.title}` : ''}
        </Typography>
        {!page && (
          <Typography color="text.secondary">Select a module and page to edit content.</Typography>
        )}
        {page && (
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              gap: 2,
              minHeight: 0,
              flex: 1,
              overflow: 'hidden',
              pt: 1,
            }}
          >
            <TextField
              label="Page Title"
              value={pageTitle}
              onChange={e => setPageTitle(e.target.value)}
              fullWidth
            />
            <FormControlLabel
              control={<Switch checked={convertToQuestion} onChange={handleToggleConvert} />}
              label="Convert to Question"
            />
            {convertToQuestion && (
              <>
                <FormControlLabel
                  control={<Switch checked={enableBranching} onChange={handleToggleBranching} />}
                  label="Enable Branching"
                />

                <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={questionTypes.multipleChoice}
                        onChange={handleToggleQuestionType('multipleChoice')}
                      />
                    }
                    label="Multiple Choice"
                  />
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={questionTypes.shortAnswer}
                        onChange={handleToggleQuestionType('shortAnswer')}
                      />
                    }
                    label="Short Answer"
                  />
                </Box>
              </>
            )}

            <Box
              sx={{
                flex: 1,
                minHeight: 0,
                overflow: 'auto',
                display: 'flex',
                flexDirection: 'column',
                gap: 2,
                pr: 1,
              }}
            >
              <Box>
                <Typography variant="subtitle2" sx={{ mb: 1 }}>
                  Page Description
                </Typography>
                <ReactQuill value={pageDescription} onChange={setPageDescription} theme="snow" />
              </Box>
              <Divider />
              <Box>
                <Typography variant="subtitle2" sx={{ mb: 1 }}>
                  Section Content
                </Typography>
                <ReactQuill
                  key={sectionContentKey}
                  value={contentValue}
                  onChange={setContentValue}
                  theme="snow"
                />
              </Box>
            </Box>
          </Box>
        )}
        <Box
          sx={{
            mt: 'auto',
            display: 'flex',
            justifyContent: 'flex-end',
            gap: 2,
          }}
        >
          <Button onClick={onClose} color="inherit">
            Cancel
          </Button>
          <Button sx={{ background: '#6aa57a' }} onClick={handleSave} variant="contained">
            Save
          </Button>
        </Box>
      </Box>
    </Modal>
  );
}
