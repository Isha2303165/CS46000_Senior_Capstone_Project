import React, { useState } from 'react';
import {
  Modal,
  Box,
  Typography,
  TextField,
  Button,
  Stack,
  IconButton,
  Card,
  CardMedia,
  Snackbar,
  Alert,
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';

const CourseCreationModal = ({ open, onClose }) => {
  const [courseName, setCourseName] = useState('');
  const [estimatedTime, setEstimatedTime] = useState('');
  const [isHidden, setIsHidden] = useState(true);
  const [image, setImage] = useState(null);
  const [showPreview, setShowPreview] = useState(false);
  const [errorMessage] = useState('');
  const [notice, setNotice] = useState({ open: false, message: '', severity: 'warning' });

  const notify = (message, severity = 'warning') => {
    setNotice({ open: true, message, severity });
  };

  const navigate = useNavigate();

  const handleSubmit = async (e, goToEditor = false) => {
    console.log('isHidden:', isHidden);
    e.preventDefault();

    if (!courseName) {
      notify('Course name is required', 'error');
      return;
    }
    const regex = /[a-zA-Z]/;
    if (!regex.test(courseName)) {
      notify('Course name must contain at least one valid character', 'error');
      return;
    }

    try {
      const payload = {
        title: courseName,
        topics: [],
        image:
          image ||
          'https://img.freepik.com/free-photo/closeup-scarlet-macaw-from-side-view-scarlet-macaw-closeup-head_488145-3540.jpg?semt=ais_hybrid&w=740&q=80',
        hidden: isHidden,
      };

      const response = await axios.post(
        `${process.env.REACT_APP_API_BASE_URL}/api/courses/create`,
        payload
      );

      console.log(response.data.message, response.data.course);

      // Navigate if user clicked "Go To Course"
      if (goToEditor) {
        navigate('/admin/Editmodules', {
          state: {
            courseId: response.data.course._id,
            courseTitle: response.data.course.title,
          },
        });
        localStorage.setItem('lastCourseId', response.data.course._id);
      } else {
        window.location.reload();
        onClose();
      }
    } catch (err) {
      console.error(err.response?.data || err.message);
      notify('Failed to create course: ' + (err.response?.data?.message || err.message), 'error');
    }
  };

  return (
    <>
      <Snackbar
        open={notice.open}
        autoHideDuration={4000}
        onClose={() => setNotice(s => ({ ...s, open: false }))}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
      >
        <Alert
          onClose={() => setNotice(s => ({ ...s, open: false }))}
          severity={notice.severity}
          sx={{ width: '100%' }}
        >
          {notice.message}
        </Alert>
      </Snackbar>
      <Modal open={open} onClose={onClose}>
        <Box
          component="form"
          onSubmit={handleSubmit}
          sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: '33vw',
            height: 'auto',
            bgcolor: 'background.paper',
            boxShadow: 24,
            borderRadius: 2,
            p: 4,
            display: 'flex',
            flexDirection: 'column',
            justifyContent: 'space-between',
          }}
        >
          <Box>
            <Typography variant="h6" component="h2" sx={{ mb: 2 }}>
              Create a New Course
            </Typography>

            {errorMessage && (
              <Typography color="error" sx={{ mb: 2 }}>
                {errorMessage}
              </Typography>
            )}

            <Stack spacing={2}>
              <TextField
                label="Course Name"
                variant="outlined"
                value={courseName}
                onChange={e => setCourseName(e.target.value)}
                fullWidth
              />

              <TextField
                label="Estimated Time for Completion"
                variant="outlined"
                value={estimatedTime}
                onChange={e => setEstimatedTime(e.target.value)}
                fullWidth
              />

              {/* Visibility toggle */}
              <Box display="flex" alignItems="center" justifyContent="space-between">
                <Box display="flex" alignItems="center" gap={1}>
                  <IconButton
                    aria-label={isHidden ? 'Set course visible' : 'Set course hidden'}
                    onClick={() => setIsHidden(prev => !prev)}
                    sx={{ color: '#000' }}
                  >
                    {isHidden ? <VisibilityOff /> : <Visibility />}
                  </IconButton>
                  <Typography variant="body2" fontWeight="bold">
                    {isHidden ? 'Hidden' : 'Visible'}
                  </Typography>
                </Box>

                <TextField
                  label="Background Image URL"
                  variant="outlined"
                  value={image || ''}
                  onChange={e => setImage(e.target.value)}
                  placeholder="https://example.com/image.jpg"
                  sx={{
                    width: '60%',
                    '& .MuiOutlinedInput-root': {
                      '& fieldset': {
                        borderColor: '#02542D',
                      },
                      '&:hover fieldset': {
                        borderColor: '#02542D',
                      },
                    },
                    '& .MuiInputLabel-root': {
                      color: '#02542D',
                    },
                    '& .MuiInputBase-input': {
                      color: '#02542D',
                    },
                  }}
                />
              </Box>
            </Stack>
          </Box>

          <Stack
            direction="row"
            spacing={2}
            justifyContent="space-between"
            alignItems="center"
            sx={{ mt: 3 }}
          >
            <Box position="relative">
              <Button
                variant="outlined"
                onMouseEnter={() => setShowPreview(true)}
                onMouseLeave={() => setShowPreview(false)}
                sx={{
                  borderColor: '#02542D',
                  color: '#02542D',
                  backgroundColor: '#fff',
                  '&:hover': {
                    backgroundColor: '#02542D',
                    color: '#fff',
                  },
                }}
              >
                Preview
              </Button>

              {/* Hover Preview Card */}
              {showPreview && (
                <Box
                  sx={{
                    position: 'absolute',
                    bottom: '110%',
                    left: 0,
                    zIndex: 9999,
                    transition: 'opacity 0.3s ease, transform 0.3s ease',
                    opacity: 1,
                    transform: 'translateY(-10px)',
                    width: 500,
                    height: 400,
                  }}
                >
                  <Card
                    sx={{
                      width: 400,
                      height: 400,
                      boxShadow: '0 4px 10px rgba(0, 0, 0, 0.15)',
                      borderRadius: 3,
                      overflow: 'hidden',
                      backgroundColor: '#f9f9f9',
                    }}
                  >
                    <CardMedia
                      component="img"
                      image={image || 'https://via.placeholder.com/400x350.png?text=Course+Image'}
                      alt={courseName}
                      sx={{
                        width: '100%',
                        height: 300,
                        objectFit: 'contain',
                        backgroundColor: '#fff',
                      }}
                    />
                    <Box
                      sx={{
                        height: 100,
                        backgroundColor: '#fff',
                        borderTop: '1px solid #ddd',
                        padding: '10px 15px',
                        display: 'flex',
                        flexDirection: 'column',
                        justifyContent: 'center',
                        textAlign: 'left',
                      }}
                    >
                      <Typography variant="h6" sx={{ fontWeight: 'bold', color: '#02542D' }}>
                        {courseName || 'Course Title'}
                      </Typography>

                      <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 0.5 }}>
                        <Typography variant="body2" color="text.secondary">
                          {estimatedTime ? `Estimated: ${estimatedTime}` : 'Estimated: N/A'}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {isHidden ? 'Hidden' : 'Visible'}
                        </Typography>
                      </Box>
                    </Box>
                  </Card>
                </Box>
              )}
            </Box>

            <Stack direction="row" spacing={2}>
              <Button
                type="submit"
                onClick={e => handleSubmit(e, true)}
                variant="outlined"
                sx={{
                  borderColor: '#02542D',
                  color: '#02542D',
                  backgroundColor: '#fff',
                  '&:hover': {
                    backgroundColor: '#02542D',
                    color: '#fff',
                  },
                }}
              >
                Create: Go To Course
              </Button>

              <Button
                type="submit"
                onClick={handleSubmit}
                variant="outlined"
                sx={{
                  borderColor: '#02542D',
                  color: '#02542D',
                  backgroundColor: '#fff',
                  '&:hover': {
                    backgroundColor: '#02542D',
                    color: '#fff',
                  },
                }}
              >
                Create Course
              </Button>

              <Button
                onClick={onClose}
                variant="outlined"
                sx={{
                  borderColor: '#02542D',
                  color: '#02542D',
                  backgroundColor: '#fff',
                  '&:hover': {
                    backgroundColor: '#02542D',
                    color: '#fff',
                  },
                }}
              >
                Cancel
              </Button>
            </Stack>
          </Stack>
        </Box>
      </Modal>
    </>
  );
};
export default CourseCreationModal;
