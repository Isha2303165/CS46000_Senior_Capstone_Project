import { Box, Button, Container, createTheme, Grid, TextField, ThemeProvider, Typography } from '@mui/material';
import axios from 'axios';
import { jwtDecode as jwt_decode } from 'jwt-decode';
import React, { useState } from 'react';
import { Link as RouterLink, useNavigate } from 'react-router-dom';

const interactableTheme = createTheme({
  palette: {
    primary: {
      main: '#4caf50',
    },
    tonalOffset: '0.3',
  }
});

const LoginPage = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errMsg, setErrMsg] = useState('');
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const response = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/login`, {
        params: { uname: username, upass: password },
      });

      const token = response.data.token;
      localStorage.setItem('token', token);

      // If login is successful, navigate to the dashboard and pass the username
      if (response.status === 200) {
        const decodedToken = jwt_decode(token);
        await axios.post(`${process.env.REACT_APP_API_BASE_URL}/api/user/logins?uname=${username}`);
        if (decodedToken.type === 'parent') {
          navigate('/dashboard');
        } else {
          navigate('/admin/dashboard');
        }
      }
    } catch (err) {
      console.error(err);
      setErrMsg('Username or password is incorrect');
    }
  };

  return (

    <Box component="main" sx={{
      p: 2, width: '100%', height: '100%',
      display: 'flex', justifyContent: 'center', alignItems: 'center',
      backgroundImage: "url('/loginbackground.jpeg')", backgroundSize: 'cover',
      backgroundPosition: 'center', backgroundAttachment: 'fixed'
    }}>
      <Container maxWidth="xs" sx={{ p: 2, border: '1px black', bgcolor: 'white', borderRadius: '5px' }}>
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
          <img
            src="/HDHLogo.png"
            alt="HDH Logo"
            style={{
              height: '50px',
              width: 'auto',
              objectFit: 'contain',
            }}
          />
          <div style={{ padding: '30px', textAlign: 'center' }}>
            {errMsg && (
              <Typography style={{ color: 'firebrick', fontWeight: 'bold' }} sx={{ mt: 2 }}>
                {errMsg}
              </Typography>
            )}
            <Box component="form" noValidate sx={{ mt: 1 }}>
              <ThemeProvider theme={interactableTheme}>
                <TextField
                  margin="normal"
                  required
                  fullWidth
                  id="username"
                  label="Username"
                  name="username"
                  autoComplete="username"
                  autoFocus
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                />
                <TextField
                  margin="normal"
                  required
                  fullWidth
                  name="password"
                  label="Password"
                  type="password"
                  id="password"
                  autoComplete="current-password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter') {
                      handleLogin();
                    }
                  }}
                />

                <Button
                  fullWidth
                  variant="contained"
                  color="primary"
                  sx={{ mt: 3, mb: 2, width: '100%', color: 'white', bgcolor: 'primary', ":hover": { bgcolor: 'primary.light' } }}
                  onClick={handleLogin}
                >
                  Log in
                </Button>
              </ThemeProvider>
              <Grid container justifyContent="center">
                <Grid item>
                  <RouterLink to="/forgot" style={{ textDecoration: 'none', color: 'black' }}>
                    <u>Forgot password?</u>
                  </RouterLink>
                  <br />
                  <br />
                  <RouterLink to="/register" style={{ textDecoration: 'none', color: 'black' }}>
                    New to Healthy Digital Habits? <u>Register Now!</u>
                  </RouterLink>
                </Grid>
              </Grid>
            </Box>
          </div>
        </Box>
      </Container>
    </Box>
  );
};

export default LoginPage;
