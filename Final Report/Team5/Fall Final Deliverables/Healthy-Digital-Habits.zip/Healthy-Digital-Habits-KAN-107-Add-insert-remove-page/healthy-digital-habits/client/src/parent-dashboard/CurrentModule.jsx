import { Typography, Card } from '@mui/material/';
import Box from '@mui/material/Box';
import CircularProgress from '@mui/material/CircularProgress';
import { textAlign } from '@mui/system';
import axios from 'axios';
import { jwtDecode as jwt_decode } from 'jwt-decode';
import React, { useLayoutEffect, useState } from 'react';

const CurrentModule = () => {
  const BoxStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    width: '50%',
    marginTop: '-3rem',
    border: '2px solid rgb(206, 206, 206)',
    padding: '1rem',
    backgroundColor: '#F1EFEC',
  };

  const titleboxStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'center',
    paddingBottom: '2rem',
  };

  const titleTextStyle = {
    fontFamily: 'system-ui',
    fontWeight: '775',
    fontSize: 'clamp(2.5rem, 1.5vw, 2rem)',
    color: 'black',
  };

  const progressTextStyle = {
    fontFamily: 'system-ui',
    fontWeight: '775',
    fontSize: 'clamp(1rem, 1.25vw, 2rem)',
    color: 'black',
  };

  const [progress, setProgress] = useState(null);
  const [module, setModule] = useState(null);

  useLayoutEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem('token');
      if (token) {
        try {
          const decoded = jwt_decode(token);
          const decodedModuleId = decoded.module;
          const response = await axios.get(
            `${process.env.REACT_APP_API_BASE_URL}/api/user/modulestring?uname=${decoded.uname}`
          );
          const progressRes = await axios.get(
            `${process.env.REACT_APP_API_BASE_URL}/api/module/progress/${decodedModuleId}/${decoded.uname}`
          );
          setProgress(progressRes.data.progressPercentage);
          setModule(response.data);
        } catch (error) {
          console.error('Error fetching data:', error);
        }
      }
    };

    fetchData();
  }, []);

  return (
    <Card elevation={2} sx={BoxStyle}>
      <Box style={titleboxStyle}>
        <Typography style={titleTextStyle}>Current Module</Typography>
        <div style={progressTextStyle}>
          {module ? `Module: ${module}` : 'Loading module information...'}
        </div>
      </Box>

      <Box display="flex" alignItems="center" position="relative" justifyContent="center">
        <CircularProgress
          size={'clamp(8rem, 8vw, 12rem)'}
          thickness={5.5}
          value={progress || 0}
          variant="determinate"
          style={{
            color: '#008000',
            borderRadius: '50%',
            boxShadow: 'inset 0 0 0 25.5px 808080',
            backgroundColor: '#ffffff',
            outline: '3px solid #dcdcdc',
          }}
        />
        <Typography
          variant="h5"
          style={{
            position: 'absolute',
            color: 'rgb(0, 14, 36)',
            fontFamily: 'system-ui',
            fontWeight: '775',
            fontSize: 'clamp(1.2rem, 2vw, 2rem)',
          }}
        >
          {`${Math.round(progress)}%`}
        </Typography>
      </Box>
    </Card>
  );
};

export default CurrentModule;
