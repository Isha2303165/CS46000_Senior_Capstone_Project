import { Box, Button, Container, createTheme, Grid, MenuItem, Select, TextField, ThemeProvider } from '@mui/material';
import axios from 'axios';
import React, { useEffect, useRef, useState } from 'react';
import { Link as RouterLink, useNavigate } from 'react-router-dom';

const USER_REGEX = /^[a-zA-Z0-9]{5,20}$/;
const PWD_REGEX =
  /^(?=.*[!@#$%^&*()_+[\]{};':"\\|,.<>?/-])[a-zA-Z0-9!@#$%^&*()_+[\]{};':"\\|,.<>?/-]{8,15}$/;
const EMAIL_REGEX = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
const NAME_REGEX = /^[A-Za-z-]+$/;
const PHONE_REGEX = /^(?:\+?1[-. ]?)?(?:(\(\d{3}\))|\d{3})[-. ]?\d{3}[-. ]?\d{4}$/;

const interactableTheme = createTheme({
  palette: {
    primary: {
      main: '#4caf50',
    },
    tonalOffset: '0.3',
  }
});

const RegisterPage = () => {
  const errRef = useRef();

  const [firstName, setFirstName] = useState('');
  const [validFirst, setValidFirst] = useState(false);

  const [lastName, setLastName] = useState('');
  const [validLast, setValidLast] = useState(false);

  const [email, setEmail] = useState('');
  const [validEmail, setValidEmail] = useState(false);

  const [phoneNumber, setPhoneNumber] = useState('');
  const [validPhone, setValidPhone] = useState(false);

  const [username, setUsername] = useState('');
  const [validUser, setValidUser] = useState(false);

  const [password, setPassword] = useState('');
  const [validPass, setValidPass] = useState(false);

  const [confirmPassword, setConfirmPassword] = useState('');
  const [validConfirm, setValidConfirm] = useState(false);

  const [selectedOption, setSelectedOption] = useState('');
  const options = [
    'What was the name of your first pet?',
    "What is your mother's maiden name?",
    'What was the make and model of your first car?',
    'What city were you born in?',
    'What was the name of your elementary school?',
  ];
  const [validOption, setValidOption] = useState(false);
  const [securityAnswer, setSecurityAnswer] = useState('');
  const [validAnswer, setValidAnswer] = useState(false);

  const [errMsg, setErrMsg] = useState('');
  const [registerClick, setRegisterClick] = useState(false); // State variable for register click
  const navigate = useNavigate();

  useEffect(() => {
    // Reset all validation states when component mounts
    setValidFirst(false);
    setValidLast(false);
    setValidEmail(false);
    setValidPhone(false);
    setValidUser(false);
    setValidPass(false);
    setValidConfirm(false);
    setValidOption(false);
    setValidAnswer(false);
    setErrMsg('');
  }, []); // Empty dependency array ensures this runs only on mount

  const registerUser = () => {
    setRegisterClick(true); // Set to true when register is clicked
    setValidUser(USER_REGEX.test(username));
    setValidPass(PWD_REGEX.test(password));
    setValidConfirm(password === confirmPassword);
    setValidEmail(EMAIL_REGEX.test(email));
    setValidFirst(NAME_REGEX.test(firstName));
    setValidLast(NAME_REGEX.test(lastName));
    setValidPhone(PHONE_REGEX.test(phoneNumber));
    setValidOption(selectedOption != '');
    setValidAnswer(securityAnswer != '');
    setErrMsg('');
  };

  const handleRegister = async e => {
    e.preventDefault();

    if (
      !validUser ||
      !validPass ||
      !validEmail ||
      !validFirst ||
      !validLast ||
      !validPhone ||
      !validOption ||
      !validAnswer
    ) {
      setErrMsg('Please correct the highlighted fields.');
      return;
    }

    try {
      await axios.post(`${process.env.REACT_APP_API_BASE_URL}/api/register`, {
        fname: firstName,
        lname: lastName,
        email,
        ph: phoneNumber,
        uname: username,
        upass: password,
        type: 'parent',
        secq: selectedOption,
        seca: securityAnswer,
      });

      // Reset form on successful registration
      setFirstName('');
      setLastName('');
      setEmail('');
      setPhoneNumber('');
      setUsername('');
      setPassword('');
      setConfirmPassword('');
      setSelectedOption('');
      setSecurityAnswer('');
      setErrMsg('');
      navigate('/login');
    } catch (err) {
      if (!err?.response) {
        setErrMsg('No Server Response');
      } else if (err.response?.status === 409) {
        setErrMsg('Username Taken');
      } else {
        setErrMsg('Registration Failed');
      }
    }
  };

  const handleChange = event => {
    setSelectedOption(event.target.value);
  };

  return (
    <Box component="main" sx={{
      p: 2, width: '100%', height: '100%',
      display: 'flex', justifyContent: 'center', alignItems: 'center',
      backgroundImage: "url('/loginbackground.jpeg')", backgroundSize: 'cover',
      backgroundPosition: 'center', backgroundAttachment: 'fixed'
    }}>
      <Container maxWidth="xs" sx={{ p: 2, border: '1px black', bgcolor: 'white', borderRadius: '5px' }}>
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
          <img
            src="/HDHLogo.png"
            alt="HDH Logo"
            style={{
              height: '50px',
              width: 'auto',
              objectFit: 'contain',
            }}
          />
          <div style={{ padding: '30px', textAlign: 'center' }}>
            <p ref={errRef} style={{ color: 'firebrick', fontWeight: 'bold' }}>
              {errMsg}
            </p>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Box component="form" onSubmit={handleRegister} noValidate sx={{ mt: 3 }}>
                  <ThemeProvider theme={interactableTheme}>
                    // Note: console warnings regarding margin="normal" can be safely ignored.
                    <TextField
                      margin="normal"
                      required
                      fullWidth
                      id="firstName"
                      label="First Name"
                      name="firstName"
                      autoComplete="given-name"
                      value={firstName}
                      onChange={e => setFirstName(e.target.value)}
                      error={!validFirst && registerClick}
                      helperText={!validFirst && registerClick ? 'Invalid first name' : ''}
                    />
                    <TextField
                      margin="normal"
                      required
                      fullWidth
                      id="lastName"
                      label="Last Name"
                      name="lastName"
                      autoComplete="family-name"
                      value={lastName}
                      onChange={e => setLastName(e.target.value)}
                      error={!validLast && registerClick}
                      helperText={!validLast && registerClick ? 'Invalid last name' : ''}
                    />
                    <TextField
                      margin="normal"
                      required
                      fullWidth
                      id="email"
                      label="Email Address"
                      name="email"
                      autoComplete="email"
                      type="email"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      error={!validEmail && registerClick}
                      helperText={!validEmail && registerClick ? 'Invalid email address' : ''}
                    />
                    <TextField
                      margin="normal"
                      fullWidth
                      id="phoneNumber"
                      label="Phone Number"
                      name="phoneNumber"
                      autoComplete="tel"
                      value={phoneNumber}
                      onChange={e => setPhoneNumber(e.target.value)}
                      error={!validPhone && registerClick}
                      helperText={!validPhone && registerClick ? 'Invalid phone number' : ''}
                    />
                    <TextField
                      margin="normal"
                      required
                      fullWidth
                      id="username"
                      label="Username"
                      name="username"
                      autoComplete="username"
                      value={username}
                      onChange={e => setUsername(e.target.value)}
                      error={!validUser && registerClick}
                      helperText={!validUser && registerClick ? 'Username must be 5-20 characters' : ''}
                    />
                    <TextField
                      margin="normal"
                      required
                      fullWidth
                      name="password"
                      label="Password"
                      type="password"
                      id="password"
                      autoComplete="new-password"
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      error={!validPass && registerClick}
                      helperText={
                        !registerClick
                          ? 'Password must be 8-15 characters long and include at least one special character (!@#$%^&*)'
                          : !validPass
                            ? 'Password must be 8-15 characters and contain at least one special character (!@#$%^&*)'
                            : 'Password must be 8-15 characters long and include at least one special character (!@#$%^&*)'
                      }
                    />
                    <TextField
                      margin="normal"
                      required
                      fullWidth
                      name="confirmPassword"
                      label="Confirm Password"
                      type="password"
                      id="confirmPassword"
                      autoComplete="new-password"
                      value={confirmPassword}
                      onChange={e => setConfirmPassword(e.target.value)}
                      error={!validConfirm && registerClick}
                      helperText={!validConfirm && registerClick ? 'Passwords do not match' : ''}
                    />
                    <br />
                    <br />
                    <Select
                      margin="normal"
                      required
                      fullWidth
                      value={selectedOption}
                      onChange={handleChange}
                      displayEmpty
                      style={{ textAlign: 'left', color: '#666c60' }}
                      error={!validOption && registerClick}
                      helperText={!validOption && registerClick ? 'Invalid security question' : ''}
                    >
                      <MenuItem value="" disabled>
                        Select a security question
                      </MenuItem>
                      {options.map(option => (
                        <MenuItem key={option} value={option}>
                          {option}
                        </MenuItem>
                      ))}
                    </Select>
                    <TextField
                      margin="normal"
                      required
                      fullWidth
                      id="security-answer"
                      label="Security Answer"
                      name="security-answer"
                      autoComplete="security-answer"
                      value={securityAnswer}
                      onChange={e => setSecurityAnswer(e.target.value)}
                      error={!validAnswer && registerClick}
                      helperText={!validAnswer && registerClick ? 'Invalid security answer' : ''}
                    />
                    <Button
                      fullWidth
                      variant="contained"
                      color="primary"
                      sx={{ mt: 3, mb: 2, color: 'white', bgcolor: 'primary', ":hover": { bgcolor: 'primary.light' } }}
                      type="submit"
                      onClick={registerUser}
                    >
                      Register
                    </Button>
                    <Grid container justifyContent="center">
                      <Grid item>
                        <RouterLink to="/" style={{ textDecoration: 'none', color: 'black' }}>
                          Already have an account? <u>Sign in!</u>
                        </RouterLink>
                      </Grid>
                    </Grid>
                  </ThemeProvider>
                </Box>
              </Grid>
            </Grid>
          </div>
        </Box>
      </Container>
    </Box>
  );
};

export default RegisterPage;
