import { Button, Card, FormControl, MenuItem, Select, Typography } from '@mui/material';
import React from 'react';

const DeleteTopic = ({
  selectedTopicToDelete,
  setSelectedTopicToDelete,
  topics,
  handleDeleteTopic,
}) => {
  return (
    <Card
      sx={{
        marginTop: '20px',
        padding: '20px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Typography variant="h6" sx={{ marginBottom: '20px' }}>
        Delete Topic
      </Typography>
      <FormControl
        fullWidth
        sx={{
          display: 'flex',
          alignItems: 'center',
        }}
      >
        <Typography variant="body1">Select Topic to Delete</Typography>
        <Select
          labelId="topic-delete-select-label"
          value={selectedTopicToDelete}
          onChange={e => setSelectedTopicToDelete(e.target.value)}
          style={{ width: '100%' }}
        >
          {topics.map(topic => (
            <MenuItem key={topic._id} value={topic.title}>
              {topic.title}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <br />
      <Button variant="contained" color="error" onClick={handleDeleteTopic}>
        Delete Topic
      </Button>
    </Card>
  );
};

export default DeleteTopic;
