import { Box, FormControl, InputLabel, MenuItem, Select, TextField } from '@mui/material';
import React from 'react';
import ReactQuill from 'react-quill';

const QuestionComponent = ({ page, index, handlePageChange, option }) => {
  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      <FormControl fullWidth sx={{ marginBottom: 2 }}>
        <InputLabel id={`type-label-${index}`}>Question Type</InputLabel>
        <Select
          labelId={`type-label-${index}`}
          value={page[`${option}-type`]}
          onChange={e => handlePageChange(index, `${option}-type`, e.target.value)}
        >
          <MenuItem value="Single">Single Select Multiple Choice</MenuItem>
          <MenuItem value="Multi">Multi Select Multiple Choice</MenuItem>
          <MenuItem value="Essay">Short Answer</MenuItem>
          <MenuItem value="FillInBlank">Fill in the Blank</MenuItem>
        </Select>
      </FormControl>

      {(page[`${option}-type`] === 'Essay' ||
        page[`${option}-type`] === 'Single' ||
        page[`${option}-type`] === 'Multi') && (
        <ReactQuill
          value={page[`${option}-questionDescription`]}
          onChange={content => handlePageChange(index, `${option}-questionDescription`, content)}
          placeholder="Enter Prompt/Description"
          style={{ marginBottom: '16px', width: '100%' }}
        />
      )}

      {(page[`${option}-type`] === 'Single' || page[`${option}-type`] === 'Multi') && (
        <>
          <FormControl fullWidth sx={{ marginBottom: 2 }}>
            <TextField
              id="number-input"
              type="number"
              value={page[`${option}-numberResponses`]}
              onChange={e => handlePageChange(index, `${option}-numberResponses`, e.target.value)}
              InputProps={{ inputProps: { min: 1, max: 15 } }}
              label="Number of Responses"
            />
          </FormControl>
          <div>
            {Array.from({ length: page[`${option}-numberResponses`] || 0 }, (_, idx) => (
              <TextField
                key={idx}
                label={`Value ${idx + 1}`}
                value={page[`${option}-value`]?.[idx] || ''}
                onChange={e => {
                  const newValues = [...(page[`${option}-value`] || [])];
                  newValues[idx] = e.target.value;
                  handlePageChange(index, `${option}-value`, newValues);
                }}
                style={{ marginBottom: '8px' }}
              />
            ))}
          </div>
          <FormControl fullWidth sx={{ marginTop: 2 }}>
            <InputLabel id="orientation-select-label">Orientation</InputLabel>
            <Select
              labelId="orientation-select-label"
              value={page[`${option}-orientation`]}
              onChange={e => handlePageChange(index, `${option}-orientation`, e.target.value)}
              label="Orientation"
            >
              <MenuItem value="vertical">Vertical</MenuItem>
              <MenuItem value="horizontal">Horizontal</MenuItem>
            </Select>
          </FormControl>
        </>
      )}

      {page[`${option}-type`] === 'FillInBlank' && (
        <ReactQuill
          value={page[`${option}-questionDescription`] || ''}
          onChange={content => handlePageChange(index, `${option}-questionDescription`, content)}
          placeholder="Type your question and use 3 underscores (___) to indicate blank space."
          style={{ marginBottom: '16px', width: '100%' }}
        />
      )}
    </Box>
  );
};

export default QuestionComponent;
