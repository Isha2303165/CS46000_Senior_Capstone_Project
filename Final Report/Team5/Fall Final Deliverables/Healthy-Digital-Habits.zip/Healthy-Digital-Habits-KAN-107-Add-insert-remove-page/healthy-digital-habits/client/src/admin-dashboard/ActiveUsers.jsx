import { Card, Typography, Box } from '@mui/material';
import { borderRadius } from '@mui/system';
import axios from 'axios';
import React, { useEffect, useState } from 'react';

const ActiveUsers = () => {
  const cardStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    width: '40vw',
    height: '15vw',
    backgroundColor: '#FFFFFF',
    border: '4px solid #4caf50',
    borderRadius: '12px',
    boxShadow: '0 0 0 10px #FFFFFF',
    padding: '1rem',
    marginBottom: '1rem',
  };

  const titleBoxStyle = {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: '1rem',
  };

  const titleTextStyle = {
    fontFamily: 'system-ui',
    fontWeight: 775,
    fontSize: '2vw',
    color: 'black',
  };

  const metricsRowStyle = {
    display: 'flex',
    justifyContent: 'space-around',
    width: '100%',
  };

  const numBoxStyle = {
    textAlign: 'center',
  };

  const numTextStyle = {
    fontFamily: 'system-ui',
    fontWeight: 775,
    fontSize: '3vw',
    color: 'rgb(0, 14, 36)',
  };

  const headerTextStyle = {
    fontFamily: 'system-ui',
    fontWeight: 775,
    fontSize: '1.5vw',
    color: 'black',
  };

  const [oneDayLogins, setOneDayLogins] = useState(0);
  const [sevenDayLogins, setSevenDayLogins] = useState(0);
  const [thirtyDayLogins, setThirtyDayLogins] = useState(0);

  const fetchDataFromMongoDB = async () => {
    try {
      const response = await axios.get(
        `${process.env.REACT_APP_API_BASE_URL}/api/user/logins?days=1`
      );
      setOneDayLogins(response.data.count);
      const response7 = await axios.get(
        `${process.env.REACT_APP_API_BASE_URL}/api/user/logins?days=7`
      );
      setSevenDayLogins(response7.data.count);
      const response30 = await axios.get(
        `${process.env.REACT_APP_API_BASE_URL}/api/user/logins?days=30`
      );
      setThirtyDayLogins(response30.data.count);
    } catch (err) {
      console.error('Error fetching logins:', err);
    }
  };

  useEffect(() => {
    fetchDataFromMongoDB();
  }, []);

  return (
    <Card elevation={2} sx={cardStyle}>
      <Box sx={titleBoxStyle}>
        <Typography sx={titleTextStyle}>Active Users</Typography>
      </Box>

      <Box sx={metricsRowStyle}>
        <Box sx={numBoxStyle}>
          <Typography variant="h6" sx={numTextStyle}>
            {oneDayLogins}
          </Typography>
          <Typography variant="h5" sx={headerTextStyle}>
            Today
          </Typography>
        </Box>

        <Box sx={numBoxStyle}>
          <Typography variant="h6" sx={numTextStyle}>
            {sevenDayLogins}
          </Typography>
          <Typography variant="h5" sx={headerTextStyle}>
            7 Days
          </Typography>
        </Box>

        <Box sx={numBoxStyle}>
          <Typography variant="h6" sx={numTextStyle}>
            {thirtyDayLogins}
          </Typography>
          <Typography variant="h5" sx={headerTextStyle}>
            30 Days
          </Typography>
        </Box>
      </Box>
    </Card>
  );
};

export default ActiveUsers;
