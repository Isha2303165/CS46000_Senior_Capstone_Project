import React from 'react';
import { Modal, Box, Typography, Button } from '@mui/material';

const ConfirmationCheck = ({ open, onClose, onConfirm, title, message }) => {
  return (
    <Modal open={open} onClose={onClose} aria-labelledby="confirmation-modal">
      <Box
        sx={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: '25%',
          bgcolor: 'white',
          boxShadow: 30,
          p: 4,
          borderRadius: 2,
          width: 400,
          textAlign: 'center',
        }}
      >
        <Typography id="modal-title" variant="h6">
          {title || 'Confirm action'}
        </Typography>

        <Typography sx={{ mt: 2 }}>{message || 'Are you sure?'}</Typography>

        <Box sx={{ display: 'flex', justifyContent: 'center', gap: 2, mt: 3 }}>
          <Button
            sx={{
              color: '#fff',
              backgroundColor: '#6aa57a',
              '&:hover': {
                color: '#6aa57a',
                backgroundColor: 'transparent',
              },
            }}
            variant="contained"
            onClick={onConfirm}
          >
            Yes
          </Button>

          <Button
            variant="outlined"
            onClick={onClose}
            sx={{
              color: '#6aa57a',
              borderColor: '#6aa57a',
              '&:hover': {
                borderColor: '#6aa57a',
                color: '#6aa57a',
                backgroundColor: 'transparent',
              },
            }}
          >
            No
          </Button>
        </Box>
      </Box>
    </Modal>
  );
};

export default ConfirmationCheck;
