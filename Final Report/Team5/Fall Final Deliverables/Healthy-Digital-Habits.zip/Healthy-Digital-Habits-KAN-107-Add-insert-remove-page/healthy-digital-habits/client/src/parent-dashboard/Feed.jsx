import { Box, Button, CircularProgress, Typography, Card } from '@mui/material';
import useMediaQuery from '@mui/material/useMediaQuery';
import axios from 'axios';
import { jwtDecode as jwt_decode } from 'jwt-decode';
import React, { useEffect, useState } from 'react';
import Graph from './Graph';
import { textAlign } from '@mui/system';

const Feed = () => {
  const isSmallScreen = useMediaQuery('(max-width:600px)');

  const [circles, setCircles] = useState([]);
  const [circleData, setCircleData] = useState();
  const [openModal, setOpenModal] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [showGraphButton, setGraphButton] = useState(true);
  const [showNoData, setShowNoData] = useState(false);
  const [showTimestamp, setTimestamp] = useState('');
  const [notHidden, setNotHidden] = useState('');

  const getColor = progress => {
    if (progress <= 30) return '#da614e';
    if (progress <= 50) return '#ffae42';
    if (progress <= 70) return '#fada5e';
    return '#008000';
  };

  const feedStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '.5rem',
    backgroundColor: '#F1EFEC',
  };

  const titleBoxContainerStyle = {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginBottom: '.5rem',
    gap: '1rem',
  };

  const titleboxStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
    justifyContent: 'center',
  };

  const titleTextStyle = {
    fontFamily: 'system-ui',
    fontWeight: '775',
    fontSize: 'clamp(2.5rem, 1.5vw, 2rem)',
    color: 'black',
  };

  const circleTextStyle = {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 'clamp(1rem, 5vw, 10rem)',
    padding: '.5rem',
    fontSize: 'clamp(1rem, 20vw, 2rem)',
  };

  const circleStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    width: 'clamp(6rem, 20vw, 12rem)',
  };

  const textStyle = {
    textAlign: 'center',
    marginTop: '8px',
    fontFamily: 'system-ui',
    fontWeight: '750',
    fontSize: 'clamp(1rem, 1.25vw, 2rem)',
    color: 'black',
  };

  const handleOpenModal = () => {
    setIsOpen(true);
    setGraphButton(false);
  };

  const handleCloseModal = () => {
    setIsOpen(false);
    setGraphButton(true);
  };

  const formatDate = dateString => {
    const options = { year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const token = localStorage.getItem('token');
        const decoded = jwt_decode(token);
        const res = await axios.get(
          `${process.env.REACT_APP_API_BASE_URL}/api/dashboard?uname=${decoded.uname}`
        );
        const result = res.data.pop();
        let resultArr = [];
        if (result) {
          resultArr.push(
            {
              progress: result.mood.Focus * 10,
              number: result.mood.Focus,
              text: 'Focus',
              color: getColor(result.mood.Focus * 10),
            },
            {
              progress: result.mood.Control * 10,
              number: result.mood.Control,
              text: 'Control',
              color: getColor(result.mood.Control * 10),
            },
            {
              progress: result.mood.Empowerment * 10,
              number: result.mood.Empowerment,
              text: 'Empowerment',
              color: getColor(result.mood.Empowerment * 10),
            },
            {
              progress: result.mood.Guilt * 10,
              number: result.mood.Guilt,
              text: 'Guilt',
              color: getColor(result.mood.Guilt * 10),
            }
          );
          setShowNoData(false);
          setTimestamp(formatDate(result.createdAt));
        } else {
          setShowNoData(true);
          setTimestamp('None');
        }
        setCircles(resultArr);
      } catch (error) {
        console.error('Error: ', error);
      }
    };

    fetchData();
  }, []);

  return (
    <Card elevation={2} sx={{ outline: '2px solid rgb(206, 206, 206)', width: '90%' }}>
      <Box sx={feedStyle}>
        <Box style={titleBoxContainerStyle}>
          <Box style={titleboxStyle}>
            <Typography style={titleTextStyle}>Daily Survey Results</Typography>
            <Typography style={textStyle}>Last Updated: {showTimestamp}</Typography>
          </Box>
          <Button
            style={{ display: showGraphButton ? 'block' : 'none' }}
            onClick={() => {
              handleOpenModal();
              setNotHidden('');
            }}
            variant="contained"
            sx={{
              backgroundColor: '#1A477F',
              height: '60px',
              top: '20px',
              '&:hover': {
                backgroundColor: '#0F2B4D',
              },
            }}
          >
            See your feelings over time
          </Button>
        </Box>

        {isOpen && <Graph onClose={handleCloseModal} notHidden={notHidden} />}

        {!isOpen && (
          <div style={circleTextStyle}>
            {circles.map((circle, index) => (
              <div
                key={index}
                style={{
                  ...circleStyle,
                  cursor: 'pointer',
                  display: 'grid',
                  placeItems: 'center',
                  textAlign: 'center',
                }}
                onClick={() => {
                  setNotHidden(circle.text);
                  handleOpenModal();
                }}
              >
                <div style={{ position: 'relative' }}>
                  <CircularProgress
                    variant="determinate"
                    value={circle.progress}
                    style={{
                      color: circle.color,
                      borderRadius: '50%',
                      backgroundColor: '#ffffff',
                      outline: '3px solid #dcdcdc',
                    }}
                    size={'clamp(5rem, 8vw, 12rem)'}
                    thickness={'5.5'}
                  />
                  <Typography
                    style={{
                      position: 'absolute',
                      top: '45%',
                      left: '50%',
                      transform: 'translate(-50%, -50%)',
                      fontSize: 'clamp(1.2rem, 2vw, 2rem)',
                      fontWeight: '600',
                      color: 'black',
                      paddingBottom: '2rem',
                    }}
                  >
                    {circle.number}
                  </Typography>
                  <Typography style={textStyle}>{circle.text}</Typography>
                </div>
              </div>
            ))}
          </div>
        )}
      </Box>
    </Card>
  );
};

export default Feed;
