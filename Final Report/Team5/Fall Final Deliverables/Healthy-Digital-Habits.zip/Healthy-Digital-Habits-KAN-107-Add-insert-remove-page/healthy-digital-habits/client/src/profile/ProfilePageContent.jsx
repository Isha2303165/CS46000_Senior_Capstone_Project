import React from 'react';
import NavBar from '../shared/NavBar';
import ProfilePage from './ProfilePage';

const ProfilePageContent = () => (
  <div
    style={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      height: '100vh',
      flexDirection: 'column',
    }}
  >
    <NavBar />
    <ProfilePage />
  </div>
);

export default ProfilePageContent;
