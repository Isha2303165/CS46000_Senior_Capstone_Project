import { Box, Button, Collapse, Snackbar, Typography } from '@mui/material';
import axios from 'axios';
import { useEffect, useState } from 'react';
import 'react-quill/dist/quill.snow.css';
import AddCourse from './AddCourse.jsx';
import AddModule from './AddModule.jsx';
import AddTopic from './AddTopic.jsx';
import DeleteCourse from './DeleteCourse.jsx';
import DeleteModule from './DeleteModule.jsx';
import DeleteTopic from './DeleteTopic.jsx';
import EditCourse from './EditCourse.jsx';
import EditModule from './EditModule.jsx';
import EditTopic from './EditTopic.jsx';
import RestartModule from './RestartModule.jsx';
import DndSidebar from './DndSidebar.jsx';
import { useLocation } from 'react-router-dom';
// const selectedCourseId = state?.courseId ?? localStorage.getItem('lastCourseId');

export default function ManageTopics() {
  const [topics, setTopics] = useState([]);
  const [modules, setModules] = useState([]);
  const [courses, setCourses] = useState([]);
  const [users, setUsers] = useState([]);
  //New for DND sidebar
  const [courseTreeData, setCourseTreeData] = useState([]);
  const [selectedTopicToEdit, setSelectedTopicToEdit] = useState('');
  const [selectedTopicToDelete, setSelectedTopicToDelete] = useState('');
  const [selectedCourseToEdit, setSelectedCourseToEdit] = useState('');
  const [selectedCourseToDelete, setSelectedCourseToDelete] = useState('');
  const [selectedModuleToEdit, setSelectedModuleToEdit] = useState('');
  const [selectedModuleToDelete, setSelectedModuleToDelete] = useState('');
  const [selectedModuleToRestart, setSelectedModuleToRestart] = useState('');
  const [selectedUser, setSelectedUser] = useState('');
  const [topicTitle, setTopicTitle] = useState('');
  const [courseTitle, setCourseTitle] = useState('');
  const [courseImage, setCourseImage] = useState('');
  const [newTopicName, setNewTopicName] = useState('');
  const [newModuleName, setNewModuleName] = useState('');
  const [selectedModulesForAdd, setSelectedModulesForAdd] = useState([]);
  const [selectedTopicsForAdd, setSelectedTopicsForAdd] = useState([]);
  const [selectedTopicsForEdit, setSelectedTopicsForEdit] = useState([]);
  const [selectedModulesForEdit, setSelectedModulesForEdit] = useState([]);
  const [selectedModulesForEditTitles, setSelectedModulesForEditTitles] = useState([]);
  const [moduleTitle, setModuleTitle] = useState('');
  const [moduleDescription, setModuleDescription] = useState('');
  const [moduleImage, setModuleImage] = useState('');
  const [modulePrereqs, setModulePrereqs] = useState([]);
  const [newCourseName, setNewCourseName] = useState('');
  const [pages, setPages] = useState([
    {
      pageDescription: '',
      content: '',
      type: '',
      questionDescription: '',
      value: '',
      media: '',
      layout: '',
      option1: '',
      option2: '',
      option3: '',
      option4: '',
      pagePaths: '',
    },
  ]);
  const [errors, setErrors] = useState({});
  const [confirmationMessage, setConfirmationMessage] = useState('');
  const [openSnackbar, setOpenSnackbar] = useState(false);

  const [open, setOpen] = useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);
  const [questionSelectPath, setQuestionSelectPath] = useState('');
  const [inputPaths, setInputPaths] = useState({});

  const [addCourseOpen, setAddCourseOpen] = useState(false);
  const [editCourseOpen, setEditCourseOpen] = useState(false);
  const [deleteCourseOpen, setDeleteCourseOpen] = useState(false);
  const [addTopicOpen, setAddTopicOpen] = useState(false);
  const [editTopicOpen, setEditTopicOpen] = useState(false);
  const [deleteTopicOpen, setDeleteTopicOpen] = useState(false);
  const [addModuleOpen, setAddModuleOpen] = useState(false);
  const [editModuleOpen, setEditModuleOpen] = useState(false);
  const [deleteModuleOpen, setDeleteModuleOpen] = useState(false);
  const [restartModuleOpen, setRestartModuleOpen] = useState(false);

  const { state } = useLocation();

  //Getting state from TopicsModule.jsx
  useEffect(() => {
    const navId = state?.courseId;
    const navTitle = state?.courseTitle;
    const last = localStorage.getItem('lastCourseId');

    if (navId) {
      setSelectedCourseToEdit(navId);
      localStorage.setItem('lastCourseId', navId);
    } else if (navTitle && courses.length) {
      const c = courses.find(x => x.title === navTitle);
      if (c) {
        setSelectedCourseToEdit(c._id);
        localStorage.setItem('lastCourseId', c._id);
      }
    } else if (last) {
      setSelectedCourseToEdit(last);
    }
  }, [state, courses]);

  //Original just getting all data.
  useEffect(() => {
    (async () => {
      try {
        const [topicsRes, coursesRes, modulesRes, usersRes] = await Promise.all([
          axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/topics/all`),
          axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/courses/all`),
          axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/module`),
          axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/user/all`),
        ]);
        setTopics(topicsRes.data);
        setCourses(coursesRes.data);
        setModules(modulesRes.data);
        setUsers(usersRes.data);
      } catch (e) {
        console.error('Error fetching data:', e);
      }
    })();
  }, []);

  useEffect(() => {
    if (!selectedCourseToEdit || !courses.length || !topics.length || !modules.length) return;

    const course = courses.find(c => c._id === selectedCourseToEdit);
    if (!course) {
      console.warn('Selected course not found:', selectedCourseToEdit);
      setCourseTreeData([]);
      return;
    }

    const tree = (course.topics || []).map(topicTitle => {
      const t = topics.find(x => x.title === topicTitle);
      return {
        courseId: course._id,
        courseTitle: course.title,
        topicId: t?._id ?? null,
        topicTitle: topicTitle,
        modules: (t?.modules || []).map(mid => {
          const m = modules.find(x => x._id === mid);
          return { moduleId: mid, moduleTitle: m?.title ?? null };
        }),
      };
    });

    setCourseTreeData(tree);
  }, [selectedCourseToEdit, courses, topics, modules]);

  // useEffect(() => {
  //   console.log('selectedCourseToEdit:', selectedCourseToEdit);
  // }, [selectedCourseToEdit]);

  // useEffect(() => {
  //   console.log('courseTreeData:', courseTreeData);
  // }, [courseTreeData]);

  // Persist DnD sidebar reorders/moves
  const handleTreeReorder = async (payload) => {
    try {
      const base = process.env.REACT_APP_API_BASE_URL;
      if (payload?.kind === 'topics') {
        const course = courses.find(c => c._id === payload.courseId);
        if (!course) return;
        await axios.put(`${base}/api/courses/addTopic`, {
          title: course.title,
          topics: payload.topics,
          image: course.image,
        });
        const coursesRes = await axios.get(`${base}/api/courses/all`);
        setCourses(coursesRes.data);
      } else if (payload?.kind === 'modules') {
        const { fromTopicId, toTopicId, newFromModules, newToModules } = payload.move || {};
        const fromTopic = topics.find(t => t._id === fromTopicId);
        const toTopic = topics.find(t => t._id === toTopicId);
        if (!fromTopic || !toTopic) return;
        if (fromTopicId === toTopicId) {
          await axios.put(`${base}/api/topics/addModule`, { title: fromTopic.title, modules: newFromModules });
        } else {
          await Promise.all([
            axios.put(`${base}/api/topics/addModule`, { title: fromTopic.title, modules: newFromModules }),
            axios.put(`${base}/api/topics/addModule`, { title: toTopic.title, modules: newToModules }),
          ]);
        }
        const topicsRes = await axios.get(`${base}/api/topics/all`);
        setTopics(topicsRes.data);
      }
    } catch (e) {
      console.error('Failed to persist reorder:', e);
    }
  };

  const handleRenameTopicFromSidebar = async ({ topicId, oldTitle, newTitle, modules }) => {
    try {
      const base = process.env.REACT_APP_API_BASE_URL;
      const fallbackTopic = topics.find(t => t._id === topicId) || topics.find(t => t.title === oldTitle);
      const payloadTitle = oldTitle || fallbackTopic?.title;
      if (!payloadTitle) {
        console.warn('Unable to rename topic: title not found');
        return;
      }

      const moduleIds = (modules && modules.length ? modules : fallbackTopic?.modules) || [];
      await axios.put(`${base}/api/topics/addModule`, {
        title: payloadTitle,
        newName: newTitle,
        modules: moduleIds,
      });

      const [topicsRes, coursesRes] = await Promise.all([
        axios.get(`${base}/api/topics/all`),
        axios.get(`${base}/api/courses/all`),
      ]);
      setTopics(topicsRes.data);
      setCourses(coursesRes.data);
    } catch (e) {
      console.error('Failed to rename topic:', e);
    }
  };

  const handleAddCourse = async () => {
    if (!courseTitle) {
      setErrors({ message: 'Please provide a course title' });
      return;
    }

    try {
      await axios.post(`${process.env.REACT_APP_API_BASE_URL}/api/courses/create`, {
        title: courseTitle,
        topics: selectedTopicsForAdd,
        image: courseImage,
      });

      // Refresh topics after adding
      const coursesRes = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/courses/all`);
      setCourses(coursesRes.data);
      setCourseTitle('');
      setSelectedTopicsForAdd([]);

      // Show confirmation
      setConfirmationMessage('Course added successfully');
      setOpenSnackbar(true);
    } catch (error) {
      console.error('Error adding course:', error);
    }
  };

  // Functions for Topic Management
  const handleAddTopic = async () => {
    if (!topicTitle) {
      setErrors({ message: 'Please provide a topic title' });
      return;
    }

    try {
      await axios.post(`${process.env.REACT_APP_API_BASE_URL}/api/topics/create`, {
        title: topicTitle,
        modules: selectedModulesForAdd,
      });

      // Refresh topics after adding
      const topicsRes = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/topics/all`);
      setTopics(topicsRes.data);
      setTopicTitle('');
      setSelectedModulesForAdd([]); // Clear selected modules for add

      // Show confirmation
      setConfirmationMessage('Topic added successfully');
      setOpenSnackbar(true);
    } catch (error) {
      console.error('Error adding topic:', error);
    }
  };

  const handleDeleteCourse = async () => {
    try {
      await axios.delete(
        `${process.env.REACT_APP_API_BASE_URL}/api/courses/delete?title=${selectedCourseToDelete}`
      );

      const coursesRes = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/courses/all`);
      setCourses(coursesRes.data);

      setSelectedCourseToDelete('');

      setConfirmationMessage('Course deleted successfully');
      setOpenSnackbar(true);
    } catch (error) {
      console.error('Error deleting course:', error);
    }
  };

  const handleDeleteTopic = async () => {
    try {
      await axios.delete(
        `${process.env.REACT_APP_API_BASE_URL}/api/topics/delete?title=${selectedTopicToDelete}`
      );

      try {
        const coursesRes = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/courses/all`);
        const courses = coursesRes.data;

        for (const course of courses) {
          const courseRes = await axios.get(
            `${process.env.REACT_APP_API_BASE_URL}/api/courses/oneCourse?course=${course.title}`
          );
          const courseData = courseRes.data;

          if (courseData.topics.includes(selectedTopicToDelete)) {
            await axios.put(`${process.env.REACT_APP_API_BASE_URL}/api/courses/removeTopic`, {
              title: course.title,
              topicId: selectedTopicToDelete,
            });
          }
        }
      } catch (error) {
        console.error('Error while removing topic from courses:', error);
      }

      // Refresh topics after deleting
      const topicsRes = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/topics/all`);
      setTopics(topicsRes.data);

      setSelectedTopicToDelete('');

      // Show confirmation
      setConfirmationMessage('Topic deleted successfully');
      setOpenSnackbar(true);
    } catch (error) {
      console.error('Error deleting topic:', error);
    }
  };

  const handleTopicModuleFill = async e => {
    setSelectedTopicToEdit(e.target.value);
    const modulesToEdit = await axios.get(
      `${process.env.REACT_APP_API_BASE_URL}/api/topics/oneTopic?topic=${e.target.value}`
    );
    setSelectedModulesForEdit(modulesToEdit.data.modules);
    convertModuleIdsToTitles(modulesToEdit.data.modules);
  };

  const handleCourseTopicFill = async e => {
    setSelectedCourseToEdit(e.target.value);
    const topicsToEdit = await axios.get(
      `${process.env.REACT_APP_API_BASE_URL}/api/courses/oneCourse?course=${e.target.value}`
    );
    setSelectedTopicsForEdit(topicsToEdit.data.topics);
    setCourseImage(topicsToEdit.data.image);
  };

  const handleUpdateCourse = async () => {
    if (!selectedCourseToEdit || selectedTopicsForEdit.length === 0) {
      setErrors({ message: 'Please select a course and add/remove topics' });
      return;
    }

    try {
      await axios.put(`${process.env.REACT_APP_API_BASE_URL}/api/courses/addTopic`, {
        title: selectedCourseToEdit,
        topics: selectedTopicsForEdit,
        newName: newCourseName,
        image: courseImage,
      });
      const coursesRes = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/courses/all`);
      setCourses(coursesRes.data);

      setSelectedCourseToEdit('');
      setNewCourseName('');
      setSelectedTopicsForEdit([]);
      setCourseImage('');

      setConfirmationMessage('Course updated successfully');
      setOpenSnackbar(true);
    } catch (error) {
      console.error('Error updating course:', error);
    }
  };

  const handleUpdateTopic = async () => {
    if (!selectedTopicToEdit || selectedModulesForEdit.length === 0) {
      setErrors({ message: 'Please select a topic and add/remove modules' });
      return;
    }

    try {
      await axios.put(`${process.env.REACT_APP_API_BASE_URL}/api/topics/addModule`, {
        title: selectedTopicToEdit,
        newName: newTopicName,
        modules: selectedModulesForEdit,
      });
      // Refresh topics after updating
      const topicsRes = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/topics/all`);
      setTopics(topicsRes.data);

      setSelectedTopicToEdit('');
      setSelectedModulesForEdit([]);
      setNewTopicName('');
      setSelectedModulesForEditTitles([]);

      // Show confirmation
      setConfirmationMessage('Topic updated successfully');
      setOpenSnackbar(true);
    } catch (error) {
      console.error('Error updating topic:', error);
    }
  };

  // Functions for Module Management
  const handleAddModule = async () => {
    if (
      !moduleTitle ||
      !moduleDescription ||
      !moduleImage ||
      pages[-1].content != 'End of Module Activity' ||
      pages.length === 0
    ) {
      setErrors({
        message:
          'Please provide title, description, image, and at least one page. Need an End of Module activity',
      });
      return;
    }

    const sortedPages = [...pages];
    const endOfModuleIndex = sortedPages.findIndex(
      page => page.content === 'End of Module Activity'
    );

    if (endOfModuleIndex !== -1) {
      const [endOfModulePage] = sortedPages.splice(endOfModuleIndex, 1);
      sortedPages.push(endOfModulePage);
    }

    try {
      await axios.post(`${process.env.REACT_APP_API_BASE_URL}/api/createmodule`, {
        title: moduleTitle,
        description: moduleDescription,
        image: moduleImage,
        prereqs: modulePrereqs,
        pages: sortedPages,
        pagePaths: inputPaths,
      });

      // Refresh modules after adding
      const modulesRes = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/module`);
      setModules(modulesRes.data);
      setModuleTitle('');
      setModuleDescription('');
      setModuleImage('');
      setPages([
        {
          pageDescription: '',
          content: '',
          type: '',
          questionDescription: '',
          value: '',
          media: '',
          layout: '',
          option1: '',
          option2: '',
          option3: '',
          option4: '',
          pagePaths: '',
        },
      ]);

      // Show confirmation
      setConfirmationMessage('Module added successfully');
      setOpenSnackbar(true);
    } catch (error) {
      console.error('Error adding module:', error);
    }
  };

  const handleDeleteModule = async () => {
    try {
      await axios.delete(
        `${process.env.REACT_APP_API_BASE_URL}/api/module/?id=${selectedModuleToDelete}`
      );

      try {
        const topicsRes = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/topics/all`);
        const topics = topicsRes.data;
        for (const topic of topics) {
          const topicRes = await axios.get(
            `${process.env.REACT_APP_API_BASE_URL}/api/topics/oneTopic?topic=${topic.title}`
          );
          const topicData = topicRes.data;
          if (topicData.modules.includes(selectedModuleToDelete)) {
            await axios.put(`${process.env.REACT_APP_API_BASE_URL}/api/topics/removeModule`, {
              title: topicData.title,
              moduleId: selectedModuleToDelete,
            });
          }
        }
      } catch (error) {
        console.error('Error while removing module from topics:', error);
      }

      // Refresh modules after deleting
      const modulesRes = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/module`);
      setModules(modulesRes.data);

      // Show confirmation
      setConfirmationMessage('Module deleted successfully');
      setOpenSnackbar(true);
    } catch (error) {
      console.error('Error deleting module:', error);
    }
  };

  const handleUpdateModule = async () => {
    if (
      !selectedModuleToEdit ||
      !moduleTitle ||
      !moduleDescription ||
      !moduleImage ||
      pages.length === 0
    ) {
      setErrors({ message: 'Please select a module and fill all fields' });
      return;
    }

    try {
      await axios.put(`${process.env.REACT_APP_API_BASE_URL}/api/module/update`, {
        title: moduleTitle,
        newName: newModuleName,
        description: moduleDescription,
        image: moduleImage,
        prereqs: modulePrereqs,
        pages,
        pagePaths: inputPaths,
      });
      // Refresh modules after updating
      const modulesRes = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/module`);
      setModules(modulesRes.data);

      setNewModuleName('');
      setSelectedModuleToEdit('');
      // Show confirmation
      setConfirmationMessage('Module updated successfully');
      setOpenSnackbar(true);
    } catch (error) {
      console.error('Error updating module:', error);
    }
  };

  const handleModuleSelect = async e => {
    setSelectedModuleToEdit(e.target.value);
    const moduleRes = await axios.get(
      `${process.env.REACT_APP_API_BASE_URL}/api/module/${e.target.value}`
    );
    if (
      moduleRes.data.pages[moduleRes.data.pages.length - 1].content ===
      'End of Module Activity Questions'
    ) {
      moduleRes.data.pages.pop();
    }
    setPages(moduleRes.data.pages);
    setModuleTitle(moduleRes.data.title);
    setModuleDescription(moduleRes.data.description);
    setModuleImage(moduleRes.data.image);
    setModulePrereqs(moduleRes.data.prereqs);
    if (moduleRes?.data?.pagePaths) {
      const allPaths = Object.keys(moduleRes.data.pagePaths).map(outerKey => {
        const selectedPath = moduleRes.data.pagePaths[outerKey];
        const keys = Object.keys(selectedPath);
        const values = keys.slice(0, keys.length - 1);
        const pageNumber = selectedPath[keys[keys.length - 1]];

        return {
          desc: outerKey,
          responses: values.length,
          values: values,
          pageNumber: pageNumber,
        };
      });

      const firstPath = allPaths[0];
      setQuestionSelectPath(firstPath);

      setInputPaths(moduleRes.data.pagePaths);
      console.log(allPaths);
    }
  };

  const handleRestartModule = async () => {
    try {
      const res = await axios.put(
        `${process.env.REACT_APP_API_BASE_URL}/api/moduleincomplete?id=${selectedModuleToRestart}&uname=${selectedUser}`
      );
      setConfirmationMessage('Module restarted for user');
      setOpenSnackbar(true);
    } catch (error) {
      if (error.response && error.response.status === 400) {
        console.error('400 Bad Request:', error.response.data);
        setConfirmationMessage('User has not completed module');
        setOpenSnackbar(true);
      } else {
        console.error('An unexpected error occurred:', error.message);
      }
    }
  };

  // Close Snackbar
  const handleCloseSnackbar = () => {
    setOpenSnackbar(false);
  };

  // Page management
  const handlePageChange = (index, key, value, qIndex, valueIndex) => {
    const updatedPages = [...pages];

    // Handle non-question keys
    if (!key.startsWith('questions')) {
      updatedPages[index][key] = value;
    }
    // Handle question keys
    else {
      const questions = updatedPages[index]['questions'];

      // Ensure the question object exists at qIndex
      if (questions[qIndex] === undefined) {
        questions[qIndex] = {};
      }

      if (questions[qIndex].value === undefined) {
        questions[qIndex].value = [];
      }

      if (key === 'questionsType') {
        questions[qIndex].type = value;
      } else if (key === 'questionsDescription') {
        questions[qIndex].description = value;
      } else if (key === 'questionsValue') {
        questions[qIndex].value[valueIndex] = value;
      } else if (key === 'questionsResponses') {
        questions[qIndex].responses = value;
      } else if (key === 'questionsOrientation') {
        questions[qIndex].orientation = value;
      }
    }

    setPages(updatedPages);
  };

  const handleAddPage = () => {
    setPages([
      ...pages,
      {
        pageDescription: '',
        content: '',
        type: '',
        questionDescription: '',
        value: '',
        media: '',
        layout: '',
        option1: '',
        option2: '',
        option3: '',
        option4: '',
      },
    ]);
  };

  const handleAddEOMPage = () => {
    setPages([
      ...pages,
      {
        pageDescription: '',
        content: 'End of Module Activity',
        type: '',
        questionDescription: '',
        value: '',
        media: '',
        layout: '',
        time: '',
        numberQuestions: '',
        questions: [],
      },
    ]);
  };

  const handleRemovePage = index => {
    setPages(pages.filter((_, i) => i !== index));
  };

  const moveUpTopics = index => {
    if (index > 0) {
      const newTopics = [...selectedTopicsForEdit];
      const temp = newTopics[index - 1];
      newTopics[index - 1] = newTopics[index];
      newTopics[index] = temp;
      setSelectedTopicsForEdit(newTopics);
    }
  };

  const moveDownTopics = index => {
    if (index < selectedTopicsForEdit.length - 1) {
      const newTopics = [...selectedTopicsForEdit];
      const temp = newTopics[index + 1];
      newTopics[index + 1] = newTopics[index];
      newTopics[index] = temp;
      setSelectedTopicsForEdit(newTopics);
    }
  };

  const moveUpModules = index => {
    if (index > 0) {
      const newModules = [...selectedModulesForEdit];
      const temp = newModules[index - 1];
      newModules[index - 1] = newModules[index];
      newModules[index] = temp;
      convertModuleIdsToTitles(newModules);
      setSelectedModulesForEdit(newModules);
    }
  };

  const moveDownModules = index => {
    if (index < selectedModulesForEdit.length - 1) {
      const newModules = [...selectedModulesForEdit];
      const temp = newModules[index + 1];
      newModules[index + 1] = newModules[index];
      newModules[index] = temp;
      convertModuleIdsToTitles(newModules);
      setSelectedModulesForEdit(newModules);
    }
  };

  const convertModuleIdsToTitles = async moduleArray => {
    try {
      const titles = [];
      for (const moduleId of moduleArray) {
        const moduleRes = await axios.get(
          `${process.env.REACT_APP_API_BASE_URL}/api/moduletitle?id=${moduleId}`
        );
        titles.push(moduleRes.data);
      }
      setSelectedModulesForEditTitles(titles);
    } catch (error) {
      console.error('Error fetching module titles:', error);
    }
  };

  const handleChange = (selectedDesc, pageIndex) => {
    const selectedQuestion = pages
      .flatMap(pg =>
        ['option1', 'option2', 'option3', 'option4'].map(optionKey => {
          if (
            pg[optionKey] === 'question' &&
            pg[`${optionKey}-questionDescription`] === selectedDesc
          ) {
            return {
              desc: selectedDesc,
              responses: pg[`${optionKey}-numberResponses`],
              values: pg[`${optionKey}-value`],
              pageNumber: pageIndex + 1,
            };
          }
          return null;
        })
      )
      .find(item => item !== null);

    if (selectedQuestion) {
      setQuestionSelectPath(selectedQuestion);
    }
  };

  const handleInputChange = (idx, value) => {
    const questionDesc = questionSelectPath.desc;
    const key = questionSelectPath.values[idx];
    const pageNumber = questionSelectPath.pageNumber;

    setInputPaths(prevPaths => ({
      ...prevPaths,
      [questionDesc]: {
        ...prevPaths[questionDesc],
        pageNumber: pageNumber,
        [key]: value,
      },
    }));
  };

  // When using the legacy AdminModules page, synthesize the course info for the sidebar.
  const sidebarCourseInfo = (() => {
    const byId = courses.find(c => c._id === selectedCourseToEdit);
    if (byId) return { courseId: byId._id, courseTitle: byId.title, courseImage: byId.image };
    const byTitle = courses.find(c => c.title === selectedCourseToEdit);
    return byTitle
      ? { courseId: byTitle._id, courseTitle: byTitle.title, courseImage: byTitle.image }
      : null;
  })();

  return (
    <>
      {' '}
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'center', width: '100%' }}>
          <DndSidebar
            courseTree={courseTreeData}
            courseInfo={sidebarCourseInfo}
            selectedModuleToEdit={selectedModuleToEdit}
            setSelectedModuleToEdit={setSelectedModuleToEdit}
            onRenameTopic={handleRenameTopicFromSidebar}
            onReorder={handleTreeReorder}
          />











        {/*V2 code commented out because it causing many different errors */}
          {/* <Box sx={{ marginTop: '1rem', padding: '20px', width: '100%', textAlign: 'center' }}>
            <Typography variant="h5">Courses</Typography>
            Add Course Section
            <Button
              onClick={() => setAddCourseOpen(!addCourseOpen)}
              sx={{ display: 'block', margin: '0 auto' }}
            >
              {addCourseOpen ? 'Hide Add Course' : 'Show Add Course'}
            </Button>
            <Collapse in={addCourseOpen}>
              <AddCourse
                courseTitle={courseTitle}
                setCourseTitle={setCourseTitle}
                courseImage={courseImage}
                setCourseImage={setCourseImage}
                selectedTopicsForAdd={selectedTopicsForAdd}
                setSelectedTopicsForAdd={setSelectedTopicsForAdd}
                topics={topics}
                errors={errors}
                handleAddCourse={handleAddCourse}
              />
            </Collapse>

            Edit Course Section
            <Button
              onClick={() => setEditCourseOpen(!editCourseOpen)}
              sx={{ display: 'block', margin: '0 auto' }}
            >
              {editCourseOpen ? 'Hide Edit Course' : 'Show Edit Course'}
            </Button>
            <Collapse in={editCourseOpen}>
              <EditCourse
                selectedCourseToEdit={selectedCourseToEdit}
                courseImage={courseImage}
                setCourseImage={setCourseImage}
                handleCourseTopicFill={handleCourseTopicFill}
                courses={courses}
                selectedTopicsForEdit={selectedTopicsForEdit}
                setSelectedTopicsForEdit={setSelectedTopicsForEdit}
                topics={topics}
                moveUpTopics={moveUpTopics}
                moveDownTopics={moveDownTopics}
                handleUpdateCourse={handleUpdateCourse}
                setNewCourseName={setNewCourseName}
                newCourseName={newCourseName}
              />
            </Collapse>

            Delete Course Section
            <Button
              onClick={() => setDeleteCourseOpen(!deleteCourseOpen)}
              sx={{ display: 'block', margin: '0 auto' }}
            >
              {deleteCourseOpen ? 'Hide Delete Course' : 'Show Delete Course'}
            </Button>
            <Collapse in={deleteCourseOpen}>
              <DeleteCourse
                selectedCourseToDelete={selectedCourseToDelete}
                setSelectedCourseToDelete={setSelectedCourseToDelete}
                courses={courses}
                handleDeleteCourse={handleDeleteCourse}
              />
            </Collapse>
          </Box>

          <Box sx={{ marginTop: '1rem', padding: '20px', width: '100%', textAlign: 'center' }}>
            <Typography variant="h5">Modules</Typography>
            Add Module Section
            <AddModule
              courses={courses}
              topics={topics}
              modules={modules}
              pages={pages}
              moduleImage={moduleImage}
              setModuleImage={setModuleImage}
              handlePageChange={handlePageChange}
              setModuleTitle={setModuleTitle}
              setModuleDescription={setModuleDescription}
              setModulePrereqs={setModulePrereqs}
              moduleTitle={moduleTitle}
              moduleDescription={moduleDescription}
              modulePrereqs={modulePrereqs}
              selectedModuleToEdit={selectedModuleToEdit}
              handleRemovePage={handleRemovePage}
              handleAddPage={handleAddPage}
              handleOpen={handleOpen}
              handleClose={handleClose}
              questionSelectPath={questionSelectPath}
              handleChange={handleChange}
              inputPaths={inputPaths}
              handleInputChange={handleInputChange}
              setConfirmationMessage={setConfirmationMessage}
              setOpenSnackbar={setOpen}
              handleAddModule={handleAddModule}
              handleAddEOMPage={handleAddEOMPage}
              errors={errors}
              open={open}
            />

            Edit Module Section
            <Button
              onClick={() => setEditModuleOpen(!editModuleOpen)}
              sx={{ display: 'block', margin: '0 auto' }}
            >
              {editModuleOpen ? 'Hide Edit Module' : 'Show Edit Module'}
            </Button>
            <Collapse in={editModuleOpen}>
              <EditModule
                selectedModuleToEdit={selectedModuleToEdit}
                setSelectedModuleToEdit={setSelectedModuleToEdit}
                modules={modules}
                handleModuleSelect={handleModuleSelect}
                handleUpdateModule={handleUpdateModule}
                newModuleName={newModuleName}
                setNewModuleName={setNewModuleName}
              />
            </Collapse>

            Delete Module Section
            <Button
              onClick={() => setDeleteModuleOpen(!deleteModuleOpen)}
              sx={{ display: 'block', margin: '0 auto' }}
            >
              {deleteModuleOpen ? 'Hide Delete Module' : 'Show Delete Module'}
            </Button>
            <Collapse in={deleteModuleOpen}>
              <DeleteModule
                selectedModuleToDelete={selectedModuleToDelete}
                setSelectedModuleToDelete={setSelectedModuleToDelete}
                modules={modules}
                handleDeleteModule={handleDeleteModule}
              />
            </Collapse>

            Restart Module Section
            <Button
              onClick={() => setRestartModuleOpen(!restartModuleOpen)}
              sx={{ display: 'block', margin: '0 auto' }}
            >
              {restartModuleOpen ? 'Hide Restart Module' : 'Show Restart Module'}
            </Button>
            <Collapse in={restartModuleOpen}>
              <RestartModule
                selectedModuleToRestart={selectedModuleToRestart}
                setSelectedModuleToRestart={setSelectedModuleToRestart}
                modules={modules}
                handleRestartModule={handleRestartModule}
                users={users}
                selectedUser={selectedUser}
                setSelectedUser={setSelectedUser}
              />
            </Collapse>

            Snackbar for confirmation messages
            <Snackbar
              open={openSnackbar}
              autoHideDuration={6000}
              onClose={handleCloseSnackbar}
              message={confirmationMessage}
            />
          </Box> */}
        </div>
      </div>
    </>
  );
}
