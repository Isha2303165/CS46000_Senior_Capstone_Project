import { Button, Card, FormControl, MenuItem, Select, TextField, Typography } from '@mui/material';
import React from 'react';

const AddCourse = ({
  courseTitle,
  courseImage,
  setCourseTitle,
  setCourseImage,
  selectedTopicsForAdd,
  setSelectedTopicsForAdd,
  topics,
  errors,
  handleAddCourse,
}) => {
  return (
    <Card
      sx={{
        marginTop: '20px',
        padding: '20px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Typography variant="h6" sx={{ marginBottom: '20px' }}>
        Add Course
      </Typography>
      <TextField
        label="Course Title"
        value={courseTitle}
        onChange={e => setCourseTitle(e.target.value)}
        style={{ width: '100%' }}
      />
      <br />
      <TextField
        label="Course Image"
        value={courseImage}
        onChange={e => setCourseImage(e.target.value)}
        style={{ width: '100%' }}
      />
      <FormControl
        fullWidth
        sx={{
          display: 'flex',
          alignItems: 'center',
        }}
      >
        <br />
        <Typography variant="body1">Select Topics</Typography>
        <Select
          labelId="modules-select-label"
          multiple
          value={selectedTopicsForAdd}
          onChange={e => setSelectedTopicsForAdd(e.target.value)}
          style={{ width: '100%' }}
        >
          {topics.map(topic => (
            <MenuItem key={topic.title} value={topic.title}>
              {topic.title}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <br />
      {errors.message && <Typography color="error">{errors.message}</Typography>}
      <Button variant="contained" onClick={handleAddCourse}>
        Add Course
      </Button>
    </Card>
  );
};

export default AddCourse;
