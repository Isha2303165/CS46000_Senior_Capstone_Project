import LogInPage from './LogInPage';

const LogInContents = () => (
  <div
    style={{
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      height: '100vh',
    }}
  >
    <LogInPage />
  </div>
);

export default LogInContents;
