import {
  Box,
  Button,
  Collapse,
  Slide,
  Snackbar,
  Switch,
  ToggleButton,
  Typography,
} from '@mui/material';
import axios from 'axios';

import 'react-quill/dist/quill.snow.css';

import { useEffect, useMemo, useState, useRef } from 'react';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import Alert from '@mui/material/Alert';
import { useCourse } from '../contexts/CourseContext';
import { useLocation } from 'react-router-dom';
import { TextField, InputAdornment, IconButton, MenuItem, Tooltip } from '@mui/material';
import ClearIcon from '@mui/icons-material/Clear';
import DndSidebar from './DndSidebar.jsx';
import Pagination from '@mui/material/Pagination';
import PaginationItem from '@mui/material/PaginationItem';
import LayoutEditButtons from './LayoutEditButtons.jsx';
import AdminLessonModal from './AdminLessonModal.jsx';
import AdminQuestionModal from '../components/AdminQuestionModal.jsx';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import ConfirmationCheck from '../shared/ConfirmationCheck.jsx';
import AutoAwesomeMotionIcon from '@mui/icons-material/AutoAwesomeMotion';

const createDefaultQuestionData = () => ({
  questionText: '',
  questionType: 'multiple-choice',
  choices: ['', ''],
  shortAnswer: '',
  correctAnswers: [],
  enableBranching: false,
});

const createEmptyPage = () => ({
  content: '',
  pageDescription: '',
  layout: 'top-center-bottom',
  option1: 'rich-text',
  option2: 'rich-text',
  option3: 'rich-text',
  option4: 'rich-text',
});

const AdminModuleEditor = ({ course: courseProp }) => {
  const { selectedCourse, coursesData, setSelectedCourse } = useCourse();
  const [courses, setCourses] = useState([]);
  const [topics, setTopics] = useState([]);
  const [modules, setModules] = useState([]);
  const [users, setUsers] = useState([]);
  const [courseTreeData, setCourseTreeData] = useState([]);
  const [selectedModuleToEdit, setSelectedModuleToEdit] = useState('');
  const [selectedPageToEdit, setSelectedPageToEdit] = useState(1);
  const location = useLocation();
  const [isDrawerOpen, setIsDrawerOpen] = useState(true);
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const [notice, setNotice] = useState({
    open: false,
    message: '',
    severity: 'success',
  });

  // Use course from prop, context, or route state, in that order
  const course =
    courseProp ||
    selectedCourse ||
    location.state?.course ||
    (location.state?.courseId
      ? coursesData.find(course => course._id === location.state.courseId)
      : null);

  //New course context retrieval that fallsback to local storage properly
  useEffect(() => {
    // wait until we actually have courses (if they're loaded async)
    if (!courses || !courses.length) return;

    const navState = location.state || {};
    const navCourse = navState.course;
    const navCourseId = navState.courseId;
    const navCourseTitle = navState.courseTitle;
    const lastId = localStorage.getItem('lastCourseId');

    // If we already have a selectedCourse, just keep localStorage in sync and bail
    if (selectedCourse) {
      const currentId = selectedCourse._id || selectedCourse.id;
      if (currentId && lastId !== currentId) {
        localStorage.setItem('lastCourseId', currentId);
      }

      return;
    }

    // 1) Full course passed via route state
    if (navCourse) {
      setSelectedCourse(navCourse);
      const id = navCourse._id || navCourse.id;
      if (id) localStorage.setItem('lastCourseId', id);
      return;
    }

    // 2) courseId passed via route state
    if (navCourseId) {
      const c = courses.find(x => x._id === navCourseId || x.id === navCourseId);
      if (c) {
        setSelectedCourse(c);
        const id = c._id || c.id;
        if (id) localStorage.setItem('lastCourseId', id);
        return;
      }
    }

    // 3) courseTitle passed via route state
    if (navCourseTitle) {
      const c = courses.find(x => x.title === navCourseTitle);
      if (c) {
        setSelectedCourse(c);
        const id = c._id || c.id;
        if (id) localStorage.setItem('lastCourseId', id);
        return;
      }
    }

    // 4) Fallback: lastCourseId from localStorage
    if (lastId) {
      const c = courses.find(x => x._id === lastId || x.id === lastId);
      if (c) {
        setSelectedCourse(c);
      }
    }
  }, [location.state, courses, selectedCourse, setSelectedCourse]);

  // Module title editing state
  const [inputValue, setValue] = useState('');

  const saveTimeoutRef = useRef(null);

  const debounceSaveModuleTitle = newTitle => {
    // Prevent backend crash by refusing to call without valid module selected
    if (!selectedModuleToEdit || typeof selectedModuleToEdit !== 'string') {
      return;
    }

    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
    }

    saveTimeoutRef.current = setTimeout(() => {
      handleSaveModuleTitle(newTitle);
    }, 500);
  };

  //Adding, inserting, and removing pages
  //-----------------------------------------
  const handleAppendPage = async () => {
    if (!selectedModule) return;
    const pages = Array.isArray(selectedModule.pages) ? [...selectedModule.pages] : [];
    pages.push(createEmptyPage());
    try {
      await persistModulePages(pages);
      setSelectedPageToEdit(pages.length);
      setNotice({ open: true, message: 'New page added to the end.', severity: 'success' });
    } catch (err) {
      console.error('Failed to add page:', err);
      setNotice({ open: true, message: 'Unable to add page.', severity: 'error' });
    }
  };

  const handleInsertPageAtSelection = async () => {
    if (!selectedModule) return;
    const pages = Array.isArray(selectedModule.pages) ? [...selectedModule.pages] : [];
    //.min() is nice to handle edge case the current index is greater than the pages its getting from its source.
    const insertIndex = Math.min(currentPageIndex, pages.length);
    pages.splice(insertIndex, 0, createEmptyPage());
    try {
      await persistModulePages(pages);
      setSelectedPageToEdit(insertIndex + 1);
      setNotice({ open: true, message: 'Page inserted.', severity: 'success' });
    } catch (err) {
      console.error('Failed to insert page:', err);
      setNotice({ open: true, message: 'Unable to insert page.', severity: 'error' });
    }
  };

  const handleDeleteCurrentPage = async () => {
    //close the confirmation modal when called.
    setIsConfirmationOpen(false);
    if (!selectedModule) return;
    const pages = Array.isArray(selectedModule.pages) ? [...selectedModule.pages] : [];
    if (!pages.length) return;

    const updatedPages = pages.filter((_, idx) => idx !== currentPageIndex);
    if (updatedPages.length === pages.length) return;

    try {
      await persistModulePages(updatedPages);
      const nextIndex =
        updatedPages.length === 0 ? 0 : Math.min(currentPageIndex, updatedPages.length - 1);
      setSelectedPageToEdit(nextIndex + 1);
      setNotice({ open: true, message: 'Page deleted.', severity: 'success' });
    } catch (err) {
      console.error('Failed to delete page:', err);
      setNotice({ open: true, message: 'Unable to delete page.', severity: 'error' });
    }
  };

  console.log(course);
  const handleModuleTitleChange = event => {
    setValue(event.target.value);
  };
  const handleClear = () => {
    setValue('');
  };

  // Page layout selection
  const [selectedOption, setSelectedOption] = useState('');
  const handleSelect = async event => {
    const newLayoutOption = event.target.value;
    setSelectedOption(newLayoutOption);

    // --- 1. Convert dropdown option into your layout string ---
    const optionToLayoutMap = {
      option0: 'top-center-bottom',
      option1: 'left-middle-right',
      option2: 'top-bottom',
      option3: 'left-right',
      option4: 'left-right-centerbottom',
    };

    const layoutString = optionToLayoutMap[newLayoutOption];

    // --- 2. Update the current page inside selectedModule ---
    if (!selectedModule) return;

    const pages = [...selectedModule.pages];
    const current = pages[currentPageIndex];

    // set the layout
    pages[currentPageIndex] = {
      ...current,
      layout: layoutString,
    };

    try {
      // --- 3. Save it to database ---
      await persistModulePages(pages);

      // --- 4. Trigger snackbar ---
      setNotice({
        open: true,
        message: 'Layout saved!',
        severity: 'success',
      });
    } catch (err) {
      console.error('Error saving layout:', err);
    }
  };

  // Section editing state and handlers
  const [sectionToEdit, setSectionToEdit] = useState({
    optionKey: '',
    label: '',
    initialContent: '',
    sectionType: '',
  });
  // Primary use for AdminLessonModal.jsx
  const [isLessonModalOpen, setIsLessonModalOpen] = useState(false);
  const [isQuestionModalOpen, setIsQuestionModalOpen] = useState(false);
  const [questionModalContext, setQuestionModalContext] = useState({
    optionKey: '',
    label: '',
    pageIndex: 0,
    initialData: createDefaultQuestionData(),
  });
  // (OptionKey: "option1", label: "Left") etc
  //The digit in "option1" correstponds to the index of the button regardless of layout
  const handleEditSection = (optionKey, label) => {
    const page = selectedModule?.pages?.[currentPageIndex];
    //Sectiontype is "rich-text", "question, or "media"
    const sectionType = page?.[optionKey] ?? '';
    if (sectionType === 'question') {
      openQuestionModalForSection(optionKey, label);
      return;
    }
    //This helps update the modal when switching between sections.
    const initialContent = extractSectionContent(page, optionKey);
    //Send to AdminLessonModal.jsx
    setSectionToEdit({ optionKey, label, initialContent, sectionType });
    setIsLessonModalOpen(true);
  };

  const handleCloseLessonModal = () => {
    setIsLessonModalOpen(false);
  };

  const handleConvertLessonSectionToQuestion = ({
    sectionKey,
    sectionLabel,
    pageIndex,
    contentValue,
  }) => {
    if (!sectionKey) return;
    const targetPageIndex =
      typeof pageIndex === 'number' && pageIndex >= 0 ? pageIndex : currentPageIndex;
    setIsLessonModalOpen(false);
    openQuestionModalForSection(
      sectionKey,
      sectionLabel || sectionKey,
      {
        ...createDefaultQuestionData(),
        questionText: typeof contentValue === 'string' ? contentValue : '',
      },
      targetPageIndex
    );
  };

  const openQuestionModalForSection = (
    optionKey,
    label,
    initialDataOverride,
    pageIndexOverride = currentPageIndex
  ) => {
    if (!selectedModule || !optionKey) return;

    const page =
      Array.isArray(selectedModule.pages) && selectedModule.pages.length
        ? selectedModule.pages[pageIndexOverride]
        : null;
    const derivedData =
      initialDataOverride ?? extractQuestionData(page, optionKey) ?? createDefaultQuestionData();

    setQuestionModalContext({
      optionKey,
      label,
      pageIndex: pageIndexOverride,
      initialData: derivedData,
    });
    setIsQuestionModalOpen(true);
  };

  const handleCloseQuestionModal = () => {
    setIsQuestionModalOpen(false);
    setQuestionModalContext({
      optionKey: '',
      label: '',
      pageIndex: 0,
      initialData: createDefaultQuestionData(),
    });
  };

  const handleConvertQuestionToLesson = (questionState = {}) => {
    const { optionKey, label, pageIndex } = questionModalContext;
    if (!optionKey) return;
    setIsQuestionModalOpen(false);
    setSectionToEdit({
      optionKey,
      label: label || optionKey,
      initialContent: questionState?.questionText || '',
      sectionType: 'rich-text',
    });
    setIsLessonModalOpen(true);
  };

  //Helper to persist module pages after edits
  const persistModulePages = async updatedPages => {
    if (!selectedModule) return null;
    const moduleId = selectedModule._id ?? selectedModule.id;
    if (!moduleId) return null;

    try {
      const base = process.env.REACT_APP_API_BASE_URL;
      const response = await axios.put(`${base}/api/module/${moduleId}`, {
        pages: updatedPages,
      });
      const updatedModule = response.data?.module;
      setModules(prev =>
        prev.map(moduleItem =>
          String(moduleItem._id ?? moduleItem.id) === String(moduleId)
            ? updatedModule || { ...moduleItem, pages: updatedPages }
            : moduleItem
        )
      );
      return updatedModule || { ...selectedModule, pages: updatedPages };
    } catch (err) {
      console.error('Failed to persist module pages:', err);
      throw err;
    }
  };

  // Save section content handler, gives all the state.
  const handleSaveSectionContent = async ({
    pageTitle,
    pageDescription,
    contentValue,
    sectionKey,
    pageIndex,
    convertToQuestion,
    sectionType,
  }) => {
    if (!selectedModule || typeof pageIndex !== 'number' || !sectionKey) return;

    const pages = Array.isArray(selectedModule.pages) ? [...selectedModule.pages] : [];
    if (!pages[pageIndex]) return;

    const normalizedCurrentType =
      typeof sectionType === 'string' && sectionType.length ? sectionType : 'rich-text';
    let nextType = normalizedCurrentType;
    if (convertToQuestion) {
      nextType = 'question';
    } else if (normalizedCurrentType === 'question') {
      nextType = 'rich-text';
    }
    const shouldOpenQuestionModal = nextType === 'question';

    const updatedPages = pages.map((page, idx) => {
      if (idx !== pageIndex) return page;
      const updatedPage = { ...page, content: pageTitle, pageDescription };
      updatedPage[sectionKey] = nextType;
      if (nextType === 'question') {
        updatedPage[`${sectionKey}-questionDescription`] = contentValue;
      } else if (nextType === 'media') {
        updatedPage[`${sectionKey}-media`] = contentValue;
      } else {
        updatedPage[`${sectionKey}-rich-text`] = contentValue;
      }
      return updatedPage;
    });

    try {
      await persistModulePages(updatedPages);
      setSectionToEdit(prev => ({
        ...prev,
        initialContent: contentValue,
        sectionType: nextType,
      }));
      setIsLessonModalOpen(false);
      if (shouldOpenQuestionModal) {
        openQuestionModalForSection(
          sectionKey,
          sectionToEdit.label || sectionKey,
          {
            ...createDefaultQuestionData(),
            questionText: contentValue,
          },
          pageIndex
        );
      }
    } catch (err) {
      console.error('Failed to save lesson content:', err);
    }
  };

  const handleSaveQuestionContent = async questionData => {
    if (!selectedModule) return;
    const { optionKey, pageIndex } = questionModalContext;
    if (!optionKey || typeof pageIndex !== 'number') return;

    const pages = Array.isArray(selectedModule.pages) ? [...selectedModule.pages] : [];
    if (!pages[pageIndex]) return;

    const updatedPages = pages.map((page, idx) => {
      if (idx !== pageIndex) return page;
      const updatedPage = { ...page };
      updatedPage[optionKey] = 'question';
      updatedPage[`${optionKey}-questionDescription`] = questionData?.questionText || '';
      updatedPage[`${optionKey}-questionType`] = questionData?.questionType || 'multiple-choice';
      updatedPage[`${optionKey}-questionChoices`] =
        questionData?.questionType === 'multiple-choice' && Array.isArray(questionData?.choices)
          ? questionData.choices
          : [];
      updatedPage[`${optionKey}-questionShortAnswer`] =
        questionData?.questionType === 'short-answer' ? questionData?.shortAnswer || '' : '';
      updatedPage[`${optionKey}-questionCorrectAnswers`] =
        questionData?.questionType === 'multiple-choice' &&
        Array.isArray(questionData?.correctAnswers)
          ? questionData.correctAnswers
          : [];
      updatedPage[`${optionKey}-questionBranching`] = !!questionData?.enableBranching;
      return updatedPage;
    });

    try {
      await persistModulePages(updatedPages);
      setQuestionModalContext(prev => ({
        ...prev,
        initialData: questionData || createDefaultQuestionData(),
      }));
      setIsQuestionModalOpen(false);
    } catch (err) {
      console.error('Failed to save question content:', err);
    }
  };

  // Handle module selection from sidebar
  const handleSelectModule = (moduleId, moduleTitle) => {
    setSelectedModuleToEdit(moduleId);
    setValue(moduleTitle || '');
  };

  // Fetch topics and modules data, this was nice for the tree hydration
  useEffect(() => {
    (async () => {
      try {
        const [topicsRes, coursesRes, modulesRes, usersRes] = await Promise.all([
          axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/topics/all`),
          axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/courses/all`),
          axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/module`),
          axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/user/all`),
        ]);
        setTopics(topicsRes.data);
        setCourses(coursesRes.data);
        setModules(modulesRes.data);
        setUsers(usersRes.data);
      } catch (e) {
        console.error('Error fetching data:', e);
      }
    })();
  }, []);

  // Memoized selected module based on selectedModuleToEdit
  const selectedModule = useMemo(() => {
    if (!selectedModuleToEdit) return null;
    return modules.find(
      moduleItem => String(moduleItem._id ?? moduleItem.id) === String(selectedModuleToEdit)
    );
  }, [modules, selectedModuleToEdit]);
  const modulePageCount = selectedModule?.pages?.length ?? 0;
  const currentPageIndex = Math.max(0, selectedPageToEdit - 1);
  const showModulePlaceholder = !selectedModule;
  const handlePageChange = (_, page) => {
    setSelectedPageToEdit(page);
  };

  useEffect(() => {
    setValue(selectedModule?.title ?? '');
  }, [selectedModule]);

  useEffect(() => {
    setSelectedPageToEdit(1);
  }, [selectedModuleToEdit]);

  useEffect(() => {
    if (!modulePageCount) {
      setSelectedPageToEdit(1);
      return;
    }
    setSelectedPageToEdit(prev => {
      const next = prev || 1;
      return next > modulePageCount ? modulePageCount : next;
    });
  }, [modulePageCount]);

  // Build courseTreeData from course, topics, and modules
  useEffect(() => {
    if (!selectedCourse || !courses.length || !topics.length || !modules.length) return;

    const course = courses.find(c => c._id === selectedCourse._id);
    if (!course) {
      console.warn('Selected course not found:', selectedCourse._id);
      setCourseTreeData([]);
      return;
    }

    const tree = (course.topics || []).map(topicTitle => {
      const t = topics.find(x => x.title === topicTitle);
      return {
        courseId: course._id,
        courseTitle: course.title,
        topicId: t?._id ?? null,
        topicTitle: topicTitle,
        modules: (t?.modules || []).map(mid => {
          const m = modules.find(x => x._id === mid);
          return { moduleId: mid, moduleTitle: m?.title ?? null };
        }),
      };
    });

    setCourseTreeData(tree);
  }, [selectedCourse, courses, topics, modules]);

  const handleRenameTopicFromSidebar = async ({ topicId, oldTitle, newTitle, modules }) => {
    try {
      const base = process.env.REACT_APP_API_BASE_URL;
      const fallbackTopic =
        topics.find(t => t._id === topicId) || topics.find(t => t.title === oldTitle);
      const payloadTitle = oldTitle || fallbackTopic?.title;
      if (!payloadTitle) {
        console.warn('Unable to rename topic: title not found');
        return;
      }

      const moduleIds = (modules && modules.length ? modules : fallbackTopic?.modules) || [];
      await axios.put(`${base}/api/topics/addModule`, {
        title: payloadTitle,
        newName: newTitle,
        modules: moduleIds,
      });

      const [topicsRes, coursesRes] = await Promise.all([
        axios.get(`${base}/api/topics/all`),
        axios.get(`${base}/api/courses/all`),
      ]);
      setTopics(topicsRes.data);
      setCourses(coursesRes.data);
    } catch (e) {
      console.error('Failed to rename topic:', e);
    }
  };
  //Sort of dehydrates the data from the tree and persists it back to the server
  const handleTreeReorder = async payload => {
    try {
      const base = process.env.REACT_APP_API_BASE_URL;
      if (payload?.kind === 'topics') {
        const course = courses.find(c => c._id === payload.courseId);
        if (!course) return;
        await axios.put(`${base}/api/courses/addTopic`, {
          title: course.title,
          topics: payload.topics,
          image: course.image,
        });
        const coursesRes = await axios.get(`${base}/api/courses/all`);
        setCourses(coursesRes.data);
      } else if (payload?.kind === 'modules') {
        const { fromTopicId, toTopicId, newFromModules, newToModules } = payload.move || {};
        const fromTopic = topics.find(t => t._id === fromTopicId);
        const toTopic = topics.find(t => t._id === toTopicId);
        if (!fromTopic || !toTopic) return;
        if (fromTopicId === toTopicId) {
          await axios.put(`${base}/api/topics/addModule`, {
            title: fromTopic.title,
            modules: newFromModules,
          });
        } else {
          await Promise.all([
            axios.put(`${base}/api/topics/addModule`, {
              title: fromTopic.title,
              modules: newFromModules,
            }),
            axios.put(`${base}/api/topics/addModule`, {
              title: toTopic.title,
              modules: newToModules,
            }),
          ]);
        }
        const topicsRes = await axios.get(`${base}/api/topics/all`);
        setTopics(topicsRes.data);
      }
    } catch (e) {
      console.error('Failed to persist reorder:', e);
    }
  };

  const handleRefreshCourseTree = async () => {
    try {
      const base = process.env.REACT_APP_API_BASE_URL;
      const [topicsRes, coursesRes, modulesRes] = await Promise.all([
        axios.get(`${base}/api/topics/all`),
        axios.get(`${base}/api/courses/all`),
        axios.get(`${base}/api/module`),
      ]);
      setTopics(topicsRes.data);
      setCourses(coursesRes.data);
      setModules(modulesRes.data);
    } catch (e) {
      console.error('Failed to refresh course tree:', e);
    }
  };

  // Provide the sidebar with the current course metadata so add-topic works with empty trees.
  const sidebarCourseInfo = course
    ? { courseId: course._id, courseTitle: course.title, courseImage: course.image }
    : null;

  const handleSaveModuleTitle = async newTitle => {
    if (!selectedModuleToEdit) return;

    try {
      const base = process.env.REACT_APP_API_BASE_URL;

      await axios.put(`${base}/api/module/updateTitle`, {
        moduleId: selectedModuleToEdit,
        title: newTitle,
      });

      await handleRefreshCourseTree();
    } catch (err) {
      console.error('Error updating module title:', err);
    }
  };

  const layoutConfig = {
    option0: ['Top', 'Middle', 'Bottom'], // default
    option1: ['Left', 'Middle', 'Right'],
    option2: ['Top', 'Bottom'],
    option3: ['Left', 'Right'],
    option4: ['Left', 'Right', 'CenterBottom'],
  };

  const layoutToOptionMap = {
    'top-center-bottom': 'option0',
    'left-middle-right': 'option1',
    'top-bottom': 'option2',
    'left-right': 'option3',
    'left-right-centerbottom': 'option4',
  };

  const selectedSections = layoutConfig[selectedOption] || [];

  const extractSectionContent = (page, key) => {
    if (!page || !key) return '';
    const type = page[key];
    if (type === 'rich-text') return page[`${key}-rich-text`] || '';
    if (type === 'question') return page[`${key}-questionDescription`] || '';
    if (type === 'media') return page[`${key}-media`] || '';
    return (
      page[`${key}-rich-text`] || page[`${key}-questionDescription`] || page[`${key}-media`] || ''
    );
  };

  const extractQuestionData = (page, key) => {
    if (!page || !key) return null;
    const storedType = page[`${key}-questionType`];
    const questionType = storedType === 'short-answer' ? 'short-answer' : 'multiple-choice';
    const questionText = page[`${key}-questionDescription`] || '';
    const enableBranching = Boolean(page[`${key}-questionBranching`]);
    const storedChoices = Array.isArray(page[`${key}-questionChoices`])
      ? page[`${key}-questionChoices`]
      : [];
    const storedShortAnswer = page[`${key}-questionShortAnswer`] || '';
    const storedCorrectAnswers = Array.isArray(page[`${key}-questionCorrectAnswers`])
      ? page[`${key}-questionCorrectAnswers`]
      : [];

    return {
      questionText,
      questionType,
      enableBranching,
      choices:
        questionType === 'multiple-choice' ? (storedChoices.length ? storedChoices : ['', '']) : [],
      shortAnswer: questionType === 'short-answer' ? storedShortAnswer : '',
      correctAnswers: questionType === 'multiple-choice' ? storedCorrectAnswers : [],
    };
  };

  useEffect(() => {
    const layout = selectedModule?.pages?.[currentPageIndex]?.layout;
    if (!layout) return;
    const inferred = layoutToOptionMap[layout] ?? '';
    setSelectedOption(prev => (prev === inferred ? prev : inferred));
  }, [selectedModule, currentPageIndex]);

  //========Start of JSX return===========
  return (
    <div
      style={{
        marginTop: '3rem',
      }}
    >
      <div style={{ display: 'flex', flexDirection: 'row', width: '100%' }}>
        <DndSidebar
          onDrawerChange={setIsDrawerOpen}
          courseTree={courseTreeData}
          courseInfo={sidebarCourseInfo}
          selectedModuleToEdit={selectedModuleToEdit}
          selectedModuleId={selectedModuleToEdit}
          liveModuleTitle={inputValue}
          onSelectModule={handleSelectModule}
          onRenameTopic={handleRenameTopicFromSidebar}
          onReorder={handleTreeReorder}
          onRefreshCourseTree={handleRefreshCourseTree}
        />

        <Box
          sx={{
            marginLeft: isDrawerOpen ? 'calc(max(25vw, 150px) + 40px)' : '60px', // shrinks back when closed
            transition: 'margin-left 0.3s ease',
            marginTop: '1rem',
            padding: '20px',
            width: '100%',
          }}
        >
          {showModulePlaceholder ? (
            <div
              style={{
                marginTop: '6rem',
                width: '100%',
                textAlign: 'center',
                padding: '60px 20px',
                fontFamily: 'Arial, sans-serif',
                maxWidth: '450px',
                margin: '0 auto',
              }}
            >
              <h1 style={{ fontSize: '50px', color: '#555', marginBottom: '10px' }}>
                NO MODULES SELECTED
              </h1>

              <p style={{ fontSize: '20px', color: '#777', marginBottom: '40px' }}>
                Select a module from the menu, create a new one, or exit.
              </p>
            </div>
          ) : (
            <div
              style={{
                marginTop: '3rem',
              }}
            >
              <div
                style={{
                  top: '5rem',
                  right: '1rem',
                  position: 'absolute',
                  display: 'flex',
                  flexDirection: 'row',
                  alignItems: 'center',
                }}
              >
                Learner View
                <Switch></Switch>
              </div>

              <div
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  marginBottom: '2rem',
                  marginTop: '4rem',
                }}
              >
                <TextField
                  label="Module Title"
                  variant="outlined"
                  value={inputValue}
                  onChange={e => {
                    setValue(e.target.value);
                    debounceSaveModuleTitle(e.target.value);
                  }}
                  sx={{
                    width: '30rem',
                    '& .MuiOutlinedInput-root': {
                      borderRadius: '6px',
                    },
                  }}
                  InputProps={{
                    endAdornment: inputValue && (
                      <InputAdornment position="end">
                        <IconButton onClick={() => setValue('')} edge="end">
                          <ClearIcon />
                        </IconButton>
                      </InputAdornment>
                    ),
                  }}
                />
              </div>
              <div>
                <div>
                  <TextField
                    select
                    label="Page Layout"
                    value={selectedOption}
                    onChange={handleSelect}
                    variant="outlined"
                    sx={{ width: '20rem', borderRadius: '6px', mt: 1 }}
                    SelectProps={{
                      MenuProps: {
                        PaperProps: {
                          sx: {
                            borderRadius: '8px',
                          },
                        },
                      },
                    }}
                  >
                    <MenuItem value="option0">Top / Middle / Bottom</MenuItem>
                    <MenuItem value="option1">Left / Middle / Right</MenuItem>
                    <MenuItem value="option2">Top / Bottom</MenuItem>
                    <MenuItem value="option3">Left / Right</MenuItem>
                    <MenuItem value="option4">Left / Right / Center Bottom</MenuItem>
                  </TextField>
                </div>
                {/* These buttons are just place holders, these will be replaced with the actual buttons that are dependent on the selected page layoutoption */}
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                  <LayoutEditButtons
                    layout={selectedOption}
                    sections={selectedSections}
                    onEditSection={handleEditSection}
                  />
                </div>
              </div>
              <div>
                {/* Pagination component, allow navigation through all pages, update the selected page based on input */}
                {modulePageCount > 0 && (
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      gap: '0.5rem',
                      marginTop: '2rem',
                      flexWrap: 'wrap',
                    }}
                  >
                    <Pagination
                      shape="rounded"
                      style={{
                        alignItems: 'center',
                        display: 'flex',
                        justifyContent: 'center',
                        padding: '10px',
                      }}
                      count={modulePageCount}
                      //We are simply giving the page number.
                      page={selectedPageToEdit}
                      onChange={handlePageChange}
                      renderItem={item => (
                        <PaginationItem
                          spacing={4}
                          sx={{
                            width: '100%',
                            '&.Mui-selected': {
                              backgroundColor: '#6aa57a',
                              color: 'white',
                            },
                            padding: '10px',
                          }}
                          slots={{
                            previous: ArrowBackIosNewIcon,
                            next: ArrowForwardIosIcon,
                          }}
                          {...item}
                        />
                      )}
                    />
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '0.25rem',
                      }}
                    >
                      <Tooltip title="Add page to end">
                        <span>
                          <IconButton sx={{ color: '#6aa57a' }} onClick={handleAppendPage}>
                            <AddCircleOutlineIcon />
                          </IconButton>
                        </span>
                      </Tooltip>
                      <Tooltip title="Insert page at current spot">
                        <span>
                          <IconButton
                            sx={{ color: '#6aa57a' }}
                            onClick={handleInsertPageAtSelection}
                            disabled={modulePageCount === 0}
                          >
                            <AutoAwesomeMotionIcon fontSize="small" />
                          </IconButton>
                        </span>
                      </Tooltip>
                      <Tooltip title="Delete current page">
                        <span>
                          <IconButton
                            color="error"
                            onClick={() => setIsConfirmationOpen(true)}
                            disabled={modulePageCount === 0}
                          >
                            <DeleteOutlineIcon />
                          </IconButton>
                        </span>
                      </Tooltip>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </Box>
      </div>
      {selectedModule && (
        <AdminLessonModal
          open={isLessonModalOpen}
          onClose={handleCloseLessonModal}
          onSave={handleSaveSectionContent}
          onConvertToQuestion={handleConvertLessonSectionToQuestion}
          module={selectedModule}
          pageIndex={currentPageIndex}
          sectionKey={sectionToEdit.optionKey}
          sectionLabel={sectionToEdit.label}
          initialSectionContent={sectionToEdit.initialContent}
          sectionType={sectionToEdit.sectionType}
        />
      )}
      {selectedModule && (
        <AdminQuestionModal
          open={isQuestionModalOpen}
          onClose={handleCloseQuestionModal}
          onConfirm={handleSaveQuestionContent}
          itemName={questionModalContext.label}
          itemType="page section"
          AddModuleButton="Save Question"
          SaveExitButton="Cancel"
          initialQuestionData={questionModalContext.initialData}
          onConvertToLesson={handleConvertQuestionToLesson}
        />
      )}
      <Snackbar
        open={notice.open}
        autoHideDuration={4000}
        onClose={() => setNotice(n => ({ ...n, open: false }))}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}
      >
        <Alert
          onClose={() => setNotice(n => ({ ...n, open: false }))}
          severity={notice.severity}
          sx={{ width: '100%' }}
        >
          {notice.message}
        </Alert>
      </Snackbar>

      <ConfirmationCheck
        open={isConfirmationOpen}
        onConfirm={handleDeleteCurrentPage}
        onClose={() => setIsConfirmationOpen(false)}
        title="Confirm Page Delete"
        message="Are you sure you want to delete this page permanantly?"
      />
    </div>
  );
};

export default AdminModuleEditor;
