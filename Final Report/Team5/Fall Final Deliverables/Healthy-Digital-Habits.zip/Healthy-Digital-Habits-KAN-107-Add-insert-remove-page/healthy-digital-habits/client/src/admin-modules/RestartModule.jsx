import { Button, Card, FormControl, MenuItem, Select, Typography } from '@mui/material';
import React, { useState } from 'react';
import ConfirmationCheck from '../shared/ConfirmationCheck';

const RestartModule = ({
  selectedModuleToRestart,
  setSelectedModuleToRestart,
  modules,
  handleRestartModule,
  users,
  selectedUser,
  setSelectedUser,
}) => {
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);

  const restartModule = async () => {
    setIsConfirmationOpen(false);
    handleRestartModule();
  };

  return (
    <Card
      sx={{
        marginTop: '20px',
        padding: '20px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Typography variant="h6" sx={{ marginBottom: '20px' }}>
        Restart Module
      </Typography>
      <FormControl
        fullWidth
        sx={{
          display: 'flex',
          alignItems: 'center',
        }}
      >
        <Typography variant="body1">Select a User</Typography>
        <Select
          value={selectedUser}
          onChange={e => setSelectedUser(e.target.value)}
          displayEmpty
          sx={{ width: '50%' }}
        >
          {users.map(u => (
            <MenuItem key={u.uname} value={u.uname}>
              {`${u.fname} ${u.lname}`}
            </MenuItem>
          ))}
        </Select>
        <br />
        <Typography variant="body1">Select Module to Restart</Typography>
        <Select
          labelId="module-restat-select-label"
          value={selectedModuleToRestart}
          onChange={e => setSelectedModuleToRestart(e.target.value)}
          style={{ width: '50%' }}
        >
          {modules.map(module => (
            <MenuItem key={module._id} value={module._id}>
              {module.title}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <br />
      <Button variant="contained" color="primary" onClick={() => setIsConfirmationOpen(true)}>
        Restart Module
      </Button>

      <ConfirmationCheck
        open={isConfirmationOpen}
        onConfirm={restartModule}
        onClose={() => setIsConfirmationOpen(false)}
        title="Confirm Module Restart"
        message="Are you sure you want to restart this module?"
      />
    </Card>
  );
};

export default RestartModule;
