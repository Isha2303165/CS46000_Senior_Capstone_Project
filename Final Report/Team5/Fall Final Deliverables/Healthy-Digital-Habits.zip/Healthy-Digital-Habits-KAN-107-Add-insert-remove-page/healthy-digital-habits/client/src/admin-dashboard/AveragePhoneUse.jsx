import { Card, Typography } from '@mui/material';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import axios from 'axios';
import React, { useEffect, useState } from 'react';

const PhoneUse = () => {
  const CardStyle = {
    backgroundColor: '#FFFFFF',
    border: '4px solid #4caf50',
    borderRadius: '15px',
    boxShadow: '0 0 0 10px #FFFFFF',
    padding: '1rem',
    marginBottom: '1rem',
    marginTop: '1rem',
  };
  //{ marginTop: '1rem', backgroundColor: 'wh', borderRadius: '15px' }

  const BoxStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: '50px',
    // border: '4px solid #4caf50', // medium green
    // borderRadius: '12px',
  };

  const titleboxStyle = {
    display: 'flex',
    justifyContent: 'center',
  };

  const titleTextStyle = {
    marginTop: '0px',
    fontFamily: 'Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", sans-serif',
    fontWeight: 775,
    fontSize: '2vw',
    color: 'black',
  };

  const gridItemStyle = {
    backgroundColor: '#a2d6a4ff',
    padding: '5px',
    margin: '1px',
    border: '1px solid white',
    borderRadius: '10px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '3vw',
    fontFamily: 'system-ui',
    fontWeight: '775',
    fontSize: '1.25vw',
    position: 'relative',
    color: 'rgb(0, 14, 36)',
  };

  const [gridData, setGridData] = useState(null);

  // Listen for messages from other tabs
  const reloadChannel = new BroadcastChannel('adminDashboardReload');
  reloadChannel.onmessage = event => {
    // Reload the admin dashboard page if it's open in this tab
    if (event.data === 'reload' && window.location.pathname === '/admin/dashboard') {
      window.location.reload();
    }
  };

  useEffect(() => {
    fetchDataAndUpdateGrid();
  }, [gridData]);

  const fetchDataAndUpdateGrid = async () => {
    try {
      const response = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/dashboard`);
      if (response.data) {
        const rowData = response.data.pop(); // Assuming the last item contains the desired data
        if (rowData && rowData.mood) {
          const focus = rowData.mood.Focus;
          const control = rowData.mood.Control;
          const empowerment = rowData.mood.Empowerment;
          const guilt = rowData.mood.Guilt;

          // Calculating average values for the last 7 days
          const lastSevenDaysData = response.data.slice(-7);
          const averages = calculateAverages(lastSevenDaysData);

          // Calculating overall averages
          const overallAverages = calculateOverallAverages(response.data);

          const updatedGridData = [
            ['', '1 day', 'Past 7 days', 'Total Average'],
            [
              'Focus',
              focus.toFixed(2),
              averages.focusAverage.toFixed(2),
              overallAverages.focusAverage.toFixed(2),
            ],
            [
              'Control',
              control.toFixed(2),
              averages.controlAverage.toFixed(2),
              overallAverages.controlAverage.toFixed(2),
            ],
            [
              'Empowerment',
              empowerment.toFixed(2),
              averages.empowermentAverage.toFixed(2),
              overallAverages.empowermentAverage.toFixed(2),
            ],
            [
              'Guilt',
              guilt.toFixed(2),
              averages.guiltAverage.toFixed(2),
              overallAverages.guiltAverage.toFixed(2),
            ],
          ];
          setGridData(updatedGridData);
        }
      }
    } catch (error) {
      console.error('Error fetching data: ', error);
    }
  };

  const calculateAverages = data => {
    let focusSum = 0;
    let controlSum = 0;
    let empowermentSum = 0;
    let guiltSum = 0;

    data.forEach(entry => {
      focusSum += parseFloat(entry.mood?.Focus || 0);
      controlSum += parseFloat(entry.mood?.Control || 0);
      empowermentSum += parseFloat(entry.mood?.Empowerment || 0);
      guiltSum += parseFloat(entry.mood?.Guilt || 0);
    });

    const focusAverage = focusSum / data.length;
    const controlAverage = controlSum / data.length;
    const empowermentAverage = empowermentSum / data.length;
    const guiltAverage = guiltSum / data.length;

    return {
      focusAverage,
      controlAverage,
      empowermentAverage,
      guiltAverage,
    };
  };

  const calculateOverallAverages = data => {
    const lastThirtyDaysData = data.slice(-30); // Consider only the last 30 days

    let focusSum = 0;
    let controlSum = 0;
    let empowermentSum = 0;
    let guiltSum = 0;

    lastThirtyDaysData.forEach(entry => {
      focusSum += parseFloat(entry.mood?.Focus || 0);
      controlSum += parseFloat(entry.mood?.Control || 0);
      empowermentSum += parseFloat(entry.mood?.Empowerment || 0);
      guiltSum += parseFloat(entry.mood?.Guilt || 0);
    });

    const focusAverage = focusSum / lastThirtyDaysData.length;
    const controlAverage = controlSum / lastThirtyDaysData.length;
    const empowermentAverage = empowermentSum / lastThirtyDaysData.length;
    const guiltAverage = guiltSum / lastThirtyDaysData.length;

    return {
      focusAverage,
      controlAverage,
      empowermentAverage,
      guiltAverage,
    };
  };

  return (
    <Card elevation={2} style={CardStyle}>
      <Box sx={BoxStyle}>
        <Box style={titleboxStyle}>
          <Typography style={titleTextStyle}> Average Phone Use Feelings </Typography>
        </Box>
        <div>
          <Grid
            container
            spacing={0}
            style={{ marginTop: '10px', justifyContent: 'center', alignItems: 'center' }}
          >
            {gridData &&
              gridData.map((rowData, rowIndex) => (
                <Grid container item key={rowIndex} spacing={0} justifyContent={'center'}>
                  {rowData.map((value, colIndex) => (
                    <Grid item key={colIndex} xs={2.6}>
                      <div
                        style={{
                          ...gridItemStyle,
                          backgroundColor:
                            rowIndex === 0 || colIndex === 0
                              ? '#FAF9F6'
                              : value > 4
                                ? value > 8
                                  ? '#90EE90'
                                  : '#F5BF84'
                                : '#F59B84',
                        }}
                      >
                        {value}
                      </div>
                    </Grid>
                  ))}
                </Grid>
              ))}
          </Grid>
        </div>
      </Box>
    </Card>
  );
};

export default PhoneUse;
