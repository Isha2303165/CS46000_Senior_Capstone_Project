import { Button, Card, FormControl, MenuItem, Select, TextField, Typography } from '@mui/material';
import React from 'react';

const AddTopic = ({
  topicTitle,
  setTopicTitle,
  selectedModulesForAdd,
  setSelectedModulesForAdd,
  modules,
  errors,
  handleAddTopic,
}) => {
  return (
    <Card
      sx={{
        marginTop: '20px',
        padding: '20px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Typography variant="h6" sx={{ marginBottom: '20px' }}>
        Add Topic
      </Typography>
      <TextField
        label="Topic Title"
        value={topicTitle}
        onChange={e => setTopicTitle(e.target.value)}
        style={{ width: '100%' }}
      />
      <FormControl
        fullWidth
        sx={{
          display: 'flex',
          alignItems: 'center',
        }}
      >
        <br />
        <Typography variant="body1">Select Modules</Typography>
        <Select
          labelId="modules-select-label"
          multiple
          value={selectedModulesForAdd}
          onChange={e => setSelectedModulesForAdd(e.target.value)}
          style={{ width: '100%' }}
        >
          {modules.map(mod => (
            <MenuItem key={mod._id} value={mod._id}>
              {mod.title}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <br />
      {errors.message && <Typography color="error">{errors.message}</Typography>}
      <Button variant="contained" onClick={handleAddTopic}>
        Add Topic
      </Button>
    </Card>
  );
};

export default AddTopic;
