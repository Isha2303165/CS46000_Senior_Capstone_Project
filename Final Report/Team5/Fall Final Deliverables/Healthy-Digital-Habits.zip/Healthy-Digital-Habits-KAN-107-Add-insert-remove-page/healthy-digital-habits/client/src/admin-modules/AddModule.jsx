import {
  Box,
  Button,
  Card,
  Collapse,
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Modal,
  Select,
  TextField,
  Typography,
} from '@mui/material';
import React, { useState } from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import QuestionComponent from './QuestionComponent';

const AddModule = ({
  courses,
  topics,
  modules,
  pages,
  handlePageChange,
  moduleImage,
  setModuleImage,
  setModuleTitle,
  setModuleDescription,
  setModulePrereqs,
  moduleTitle,
  moduleDescription,
  modulePrereqs,
  selectedModuleToEdit,
  handleRemovePage,
  handleAddPage,
  handleOpen,
  handleClose,
  questionSelectPath,
  handleChange,
  inputPaths,
  handleInputChange,
  setConfirmationMessage,
  setOpenSnackbar,
  handleAddModule,
  handleAddEOMPage,
  errors,
  open,
}) => {
  const [openPages, setOpenPages] = useState([]);

  const handleCollapseToggle = index => {
    setOpenPages(prevOpenPages => {
      const newOpenPages = [...prevOpenPages];
      newOpenPages[index] = !newOpenPages[index];
      return newOpenPages;
    });
  };

  return (
    <Card
      sx={{
        marginTop: '20px',
        padding: '20px',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Typography variant="h6" sx={{ marginBottom: '20px' }}>
        Add Module
      </Typography>
      <TextField
        label="Module Title"
        value={moduleTitle}
        onChange={e => setModuleTitle(e.target.value)}
        disabled={selectedModuleToEdit !== ''}
        style={{ width: '100%' }}
      />
      <br />
      <ReactQuill
        label="Module Description"
        value={moduleDescription}
        onChange={content => setModuleDescription(content)}
        placeholder="Enter the Module Description"
        style={{ width: '100%' }}
      />
      <br />

      <TextField
        label="Module Image"
        value={moduleImage}
        onChange={e => setModuleImage(e.target.value)}
        style={{ width: '100%' }}
      />
      <br />
      <FormControl
        fullWidth
        sx={{
          display: 'flex',
          alignItems: 'center',
        }}
      >
        <Typography variant="body1">Select Prerequisites</Typography>
        <Select
          labelId="topic-edit-select-label"
          multiple
          value={modulePrereqs}
          onChange={e => setModulePrereqs(e.target.value)}
          style={{ width: '100%' }}
        >
          {courses.map(course => (
            <MenuItem key={course.title} value={course.title}>
              Course: {course.title}
            </MenuItem>
          ))}
          {topics.map(topic => (
            <MenuItem key={topic._id} value={topic.title}>
              Topic: {topic.title}
            </MenuItem>
          ))}
          {modules.map(mod => (
            <MenuItem key={mod._id} value={mod._id}>
              Module: {mod.title}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <br />

      <Typography variant="h6">Pages</Typography>
      {pages.map((page, index) => (
        <>
          <br />
          <Button
            variant="outlined"
            onClick={() => handleCollapseToggle(index)}
            sx={{ marginBottom: '1rem' }}
          >
            {openPages[index] ? `Hide Page ${index + 1}` : `Show Page ${index + 1}`}
          </Button>
          <Collapse
            in={openPages[index]}
            sx={{
              width: '100%',
            }}
          >
            <div
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <TextField
                label="Page Title"
                value={page.content}
                onChange={e => handlePageChange(index, 'content', e.target.value)}
                disabled={page.content === 'End of Module Activity'}
                style={{ width: '100%' }}
              />

              <FormControl
                fullWidth
                variant="outlined"
                margin="normal"
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                }}
              >
                <Typography variant="body1">Select a Question to Pipe</Typography>
                <Select
                  labelId="question-select-label"
                  value={page.questiontopipe}
                  onChange={e => handlePageChange(index, 'questiontopipe', e.target.value)}
                  style={{ width: '100%' }}
                >
                  {pages.map((pg, pageIndex) =>
                    ['option1', 'option2', 'option3', 'option4'].map(
                      optionKey =>
                        pg[optionKey] === 'question' && (
                          <MenuItem
                            key={`${pageIndex}-${optionKey}`}
                            value={pg[`${optionKey}-questionDescription`]}
                          >
                            {pg[`${optionKey}-questionDescription`]}
                          </MenuItem>
                        )
                    )
                  )}
                </Select>
              </FormControl>
              <br />
              <ReactQuill
                label={
                  page.content === 'End of Module Activity'
                    ? 'Activity Description'
                    : 'Page Description'
                }
                value={page.pageDescription}
                onChange={content => handlePageChange(index, 'pageDescription', content)}
                placeholder="Enter the Page Description"
                style={{ width: '100%' }}
              />

              {page.content === 'End of Module Activity' && (
                <>
                  <br />
                  {/* Wait Time Input */}
                  <TextField
                    label="Wait Time for EOM Questions (in hours)"
                    value={page.time}
                    onChange={e => handlePageChange(index, 'time', e.target.value)}
                    style={{ width: '100%' }}
                  />

                  <br />

                  {/* Select Number of Questions */}
                  <FormControl
                    fullWidth
                    sx={{
                      display: 'flex',
                      alignItems: 'center',
                    }}
                  >
                    <Typography variant="body1">Select Number of Questions</Typography>
                    <Select
                      labelId="number-select-label"
                      value={page.numberQuestions}
                      onChange={e => handlePageChange(index, 'numberQuestions', e.target.value)}
                      style={{ width: '100%' }}
                    >
                      {[1, 2, 3, 4, 5].map(num => (
                        <MenuItem key={num} value={num}>
                          {num}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>

                  {/* Render Question Type Dropdowns based on numberQuestions */}
                  {Array.from({ length: page.numberQuestions }, (_, qIndex) => (
                    <>
                      <br />
                      <FormControl
                        fullWidth
                        key={qIndex}
                        sx={{
                          display: 'flex',
                          alignItems: 'center',
                        }}
                      >
                        <Typography variant="body1">Question Type {qIndex + 1}</Typography>
                        <Select
                          labelId={`type-label-${qIndex}`}
                          value={page.questions[qIndex]?.type || ''}
                          onChange={e =>
                            handlePageChange(index, 'questionsType', e.target.value, qIndex)
                          }
                          style={{ width: '100%' }}
                        >
                          <MenuItem value="Single">Single Select Multiple Choice</MenuItem>
                          <MenuItem value="Multi">Multi Select Multiple Choice</MenuItem>
                          <MenuItem value="Essay">Short Answer</MenuItem>
                        </Select>
                        {(page.questions[qIndex]?.type === 'Essay' ||
                          page.questions[qIndex]?.type === 'Single' ||
                          page.questions[qIndex]?.type === 'Multi') && (
                          <>
                            <br />
                            <ReactQuill
                              value={page.questions[qIndex].description}
                              onChange={content =>
                                handlePageChange(index, 'questionsDescription', content, qIndex)
                              }
                              placeholder="Enter the Question Description"
                              style={{ width: '100%' }}
                            />
                          </>
                        )}

                        {(page.questions[qIndex]?.type === 'Single' ||
                          page.questions[qIndex]?.type === 'Multi') && (
                          <>
                            <br />
                            <FormControl
                              fullWidth
                              sx={{
                                display: 'flex',
                                alignItems: 'center',
                              }}
                            >
                              <TextField
                                id="number-input"
                                type="number"
                                value={page.questions[qIndex]?.responses}
                                onChange={e =>
                                  handlePageChange(
                                    index,
                                    'questionsResponses',
                                    e.target.value,
                                    qIndex
                                  )
                                }
                                InputProps={{ inputProps: { min: 1, max: 15 } }}
                                label="Number of Responses"
                                style={{ width: '100%' }}
                              />
                            </FormControl>

                            <br />

                            <div>
                              <Grid container justifyContent="center" spacing={2}>
                                {Array.from(
                                  { length: page.questions[qIndex]?.responses },
                                  (_, idx) => (
                                    <Grid
                                      item
                                      xs={12}
                                      key={idx}
                                      display="flex"
                                      justifyContent="center"
                                    >
                                      <TextField
                                        label={`Value ${idx + 1}`}
                                        value={page.questions[qIndex]?.value[idx] || ''}
                                        onChange={e => {
                                          handlePageChange(
                                            index,
                                            'questionsValue',
                                            e.target.value,
                                            qIndex,
                                            idx
                                          );
                                        }}
                                        style={{ width: '100%' }}
                                        fullWidth
                                      />
                                    </Grid>
                                  )
                                )}
                              </Grid>
                            </div>

                            <br />
                            <FormControl
                              fullWidth
                              sx={{
                                display: 'flex',
                                alignItems: 'center',
                              }}
                            >
                              <Typography variant="body1">Orientation</Typography>
                              <Select
                                labelId="orientation-select-label"
                                value={page.questions[qIndex]?.orientation}
                                onChange={e =>
                                  handlePageChange(
                                    index,
                                    'questionsOrientation',
                                    e.target.value,
                                    qIndex
                                  )
                                }
                                style={{ width: '100%' }}
                              >
                                <MenuItem value="vertical">Vertical</MenuItem>
                                <MenuItem value="horizontal">Horizontal</MenuItem>
                              </Select>
                            </FormControl>
                          </>
                        )}
                      </FormControl>
                    </>
                  ))}
                </>
              )}

              {page.content !== 'End of Module Activity' && (
                <>
                  <br />
                  <FormControl
                    fullWidth
                    sx={{
                      display: 'flex',
                      alignItems: 'center',
                    }}
                  >
                    <Typography variant="body1">Screen Layout</Typography>
                    <Select
                      labelId="screen-layout-select-label"
                      value={page.layout}
                      onChange={e => handlePageChange(index, 'layout', e.target.value)}
                      style={{ width: '100%' }}
                    >
                      <MenuItem value="top-bottom">Top / Bottom</MenuItem>
                      <MenuItem value="left-right">Left / Right</MenuItem>
                      <MenuItem value="top-center-bottom">Top / Center / Bottom</MenuItem>
                      <MenuItem value="left-center-right">Left / Center / Right</MenuItem>
                      <MenuItem value="left-right-centerbottom">
                        Left / Right / Center Bottom
                      </MenuItem>
                      <MenuItem value="four-squares">Four Squares</MenuItem>
                    </Select>
                  </FormControl>
                  <br />
                  {page.layout !== '' && (
                    <>
                      <FormControl
                        fullWidth
                        sx={{
                          display: 'flex',
                          alignItems: 'center',
                        }}
                      >
                        <Typography variant="body1">Screen Layout - Option 1</Typography>
                        <Select
                          labelId="option-1-select-label"
                          value={page.option1}
                          onChange={e => handlePageChange(index, 'option1', e.target.value)}
                          style={{ width: '100%' }}
                        >
                          {[
                            <MenuItem key="question" value="question">
                              Question
                            </MenuItem>,
                            <MenuItem key="media" value="media">
                              Media
                            </MenuItem>,
                            <MenuItem key="rich-text" value="rich-text">
                              Rich Text
                            </MenuItem>,
                          ]}
                        </Select>
                      </FormControl>

                      <br />
                      {page.option1 === 'question' && (
                        <Box sx={{ width: '100%' }}>
                          <QuestionComponent
                            page={page}
                            index={index}
                            handlePageChange={handlePageChange}
                            option={'option1'}
                          />
                        </Box>
                      )}

                      <br />
                      {page.option1 === 'media' && (
                        <TextField
                          value={page['option1-media']}
                          label="Media Link"
                          variant="outlined"
                          fullWidth
                          onChange={e => handlePageChange(index, 'option1-media', e.target.value)}
                          style={{ width: '100%' }}
                        />
                      )}

                      {page.option1 === 'rich-text' && (
                        <ReactQuill
                          value={page['option1-rich-text']}
                          onChange={content =>
                            handlePageChange(index, 'option1-rich-text', content)
                          }
                          placeholder="Enter Option 1 Text"
                          style={{ width: '100%' }}
                        />
                      )}
                      <br />
                      <FormControl
                        fullWidth
                        sx={{
                          display: 'flex',
                          alignItems: 'center',
                        }}
                      >
                        <Typography variant="body1">Screen Layout - Option 2</Typography>
                        <Select
                          labelId="option-2-select-label"
                          value={page.option2}
                          onChange={e => handlePageChange(index, 'option2', e.target.value)}
                          style={{ width: '100%' }}
                        >
                          {[
                            <MenuItem key="question" value="question">
                              Question
                            </MenuItem>,
                            <MenuItem key="media" value="media">
                              Media
                            </MenuItem>,
                            <MenuItem key="rich-text" value="rich-text">
                              Rich Text
                            </MenuItem>,
                          ]}
                        </Select>
                      </FormControl>

                      <br />
                      {page.option2 === 'question' && (
                        <Box sx={{ width: '100%' }}>
                          <QuestionComponent
                            page={page}
                            index={index}
                            handlePageChange={handlePageChange}
                            option={'option2'}
                          />
                        </Box>
                      )}

                      <br />
                      {page.option2 === 'media' && (
                        <TextField
                          value={page['option2-media']}
                          label="Media Link"
                          variant="outlined"
                          fullWidth
                          onChange={e => handlePageChange(index, 'option2-media', e.target.value)}
                          style={{ width: '100%' }}
                        />
                      )}

                      {page.option2 === 'rich-text' && (
                        <ReactQuill
                          value={page['option2-rich-text']}
                          onChange={content =>
                            handlePageChange(index, 'option2-rich-text', content)
                          }
                          placeholder="Enter Option 2 Text"
                          style={{ width: '100%' }}
                        />
                      )}

                      {page.layout !== 'left-right' && page.layout !== 'top-bottom' && (
                        <>
                          <FormControl
                            fullWidth
                            sx={{
                              display: 'flex',
                              alignItems: 'center',
                            }}
                          >
                            <Typography variant="body1">Screen Layout - Option 3</Typography>
                            <Select
                              labelId="option-3-select-label"
                              value={page.option3}
                              onChange={e => handlePageChange(index, 'option3', e.target.value)}
                              style={{ width: '100%' }}
                            >
                              {[
                                <MenuItem key="question" value="question">
                                  Question
                                </MenuItem>,
                                <MenuItem key="media" value="media">
                                  Media
                                </MenuItem>,
                                <MenuItem key="rich-text" value="rich-text">
                                  Rich Text
                                </MenuItem>,
                              ]}
                            </Select>
                          </FormControl>
                        </>
                      )}

                      <br />
                      {page.option3 === 'question' && (
                        <Box sx={{ width: '100%' }}>
                          <QuestionComponent
                            page={page}
                            index={index}
                            handlePageChange={handlePageChange}
                            option={'option3'}
                          />
                        </Box>
                      )}

                      <br />
                      {page.option3 === 'media' && (
                        <TextField
                          value={page['option3-media']}
                          label="Media Link"
                          variant="outlined"
                          fullWidth
                          onChange={e => handlePageChange(index, 'option3-media', e.target.value)}
                          style={{ width: '100%' }}
                        />
                      )}

                      {page.option3 === 'rich-text' && (
                        <ReactQuill
                          value={page['option3-rich-text']}
                          onChange={content =>
                            handlePageChange(index, 'option3-rich-text', content)
                          }
                          placeholder="Enter Option 3 Text"
                          style={{ width: '100%' }}
                        />
                      )}

                      {page.layout === 'four-squares' && (
                        <>
                          <FormControl
                            fullWidth
                            sx={{
                              display: 'flex',
                              alignItems: 'center',
                            }}
                          >
                            <Typography variant="body1">Screen Layout - Option 4</Typography>
                            <Select
                              labelId="option-4-select-label"
                              value={page.option4}
                              onChange={e => handlePageChange(index, 'option4', e.target.value)}
                              style={{ width: '100%' }}
                            >
                              {[
                                <MenuItem key="question" value="question">
                                  Question
                                </MenuItem>,
                                <MenuItem key="media" value="media">
                                  Media
                                </MenuItem>,
                                <MenuItem key="rich-text" value="rich-text">
                                  Rich Text
                                </MenuItem>,
                              ]}
                            </Select>
                          </FormControl>
                        </>
                      )}
                    </>
                  )}

                  <br />
                  {page.option4 === 'question' && (
                    <Box sx={{ width: '100%' }}>
                      <QuestionComponent
                        page={page}
                        index={index}
                        handlePageChange={handlePageChange}
                        option={'option4'}
                      />
                    </Box>
                  )}

                  <br />
                  {page.option4 === 'media' && (
                    <TextField
                      value={page['option4-media']}
                      label="Media Link"
                      variant="outlined"
                      fullWidth
                      onChange={e => handlePageChange(index, 'option4-media', e.target.value)}
                      style={{ width: '100%' }}
                    />
                  )}

                  {page.option4 === 'rich-text' && (
                    <ReactQuill
                      value={page['option4-rich-text']}
                      onChange={content => handlePageChange(index, 'option4-rich-text', content)}
                      placeholder="Enter Option 4 Text"
                      style={{ width: '100%' }}
                    />
                  )}
                </>
              )}
              <br />
              <Box sx={{ display: 'flex', gap: 1, justifyContent: 'center', alignItems: 'center' }}>
                <Button variant="contained" onClick={handleAddPage}>
                  Add Page
                </Button>
                {index !== 0 && (
                  <Button variant="outlined" color="error" onClick={() => handleRemovePage(index)}>
                    Remove Page
                  </Button>
                )}
              </Box>
            </div>
          </Collapse>
        </>
      ))}
      <br />
      <Button
        variant="contained"
        onClick={handleAddEOMPage}
        disabled={pages.findIndex(page => page.content === 'End of Module Activity') !== -1}
      >
        Add End of Module Activity
      </Button>
      <br />
      <Button variant="contained" onClick={handleOpen}>
        Page Paths
      </Button>
      <Modal open={open} onClose={handleClose}>
        <Box
          sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: 400,
            bgcolor: 'background.paper',
            boxShadow: 24,
            p: 4,
            borderRadius: 2,
          }}
        >
          <Typography variant="h6" component="h2">
            Design Page Paths
          </Typography>

          <FormControl fullWidth variant="outlined" margin="normal">
            <InputLabel id="question-select-label">Select a Question</InputLabel>
            <Select
              labelId="question-select-label"
              label="Select a Question"
              value={questionSelectPath ? questionSelectPath.desc : ''}
              onChange={e => {
                const selectedDesc = e.target.value;

                const pageIndex = pages.findIndex(pg =>
                  ['option1', 'option2', 'option3', 'option4'].some(
                    optionKey =>
                      pg[optionKey] === 'question' &&
                      pg[`${optionKey}-questionDescription`] === selectedDesc
                  )
                );

                handleChange(selectedDesc, pageIndex);
              }}
            >
              {pages.map((pg, pageIndex) =>
                ['option1', 'option2', 'option3', 'option4'].map(
                  optionKey =>
                    pg[optionKey] === 'question' && (
                      <MenuItem
                        key={`${pageIndex}-${optionKey}`}
                        value={pg[`${optionKey}-questionDescription`]}
                      >
                        {pg[`${optionKey}-questionDescription`]}
                      </MenuItem>
                    )
                )
              )}
            </Select>
          </FormControl>

          {questionSelectPath &&
            Array.from({ length: questionSelectPath.responses }, (_, idx) => (
              <TextField
                key={idx}
                label={`If ${questionSelectPath.values[idx] || ''} is selected, what should the path be?`}
                value={inputPaths[questionSelectPath.desc]?.[questionSelectPath.values[idx]] || ''}
                onChange={e => handleInputChange(idx, e.target.value)}
                style={{ marginBottom: '8px' }}
                fullWidth
              />
            ))}
          <br />

          <Button
            variant="contained"
            onClick={() => {
              setConfirmationMessage('Page Paths Added');
              setOpenSnackbar(true);
              handleClose();
            }}
            sx={{ mt: 3, marginRight: '5px' }}
          >
            Save
          </Button>
        </Box>
      </Modal>

      <br />
      {errors.message && <Typography color="error">{errors.message}</Typography>}
      <Button variant="contained" onClick={handleAddModule} disabled={selectedModuleToEdit !== ''}>
        Add Module
      </Button>
    </Card>
  );
};

export default AddModule;
