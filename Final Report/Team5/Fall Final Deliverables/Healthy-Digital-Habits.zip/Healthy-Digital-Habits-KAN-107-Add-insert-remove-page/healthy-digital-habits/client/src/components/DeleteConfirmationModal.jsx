import React from 'react';
import { Modal, Box, Typography, Button } from '@mui/material';

const DeleteConfirmationModal = ({
  open,
  onClose,
  onConfirm,
  itemName,
  itemType = 'item',
  confirmButtonText = 'Confirm Delete',
  cancelButtonText = 'Cancel',
}) => {
  const handleConfirm = event => {
    event?.stopPropagation();
    onConfirm();
  };

  const handleClose = event => {
    event?.stopPropagation();
    onClose();
  };

  return (
    <Modal open={open} onClose={handleClose}>
      <Box
        sx={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          width: 400,
          bgcolor: 'background.paper',
          boxShadow: 24,
          borderRadius: 2,
          p: 4,
        }}
      >
        <Typography variant="h6" component="h2" sx={{ mb: 2 }}>
          Confirm Deletion
        </Typography>
        <Typography sx={{ mb: 3 }}>
          Are you sure you want to delete{' '}
          <strong style={{ fontWeight: 'bold' }}>
            {itemName ? `${itemName}` : `this ${itemType}`}
          </strong>
          {''}? This action cannot be undone.
        </Typography>
        <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2 }}>
          <Button variant="outlined" onClick={handleClose}>
            {cancelButtonText}
          </Button>
          <Button variant="contained" color="error" onClick={handleConfirm}>
            {confirmButtonText}
          </Button>
        </Box>
      </Box>
    </Modal>
  );
};

export default DeleteConfirmationModal;
