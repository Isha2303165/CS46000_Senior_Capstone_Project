import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import MenuItem from '@mui/material/MenuItem';
import Select from '@mui/material/Select';
import Typography from '@mui/material/Typography';
import { height } from '@mui/system';
import axios from 'axios';
import React, { useEffect, useState } from 'react';

const AverageLogins = () => {
  const [users, setUsers] = useState([]); // Store users
  const [selectedUser, setSelectedUser] = useState(''); // Default selected user
  const [loginCount, setLoginCount] = useState(0); // Login count

  // Fetch all users when component mounts
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const response = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/user/all`);
        setUsers(response.data);
      } catch (err) {
        console.error('Error fetching users:', err);
      }
    };
    fetchUsers();
  }, []); // Run only once on mount

  // Handle change for user selection
  const handleChange = async event => {
    try {
      setSelectedUser(event.target.value);
      const response = await axios.get(
        `${process.env.REACT_APP_API_BASE_URL}/api/user/loginsSum?uname=${event.target.value}`
      );
      setLoginCount(response.data.count || 0);
    } catch (err) {
      console.error('Error fetching login count:', err);
      setLoginCount(0); // Reset login count on error
    }
  };

  const BoxStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'center',
    fontFamily: 'Helvetica, sans-serif',
    fontWeight: '775',
    fontSize: '30px',
    color: 'white',
    border: '4px solid #4caf50', // medium green
    borderRadius: '12px', // rounded corners look smoother
    padding: '1rem',
  };

  const titleboxStyle = {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  };

  const titleTextStyle = {
    marginTop: '0px',
    fontFamily: 'system-ui',
    fontWeight: '775',
    fontSize: '1.5vw',
    color: 'black',
  };

  const textboxStyle = {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  };

  const numBoxStyle = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    margin: '20px',
  };

  return (
    <Card
      elevation={2}
      sx={{
        padding: '10px',
        width: '20vw',
        height: 'inherit',
        backgroundColor: '#FFFFFF',
        borderRadius: '15px',
      }}
    >
      <Box sx={BoxStyle} style={{ display: 'flex', flexDirection: 'column' }}>
        <Box style={titleboxStyle}>
          <Typography style={titleTextStyle}>User Logins</Typography>
        </Box>

        {/* Dropdown for selecting user */}
        <Select
          value={selectedUser}
          onChange={handleChange}
          style={{
            marginTop: '10px',
            color: 'rgb(0, 14, 36)',
            width: '10vw',
            height: '45px',
            backgroundColor: 'white',
            fontFamily: 'system-ui',
            borderRadius: '5px',
            border: '2px solid #000000',
          }}
        >
          {/* Dynamically render users */}
          {users.map(user => (
            <MenuItem key={user.uname} value={user.uname}>
              {user.uname}
            </MenuItem>
          ))}
        </Select>

        <div style={numBoxStyle}>
          {/* Display login count */}
          <Typography
            style={{
              fontSize: '2vw',
              color: 'rgb(0, 14, 36)',
              fontFamily: 'system-ui',
              fontWeight: '775',
              textAlign: 'center',
            }}
          >
            {loginCount}
          </Typography>
          <Typography
            style={{
              fontSize: '1vw',
              color: 'rgb(0, 14, 36)',
              fontFamily: 'system-ui',
              fontWeight: '775',
            }}
          >
            Logins
          </Typography>
        </div>
      </Box>
    </Card>
  );
};

export default AverageLogins;
