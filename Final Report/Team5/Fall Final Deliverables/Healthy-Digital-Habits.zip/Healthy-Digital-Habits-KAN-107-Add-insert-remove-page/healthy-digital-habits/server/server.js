const path = require('path');
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
// have to clarify this since we are running from root, not from server folder
require('dotenv').config({
  path: path.join(__dirname, '.env'),
});

const app = express();

//CLIENT_ORIGIN would be something like azure app url
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || 'http://localhost:3000';

//This is only needed when running in dev. In production, the React app is served statically.
if (process.env.NODE_ENV !== 'production') {
  app.use(
    cors({
      origin: CLIENT_ORIGIN,
      methods: ['GET', 'POST', 'PUT', 'DELETE'],
      allowedHeaders: ['Content-Type', 'Authorization'],
      credentials: true,
    })
  );
}

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// db connection start
const db = require('./src/models');
db.mongoose
  .connect(db.url, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log('Database connection successful.');
  })
  .catch(err => {
    console.log('Database connection error: ', err);
    process.exit();
  });

// API routes
require('./src/routes/routes')(app);

//Changed this to a specific health route because the react router needs to handle root path
app.get('/api/health', (req, res) => {
  res.json({ message: 'Connected to HDH db' });
});

if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../client/build')));

  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../client/build', 'index.html'));
  });
}

const PORT = process.env.SERVER_PORT || 5000;

// server start
app.listen(PORT, () => {
  console.log(`Server on ${PORT}`);
});

module.exports = app;
