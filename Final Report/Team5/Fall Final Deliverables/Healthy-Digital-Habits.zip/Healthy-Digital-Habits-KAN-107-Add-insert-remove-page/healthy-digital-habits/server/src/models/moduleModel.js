/** Module model */
module.exports = mongoose => {
  const moduleModel = mongoose.model(
    'module',
    mongoose.Schema(
      {
        pages: [],
        title: String,
        description: String,
        image: String,
        prereqs: Array,
        incompleted: Array,
        completed: Array,
        pagePaths: Object,
        progress: Array,
      },
      { timestamps: true }
    )
  );

  return moduleModel;
};
