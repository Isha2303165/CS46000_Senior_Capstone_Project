const db = require('../models');
const moduleModel = db.modules;
const topicsModel = db.topics;
const mongoose = require('mongoose');

//CREATE
exports.create = (req, res) => {
  // Check if the request body is valid

  if (
    !req.body ||
    !req.body.title ||
    !req.body.description ||
    !req.body.image ||
    !req.body.pages ||
    !Array.isArray(req.body.pages)
  ) {
    return res.status(400).send({
      message:
        'Invalid request body format. Ensure title, description, image, and pages are provided correctly.',
    });
  }

  const pages = req.body.pages;
  if (pages.length > 0 && pages[pages.length - 1].content === 'End of Module Activity') {
    pages[pages.length - 1].layout = 'top-center-bottom';
    const newPage = {
      content: 'End of Module Activity Questions',
      pageDescription: '',
      questionDescription: '',
      type: '',
      value: '',
      media: '',
      layout: 'top-center-bottom',
      questions: pages[pages.length - 1].questions,
    };
    pages.push(newPage);
  }

  // Create a new module
  const newModule = new moduleModel({
    title: req.body.title,
    description: req.body.description,
    image: req.body.image,
    prereqs: req.body.prereqs,
    pages: pages,
    pagePaths: req.body.pagePaths,
  });

  // Save the module
  newModule
    .save()
    .then(moduleData => {
      res.status(200).send({
        message: 'Module added successfully',
        module: moduleData,
      });
    })
    .catch(err => {
      // Handle errors
      console.error('Error:', err); // Log the error for debugging
      res.status(500).send({
        message: err.message || 'Some error occurred while processing the request.',
      });
    });
};
exports.updateTitle = async (req, res) => {
  const { moduleId, title } = req.body;

  console.log('Incoming moduleId:', moduleId);
  console.log('Incoming title:', title);
  if (!moduleId || !title) {
    return res.status(400).send({
      message: 'moduleId and title are required.',
    });
  }

  if (!mongoose.Types.ObjectId.isValid(moduleId)) {
    return res.status(400).send({ message: 'Invalid moduleId format.' });
  }

  try {
    const updated = await moduleModel.findByIdAndUpdate(moduleId, { title }, { new: true });

    if (!updated) {
      return res.status(404).send({
        message: `Module with id "${moduleId}" not found.`,
      });
    }

    res.send({
      message: 'Module title updated successfully.',
      module: updated,
    });
  } catch (err) {
    console.error('Error updating title:', err);
    res.status(500).send({
      message: 'Internal server error updating module title.',
      error: err.message,
    });
  }
};

exports.updateModule = (req, res) => {
  // Check if the request body is valid
  if (
    !req.body ||
    !req.body.title ||
    !req.body.description ||
    !req.body.image ||
    !req.body.pages ||
    !Array.isArray(req.body.pages)
  ) {
    return res.status(400).send({
      message:
        'Invalid request body format. Ensure title, description, image, and pages are provided correctly.',
    });
  }

  const pages = req.body.pages;

  if (pages.length > 2 && pages[pages.length - 2].content === 'End of Module Activity') {
    pages[pages.length - 1].questions = pages[pages.length - 2].questions;
  }

  if (pages.length > 1 && pages[pages.length - 1].content === 'End of Module Activity') {
    pages[pages.length - 1].layout = 'top-center-bottom';
    const newPage = {
      content: 'End of Module Activity Questions',
      pageDescription: '',
      questionDescription: '',
      type: '',
      value: '',
      media: '',
      layout: 'top-center-bottom',
      questions: pages[pages.length - 1].questions,
    };
    pages.push(newPage);
  }

  // Build update object dynamically
  let updateFields = {
    description: req.body.description,
    image: req.body.image,
    prereqs: req.body.prereqs,
    pages: pages,
    pagePaths: req.body.pagePaths,
  };

  // Update title if newName is provided
  if (req.body.newName) {
    updateFields.title = req.body.newName;
  }

  // Find the module by its current title and update it
  moduleModel
    .findOneAndUpdate(
      { title: req.body.title }, // Find by current title
      { $set: updateFields }, // Apply updates
      { new: true } // Return the updated document
    )
    .then(updatedModule => {
      if (!updatedModule) {
        return res.status(404).send({
          message: `Module with title "${req.body.title}" not found.`,
        });
      }
      res.status(200).send({
        message: 'Module updated successfully',
        module: updatedModule,
      });
    })
    .catch(err => {
      console.error('Error:', err); // Log error for debugging
      res.status(500).send({
        message: err.message || 'Some error occurred while processing the request.',
      });
    });
};

//FIND ALL
exports.findAll = (req, res) => {
  //removed username to find all users
  //const username = req.query.username;

  //can be .find(username) to find with only that parameter
  moduleModel
    .find()
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.send(null);
    });
};

exports.findModule = (req, res) => {
  const id = req.params.id;
  moduleModel
    .findById(id)
    .then(data => {
      if (data) {
        res.send(data);
      } else {
        res.status(404).send({ message: 'Cannot find with oid credentials' });
      }
    })
    .catch(err => {
      res.status(500).send({ message: 'Error retrieving oid ' + id });
    });
};

exports.findActivity = (req, res) => {
  const id = req.query.id;
  const curpage = parseInt(req.query.curpage) - 1;

  moduleModel
    .findById(id)
    .then(data => {
      if (data) {
        if (data.pages[curpage].type === 'empty') {
          res.send('No Activity');
        } else {
          res.send(data.pages[curpage].questiondescription);
        }
      } else {
        res.status(404).send({ message: 'Cannot find data with the given id' });
      }
    })
    .catch(err => {
      // Log the error to debug further if necessary
      console.error('Error:', err);
      res.status(500).send({ message: 'Error retrieving data for id ' + id });
    });
};

exports.getModuleLength = (req, res) => {
  const id = req.query.id;

  moduleModel
    .findById(id)
    .then(data => {
      if (data) {
        res.send(data.pages.length.toString());
      } else {
        res.status(404).send({ message: 'Cannot find data with the given id' });
      }
    })
    .catch(err => {
      // Log the error to debug further if necessary
      console.error('Error:', err);
      res.status(500).send({ message: 'Error retrieving data for id ' + id });
    });
};

exports.getModuleTitle = (req, res) => {
  const id = req.query.id;

  moduleModel
    .findById(id)
    .then(data => {
      if (data) {
        res.send(data.title.toString());
      } else {
        res.status(404).send({ message: 'Cannot find data with the given id' });
      }
    })
    .catch(err => {
      // Log the error to debug further if necessary
      console.error('Error:', err);
      res.status(500).send({ message: 'Error retrieving data for id ' + id });
    });
};

exports.getIncompleteModule = (req, res) => {
  const id = req.query.id;

  moduleModel
    .findById(id)
    .then(data => {
      if (data) {
        res.send(data.incompleted.length.toString());
      } else {
        res.status(404).send({ message: 'Cannot find data with the given id' });
      }
    })
    .catch(err => {
      // Log the error to debug further if necessary
      console.error('Error:', err);
      res.status(500).send({ message: 'Error retrieving data for id ' + id });
    });
};

exports.getCompleteModule = (req, res) => {
  const id = req.query.id;

  moduleModel
    .findById(id)
    .then(data => {
      if (data) {
        res.send(data.completed.length.toString());
      } else {
        res.status(404).send({ message: 'Cannot find data with the given id' });
      }
    })
    .catch(err => {
      // Log the error to debug further if necessary
      console.error('Error:', err);
      res.status(500).send({ message: 'Error retrieving data for id ' + id });
    });
};

exports.incompleteModule = (req, res) => {
  const id = req.query.id;
  const uname = req.query.uname;

  moduleModel
    .findById(id)
    .then(data => {
      if (data) {
        if (!data.incompleted.includes(uname)) {
          if (data.completed.includes(uname)) {
            data.completed.pull(uname);
          }
          data.incompleted.push(uname);

          data
            .save()
            .then(() => {
              res.status(200).send({ message: 'Uname added to incompleted array' });
            })
            .catch(saveErr => {
              console.error('Error saving data:', saveErr);
              res.status(500).send({ message: 'Error saving data' });
            });
        } else {
          res.status(400).send({ message: 'Uname is already in the incompleted array' });
        }
      } else {
        res.status(404).send({ message: 'Cannot find data with the given id' });
      }
    })
    .catch(err => {
      console.error('Error:', err);
      res.status(500).send({ message: 'Error retrieving data for id ' + id });
    });
};

exports.getCompletedModule = (req, res) => {
  const id = req.query.id;
  const uname = req.query.uname;

  moduleModel
    .findById(id)
    .then(data => {
      if (data) {
        if (data.completed.includes(uname)) {
          res.status(200).send({ message: 'Completed' });
        } else {
          res.status(200).send({ message: 'Not Completed' });
        }
      } else {
        res.status(404).send({ message: 'Cannot find data with the given id' });
      }
    })
    .catch(err => {
      console.error('Error:', err);
      res.status(500).send({ message: 'Error retrieving data for id ' + id });
    });
};

exports.completeModule = (req, res) => {
  const id = req.query.id;
  const uname = req.query.uname;

  moduleModel
    .findById(id)
    .then(data => {
      if (data) {
        if (!data.completed.includes(uname)) {
          data.incompleted.pull(uname);
          data.completed.push(uname);

          data
            .save()
            .then(() => {
              res.status(200).send({ message: 'Uname added to completed array' });
            })
            .catch(saveErr => {
              console.error('Error saving data:', saveErr);
              res.status(500).send({ message: 'Error saving data' });
            });
        } else {
          res.status(400).send({ message: 'Uname is already in the completed array' });
        }
      } else {
        res.status(404).send({ message: 'Cannot find data with the given id' });
      }
    })
    .catch(err => {
      console.error('Error:', err);
      res.status(500).send({ message: 'Error retrieving data for id ' + id });
    });
};

//FIND ONE
exports.findOne = (req, res) => {
  const id = req.params.moduleId;
  console.log('id: ', id);

  moduleModel
    .findById(id)
    .then(data => {
      if (!data) {
        res.status(404).send({ message: 'Cannot find with oid credentials' });
      } else {
        res.send(data);
      }
    })
    .catch(err => {
      res.status(500).send({ message: 'Error retrieving oid ' + id });
    });
};

exports.getProgress = async (req, res) => {
  const { moduleId, userId } = req.params;

  if (!moduleId || !userId) {
    return res.status(400).send({
      message: 'Module ID and User ID are required.',
    });
  }

  try {
    const moduleData = await moduleModel.findById(moduleId);

    if (!moduleData) {
      return res.status(404).send({ message: `Module with id: ${moduleId} not found.` });
    }

    // Find progress for the specific user
    const userProgress = moduleData.progress.find(p => p.userId === userId);

    if (!userProgress) {
      return res.status(200).send({
        userId,
        currentPage: 0,
        progressPercentage: 0,
        exists: false,
        message: `No progress found for user ${userId} in module ${moduleId}.`,
      });
    }

    res.send({
      userId: userProgress.userId,
      currentPage: userProgress.currentPage,
      progressPercentage: userProgress.progressPercentage,
      exists: true,
    });
  } catch (err) {
    res.status(500).send({
      message: `Error retrieving progress for user ${userId} in module ${moduleId}`,
      error: err.message,
    });
  }
};

//UPDATE
exports.update = (req, res) => {
  if (!req.body) {
    return res.status(400).send({
      message: "Update data can't be empty.",
    });
  }

  const id = req.params.id;

  moduleModel
    .findByIdAndUpdate(id, req.body, { new: true })
    .then(data => {
      if (!data) {
        res.status(404).send({
          message: `Module with id: ${id} not found.`,
        });
      } else {
        res.send({ message: 'Update successful.', module: data });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: 'Error updating module, id: ' + id,
        error: err.message,
      });
    });
};

exports.updateProgress = async (req, res) => {
  if (
    !req.body ||
    !req.body.userId ||
    !req.body.currentPage ||
    req.body.progressPercentage === undefined
  ) {
    return res.status(400).send({
      message: 'Update data is incomplete.',
    });
  }

  const id = req.params.id;
  const { userId, currentPage, progressPercentage } = req.body;

  try {
    const moduleData = await moduleModel.findById(id);
    if (!moduleData) {
      return res.status(404).send({ message: `Module with id: ${id} not found.` });
    }

    // Check if progress for userId already exists
    const existingProgressIndex = moduleData.progress.findIndex(p => p.userId === userId);

    if (existingProgressIndex !== -1) {
      // Update the existing progress entry
      moduleData.progress[existingProgressIndex] = { userId, currentPage, progressPercentage };
    } else {
      // Add new progress entry
      moduleData.progress.push({ userId, currentPage, progressPercentage });
    }

    await moduleData.save();
    res.send({ message: 'Progress updated successfully.', data: moduleData });
  } catch (err) {
    res.status(500).send({
      message: `Error updating progress for module id: ${id}`,
      error: err.message,
    });
  }
};

//DELETE
exports.delete = (req, res) => {
  const id = req.query.id;

  moduleModel
    .findByIdAndDelete(id)
    .then(data => {
      if (!data) {
        // If no document is found, send a 404 error
        return res.status(404).send({
          message: `Cannot delete module with id: ${id}. No such module found.`,
        });
      }

      // If the document is found and deleted, send a success response
      res.send({
        message: 'Module deleted successfully.',
      });
    })
    .catch(err => {
      // Log the error for debugging purposes
      console.error('Error deleting module:', err);

      // Send a 500 error response with a generic message
      res.status(500).send({
        message: 'Unable to delete module. Please try again later.',
      });
    });
};
