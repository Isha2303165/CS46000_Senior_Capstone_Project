/** User entry model */
module.exports = mongoose => {
  const entryModel = mongoose.model(
    'entry',
    mongoose.Schema(
      {
        mood: {
          Focus: Number,
          Control: Number,
          Empowerment: Number,
          Guilt: Number,
        },
        ability: Number,
        story: String,
        uname: String,
      },
      { timestamps: true }
    )
  );

  return entryModel;
};
