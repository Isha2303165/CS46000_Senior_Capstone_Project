const User = require('../models/userModel');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

//this is for user authentication, but isn't being implemented anywhere yet
// jwt and bcrypt

const handleLogin = async (req, res) => {
  const { uname, upass } = req.body;
  if (!uname || !upass) return res.status(400).json({ message: 'Username+Password required.' });

  const foundUser = await User.findOne({ uname: uname }).exec();

  if (!foundUser) return res.sendStatus(401);

  const match = await bcrypt.compare(upass, foundUser.upass);
  if (match) {
    const roles = Object.values(foundUser.roles).filter(Boolean);

    const accessToken = jwt.sign(
      {
        userInfo: {
          username: foundUser.uname,
          roles: roles,
        },
      },
      process.env.ACCESS_TOKEN_SECRET,
      { expiresIn: '30s' }
    );

    const refreshToken = jwt.sign({ username: foundUser.uname }, process.env.REFRESH_TOKEN_SECRET, {
      expiresIn: '1d',
    });

    foundUser.refreshToken = refreshToken;
    const result = await foundUser.save();
    console.log(result);
    console.log(roles);

    res.cookie('jwt', refreshToken, {
      httpOnly: true,
      secure: true,
      sameSite: 'None',
      maxAge: 24 * 60 * 60 * 1000,
    });

    res.json({ roles, accessToken });
  } else {
    res.sendStatus(401);
  }
};

module.exports = { handleLogin };
