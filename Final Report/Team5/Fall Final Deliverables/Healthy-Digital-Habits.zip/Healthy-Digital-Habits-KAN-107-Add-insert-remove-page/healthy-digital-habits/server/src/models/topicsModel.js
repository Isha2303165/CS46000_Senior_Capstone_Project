module.exports = mongoose => {
  const topicsModel = mongoose.model(
    'topics',
    mongoose.Schema(
      {
        title: String,
        modules: Array,
      },
      { timestamps: true }
    )
  );

  return topicsModel;
};
