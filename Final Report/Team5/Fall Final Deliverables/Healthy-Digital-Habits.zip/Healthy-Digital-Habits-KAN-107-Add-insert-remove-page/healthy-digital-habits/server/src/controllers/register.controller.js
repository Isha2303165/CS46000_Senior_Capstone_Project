const usersDB = {
  users: require('../models/userModel'),
  setUsers: function (data) {
    this.users = data;
  },
};

const path = require('path');
const bcrypt = require('bcrypt');

const handleNewUser = async (req, res) => {
  const { user, pass } = req.body;

  if (!user || !pass) return res.status(400).json({ message: 'Username/Password required.' });

  // check for shared usernames

  const duplicate = usersDB.users.find(person => person.username == user);
  if (duplicate) return res.sendStatus(409);

  try {
    // password encryption
    // hash ([password string], [salt rounds])
    const hashedPass = await bcrypt.hash(pass, 10);

    // save new user
    const newUser = { username: user, password: hashedPass };
    usersDB.setUsers([...usersDB.users, newUser]);
  } catch (err) {
    res.send(500).json({ message: err.message });
  }
};

module.exports = { handleNewUser };
