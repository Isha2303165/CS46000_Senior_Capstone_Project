const db = require('../models');
const userModel = db.users;
const moduleModel = db.modules;

const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

//CREATE
exports.create = async (req, res) => {
  const { uname, upass } = req.body;

  if (!uname || !upass) return res.status(400).json({ message: 'Username/Password required.' });

  //check for duplicate usernames
  const duplicateCheck = await userModel
    .findOne({ uname: { $regex: new RegExp(`^${uname}$`, 'i') } })
    .exec();

  if (duplicateCheck) return res.sendStatus(409); //409: cannot be completed due to conflict

  try {
    //password encrypt
    const hashedPass = await bcrypt.hash(upass, 10); //.hash(<password string>, <salt rounds>)

    const newUser = new userModel({
      uname: req.body.uname,
      upass: hashedPass,
      email: req.body.email,
      fname: req.body.fname,
      lname: req.body.lname,
      ph: req.body.ph,
      secq: req.body.secq,
      seca: req.body.seca,
      type: req.body.type,
      module: {
        module: '',
        curpage: 1,
        curprogress: 0,
      },
    });

    newUser
      .save(newUser)
      .then(data => {
        res.send(data);
      })
      .catch(err => {
        res.status(500).send({
          message: err.message || 'Error when creating new entry.',
        });
      });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

//FIND ALL
exports.findAllUsers = (req, res) => {
  userModel
    .find()
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error when fetching.',
      });
    });
};

//FIND ALL
exports.findUser = (req, res) => {
  const uname = req.query.uname;

  userModel
    .find({ uname: uname })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error when fetching.',
      });
    });
};

// Find user's module to string
exports.moduleToString = (req, res) => {
  const uname = req.query.uname;

  userModel
    .findOne({ uname: uname })
    .then(user => {
      if (user && user.module && user.module.module) {
        const moduleId = user.module.module;
        moduleModel
          .findById(moduleId)
          .then(moduleData => {
            if (moduleData) {
              res.send(moduleData.title);
            } else {
              res.status(404).send({ message: 'Module not found with provided ID' });
            }
          })
          .catch(err => {
            res.status(500).send({ message: 'Error retrieving module with ID ' + moduleId });
          });
      } else {
        res.send('No Module');
      }
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error occurred while fetching user data',
      });
    });
};

exports.moduleToId = (req, res) => {
  const uname = req.query.uname;

  userModel
    .findOne({ uname: uname })
    .then(user => {
      if (user && user.module && user.module.module) {
        const moduleId = user.module.module;
        res.send(moduleId);
      } else {
        res.send('No Module');
      }
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error occurred while fetching user data',
      });
    });
};

exports.getCurrentPage = (req, res) => {
  const uname = req.query.uname;

  userModel
    .findOne({ uname: uname })
    .then(user => {
      res.send(user.module.curpage.toString());
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error occurred while fetching user data',
      });
    });
};

exports.getCurrentProgress = (req, res) => {
  const uname = req.query.uname;

  userModel
    .findOne({ uname: uname })
    .then(user => {
      res.send(user.module.curprogress.toString());
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error occurred while fetching user data',
      });
    });
};

//LOGIN
exports.login = async (req, res) => {
  const uname = req.query.uname;
  const upass = req.query.upass;

  try {
    const data = await userModel.findOne({
      uname: { $regex: new RegExp(`^${uname}$`, 'i') }, // Case-insensitive search
    });

    // Check if no user found
    if (!data) {
      return res.status(404).send({ message: 'Cannot find user' });
    }

    // Compare the plain-text password with the hashed password in the database
    const isMatch = await bcrypt.compare(upass, data.upass);

    if (isMatch) {
      // Generate a JWT token if the password matches
      const token = jwt.sign(
        { id: data._id, uname: data.uname, type: data.type, module: data.module.module }, // Payload
        process.env.JWT_SECRET,
        { expiresIn: '1h' }
      );

      // Return the token in the response
      return res.status(200).send({
        message: 'Password matches',
        token: token,
      });
    } else {
      return res.status(400).send({ message: 'Password does not match' });
    }
  } catch (err) {
    // Error handling
    res.status(500).send({ error: err });
  }
};

//FIND ONE
exports.findOne = (req, res) => {
  const id = req.params.id;

  userModel
    .findById(id)
    .then(data => {
      if (!data) {
        res.status(404).send({ message: 'Cannot find with oid credentials' });
      } else {
        res.send(data);
      }
    })
    .catch(err => {
      res.status(500).send({ message: 'Error retrieving oid ' + id });
    });
};

exports.makeAdmin = (req, res) => {
  if (!req.body || !req.body.users || req.body.users.length === 0) {
    return res.status(400).send({
      message: 'No users provided to update.',
    });
  }

  const users = req.body.users; // Array of usernames to update

  // Update all users where uname is in the list of users, setting their type to 'admin'
  userModel
    .updateMany(
      { uname: { $in: users } }, // Find users whose uname is in the list
      { $set: { type: 'admin' } }, // Set type to 'admin'
      { new: true, useFindAndModify: false }
    )
    .then(result => {
      if (result.nModified === 0) {
        return res.status(404).send({
          message: 'No users were updated. Check if the usernames exist.',
        });
      }
      res.send({ message: `Users have been updated to admin.` });
    })
    .catch(err => {
      res.status(500).send({
        message: 'Error updating users.',
        error: err.message,
      });
    });
};

exports.makeParent = (req, res) => {
  if (!req.body || !req.body.users || req.body.users.length === 0) {
    return res.status(400).send({
      message: 'No users provided to update.',
    });
  }

  const users = req.body.users; // Array of usernames to update

  // Update all users where uname is in the list of users, setting their type to 'parent'
  userModel
    .updateMany(
      { uname: { $in: users } }, // Find users whose uname is in the list
      { $set: { type: 'parent' } }, // Set type to 'parent'
      { new: true, useFindAndModify: false }
    )
    .then(result => {
      if (result.nModified === 0) {
        return res.status(404).send({
          message: 'No users were updated. Check if the usernames exist.',
        });
      }
      res.send({ message: `Users have been updated to parent.` });
    })
    .catch(err => {
      res.status(500).send({
        message: 'Error updating users.',
        error: err.message,
      });
    });
};

//UPDATE
exports.update = (req, res) => {
  if (!req.body) {
    return res.status(400).send({
      message: "Update data can't be empty.",
    });
  }

  const { uname, fname, lname, email, ph, type, newUname } = req.body; // Destructure uname and other fields from req.body

  // Ensure uname is provided for the update
  if (!uname) {
    return res.status(400).send({
      message: 'Username (uname) is required for the update.',
    });
  }

  // Find and update the user by uname
  userModel
    .findOneAndUpdate(
      { uname: uname },
      { fname, lname, email, ph, type, uname: newUname },
      { new: true, useFindAndModify: false }
    ) // Use new: true to return the updated document
    .then(data => {
      if (!data) {
        return res.status(404).send({
          message: `User with username: ${uname} not found.`,
        });
      }
      res.send({ message: 'Update successful.', user: data });
    })
    .catch(err => {
      res.status(500).send({
        message: 'Error updating user with username: ' + uname,
        error: err.message, // Include the error message for debugging
      });
    });
};

exports.updateUsername = (req, res) => {
  const oldUname = req.query.oldUname;
  const newUname = req.query.newUname;

  // Check if oldUname and newUname are provided
  if (!oldUname || !newUname) {
    return res.status(400).send({
      message: 'Both old and new usernames must be provided.',
    });
  }

  // First, check if the new username already exists
  userModel
    .findOne({ uname: newUname })
    .then(existingUser => {
      if (existingUser) {
        return res.status(400).send({
          message: `Username is already taken`,
        });
      }

      // If new username is available, proceed with the update
      return userModel.findOneAndUpdate(
        { uname: oldUname }, // Filter to find the user by old uname
        { uname: newUname }, // Update to new uname
        { new: true, useFindAndModify: false } // Options: return updated document
      );
    })
    .then(data => {
      if (!data) {
        return res.status(404).send({
          message: `User with username: ${oldUname} not found.`,
        });
      }
    })
    .catch(err => {
      console.log(err);
    });
};

exports.updatePassword = async (req, res) => {
  const uname = req.query.uname;
  const password = req.query.password;

  // Check if username and password are provided
  if (!uname || !password) {
    return res.status(400).send({
      message: 'Both username and password must be provided.',
    });
  }

  try {
    // Hash the new password
    const hashedPass = await bcrypt.hash(password, 10);

    // Update the user's password in the database
    const updatedUser = await userModel.findOneAndUpdate(
      { uname: uname }, // Filter to find the user by username
      { upass: hashedPass }, // Update the password
      { new: true, useFindAndModify: false } // Options: return updated document
    );

    // Check if the user was found and updated
    if (!updatedUser) {
      return res.status(404).send({
        message: `User with username: ${uname} not found.`,
      });
    }

    // Respond with a success message
    res.send({ message: 'Password updated successfully.' });
  } catch (err) {
    // Handle errors that occur during the update process
    console.error(err); // Log the error for debugging
    res.status(500).send({
      message: 'Error updating password for username: ' + uname,
      error: err.message, // Include the error message for debugging
    });
  }
};

exports.updateModule = (req, res) => {
  if (!req.body) {
    return res.status(400).send({
      message: "Update data can't be empty.",
    });
  }

  const { uname, module, id, type } = req.body;

  // Ensure uname is provided for the update
  if (!uname) {
    return res.status(400).send({
      message: 'Username (uname) and token is required for the update.',
    });
  }

  // Find and update the user's module.curpage by uname
  userModel
    .findOneAndUpdate(
      { uname: uname },
      { $set: { 'module.module': module } }, // Use $set to update only module.curpage
      { new: true, useFindAndModify: false } // Return the updated document
    )
    .then(data => {
      if (!data) {
        return res.status(404).send({
          message: `User with username: ${uname} not found.`,
        });
      }
      const tokenPayload = {
        id: id,
        uname: data.uname,
        module: data.module.module,
        type: type,
      };

      // Replace 'YOUR_SECRET_KEY' with your actual secret key used for signing tokens
      const newToken = jwt.sign(tokenPayload, process.env.JWT_SECRET, { expiresIn: '1h' });
      res.send({ message: 'Update successful.', token: newToken, user: data });
    })
    .catch(err => {
      res.status(500).send({
        message: 'Error updating user with username: ' + uname,
        error: err.message, // Include the error message for debugging
      });
    });
};

exports.updateCurrentPage = (req, res) => {
  if (!req.body) {
    return res.status(400).send({
      message: "Update data can't be empty.",
    });
  }

  const { uname, curpage } = req.body;

  // Ensure uname is provided for the update
  if (!uname) {
    return res.status(400).send({
      message: 'Username (uname) is required for the update.',
    });
  }

  // Find and update the user's module.curpage by uname
  userModel
    .findOneAndUpdate(
      { uname: uname },
      { $set: { 'module.curpage': curpage } }, // Use $set to update only module.curpage
      { new: true, useFindAndModify: false } // Return the updated document
    )
    .then(data => {
      if (!data) {
        return res.status(404).send({
          message: `User with username: ${uname} not found.`,
        });
      }
      res.send({ message: 'Update successful.', user: data });
    })
    .catch(err => {
      res.status(500).send({
        message: 'Error updating user with username: ' + uname,
        error: err.message, // Include the error message for debugging
      });
    });
};

//DELETE
exports.delete = (req, res) => {
  const id = req.params.id;

  userModel
    .findByIdAndRemove(id)
    .then(data => {
      if (!data) {
        res.status(404).send({
          message: `Cannot delete user with id: ${id}`,
        });
      } else {
        res.send({
          message: 'User deleted successfully.',
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: 'Unable to delete.',
      });
    });
};
