//associated with the answers that users give when doing modules

const db = require('../models');
const answerModel = db.answers;

//CREATE
exports.createAnswer = (req, res) => {
  if (!req.body) {
    res.status(400).send({ message: 'Cannot save answer: empty body.' });
    return;
  }

  //new entry based on model
  //todo: change the response object to be empty and add moduleComplete:false or something
  const entry = new answerModel({
    course: req.body.data.course,
    topic: req.body.data.topic,
    moduleId: req.body.data.moduleId,
    userId: req.body.data.userId,
    response: {
      pages: req.body.data.response.pageNumber,
      question: req.body.data.response.question,
      answer: req.body.data.response.answer,
    },
  });

  //save user's module answers

  entry
    .save(entry)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error when creating new entry.',
      });
    });
};

//get unanswered/not completed modules

exports.getIncomplete = (req, res) => {
  const modId = req.params.moduleId;

  answerModel
    .find({ moduleId: modId, moduleComplete: false })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.send(err);
    });
};

exports.getComplete = (req, res) => {
  const modId = req.params.moduleId;

  answerModel
    .find({ moduleId: modId, moduleComplete: true })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.send(err);
    });
};

//FIND MODULEID + USERID

exports.findByModuleAndUser = (req, res) => {
  const modId = req.params.moduleId;
  const uId = req.params.userId;

  answerModel
    .find({ moduleId: modId, userId: uId })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.send(null);
    });
};

//FIND ACTIVE MODULEID + USERID

exports.findActiveByModuleAndUser = (req, res) => {
  const modId = req.params.moduleId;
  const uId = req.params.userId;

  answerModel
    .find({ moduleId: modId, userId: uId, moduleComplete: false })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.send(null);
    });
};

exports.findResponseByModuleAndUserAndQuestion = (req, res) => {
  const modId = req.params.moduleId;
  const uId = req.params.userId;
  const question = req.params.question;

  const query = {
    moduleId: modId,
    userId: uId,
    [`response.question`]: { $regex: new RegExp(question, 'i') },
  };

  answerModel
    .find(query)
    .sort({ createdAt: -1 })
    .limit(1)
    .then(data => {
      if (data && data.length > 0) {
        res.send(data[0]);
      } else {
        res.status(404).send('No response found');
      }
    })
    .catch(err => {
      res.status(500).send({ message: 'Error retrieving response' });
    });
};

//FIND ALL
exports.findAll = (req, res) => {
  //removed username to find all users
  //const username = req.query.username;

  //can be .find(username) to find with only that parameter
  answerModel
    .find()
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.send(null);
    });
};

exports.findModule = (req, res) => {
  const id = req.params.id;
  answerModel
    .findById(id)
    .then(data => {
      if (data) {
        res.send(data);
      } else {
        res.status(404).send({ message: 'Cannot find with oid credentials' });
      }
    })
    .catch(err => {
      res.status(500).send({ message: 'Error retrieving oid ' + id });
    });
};

//FIND ANSWERS BY USERID
//I'M NOT SCREAMING

exports.findUserAnswers = (req, res) => {
  const uId = req.params.id;

  answerModel
    .find({ userId: uId })
    .then(data => {
      if (!data) {
        res.status(404).send({ message: 'Cannot find with oid credentials' });
      } else {
        res.send(data);
      }
    })
    .catch(err => {
      res.status(500).send({ message: 'Error retrieving by userId: ', uId });
    });
};

//FIND ONE
exports.findOne = (req, res) => {
  const id = req.params.id;

  answerModel
    .findById(id)
    .then(data => {
      if (data) {
        res.status(404).send({ message: 'Cannot find with oid credentials' });
      } else {
        res.send(data);
      }
    })
    .catch(err => {
      res.status(500).send({ message: 'Error retrieving oid ' + id });
    });
};

//UPDATE ANSWER
exports.updateAnswer = (req, res) => {
  if (!req.body) {
    return res.status(400).send({
      message: "Update data can't be empty.",
    });
  }
  console.log('updateAnswer req body: ', req.body);

  const modId = req.body.moduleId;
  const uId = req.body.userId;
  const userInput = req.body.data;

  console.log('user input in updateAnswer: ', userInput);

  answerModel
    .updateOne({ moduleId: modId, userId: uId }, userInput, { useFindAndModify: false })
    .then(data => {
      if (!data) {
        res.status(404).send({
          message: `answer with moduleId: ${modId} and userId: ${uId} not found.`,
        });
      } else {
        res.send({ message: 'Update successful.' });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: 'Error updating: ' + uId + ' ' + modId,
      });
    });
};

//DELETE
exports.delete = (req, res) => {
  const id = req.params.id;

  answerModel
    .findByIdAndRemove(id)
    .then(data => {
      if (!data) {
        res.status(404).send({
          message: `Cannot delete user with id: ${id}`,
        });
      } else {
        res.send({
          message: 'User deleted successfully.',
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: 'Unable to delete.',
      });
    });
};
