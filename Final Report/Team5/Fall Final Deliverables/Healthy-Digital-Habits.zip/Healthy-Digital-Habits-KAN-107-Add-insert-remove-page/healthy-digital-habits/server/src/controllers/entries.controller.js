//actions associated with entries object

const db = require('../models');
const entryModel = db.entries;

//CREATE
exports.create = (req, res) => {
  if (!req.body) {
    res.status(400).send({ message: 'Empty body.' });
    return;
  }
  const entry = new entryModel({
    mood: {
      Focus: req.body.Focus,
      Control: req.body.Control,
      Empowerment: req.body.Empowerment,
      Guilt: req.body.Guilt,
    },
    ability: req.body.ability,
    story: req.body.story,
    uname: req.body.uname,
  });

  entry
    .save(entry)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error when creating new entry.',
      });
    });
};

//FIND ALL
exports.findAll = (req, res) => {
  const uname = req.query.uname;
  const { startDate, endDate } = req.query;

  let query = { uname: uname };

  if (startDate && endDate) {
    query.createdAt = {
      $gte: new Date(startDate),
      $lte: new Date(endDate),
    };
  }

  entryModel
    .find(query)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error when fetching.',
      });
    });
};

//UPDATE
exports.update = (req, res) => {
  if (!req.body) {
    return res.status(400).send({
      message: "Update data can't be empty.",
    });
  }

  const id = req.params.id;

  entryModel
    .findByIdAndupdate(id, req.body, { useFindAndModify: false })
    .then(data => {
      if (!data) {
        res.status(404).send({
          message: `user with id: ${id} not found.`,
        });
      } else {
        res.send({ message: 'Update successful.' });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: 'Error updating, id: ' + id,
      });
    });
};

//DELETE
exports.delete = (req, res) => {
  const id = req.params.id;

  entryModel
    .findByIdAndRemove(id)
    .then(data => {
      if (!data) {
        res.status(404).send({
          message: `Cannot delete user with id: ${id}`,
        });
      } else {
        res.send({
          message: 'User deleted successfully.',
        });
      }
    })
    .catch(err => {
      res.status(500).send({
        message: 'Unable to delete.',
      });
    });
};
