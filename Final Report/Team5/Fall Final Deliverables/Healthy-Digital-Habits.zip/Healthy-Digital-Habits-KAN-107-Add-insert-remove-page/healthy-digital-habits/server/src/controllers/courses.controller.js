const db = require('../models');
const coursesModel = db.courses;

// 1. Create a new course
exports.createCourse = (req, res) => {
  const { title, topics, image, hidden } = req.body;

  if (!title || !image) {
    return res.status(400).send({
      message: 'Title and image are required to create a course.',
    });
  }

  // Ensure topics is always an array
  const topicArray = Array.isArray(topics) ? topics : [];

  // Check if a course with this title already exists
  coursesModel
    .findOne({ title })
    .then(existingCourse => {
      if (existingCourse) {
        return res.status(400).send({
          message: `A course with the title "${title}" already exists.`,
        });
      }

      // Create the new course
      const newCourse = new coursesModel({
        title,
        topics: topicArray,
        image,
        //false if value is undefined
        hidden: hidden || false,
      });

      newCourse
        .save()
        .then(data => {
          res.send({
            message: 'Course created successfully',
            course: data,
          });
        })
        .catch(err => {
          res.status(500).send({
            message: err.message || 'Error creating course.',
          });
        });
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error checking for existing course.',
      });
    });
};

// 2. Add a module to an existing topic
exports.addTopicToCourse = (req, res) => {
  const { title, topics, newName, image } = req.body;

  // Build update object dynamically
  let updateFields = { topics, image };
  if (newName) {
    updateFields.title = newName; // Update title if newName is provided
  }

  // Find the course by title and update it
  coursesModel
    .findOneAndUpdate(
      { title }, // Find course by current title
      { $set: updateFields }, // Apply updates
      { new: true } // Return the updated document
    )
    .then(data => {
      if (!data) {
        return res.status(404).send({
          message: `Course with title ${title} not found.`,
        });
      }
      res.status(200).send({
        message: 'Course updated successfully',
        course: data,
      });
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error updating course.',
      });
    });
};

exports.removeTopicFromCourse = (req, res) => {
  const { title, topicId } = req.body; // Expecting a single moduleId in the request body

  // Find the topic and update it by removing the specified moduleId from the modules array
  coursesModel
    .findOneAndUpdate(
      { title }, // Find the topic by its title
      { $pull: { topics: topicId } }, // Remove the single moduleId from the modules array
      { new: true } // Return the updated document
    )
    .then(data => {
      if (!data) {
        // Only send response once if the topic or module is not found
        return res.status(404).send({
          message: `Topic with ID ${moduleId} not found in the course.`,
        });
      }
      // Send success response if the topic is found and updated
      res.status(200).send({
        message: 'Topic removed successfully',
        course: data,
      });
    })
    .catch(err => {
      // Only send error response once
      res.status(500).send({
        message: err.message || 'Error removing topic.',
      });
    });
};

// 3. Delete a topic
exports.deleteCourse = (req, res) => {
  const { title } = req.query; // Extract from query string

  coursesModel
    .findOneAndDelete({ title })
    .then(result => {
      if (!result) {
        return res.status(404).send({
          message: 'Course not found',
        });
      }

      res.send({
        message: 'Course deleted successfully',
      });
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error deleting course.',
      });
    });
};

// 4. Get all topics
exports.getCourses = (req, res) => {
  coursesModel
    .find()
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error when fetching courses.',
      });
    });
};

exports.getCourseTopics = (req, res) => {
  const { course } = req.query;
  coursesModel
    .findOne({ title: course })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error when fetching courses.',
      });
    });
};

exports.toggleHidden = async (req, res) => {
  try {
    const { id } = req.params;
    const { hidden } = req.body;

    const updated = await coursesModel.findByIdAndUpdate(id, { hidden }, { new: true });

    if (!updated) {
      return res.status(404).send({ message: 'Course not found' });
    }

    res.send({ message: 'Visibility updated', course: updated });
  } catch (error) {
    res.status(500).send({ message: error.message });
  }
};
