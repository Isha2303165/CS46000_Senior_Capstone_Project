/** New user register model */
module.exports = mongoose => {
  const userModel = mongoose.model(
    'user',
    mongoose.Schema(
      {
        uname: String,
        upass: String,
        email: String,
        fname: String,
        lname: String,
        ph: String,
        secq: String,
        seca: String,
        type: String,
        module: {
          module: String,
          curpage: Number,
          curprogress: Number,
        },
      },
      { timestamps: true }
    )
  );

  return userModel;
};
