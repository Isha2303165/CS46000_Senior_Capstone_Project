module.exports = mongoose => {
  const coursesModel = mongoose.model(
    'courses',
    mongoose.Schema(
      {
        title: String,
        topics: Array,
        image: String,
        hidden: Boolean,
      },
      { timestamps: true }
    )
  );

  return coursesModel;
};
