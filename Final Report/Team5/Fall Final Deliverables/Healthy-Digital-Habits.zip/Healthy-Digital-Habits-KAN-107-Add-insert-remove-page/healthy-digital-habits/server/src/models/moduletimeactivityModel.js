module.exports = mongoose => {
  const moduletimeactivityModel = mongoose.model(
    'moduletimeactivities',
    mongoose.Schema(
      {
        uname: String,
        module: String,
        date: Date,
      },
      { timestamps: true }
    )
  );

  return moduletimeactivityModel;
};
