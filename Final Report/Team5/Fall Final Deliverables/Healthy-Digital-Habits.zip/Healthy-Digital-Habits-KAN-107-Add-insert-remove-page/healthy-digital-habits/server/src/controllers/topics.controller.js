const db = require('../models');
const topicsModel = db.topics;
const coursesModel = db.courses;

// 1. Create a new topic
exports.createTopic = (req, res) => {
  const { title, modules } = req.body; // Extract title and modules from request body

  // Check if modules is an array, if not set it as an empty array
  const moduleArray = Array.isArray(modules) ? modules : [];

  const newTopic = new topicsModel({
    title, // Set title as the main property
    modules: moduleArray, // Add the array of modules
  });

  newTopic
    .save()
    .then(data => {
      res.send({
        message: 'Topic created successfully',
        topic: data,
      });
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error creating topic.',
      });
    });
};

// 2. Add a module to an existing topic
exports.addModuleToTopic = async (req, res) => {
  const { title, newName, modules } = req.body;

  try {
    // Build update object dynamically
    let updateFields = { modules };
    if (newName) {
      updateFields.title = newName; // Update title if newName is provided
    }

    // Find and update the topic
    const updatedTopic = await topicsModel.findOneAndUpdate(
      { title }, // Find topic by current title
      { $set: updateFields }, // Apply updates
      { new: true } // Return the updated document
    );

    if (!updatedTopic) {
      return res.status(404).send({
        message: `Topic with title ${title} not found.`,
      });
    }

    // If newName is provided, update all course references to the old topic title
    if (newName) {
      await coursesModel.updateMany(
        { topics: title }, // Find courses containing the old topic title
        { $set: { 'topics.$': newName } } // Update matching topics in the array
      );
    }

    res.status(200).send({
      message: 'Topic and related courses updated successfully',
      topic: updatedTopic,
    });
  } catch (err) {
    res.status(500).send({
      message: err.message || 'Error updating topic and courses.',
    });
  }
};

exports.removeModuleFromTopic = (req, res) => {
  const { title, moduleId } = req.body; // Expecting a single moduleId in the request body

  // Find the topic and update it by removing the specified moduleId from the modules array
  topicsModel
    .findOneAndUpdate(
      { title }, // Find the topic by its title
      { $pull: { modules: moduleId } }, // Remove the single moduleId from the modules array
      { new: true } // Return the updated document
    )
    .then(data => {
      if (!data) {
        // Only send response once if the topic or module is not found
        return res.status(404).send({
          message: `Module with ID ${moduleId} not found in the topic.`,
        });
      }
      // Send success response if the topic is found and updated
      res.status(200).send({
        message: 'Module removed successfully',
        topic: data,
      });
    })
    .catch(err => {
      // Only send error response once
      res.status(500).send({
        message: err.message || 'Error removing module.',
      });
    });
};

// 3. Delete a topic
exports.deleteTopic = (req, res) => {
  const { title } = req.query; // Extract from query string

  topicsModel
    .findOneAndDelete({ title })
    .then(result => {
      if (!result) {
        return res.status(404).send({
          message: 'Topic not found',
        });
      }

      res.send({
        message: 'Topic deleted successfully',
      });
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error deleting topic.',
      });
    });
};

// 4. Get all topics
exports.getTopics = (req, res) => {
  topicsModel
    .find()
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error when fetching topics.',
      });
    });
};

exports.getTopicModules = (req, res) => {
  const { topic } = req.query;
  topicsModel
    .findOne({ title: topic })
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error when fetching topics.',
      });
    });
};
