const db = require('../models');
const moduletimeactivityModel = db.moduletimeactivity;

exports.createTime = (req, res) => {
  const { uname, module, time } = req.body;

  // Convert the time (hours) to a future date
  const currentTime = new Date();
  const futureTime = new Date(currentTime.getTime() + parseInt(time) * 60 * 60 * 1000);

  // Check if the uname and module combination already exists
  moduletimeactivityModel
    .findOne({ uname, module })
    .then(existingEntry => {
      if (existingEntry) {
        return res.status(400).send({
          message: 'Time entry for this uname and module already exists.',
        });
      }

      // If no entry exists, create a new one
      const newTimeEntry = new moduletimeactivityModel({
        uname,
        module,
        date: futureTime,
      });

      newTimeEntry
        .save()
        .then(data => {
          res.send({
            message: 'Time entry created successfully',
            data: data,
          });
        })
        .catch(err => {
          res.status(500).send({
            message: err.message || 'Error creating time entry.',
          });
        });
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error checking for existing time entry.',
      });
    });
};

exports.getTime = (req, res) => {
  const { uname, module } = req.query;

  // Find the entry with the given uname and module
  moduletimeactivityModel
    .findOne({ uname, module })
    .then(entry => {
      if (!entry) {
        return res.status(404).send({
          message: 'No time entry found for the given uname and module.',
          uname,
          module,
        });
      }

      // Return the date of the found entry
      res.send({
        uname: entry.uname,
        module: entry.module,
        date: entry.date,
      });
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error retrieving time entry.',
      });
    });
};

exports.deleteTime = (req, res) => {
  const { uname, module } = req.body;

  moduletimeactivityModel
    .findOneAndDelete({ uname, module })
    .then(deletedEntry => {
      if (!deletedEntry) {
        return res.status(404).send({
          message: `No time entry found for uname ${uname} and module ${module}`,
        });
      }
      res.send({
        message: 'Time entry deleted successfully',
      });
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || 'Error deleting time entry.',
      });
    });
};
