module.exports = app => {
  const users = require('../controllers/users.controller.js');
  const entries = require('../controllers/entries.controller.js');
  const modules = require('../controllers/modules.controller.js');
  const answers = require('../controllers/answers.controller.js');
  const logins = require('../controllers/logins.controller.js');
  const topics = require('../controllers/topics.controller.js');
  const courses = require('../controllers/courses.controller.js');
  const moduletimeactivity = require('../controllers/moduletimeactivity.controller.js');

  //use Express
  let router = require('express').Router();

  //links below are basically "/api/*", following the link on port 5200 will give you the request
  //also, node server needs to be reset for changes to take place

  /* Users */
  //GET
  router.get('/user', users.findUser);
  router.get('/user/all', users.findAllUsers);
  router.get('/login', users.login);
  router.get('/user/modulestring', users.moduleToString);
  router.get('/user/moduleid', users.moduleToId);
  router.get('/user/currentpage', users.getCurrentPage);
  router.get('/user/currentprogress', users.getCurrentProgress);
  //NEW
  router.post('/register', users.create);
  //UPDATE
  router.put('/user/admin', users.makeAdmin);
  router.put('/user/parent', users.makeParent);
  router.put('/user/update', users.update);
  router.put('/user/username', users.updateUsername);
  router.put('/user/password', users.updatePassword);
  router.put('/user/module', users.updateModule);
  router.put('/user/currentpage', users.updateCurrentPage);

  /* Modules */
  //GET
  router.get('/activitymodule', modules.findActivity);
  router.get('/user/modulecomplete', modules.getCompletedModule);
  router.get('/modulelength', modules.getModuleLength);
  router.get('/moduletitle', modules.getModuleTitle);
  router.get('/module', modules.findAll); //find all modules
  router.get('/oneModule/:moduleId', modules.findOne); //one module with moduleId
  router.get('/incomplete/:moduleId', answers.getIncomplete); //modules with (completed: false) [obsolete]
  router.get('/complete/:moduleId', answers.getComplete); //all modules with (completed: true) [obsolete]
  router.get('/moduleincomplete', modules.getIncompleteModule);
  router.get('/modulecomplete', modules.getCompleteModule);
  router.get('/module/progress/:moduleId/:userId', modules.getProgress);
  // POST
  router.post('/createmodule', modules.create);
  // PUT
  router.put('/moduleincomplete', modules.incompleteModule);
  router.put('/modulecomplete', modules.completeModule);
  console.log('Registering /api/module/updateTitle route');
  router.put('/module/update', modules.updateModule);
  router.put('/module/updateTitle', modules.updateTitle);
  router.put('/module/updateProgress/:id', modules.updateProgress);
  console.log('modules.updateTitle = ', modules.updateTitle);

  // DELETE
  router.delete('/module', modules.delete);

  router.put('/module/:id', modules.update);
  router.get('/module/:id', modules.findModule);

  /* Daily Surveys */
  //GET
  router.get('/dashboard', entries.findAll); //all daily survey responses
  //NEW
  router.post('/dashboard', entries.create); //new daily survey response

  /* Answers */
  //GET
  router.get('/allAnswers', answers.findAll); //all answers
  router.get('/userAnswers/:id', answers.findUserAnswers); //all by userId
  router.get('/allAnswers/:moduleId/:userId', answers.findByModuleAndUser); //all by moduleId, userId
  router.get('/answers/:moduleId/:userId', answers.findActiveByModuleAndUser); //all by moduleId, userId where moduleComplete: true
  router.get(
    '/answers/:moduleId/:userId/:question',
    answers.findResponseByModuleAndUserAndQuestion
  );
  //NEW
  router.post('/answer', answers.createAnswer); //new answer given by user
  //UPDATE
  router.put('/answer', answers.updateAnswer); //update answer

  /* Logins */
  // GET
  router.get('/user/logins', logins.findAll);
  router.get('/user/loginsSum', logins.findUserLoginsSum);
  // PUT
  router.post('/user/logins', logins.create);

  // Topics
  // GET
  router.get('/topics/all', topics.getTopics);
  router.get('/topics/oneTopic', topics.getTopicModules);
  // POST
  router.post('/topics/create', topics.createTopic);
  // PUT
  router.put('/topics/addModule', topics.addModuleToTopic);
  router.put('/topics/removeModule', topics.removeModuleFromTopic);
  // DELETE
  router.delete('/topics/delete', topics.deleteTopic);

  // Courses
  // GET
  router.get('/courses/all', courses.getCourses);
  router.get('/courses/oneCourse', courses.getCourseTopics);
  // POST
  router.post('/courses/create', courses.createCourse);
  // PUT
  router.put('/courses/addTopic', courses.addTopicToCourse);
  router.put('/courses/removeTopic', courses.removeTopicFromCourse);
  router.put('/courses/toggle-hidden/:id', courses.toggleHidden);
  // DELETE
  router.delete('/courses/delete', courses.deleteCourse);

  // Module Time Activity
  // GET
  router.get('/time', moduletimeactivity.getTime);
  // POST
  router.post('/time/create', moduletimeactivity.createTime);
  // DELETE
  router.delete('/time/delete', moduletimeactivity.deleteTime);

  /* BASE ROUTE */
  app.use('/api', router);
};
