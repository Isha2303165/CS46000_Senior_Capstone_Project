require('dotenv').config();
//provides database URL with user credentials
module.exports = {
  url: process.env.DB_URL,
};
