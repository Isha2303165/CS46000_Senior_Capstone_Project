//ties together the other models

const dbConfig = require('../config/db.config.js');

const mongoose = require('mongoose');
mongoose.Promise = global.Promise;

const db = {};
db.mongoose = mongoose;
db.url = dbConfig.url;
db.users = require('./userModel.js')(mongoose);
db.entries = require('./entryModel.js')(mongoose);
db.modules = require('./moduleModel.js')(mongoose);
db.answers = require('./answerModel.js')(mongoose);
db.logins = require('./loginsModel.js')(mongoose);
db.topics = require('./topicsModel.js')(mongoose);
db.courses = require('./coursesModel.js')(mongoose);
db.moduletimeactivity = require('./moduletimeactivityModel.js')(mongoose);

module.exports = db;
