/** User entry model */
module.exports = mongoose => {
  const answerModel = mongoose.model(
    'answer',
    mongoose.Schema(
      {
        course: String,
        topic: String,
        moduleId: String,
        userId: String,
        moduleComplete: Boolean,
        response: {
          pages: String,
          question: String,
          answer: String,
          pageComplete: Boolean,
        },
      },
      { timestamps: true }
    )
  );

  return answerModel;
};
