const db = require('../models');
const loginsModel = db.logins;

//CREATE - Record login once per user per day
exports.create = async (req, res) => {
  try {
    // Get the 'uname' query parameter from the request
    const uname = req.query.uname;

    if (!uname) {
      return res.status(400).send({ message: 'Username (uname) is required' });
    }

    // Calculate today's start and end times (midnight to midnight)
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(startOfDay);
    endOfDay.setDate(endOfDay.getDate() + 1);

    // Check if this user already has a login entry for today
    const existingLogin = await loginsModel.findOne({
      uname,
      createdAt: {
        $gte: startOfDay,
        $lt: endOfDay,
      },
    });

    if (existingLogin) {
      // Already logged in today - don't duplicate
      return res.status(200).send({
        message: 'User has already logged in today',
        user: existingLogin,
      });
    }

    // Otherwise, record the new login
    const newLogin = new loginsModel({ uname });
    await newLogin.save();

    res.status(201).send({
      message: 'Login recorded (unique for today)',
      user: newLogin,
    });
  } catch (error) {
    res.status(500).send({
      message: 'Error recording login',
      error: error.message,
    });
  }
};

//Find All
exports.findAll = async (req, res) => {
  try {
    // Get the 'days' query parameter from the request
    const days = parseInt(req.query.days);

    if (isNaN(days)) {
      return res.status(400).send({ message: 'Invalid days parameter' });
    }

    // Calculate the timestamp for `days` back
    const now = Date.now();
    const daysBackTimestamp = now - days * 24 * 60 * 60 * 1000;

    // Use Mongoose .find() to filter records where createdAt is between daysBackTimestamp and now
    const filteredRecords = await loginsModel.find({
      createdAt: {
        $gte: new Date(daysBackTimestamp), // Greater than or equal to days back timestamp
        $lte: new Date(now), // Less than or equal to current time
      },
    });

    // Send the count and filtered records
    res.status(200).send({
      count: filteredRecords.length,
      records: filteredRecords,
    });
  } catch (error) {
    res.status(500).send({
      message: 'Error retrieving records',
      error: error.message,
    });
  }
};

// Calculate sum of logins for one user
exports.findUserLoginsSum = async (req, res) => {
  try {
    const uname = req.query.uname;
    const filteredRecords = await loginsModel.find({
      uname: uname,
    });

    // Send the count and filtered records
    res.status(200).send({
      count: filteredRecords.length,
      records: filteredRecords,
    });
  } catch (error) {
    res.status(500).send({
      message: 'Error retrieving records',
      error: error.message,
    });
  }
};
