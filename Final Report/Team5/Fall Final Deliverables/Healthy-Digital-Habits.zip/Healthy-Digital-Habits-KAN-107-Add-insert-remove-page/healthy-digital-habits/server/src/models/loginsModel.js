/** Logins model */
module.exports = mongoose => {
  const loginsModel = mongoose.model(
    'logins',
    mongoose.Schema(
      {
        uname: String,
      },
      { timestamps: true }
    )
  );

  return loginsModel;
};
